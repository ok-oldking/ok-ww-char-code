"""心锁守轮切轴；心须使用同奏模态。所有执行逻辑在此文件内。"""

import base64
import re
import time

import cv2
import numpy as np

from src.Labels import Labels
from src.char.BaseChar import SwitchPriority
from src.char.Hsin import Hsin as NativeHsin


class AxisUnconfirmed(RuntimeError):
    pass


class AxisDesync(AxisUnconfirmed):
    pass


class AxisControlled(AxisUnconfirmed):
    pass


class AxisResourcePending(AxisUnconfirmed):
    pass


class Hsin(NativeHsin):
    AXIS_VERSION = "0.3.8"
    TEAM = {"Hsin", "Suoming", "ShoreKeeper"}
    PHASE_CHAR = {
        "shore": "ShoreKeeper", "lock_r": "Suoming",
        "heart_r1": "Hsin", "lock_forte": "Suoming", "heart_r2": "Hsin",
    }
    NEXT = {
        "shore": "lock_r", "lock_r": "heart_r1", "heart_r1": "lock_forte",
        "lock_forte": "heart_r2", "heart_r2": "shore",
    }
    # 用户装备轻云出月：R 后 Q；同奏套才改为 True。
    SUOMING_Q_BEFORE_R = False
    # 入场动画占用原1.05s窗口的一部分；延后闪避，避免打断尚未出手的A2。
    # 这是待实机标定的时序候选，不作为已识别到A2的证据。
    HSIN_A12_TIME = 1.65
    SUOMING_HEAVY_MIN = 2.8
    SUOMING_HEAVY_MAX = 8.0
    # 只缩短状态轮询；普攻/补发的输入间隔仍各自受限。
    POLL = 0.04
    TARGET_SECONDS = 120.0
    TARGET_R2 = 4
    # 来自00:24:04实机念深E图标；只比较上下刀刃，避开中央冷却数字。
    _DEEP_E_PNG = "iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAAAAABWqveYAAAJJ0lEQVRIDXXBC5iVAx7H8e//nDPnMnOmq2oazUYbRe49MmcKtWwz01ZClErsIiGVJFQ2a9fYJOXSU+kuuSSSpEJ5rGXpaRERUqhUmi7TzJnbuby/fd8zU+wun4+VAiY5currAIFAJiDauduh93/0AaKB5KSTvkR9Gl9WMJTlx0rxmJOOpwQIEKKBdRrc+p1P9qTFMZKTRvXJNL6sYNBvpbhMqbgcCQECFGybW3MknjRf0yGlqdX/OFBLA4Ec8yUSScf8gSwrxVNfJ+RIAgQIcm/rz9ol+9NmnSd1SK1fvistXAKkSDKRSMt8VgqymgQm5EgCAcKV+3R7VS9fXGe+6LWDAp/fTIYAkeMkk6m0rASoTQAm5EhCF07IqY5X7m7RpmUroGbL1H1mzecWbLvRwSNclqN0KpW2EqitBwOTcKQTxl8Y5L+kNj3+nZ24OLr1jjgukdEEJ522EiVqcRkehwFjw/yfxKhP7Yy5vm3jKgCRYblIVuxUCTAMV9tJ5/FLEqM/sUsfsO1jD4tjAjnIio+KDDMCI4bxKxKjPrXrRvh233SUrKTICIWxHimEx+g4O4qza8XoII0cXGZ4EgMP2CPdOTikqus3FTTI9VkhiIzphf7kyiVH000W5ePasO7ruO+8TYEmF/Q7DVfVkHL/vNMpv6Z6zl2VZFgTK8QlGHBL0w9f+qwSRHRi9w0vfRMXBPq9DKYW591wKlQMORyd05GKG8NjRouMiBXiKZjUft2bXwrDpWCb74Uksq5/CgQEzhnThYqBVe2WZhMfMOmHWSLDCoHAwIvWv12FDIwC5wcJCYmssQ9LZISuvZUBe+2ZU0j+ruWSyZuFxwqhQ58N2wxXs7q6yMBe95QLgSSCU+4VCDDRdfqYrb7HCtn2J/7cZUgKjxUSrXFwGXlPrtr89/23J0EIhIIzRgoQGdHz37FJA3hmFvPOWDoLj8UQHqP9gjDsGu4IlwQovPQKCRAeA7v5Jq7/KrwuVH0JHovRaNAoP/wwrB4MlxC0Wtw3KdFIGH3/ki6OF86E5TMEWIwM34T+QN0N34LMcAlZlydLahyJRiYumlH3+8TIP0KyuAawGJ7II+fiWjIXBGaYEFw4taRCjgSGDNA5C+KXOk9cAIz9ALAYrnbTC3AdvrpWgCyUwIQYelv/csmRCCVkuE5a8d1VrM4D3rkbsBhw4qIonqmryFB20wMg+SYWD/tOSP6CHYBh4vEjU9q9gqu2d1JYDHi6I57UZUdo1Dr6vURw+tkT3kf4e76dEC6DLqetuGIinr4HhRWJk5YZnjVl4pjOrd6D6IITZy0T4cHP1jkSHovkHJx9Pp7hXxlWhF4omNN8EHD7R+K4Xs02xC+e0HTFsh87d10Zx5EEyAxWFuApPmJmMct/7qvRrIrC4N3iuEDf8J6OI/hobV3+vz8X8iDAeDcb18LZZi0tZst+M2hvyX1QU5oSP2nZWz3PIv1i+cE3hRCOhICzFuNKXVpNcKgV5S1/cL1/7mmwYzjiuECnM8+PAdWvfrO5XAgkBwnuvQrXO3fKhm63ornpUU7RNGDjfSb8/oA/EAzln3By6zNbkbFlT/m3+w4nkulEOplCtrYVkCg+ah3uGGP33zkxxz+sM3Dgm9zcZoEc41fVJGuq4rWFfmD/9PrKe17eZB/M307bZw1YNdvICURbtclu3aZVdm6OjwZK11Ydqt29O15eVVGfSPtWR4Brt2vcSbdjK6fBjG64xn2IR4AFg816tOkfxrXt/V2f1NYnESCh4Fth+HIoZ80ZvRnrVU9oTQTQgHIaCJdF+uUODcPH/9z3Lg5CIISy14Vh8trA+p03p7EiGH85Lqd3DY0E2PmnJvMGc+AFX2pttYQEAtFkvY89VzLzguu+QBYj9HoE1w+DHH6m7SU7t/S71ffGqn3dWWWSEAJZ38mw4b4LZuwYkhIW4/K78Dy1xJfmuEj/9/aQ/1jb5+emAt31LkJCCFvQBdhytoZ+BViMwaNxOaXxYc+IRoErXq0Tkdmn3P8Wxun1O4UQgpZryPixryOwGLmv+4F4MXOnbaeBv+vHKRwCD/YYuRWDNr69gIToMwWP+u0XYDFsQxjYN5AV708nw1ofSuG5ZdjAfWAQoQYhCKxujis9dyECLAbrmgBrynzrKwbiMRAZ/e/pe0Q0EAj6T8R1tGyjEGAxGH+5wfh/5S+v753CYwiPdZteUi0aCEGLRW2AXfdsRyCwGDRZFaLuD3W9p9DvED9n7WcPSAiXACF/WU9g67gjooHFgJnd2HUNk0u5/msZP7GWTw5LC5cAoRE3gDbcX49oYDGgxWtsHsOSjozdRCMTGOFZN0q4BIK+k77NDz/6vBAYCCyG646rZr7I6haUvWaLJhwADGRYaMq9CJdAXH3T+M8GbdkKEjQ/fVNKWBGIwEsvP21vZPPUYib3nLHGaGDB8Q8iXALf1dkvVCIwkXVh8dIvHJAV4Tn3gSv96wKsmsqQUbwx+wAZlnXDbAQIBEICrO1lvT6cX4kAKyJjRN60p/OpGLk7Or+A+OI3DuMJXPUsAnRqt1eqcHBlde3f88uHt5Hht5iBge+hsvqFv2H/8Orm89pCeu3qvUcd/BdtRL7W7a87i2/H/ehAXo/hefFnFpjIiFqRzHDZo3eE55/ErqFO80Wt8Ozfsv3gyXvyOnVpjqdm5I7Wd/aQs2NENY1CIetdhRkGCiX8C37rfDbKyV8a5hc4iZBRPfEDh0a+KFZaV4dhBoLQI+ewZB4nzw/zy56bX8lxuYaVqjaBYQYCe+Ic/raODvNC/IId0z4SMjIsEgArRVUOhpGhqT2S935gHR/K438o+cTKBOKYYERgpaBKgWGAoOziqtt2KjzgihNp4DgBwNn0yC4QxwQjAqzEQJXCZYaAsov33L03AX2G5/uMhZ/srW93cqf819fgEo2yInisVBiqcnAZGXf3Dh7968cJlHff6VmJ8R85SCaExwRYKCQ8VoLLFE/jMjJ8BVf3q9845zCKNrsklv3cxhpMwmN4QiGRYSV4jLo6wPAICIQG9ql4fqNAgWiqCkQDA1+2D+GRlZBhpKqF4REZdkLPM/as3itAiGPMn20gXMJKaGBQncIjMoRQy3Nztu1MIXGMRbJwCZf4D/DXZPiVSBoNAAAAAElFTkSuQmCC"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._axis_reset()

    def _axis_reset(self):
        self._axis_phase = "shore"
        self._axis_done = set()
        self._axis_failures = 0
        self._axis_unison = None
        self._axis_transformed = False
        self._axis_guard_until = 0.0
        self._axis_cd_fallback_logged = set()
        self._axis_cd_readings = {}
        self._axis_failure_shots = set()
        self._axis_control_next_check = 0.0
        self._axis_control_active = False
        self._axis_shore_heavies = 0
        self._axis_target_notice_at = 0.0
        self._axis_version_logged = False
        self._axis_break_next_check = 0.0
        self._axis_break_pending = False
        self._axis_phase_stamp = None
        self._axis_r2_stamp = None
        self._axis_start_stamp = None
        self._axis_counts = {"H1": 0, "R1": 0, "R2": 0}
        self._axis_hit_next_dodge = 0.0
        self._axis_hit_dodges = 0
        self._axis_lock_intro = False
        self._axis_deep_template = None
        self._axis_ring_geometry = None
        self._axis_deep_scaled = None

    def reset_state(self):
        super().reset_state()
        self._axis_reset()
        self.h2_completed = False
        self.h2_guard_until = 0.0

    def axis_enabled(self):
        return {c.name for c in self.task.chars if c is not None} == self.TEAM

    def _challenge_remaining(self):
        texts = self.task.ocr(0.43, 0.115, 0.57, 0.165)
        for text in texts:
            # 时钟图案可能被OCR读成前缀C；保留数字边界，拒绝日期等长数字。
            timer = re.search(r"(?<!\d)(\d{1,2}):(\d{2})[:.](\d{2})(?!\d)",
                              str(text.name).replace(" ", "").replace("：", ":"))
            if timer:
                minutes, seconds, fraction = map(int, timer.groups())
                if seconds < 60:
                    return minutes * 60 + seconds + fraction / 100
        return None

    def has_active_combat_evidence(self):
        # 仅正在战斗且丢锁时由框架查询；新鲜倒计时与队伍HUD共同证明挑战还在。
        ok, _, count = self.task.in_team()
        if not self.axis_enabled() or not ok or count != 3:
            return False
        remaining = self._challenge_remaining()
        if remaining is None or remaining <= 0:
            return False
        if time.time() >= self._axis_target_notice_at:
            self._log(f"目标暂失但挑战倒计时{remaining:.2f}s与队伍HUD仍在，保留当前阶段检查点")
            self._axis_target_notice_at = time.time() + 2
        return True

    def _timing(self, tag, previous):
        now, remaining = time.time(), self._challenge_remaining()
        if previous:
            wall = now - previous[0]
            game = (f"{previous[1] - remaining:.2f}s"
                    if previous[1] is not None and remaining is not None and previous[1] >= remaining
                    else "缺少有效倒计时")
            self._log(f"轴长[{tag}]：现实{wall:.2f}s，游戏{game}")
        return now, remaining

    def axis_priority(self, char):
        return (SwitchPriority.MUST if char.name == self.PHASE_CHAR[self._axis_phase]
                else SwitchPriority.NO)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self.axis_enabled():
            return self.axis_priority(self)
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def skip_combat_check(self):
        return time.time() < self._axis_guard_until or super().skip_combat_check()

    def do_perform(self):
        if not self.axis_enabled():
            return super().do_perform()
        return self.axis_run(self)

    def _log(self, message):
        self.logger.info(f"[心锁守:{self._axis_phase}] {message}")

    def _hud(self, char):
        ok, index, count = self.task.in_team()
        if ok and index != char.index:
            raise AxisDesync(f"场上角色变为位置{index + 1}，预期{char.name}")
        return bool(ok and count == 3 and index == char.index)

    def _sync_current(self, char):
        ok, index, count = self.task.in_team()
        if not ok or count != 3 or index == char.index:
            return char
        actual = next(c for c in self.task.chars if c.index == index)
        self._wait_hud(actual, timeout=1)
        for teammate in self.task.chars:
            teammate.is_current_char = teammate is actual
        self._log(f"场上缓存已按连续HUD重对齐：{char.name}→{actual.name}，保留阶段检查点")
        return actual

    def _control_prompt(self):
        return bool(self.task.ocr(0.35, 0.21, 0.72, 0.30,
                                  match=re.compile(r"交替.*挣脱")))

    def _recover_control(self, char):
        if not self._axis_control_active and time.time() < self._axis_control_next_check:
            return 0.0
        self._axis_control_next_check = time.time() + 0.6
        if not self._axis_control_active and not self._control_prompt():
            return 0.0
        self._axis_control_active = True
        start = time.time()
        previous_guard = self._axis_guard_until
        self._axis_guard_until = max(previous_guard, start + 6)
        self._release(char)
        self._log("检测到交替挣脱提示，先交替A/D解控，保留技能检查点")
        gone = 0
        try:
            while time.time() - start < 6:
                self.task.next_frame()
                gone = 0 if self._control_prompt() else gone + 1
                if gone >= 2:
                    self._axis_control_active = False
                    elapsed = time.time() - start
                    self._log(f"挣脱提示连续消失，恢复原阶段；解控用时{elapsed:.2f}s")
                    return elapsed
                if not gone:
                    self.task.send_key('a', down_time=0.04)
                    self.task.send_key('d', down_time=0.04)
                char.sleep(0.1)
            raise AxisControlled("挣脱提示仍存在，保留当前阶段等待解控")
        finally:
            self._axis_guard_until = previous_guard
            self._axis_control_next_check = time.time() + 0.6

    def _break_prompt(self):
        # 不使用can_break缓存；必须是当前画面的可施放提示，排除拾取F。
        # 满谐度标记不等于当前距离已能执行；必须看见实际F键提示。
        return bool(self.task.find_one('f_break', box=self.task.box_of_screen(
                        0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True),
                        target_height=720, threshold=0.90) and not self.task.is_pick_f())

    def _maybe_break(self, char):
        pending = self._axis_break_pending
        if not pending:
            # 资源积累时插入F；同奏切人、H1/H2连段和锁暝长按期间不插入。
            safe = ((self._axis_phase == 'shore' and 'shore_r' not in self._axis_done)
                    or (self._axis_phase == 'lock_forte' and 'lock_forte_e' not in self._axis_done))
            if (not safe or self._axis_unison or time.time() < self._axis_guard_until
                    or time.time() < self._axis_break_next_check):
                return 0.0
            self._axis_break_next_check = time.time() + 0.4
            if not self._hud(char) or not self._break_prompt():
                return 0.0
            self.task.next_frame()
            if not self._hud(char) or not self._break_prompt():
                return 0.0
            if self._control_prompt():
                return 0.0
            self.task.screenshot('hsin_fbreak_before')
            self._log(f"谐度破坏：{char.name}资源段连续确认F，保留当前检查点")
        start = time.time()
        previous_skip = self.task.skip_combat_check
        self.task.skip_combat_check = True
        self._axis_break_pending = True
        self._release(char)
        sent, stable, hidden = 0, 0, False
        clock_last = self._challenge_remaining()
        frozen_since, saw_freeze, resumed = None, False, False
        try:
            if not pending:
                self.task.send_key('f', down_time=0.05)
                sent = 1
            while time.time() - start < 6:
                self.task.next_frame()
                hud = self._hud(char)
                hidden = hidden or not hud
                prompt = self._break_prompt() if hud else False
                remaining = self._challenge_remaining() if hud else None
                if remaining is not None and clock_last is not None:
                    if remaining < clock_last - 0.01:
                        resumed = saw_freeze
                        frozen_since = None
                    elif abs(remaining - clock_last) <= 0.01:
                        if frozen_since is None:
                            frozen_since = time.time()
                        elif time.time() - frozen_since >= 0.3:
                            saw_freeze, resumed = True, False
                if remaining is not None:
                    clock_last = remaining
                # F演出仍显示队伍HUD，不能把提示刚消失当作动画已经结束。
                # 有倒计时则等时停后恢复走时；未捕获时停时至少留2s恢复窗口。
                recovered = ((saw_freeze and resumed) or
                             (not saw_freeze and time.time() - start >= 2.0))
                stable = stable + 1 if hud and not prompt and recovered else 0
                if stable >= 2 and time.time() - start >= 1.0:
                    self._axis_break_pending = False
                    self.task.can_break = False
                    self._axis_break_next_check = time.time() + 1
                    self.task.screenshot('hsin_fbreak_after')
                    self._log(f"谐度破坏确认：F提示消耗、HUD恢复，发键{sent}次，"
                              f"现实{time.time() - start:.2f}s，曾隐藏HUD={hidden}，"
                              f"倒计时时停后恢复={saw_freeze and resumed}")
                    return time.time() - start
                if hud and prompt and sent == 1 and not hidden and time.time() - start >= 0.4:
                    self.task.send_key('f', down_time=0.05)
                    sent += 1
                char.sleep(self.POLL)
            self.task.screenshot('hsin_fbreak_unconfirmed')
            if self._hud(char):
                self._axis_break_pending = False
                self._axis_break_next_check = time.time() + 2
            raise AxisControlled("F提示消耗/HUD恢复未确认，保留原阶段")
        finally:
            self.task.skip_combat_check = previous_skip

    def _pause(self, char, started=None):
        # 检测和采帧已占用轮询时间时不再叠加40ms；sleep(0)仍清画面，下帧检查停止。
        char.sleep(self.POLL if started is None else max(0, self.POLL - (time.time() - started)))

    def _hp_snapshot(self):
        frame = getattr(self.task, 'frame', None)
        if frame is None:
            return None
        # 血条与数字一起保留；平时只算白色条面积，疑似掉血才调用OCR。
        box = self.task.box_of_screen(800 / 1920, 1027 / 1080,
                                      1102 / 1920, 1044 / 1080,
                                      hcenter=True, vcenter=True)
        crop = box.crop_frame(frame)
        if crop.size == 0 or crop.ndim != 3 or crop.shape[2] != 3:
            return None
        white = (crop.min(axis=2) >= 175) & (crop.max(axis=2) - crop.min(axis=2) <= 45)
        return float(white.mean()), crop.copy()

    def _hp_value(self, crop):
        texts = self.task.ocr(frame=crop, target_height=80)
        for text in texts:
            value = re.fullmatch(r'(\d{1,6})/(\d{1,6})',
                                 str(text.name).replace(' ', '').replace('／', '/'))
            if value:
                current, maximum = map(int, value.groups())
                if 0 < current <= maximum and maximum >= 1000:
                    return current, maximum
        return None

    def _arm_hit_recovery(self, char, tag, retry, ready=lambda: True):
        return dict(index=char.index, tag=tag, retry=retry, ready=ready,
                    hp=self._hp_snapshot(), candidate=0, used=False,
                    progress=False, retries=0)

    def _recover_hit(self, char, state, allow_guard=False):
        now = time.time()
        if state['used'] or state['progress']:
            return 0.0
        if (state['index'] != char.index or not self._hud(char)
                or self._axis_break_pending or self._axis_control_active):
            state['hp'], state['candidate'] = None, 0
            return 0.0
        sample = self._hp_snapshot()
        previous = state['hp']
        if (sample is None or previous is None or now < self._axis_hit_next_dodge
                or (not allow_guard and now < self._axis_guard_until)):
            state['hp'], state['candidate'] = sample, 0
            return 0.0
        if previous[0] - sample[0] < 0.012:
            state['hp'], state['candidate'] = sample, 0
            return 0.0
        state['candidate'] += 1
        if state['candidate'] < 2:
            return 0.0
        before, after = self._hp_value(previous[1]), self._hp_value(sample[1])
        state['hp'], state['candidate'] = sample, 0
        if (not before or not after or before[1] != after[1]
                or before[0] - after[0] < max(1, before[1] * 0.002)):
            return 0.0
        self.task.next_frame()
        if not self._hud(char) or not state['ready']():
            state['progress'] = True
            return 0.0
        # 抓取/禁锢优先走专门解控，不能用普通闪避替代交替A/D。
        if self._control_prompt():
            self._axis_control_next_check = 0.0
            elapsed = self._recover_control(char)
            state['hp'], state['candidate'] = self._hp_snapshot(), 0
            return elapsed
        started = time.time()
        char.check_combat()
        self._release(char)
        self.task.send_key(self.task.key_config.get('Dodge Key', 'lshift'), down_time=0.05)
        state['used'] = True
        self._axis_hit_next_dodge = time.time() + 1.0
        self._axis_hit_dodges += 1
        self._log(f"受击补救：{char.name}生命{before[0]}→{after[0]}/{after[1]}，"
                  f"{state['tag']}未确认，已松键并发送闪避")
        # 闪避后再看两帧：迟到CD/提示消耗、隐藏HUD、换人均禁止盲补。
        for _ in range(2):
            self.task.next_frame()
            if not self._hud(char) or not state['ready']():
                self._log('受击补救：原动作已有变化或HUD未恢复，停止补发，继续原确认')
                return time.time() - started
            char.check_combat()
        if state['retry'] is not None:
            state['retry']()
            state['retries'] += 1
            self._log(f"受击补救：仅补发当前未确认动作[{state['tag']}]，后续仍需画面确认")
        return time.time() - started

    def _wait(self, char, condition, timeout, tag, drive=None, recover=None, hold=0,
              allow_break=True, recover_guard=False):
        start = time.time()
        stable = 0
        stable_since = None
        last_drive = -1.0
        if recover is None and drive is not None:
            recover = self._arm_hit_recovery(char, tag, lambda: char.click(interval=0.12),
                                              lambda: not condition())
        while (char.time_elapsed_accounting_for_freeze(start) < timeout
               and time.time() - start < timeout * 2 + 8):
            tick = time.time()
            self.task.next_frame()
            if self._hud(char):
                protected = self._recover_control(char)
                start += protected
                char.check_combat()
                if drive and allow_break:
                    broken = self._maybe_break(char)
                    start += broken
                    protected += broken
                if recover is not None and protected:
                    recover['hp'], recover['candidate'] = self._hp_snapshot(), 0
                satisfied = bool(condition())
                stable = stable + 1 if satisfied else 0
                stable_since = (time.time() if stable_since is None else stable_since) if satisfied else None
                if recover is not None and satisfied:
                    recover['progress'] = True
                if stable >= 2 and time.time() - stable_since >= hold:
                    return
                if recover is not None and not satisfied:
                    recovered = self._recover_hit(char, recover, allow_guard=recover_guard)
                    if recovered:
                        start += recovered
                        last_drive = time.time()
                        self._pause(char, tick)
                        continue
                if drive and not stable and time.time() - last_drive >= 0.12:
                    drive()
                    last_drive = time.time()
            else:
                stable = 0
                stable_since = None
                if recover is not None:
                    recover['hp'], recover['candidate'] = None, 0
            self._pause(char, tick)
        raise AxisUnconfirmed(f"{tag}超时({timeout:.1f}s)")

    def _wait_hud(self, char, timeout=3):
        self._wait(char, lambda: True, timeout, "HUD恢复")

    def _ensure_hud(self, char):
        # 切人末尾/上一动作已做连续确认；这里仅刷新画面检查身份。
        # HUD隐藏才等待恢复，错位仍由_hud抛出，技能各自仍须连续确认。
        self.task.next_frame()
        if not self._hud(char):
            self._wait_hud(char)
        self._recover_control(char)
        char.check_combat()

    def _attack(self, char, duration, stop=None):
        start = time.time()
        recovery = self._arm_hit_recovery(char, '普攻连段', lambda: char.click(interval=0.12),
                                          lambda: not (stop and stop()))
        while (char.time_elapsed_accounting_for_freeze(start) < duration
               and time.time() - start < duration * 2 + 3):
            tick = time.time()
            self.task.next_frame()
            if self._hud(char):
                protected = self._recover_control(char) + self._maybe_break(char)
                start += protected
                if protected:
                    recovery['hp'], recovery['candidate'] = self._hp_snapshot(), 0
                char.check_combat()
                if stop and stop():
                    return
                if self._recover_hit(char, recovery):
                    continue
                char.click(interval=0.12)
            else:
                recovery['hp'], recovery['candidate'] = None, 0
            self._pause(char, tick)

    def _once(self, key, action):
        if key not in self._axis_done:
            action()
            self._axis_done.add(key)

    def _release(self, char):
        self.task.mouse_up()
        self.task.send_key_up(char.get_resonance_key())

    def _cd(self, name):
        native = max(0.0, self.task.get_cd(name))
        if native > 0.35:
            self._axis_cd_readings[name] = {"native": native}
            return native
        # 原生整行OCR只匹配带小数的数字。漏读时单独放大该技能区域，
        # 兼容整数倒计时；仍由调用方要求连续两帧和施放前后的变化。
        left, right = {"resonance": (0.82, 0.86), "echo": (0.86, 0.91),
                       "liberation": (0.91, 0.97)}[name]
        cd_x = self.task._cd_ocr_relative_x
        # 本机ONNX OCR要求H×W×3，保留框架默认的BGR三通道输入。
        texts = self.task.ocr(cd_x(left), 0.86, cd_x(right), 0.93,
                              target_height=2160)
        raw = [str(text.name).strip() for text in texts]
        values = []
        for text in raw:
            normalized = text.replace("．", ".")
            if re.fullmatch(r"\d{1,2}(?:\.\d{1,2})?", normalized):
                value = float(normalized)
                if 0.35 < value <= 60:
                    values.append(value)
        # 多个数字不猜哪个是冷却；保留原文供超时诊断。
        value = values[0] if len(values) == 1 else native
        self._axis_cd_readings[name] = {"native": native, "local": raw, "value": value}
        key = (self.task.get_current_char().index, name)
        if value > 0.35 and key not in self._axis_cd_fallback_logged:
            self._axis_cd_fallback_logged.add(key)
            self._log(f"{name}冷却局部OCR补识别：{value:.2f}s，原生={native:.2f}")
        return value

    def _failure_snapshot(self, char, error):
        self._log(f"确认诊断：角色={char.name}，HUD={self.task.in_team()}，"
                  f"实时协奏={self.task.get_current_con():.3f}，"
                  f"最近冷却读数={self._axis_cd_readings}，原因={error}")
        if self._axis_phase not in self._axis_failure_shots:
            self._axis_failure_shots.add(self._axis_phase)
            try:
                self.task.screenshot(f"hsin_axis_{self._axis_phase}_unconfirmed")
                self._log("已保存本阶段首次确认失败截图（screenshots目录）")
            except Exception as shot_error:
                self._log(f"保存确认失败截图失败：{shot_error}")

    def _cast_cd(self, char, name, tag, optional=False):
        samples = []

        def baseline():
            samples.append(self._cd(name))
            return len(samples) == 1 or ((samples[-1] > 0.35) == (samples[-2] > 0.35))

        # 首帧作为候选，交由_wait确认连续两帧一致；HUD中断仍会清空稳定计数。
        self._wait(char, baseline, 1.2, f"{tag}冷却基线")
        if samples[-1] > 0.35:
            if optional:
                self._log(f"{tag}已有冷却，跳过本次释放")
                return False
            raise AxisUnconfirmed(f"{tag}已有冷却，不能算作本次施放成功")
        send = char.send_resonance_key if name == "resonance" else char.send_echo_key
        tail_e = (char is self and name == 'resonance' and self._axis_phase == 'heart_r2'
                  and 'heart_r2' in self._axis_done)
        lock_q = (char.name == 'Suoming' and name == 'echo' and self._axis_phase == 'lock_r'
                  and 'lock_r' in self._axis_done and self._axis_unison
                  and self._axis_unison[0] == char.name
                  and char.time_elapsed_accounting_for_freeze(self._axis_unison[1]) < 4.5)
        # 一套确认循环处理普通两次施放、锁R后Q、R2后E；候选CD出现即停键。
        retry_interval = .65 if name == 'echo' else 1.5
        max_sends, timeout = 2, retry_interval + 1.5
        if tail_e:
            retry_interval, max_sends, timeout = .4, 10, 4
        elif lock_q:
            retry_interval, max_sends, timeout = .25, 6, 2.2
        hit_extra = not (tail_e or lock_q)  # 普通两次之外保留原有的一次受击补发。
        sent, last_send, cd_seen = 0, -1.0, False

        def send_pending(force=False):
            nonlocal sent, last_send
            limit = max_sends + (recovery['retries'] + int(force) if hit_extra else 0)
            if not cd_seen and sent < limit and (force or time.time() - last_send >= retry_interval):
                send()
                sent += 1
                last_send = time.time()

        def new_cd():
            nonlocal cd_seen
            value = self._cd(name) > 0.35
            cd_seen = cd_seen or value
            return value

        recovery = self._arm_hit_recovery(char, tag, lambda: send_pending(force=True),
                                          lambda: not cd_seen and sent < max_sends + int(hit_extra) and self._cd(name) <= 0.35)
        self._ensure_hud(char)
        started = time.time()
        send_pending()
        try:
            self._wait(char, new_cd, timeout, f'{tag}新冷却', drive=send_pending,
                       recover=recovery, allow_break=False)
        except AxisUnconfirmed:
            self._log(f'{tag}未确认：发键{sent}次，用时{time.time() - started:.2f}s，保留已确认检查点')
            raise
        record = char.record_resonance_use if name == 'resonance' else char.record_echo_use
        record()
        self._log(f'{tag}确认：新冷却，发键{sent}次，用时{time.time() - started:.2f}s')
        return True

    def _echo(self, char):
        self._cast_cd(char, "echo", f"{char.name}声骸", optional=True)

    def _r(self, char, kind):
        def ready():
            if kind == "心R1":
                return bool(self.task.find_one(Labels.hsin_lib1, threshold=0.7)
                            and char.liberation_available())
            if kind == "心R2":
                # H2完成不等于125点共鸣能量已满；普通R还可能只是借相。
                feature = self.task.find_one(Labels.hsin_lib2, threshold=0.7)
                return bool(feature and char.liberation_available())
            # 将支持角色的“可施放”和“无旧CD”放在同两帧中确认。
            return bool(char.liberation_available() and self._cd('liberation') <= 0.35)

        wait_started = time.time()
        def build():
            # 先给正常变奏入场留出恢复时间；只在R无冷却仍未亮时补能。
            if (kind == '锁暝R' and time.time() - wait_started >= 1.0
                    and 'lock_energy_e' not in self._axis_done and self._cd('liberation') <= 0.35):
                if char.forte_available():
                    self._log('锁暝R未就绪，先确认强化E补能；仍保留R→Q顺序')
                    self._once('lock_energy_e', lambda: self._lock_e(char))
                    return
                if char.resonance_available():
                    self._log('锁暝R未就绪，先用普通E补能并确认新冷却；仍保留R→Q顺序')
                    self._once('lock_energy_e', lambda: self._cast_cd(char, 'resonance', '锁暝R前E补能'))
                    return
            char.click(interval=0.12)

        drive = None if kind == "心R2" else build
        try:
            self._wait(char, ready, 2.5 if kind == "心R2" else 8, f"{kind}就绪", drive=drive)
        except AxisUnconfirmed as error:
            if kind == '锁暝R':
                raise AxisResourcePending('锁暝R资源仍未就绪，保留补能检查点，不切心、不重启轴') from error
            raise
        # 同奏只能来自刚确认的大招；不得仅凭阶段名称伪造变奏。
        had_intro = bool(char.has_intro)
        recovery = self._arm_hit_recovery(
            char, kind, None, lambda: ready() and self._cd('liberation') <= 0.35)
        self._axis_guard_until = time.time() + 8
        try:
            attempts = 2
            for attempt in range(attempts):
                if char.click_liberation(wait_if_cd_ready=0, click_f=False):
                    break
                # 心/守R只有受击证据才增加一次闪避后重试；锁R保留原来的
                # 一次段内补发。已进入CD、错位、非专用R提示均不得重发。
                self.task.next_frame()
                if (attempt + 1 == attempts or not self._hud(char)
                        or self._cd('liberation') > 0.35):
                    raise AxisUnconfirmed(f"{kind}没有确认大招演出")
                dodged = self._recover_hit(char, recovery, allow_guard=True)
                if not dodged:
                    self.task.next_frame()
                    dodged = self._recover_hit(char, recovery, allow_guard=True)
                if not dodged and kind != '锁暝R':
                    raise AxisUnconfirmed(f"{kind}没有确认大招演出，且无受击补救证据")
                self._wait(char, ready, 0.8, f'{kind}补发前就绪且无新冷却')
                self._log(f'{kind}首发未确认、仍就绪且无新冷却，'
                          f'{"受击闪避后" if dodged else "段内"}仅补发一次')
            # _wait自身逐帧核对HUD与角色；把HUD恢复和施放结果合并确认。
            if kind in {"锁暝R", "守岸人R"}:
                self._wait(char, lambda: self._cd("liberation") > 0.35, 3.5, f"{kind}HUD恢复及新冷却")
            elif kind == "心R1":
                self._wait(char, lambda: not self.task.find_one(Labels.hsin_lib1, threshold=0.7),
                           3.5, "心R1 HUD恢复及形态变化")
                self._axis_transformed = True
                self._axis_counts['R1'] += 1
            else:
                self._wait(char, lambda: not self.task.find_one(Labels.hsin_lib2, threshold=0.7),
                           3.5, "心R2 HUD恢复及提示消耗")
                self._axis_transformed = False
                self.h2_completed = False
                self.h2_guard_until = 0.0
                self._axis_counts['R2'] += 1
            if kind == "锁暝R" or (kind == "心R1" and had_intro):
                self._axis_unison = (char.name, time.time())
            self._log(f"{kind}确认：演出结束且HUD恢复")
        finally:
            self._axis_guard_until = 0.0

    def _full_con(self, char, timeout=6):
        self._wait(char, lambda: self.task.get_current_con() == 1, timeout,
                   f"{char.name}满协奏", drive=lambda: char.click(interval=0.12))

    def _shore_ring_ready(self):
        # 原生凸轮廓近似可能跨过未充满的缺口；逐角检查原始彩色环，不做闭运算。
        if self.task.get_current_con() != 1:
            return False
        crop = self.task.get_con_box().crop_frame(self.task.frame)
        if crop is None or crop.size == 0:
            return False
        h, w = crop.shape[:2]
        b, g, r = cv2.split(crop.astype(np.int16))
        colored = (r - b > 60) & (g - b > 50) & (np.abs(r - g) < 65)
        geometry = self._axis_ring_geometry
        if geometry is None or geometry[0] != (h, w):
            ys, xs = np.indices((h, w))
            dx, dy = xs - w // 2, ys - h // 2
            radius = np.sqrt(dx * dx + dy * dy)
            ring = (radius >= int(h * .35119)) & (radius <= int(np.ceil(h * .42261)))
            indexes = np.flatnonzero(ring)
            angles = ((np.arctan2(dy, dx) + np.pi) * 72 / (2 * np.pi)).astype(int) % 72
            geometry = self._axis_ring_geometry = ((h, w), indexes, angles.ravel()[indexes])
        _, indexes, angles = geometry
        return bool((np.bincount(angles[colored.ravel()[indexes]], minlength=72) > 0).all())

    def _shore_outro(self, char):
        try:
            self._wait(char, self._shore_ring_ready, 6, '守延奏完整协奏环持续亮起',
                       drive=lambda: char.click(interval=0.12), hold=.18)
        except AxisUnconfirmed as error:
            if isinstance(error, (AxisDesync, AxisControlled, AxisResourcePending)):
                raise
            raise AxisResourcePending('守延奏完整环未持续亮起，继续补资源，保留守E/Q/R检查点') from error
        self._log('守延奏交棒门槛确认：实时协奏1且完整彩色环持续亮起')
        self.task.screenshot('hsin_shore_outro_ready')

    def _lock_deep_ready(self, char):
        # 以实际技能外形确认念深，不使用框架预先写入的has_intro。
        if char.forte_available():
            return True
        crop = self.task.box_of_screen_scaled(
            3840, 2160, 3160, 1850, 3330, 2010).crop_frame(self.task.frame)
        if crop is None or crop.size == 0:
            return False
        if self._axis_deep_template is None:
            self._axis_deep_template = cv2.imdecode(np.frombuffer(
                base64.b64decode(self._DEEP_E_PNG), np.uint8), cv2.IMREAD_GRAYSCALE)
        # 按实际HUD裁剪高度缩放；兼容框架的屏幕坐标适配。
        size = max(1, round(crop.shape[0] * 124 / 160))
        if min(crop.shape[:2]) < size:
            return False
        scaled = self._axis_deep_scaled
        if scaled is None or scaled[0] != size:
            template = cv2.resize(self._axis_deep_template, (size, size))
            mask = np.full((size, size), 255, np.uint8)
            cv2.rectangle(mask, (0, round(size * 19 / 62)),
                          (size, round(size * 42 / 62)), 0, -1)
            scaled = self._axis_deep_scaled = (size, template, mask)
        _, template, mask = scaled
        scores = cv2.matchTemplate(cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY), template,
                                   cv2.TM_CCOEFF_NORMED, mask=mask)
        scores = np.nan_to_num(scores, nan=-1, posinf=-1, neginf=-1)
        return bool(cv2.minMaxLoc(scores)[1] >= .70)

    def _handoff(self, char, next_phase, free=False, recovery=False, con_confirmed=False):
        if free:
            self._ensure_hud(char)
            token = self._axis_unison
            if (not token or token[0] != char.name
                    or char.time_elapsed_accounting_for_freeze(token[1]) >= 4.5):
                raise AxisUnconfirmed(f"{char.name}同奏窗口未确认或已过期")
        elif recovery:
            self._wait_hud(char)
        elif char.name == 'ShoreKeeper' and next_phase == 'lock_r':
            self._shore_outro(char)
        else:
            # 锁暝长按末尾已经连续确认满协奏；切人前仍刷新并读实值。
            # 隐藏HUD、协奏变化或断点重入均重新等待，不能靠缓存直接切。
            self.task.next_frame()
            if not (con_confirmed and self._hud(char) and self.task.get_current_con() == 1):
                self._full_con(char, timeout=4)
        actual_con = self.task.get_current_con()
        char.current_con = actual_con
        old_phase = self._axis_phase
        self._axis_phase = next_phase
        target = next(c for c in self.task.chars if c.name == self.PHASE_CHAR[next_phase])
        check_lock_intro = (not recovery and not free
                            and char.name == 'ShoreKeeper' and next_phase == 'lock_r')
        if check_lock_intro:
            self._axis_lock_intro = False
            self._release(char)
        try:
            char.switch_next_char(free_intro=free)
            self._wait_hud(target, timeout=2)
            if check_lock_intro:
                try:
                    self._wait(target, lambda: self._lock_deep_ready(target), 2,
                               '锁暝变奏后实际念深形态')
                except AxisUnconfirmed as error:
                    if isinstance(error, (AxisDesync, AxisControlled, AxisResourcePending)):
                        raise
                    target.has_intro = False
                    self.task.screenshot('hsin_shore_lock_intro_missing')
                    raise AxisResourcePending(
                        '守→锁切人已完成但念深形态未确认，回守补交棒；保留守E/Q/R检查点，不放锁R'
                    ) from error
                self._axis_lock_intro = True
                target.has_intro = True
                self.task.screenshot('hsin_lock_intro_deep')
        except BaseException:
            self._axis_phase = old_phase
            raise
        # 框架会把 free_intro 也当成消耗协奏；同奏优先消耗自身，协奏应保留。
        if free:
            char.current_con = actual_con
        keep_checkpoints = recovery and old_phase == next_phase
        if next_phase == "shore" and not keep_checkpoints:
            self._axis_shore_heavies = 0
        self._axis_unison = None
        if not keep_checkpoints:
            self._axis_done.clear()
        self._axis_failures = 0
        self._log(f"切人确认：{char.name}→{target.name}，同奏={free}，变奏标记={target.has_intro}，"
                  f"念深入场已验证={self._axis_lock_intro if check_lock_intro else '本棒不适用'}，"
                  f"保留检查点={keep_checkpoints}")

    def _shore_heavy(self, char):
        self._wait(char, char.is_mouse_forte_full, 5, "守强化重击就绪",
                   drive=lambda: char.click(interval=0.12))
        self._release(char)
        before = self.task.get_current_con()
        target_con = min(1.0, before + 0.02)
        recovery = self._arm_hit_recovery(char, '守强化重击', self.task.mouse_down,
                                          lambda: bool(char.is_mouse_forte_full()))
        self.task.mouse_down()
        try:
            self._wait(char, lambda: not char.is_mouse_forte_full(),
                       1.4, "守强化重击提示消耗", recover=recovery)
        finally:
            self.task.mouse_up()
        # 满回路已连续消耗即松开，不为等待协奏数字继续长按。
        # 协奏增长可能迟于动作；没有增长不算命中，后续依然按实值补满。
        try:
            self._wait(char, lambda: self.task.get_current_con() >= target_con,
                       0.6, "守重击松手后协奏反馈")
        except AxisUnconfirmed as error:
            if isinstance(error, (AxisDesync, AxisControlled, AxisResourcePending)):
                raise
            raise AxisResourcePending(
                f'守重击满回路已消耗并松手，但协奏未及时增长：'
                f'{before:.3f}→{self.task.get_current_con():.3f}；不记重击成功，保留阶段按实时资源继续补能'
            ) from error
        self._axis_shore_heavies += 1
        self._log(f"守强化重击第{self._axis_shore_heavies}次确认：满回路提示消耗且已松手，"
                  f"协奏{before:.3f}→{self.task.get_current_con():.3f}")

    def _shore(self, char):
        def opening_e():
            self._log(f'守资源入口：实时协奏{self.task.get_current_con():.3f}，'
                      f'满回路={bool(char.is_mouse_forte_full())}；已亮重击优先，否则先E衔接普攻')
            if char.is_mouse_forte_full():
                self._shore_heavy(char)
            self._cast_cd(char, "resonance", "守E", optional=True)

        # 官方机制：E后可衔接普攻第二段；不再每次进场先打固定1.4s。
        # E确认后仍靠满回路/实时协奏驱动普攻，不把发E当作资源足够。
        self._once("shore_e", opening_e)

        def build():
            if char.is_mouse_forte_full():
                self._shore_heavy(char)
            elif char.resonance_available():
                # 原生可用判断有时漏CD；局部复核仍在冷却时改普攻，
                # 避免只循环“E已有冷却，跳过”而没有补资源输入。
                if not self._cast_cd(char, "resonance", "守补资源E", optional=True):
                    char.click(interval=0.12)
            else:
                char.click(interval=0.12)

        # 先消耗已经亮起的强化重击；资源够用且提示未亮时直接启动。
        self._wait(char, lambda: (self.task.get_current_con() >= 0.8
                                  and not char.is_mouse_forte_full()),
                   16, "守启动资源及强化重击", drive=build)
        self._log(f'守Q/R前资源确认：实时协奏{self.task.get_current_con():.3f}，'
                  f'已确认重击{self._axis_shore_heavies}次')
        self._once("shore_q", lambda: self._echo(char))
        self._once("shore_r", lambda: self._r(char, "守岸人R"))
        self._handoff(char, "lock_r")

    def _lock_r(self, char):
        if not char.has_intro:
            raise AxisUnconfirmed("锁暝缺少实际念深入场确认，不能仅按变奏缓存放R")
        if not self._axis_lock_intro:
            self._wait(char, lambda: self._lock_deep_ready(char), 2, '锁暝R前实际念深入场')
            self._axis_lock_intro = True
        if self.SUOMING_Q_BEFORE_R:
            self._once("lock_q", lambda: self._echo(char))
        self._once("lock_r", lambda: self._r(char, "锁暝R"))
        if not self.SUOMING_Q_BEFORE_R:
            self._once("lock_q", lambda: self._echo(char))
        self._handoff(char, "heart_r1", free=True)

    def _heart_heavy(self, kind):
        try:
            if kind == 2:
                # 变奏缓存不代表已进统御众机：实机满照世心时仍可能需要强化E。
                self._wait(self, lambda: (self.heavy_available() == 2
                                          or self._heart_e_recovery_ready()),
                           6, '心H2或强化E入口', drive=lambda: self.click(interval=0.12))
                if self.heavy_available() != 2 and self._recover_heart_e():
                    self._once('heart_finish_a', self._heart_finish_attacks)
            self._wait(self, lambda: (self.heavy_available() == kind
                                      or (kind == 1 and self._live_heart_finisher())), 6 if kind == 2 else 7,
                       f"心强化重击{kind}提示", drive=lambda: self.click(interval=0.12))
        except AxisUnconfirmed as error:
            if isinstance(error, (AxisDesync, AxisControlled, AxisResourcePending)):
                raise
            if kind == 2 and self._axis_transformed:
                raise AxisResourcePending(
                    '心R1已确认但H2资源/动作仍未确认，保留终结段继续补资源，不回守重放整轴'
                ) from error
            raise
        if kind == 1 and self._live_heart_finisher():
            return False
        if kind == 2:
            self._log('心H2提示已连续确认，开始终结重击')
        self._release(self)
        self._axis_guard_until = time.time() + 7
        try:
            if not NativeHsin.handle_heavy(self, kind):
                raise AxisUnconfirmed(f"心强化重击{kind}提示未消耗")
        finally:
            self._axis_guard_until = 0.0
        self._log(f"心强化重击{kind}提示已消耗，继续核对对应R")
        if kind == 1:
            self._axis_counts['H1'] += 1
        return True

    def _live_heart_finisher(self):
        return bool(self.heavy_available() == 2
                    or self.task.find_one(Labels.hsin_lib2, threshold=0.7))

    def _resume_heart_finisher(self):
        self._axis_phase = "heart_r2"
        self._axis_done.clear()
        self._axis_failures = 0
        self._axis_transformed = True
        self._log("恢复：R1记录或实机H2/R2提示确认照世相，转终结段，不再等待H1")

    def _heart_r1(self, char):
        pending_r2 = self.h2_completed or self._live_heart_finisher()
        if (self._axis_transformed or pending_r2) and "heart_r1" not in self._axis_done:
            self._resume_heart_finisher()
            return
        if not self.has_intro:
            raise AxisUnconfirmed("心R1段缺少变奏，重新建立入口")
        self._once("heart_q", lambda: self._echo(self))
        if "heart_h1" not in self._axis_done:
            if not self._heart_heavy(1):
                self._resume_heart_finisher()
                return
            self._axis_done.add("heart_h1")
        self._once("heart_r1", lambda: self._r(self, "心R1"))
        self._once("heart_a", lambda: self._attack(self, 0.25))
        self._once("heart_e", lambda: self._cast_cd(self, "resonance", "心转相AE"))
        self._handoff(self, "lock_forte", free=True)

    def _lock_e(self, char):
        start = time.time()
        try:
            self._wait(char, char.forte_available, 8, "锁暝满妄执强化E",
                       drive=lambda: char.click(interval=0.12))
        except AxisUnconfirmed as error:
            if isinstance(error, (AxisDesync, AxisControlled, AxisResourcePending)):
                raise
            raise AxisResourcePending('锁暝强化E资源未齐，保留本段继续补资源，不重建轴') from error
        ready_at = time.time()
        recovery = self._arm_hit_recovery(char, '锁暝强化E', char.send_resonance_key,
                                          char.forte_available)
        self._log('锁暝强化E已连续就绪，开始发键并等待提示消耗')
        char.send_resonance_key()
        try:
            self._wait(char, lambda: not char.forte_available(), .65,
                       "锁暝强化E首次提示消耗", recover=recovery)
        except AxisUnconfirmed as error:
            if isinstance(error, (AxisDesync, AxisControlled, AxisResourcePending)):
                raise
            # 已出现任何消耗候选、或受击补救已补E，均禁止再补。
            # 尚无执行证据时再取两帧：图标/HUD任一变化就继续等原命令结果。
            still_ready = not recovery['progress'] and recovery['retries'] == 0
            if still_ready:
                for _ in range(2):
                    self.task.next_frame()
                    if not self._hud(char) or not char.forte_available():
                        still_ready = False
                        break
                    char.check_combat()
            if still_ready:
                self._release(char)
                char.send_resonance_key()
                recovery['retries'] += 1
                recovery['used'] = True
                self._log('锁暝强化E首发未确认，连续仍为同一强化E提示，段内仅补发一次')
            self._wait(char, lambda: not char.forte_available(), 1.15,
                       "锁暝强化E提示消耗", recover=recovery)
        self._log(f"锁暝强化E提示已消耗，发键{1 + recovery['retries']}次")
        self._log(f'锁E耗时分解：资源等待{ready_at - start:.2f}s，'
                  f'发键到提示消耗{time.time() - ready_at:.2f}s（现实时间）')

    def _lock_heavy(self, char):
        self._release(char)
        start = time.time()
        self._axis_guard_until = start + self.SUOMING_HEAVY_MAX + 2
        returned = 0
        def finished():
            nonlocal returned
            elapsed = char.time_elapsed_accounting_for_freeze(start)
            forte = elapsed >= .8 and char.forte_available()
            returned = returned + 1 if forte else 0
            if returned >= 2:
                retry_current('锁强化E重新持续亮起')
            return (elapsed >= self.SUOMING_HEAVY_MIN
                    and self.task.get_current_con() == 1
                    and not forte and char.resonance_available())

        def retry_current(reason='锁暝刻心念受击'):
            # 受击后先松键闪避；E实际重新亮起时撤销它的检查点，下一拍只补当前动作。
            if char.forte_available():
                self._axis_done.discard('lock_forte_e')
            raise AxisResourcePending(f'{reason}，立即重试当前动作，不等长按超时、不重建轴')

        recovery = self._arm_hit_recovery(char, '锁暝刻心念', retry_current,
                                          lambda: self.task.get_current_con() < .98 and char.forte_available())
        self.task.mouse_down()
        try:
            self._wait(char, finished, self.SUOMING_HEAVY_MAX,
                       "锁暝长按刻心念结束与满协奏", recover=recovery, recover_guard=True)
        finally:
            self.task.mouse_up()
            self._axis_guard_until = 0.0
        self._log(f"锁暝刻心念确认：长按{time.time() - start:.2f}s，满协奏且动作结束")

    def _lock_forte(self, char):
        if not char.has_intro:
            raise AxisUnconfirmed("锁暝回路段缺少同奏变奏")
        self._once("lock_forte_e", lambda: self._lock_e(char))
        held_now = "lock_heavy" not in self._axis_done
        self._once("lock_heavy", lambda: self._lock_heavy(char))
        self._handoff(char, "heart_r2", con_confirmed=held_now)

    def _heart_finish_attacks(self):
        # 不把has_intro当作统御众机的实机证据；亮起强化E时仍需确认消耗。
        if not self.has_intro and 'heart_recovery_e' not in self._axis_done:
            self._wait(self, lambda: self.enhanced_e_ready() or self.heavy_available() == 2,
                       8, "心恢复照世资源", drive=lambda: self.click(interval=0.12))
        if self._heart_e_recovery_ready():
            self._recover_heart_e()
        def a12_dodge():
            dodges = self._axis_hit_dodges
            self._attack(self, self.HSIN_A12_TIME, stop=lambda: self.heavy_available() == 2)
            self._ensure_hud(self)
            if self.heavy_available() != 2 and self._axis_hit_dodges == dodges:
                self.task.send_key(self.task.key_config.get("Dodge Key", "lshift"))
                self._log(f"心二段闪避候选：普攻窗口{self.HSIN_A12_TIME:.2f}s，继续以H2提示确认")
            elif self._axis_hit_dodges != dodges:
                self._log('心二段已因受击闪避，不叠加固定A2闪避，继续以H2提示确认')
        # 后续H2提示迟到时继续后半套普攻，不重放A12/闪避而打断连段。
        self._once('heart_a12_dodge', a12_dodge)
        # 后半套普攻和H2连续确认统一由_heart_heavy(2)完成，避免重复等待。

    def _heart_e_recovery_ready(self):
        return bool('heart_recovery_e' not in self._axis_done
                    and self.heavy_available() != 2
                    and not self.task.find_one(Labels.hsin_lib2, threshold=0.7)
                    and self.enhanced_e_ready())

    def _recover_heart_e(self):
        if not self._heart_e_recovery_ready():
            return False
        try:
            self._wait(self, self._heart_e_recovery_ready, .5, '心终结段强化E持续亮起')
        except AxisUnconfirmed as error:
            if isinstance(error, (AxisDesync, AxisControlled, AxisResourcePending)):
                raise
            # 迟到H2/R2优先，单帧强化E不能驱动补发。
            if self.heavy_available() == 2 or self.task.find_one(Labels.hsin_lib2, threshold=0.7):
                return False
            raise AxisResourcePending('心强化E未持续确认，保留终结阶段，不盲补') from error
        self._release(self)
        if not self.cast_enhanced_e():
            raise AxisResourcePending('心补强化E未确认消耗，保留终结阶段，后续不推进')
        self._axis_done.add('heart_recovery_e')
        # 强化E实际启动后，才重新衔接一次对应的A12；保留H1/R1及计数。
        self._axis_done.difference_update({'heart_finish_a', 'heart_a12_dodge'})
        self._log('心终结补救：强化E提示连续亮起且已确认消耗，衔接统御众机连段，不重放H1/R1')
        return True

    def _heart_r2(self, char):
        r2_prompt = bool(self.task.find_one(Labels.hsin_lib2, threshold=0.7))
        if not self._axis_done and self.has_intro and not r2_prompt:
            # 新的照世变奏会重建统御众机，不能沿用上次入场的H2完成标记。
            self.h2_completed = False
        if (self.h2_completed and not self.has_intro) or r2_prompt:
            self._axis_done.update({"heart_finish_a", "heart_h2"})
        self._once("heart_finish_a", self._heart_finish_attacks)
        self._once("heart_h2", lambda: self._heart_heavy(2))
        self._once("heart_r2", lambda: self._r(self, "心R2"))
        self._once('heart_r2_timing', self._r2_timing)
        self._once("heart_tail_e", lambda: self._cast_cd(self, "resonance", "心R2后E"))
        self._handoff(self, "shore")

    def _r2_timing(self):
        self._axis_r2_stamp = self._timing('R2→R2', self._axis_r2_stamp)
        start, end = self._axis_start_stamp, self._axis_r2_stamp
        elapsed = (start[1] - end[1] if start and start[1] is not None
                   and end[1] is not None and start[1] >= end[1] else None)
        # 当前测试为两分钟挑战：直接用120减剩余倒计时，包含锁敌/切守
        # 之前已流逝的时间。更长挑战仍按首次读取的轴起点计120秒窗口。
        challenge_clock = (elapsed is not None and 0 < start[1] <= self.TARGET_SECONDS)
        if challenge_clock:
            elapsed = self.TARGET_SECONDS - end[1]
        counts = self._axis_counts
        progress = f"本场已确认H1={counts['H1']}，R1={counts['R1']}，R2={counts['R2']}"
        if elapsed is None:
            self._log(f"两分钟目标进度：{progress}；缺少有效倒计时，不能判断达标")
            return
        left = self.TARGET_SECONDS - elapsed
        needed = max(0, self.TARGET_R2 - counts['R2'])
        budget = (f"后续{needed}次R2平均预算{max(0, left) / needed:.2f}s"
                  if needed else f"已确认第4个R2，{'在目标时间内' if left >= 0 else '已超时'}")
        origin = '从两分钟挑战开始' if challenge_clock else '从首次轴画面'
        self._log(f"两分钟目标进度：{progress}；{origin}已用游戏{elapsed:.2f}s，"
                  f"挑战剩余{end[1]:.2f}s，120s预算剩余{left:.2f}s；{budget}")

    def axis_run(self, char):
        try:
            if not self._axis_version_logged:
                self._log(f"已载入心锁守轴{self.AXIS_VERSION}：独立同帧HUD缓存；锁长按受击即重试、补资源不重建；保留严格接敌、连续确认及完整刻心念")
                self._axis_version_logged = True
            char = self._sync_current(char)
            char.check_f_on_switch = False
            if char.name != self.PHASE_CHAR[self._axis_phase]:
                self._handoff(char, self._axis_phase, recovery=True)
                return
            if self._axis_break_pending:
                self._maybe_break(char)
            self._ensure_hud(char)
            if self._axis_phase_stamp is None or self._axis_phase_stamp[0] != self._axis_phase:
                previous = self._axis_phase_stamp
                stamp = self._timing(previous[0] if previous else self._axis_phase,
                                     previous[1] if previous else None)
                self._axis_phase_stamp = (self._axis_phase, stamp)
                if self._axis_start_stamp is None:
                    self._axis_start_stamp = stamp
            self._maybe_break(char)
            self._log(f"执行{char.name}，变奏={char.has_intro}，已完成={sorted(self._axis_done)}")
            getattr(self, '_' + self._axis_phase)(char)
        except (AxisDesync, AxisControlled, AxisResourcePending) as error:
            self._failure_snapshot(char, error)
            self._log(f"暂缓动作：{error}；不计入技能失败、不清除阶段检查点")
            char.sleep(0.15)
        except AxisUnconfirmed as error:
            self._failure_snapshot(char, error)
            self._axis_failures += 1
            self._log(f"阻断后续动作：{error}；本段第{self._axis_failures}次失败")
            if self._axis_failures >= 2:
                self._axis_phase = "shore"
                self._axis_done.clear()
                self._axis_unison = None
                self._axis_failures = 0
                self._log("本段两次未确认，回守岸人重建轴；已确认的心形态保留")
            char.sleep(0.15)
        finally:
            self._release(char)
            self._axis_guard_until = 0.0
