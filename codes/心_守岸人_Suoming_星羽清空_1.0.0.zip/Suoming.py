import time

from src.char.Suoming import Suoming as NativeSuoming


class Suoming(NativeSuoming):
    def _axis_owner(self):
        for char in self.task.chars:
            if char is not None and hasattr(char, "axis_run") and char.axis_enabled():
                return char
        return None

    def do_perform(self):
        owner = self._axis_owner()
        if owner is None:
            return super().do_perform()
        return owner.axis_run(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        owner = self._axis_owner()
        if owner is not None:
            return owner.axis_priority(self)
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def skip_combat_check(self):
        owner = self._axis_owner()
        return bool(owner and time.time() < owner._axis_guard_until)
