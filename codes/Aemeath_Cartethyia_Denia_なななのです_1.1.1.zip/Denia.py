import time

from src.Labels import Labels
from src.char.Denia import Denia as NativeDenia


class Denia(NativeDenia):
    """爱/卡/达队的达妮娅: 按爱弥斯那份步骤表出手 (见 Aemeath.py), 步骤名 den_ 开头的是她的。

    队里没有爱弥斯 (或爱弥斯不是这份队伍代码) 时走内置逻辑。
    """
    # 开场切上来后先普攻多久: 确认还在战斗 (怪被一炮带走就切回爱弥斯), 也等过切人冷却 (秒)
    OPEN_CHECK_TIME = 1.0
    # "普攻 1 秒再 E" (秒)
    A_BEFORE_E = 1.0
    # "A1234": 普攻多久 (秒)。
    A1234_TIME = 2.8
    # 变奏入场后普攻多久再切回爱弥斯 (秒), 要盖过切人冷却
    INTRO_TIME = 1.0
    # A1234 之后 E、R、普攻一起连点直到 R2 放出来, 最多这么久 (秒)。
    # E1 E2 就这样按出来 (E2 之后 E 在冷却里, 多按不会有事); R2 也要打满才能放 (用户 2026-10-18: "一直打到 R2 满了"),
    # 期间一直在普攻, 不站着 (用户 2026-10-19: "A E R 可以同时, 一直连点就行, 不会冲突")
    R2_TIME_OUT = 6.0
    # R2 之后连点 Q 的最长时间 (秒): R2 后有一段时间按 Q 没反应, 一直点到它放出来
    Q_SPAM_TIME = 2.0
    # E 只按一下, 之后留这么久让技能起手再做下一件事 (秒), 免得被切人键打断。
    # 不用框架的 click_resonance: 它在 E 图标还可用时会一直补按, 停不住
    E_SETTLE = 0.15
    # 切走前协奏没满就普攻到满再延奏, 最多这么久 (秒)
    CON_FILL_TIME = 4.0
    # R1 放了就一定要等 R2 放出来才切走, 最多等这么久 (秒), 期间 E、R、普攻一直连点 (用户 2026-10-19)
    AFTER_R1_WAIT = 20.0
    # R2 是靠"图标亮过又灭了"判出来的 (HUD 没隐藏) 时, 再边普攻边按 R 复查这么久 (秒):
    # 解放进了冷却 (has_cd) 或者过场开始 = 真放出来了, 马上结束; 图标又亮了 = 误判, 接着 E R A 连点。
    # 2026-10-26 实测: 图标只是暗了一下就判成放出来了, 之后能量、协奏都满了也没再按 R, R2 没放
    R2_RECHECK_TIME = 2.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_r1 = -1
        self.r2_icon_seen = False
        self.r2_gone_count = 0
        self.r2_unconfirmed = False

    def aemeath(self):
        for char in self.task.chars:
            if char is not None and char is not self and char.char_name == 'char_aemeath' and \
                    hasattr(char, 'step'):
                return char
        return None

    def do_perform(self):
        aem = self.aemeath()
        if aem is None:
            return super().do_perform()
        if aem.last_combat_start != self.task.combat_start:
            # 新战斗由爱弥斯开炮, 达妮娅在场就先交出去 (日常副本里先等爱弥斯的强化重击刷新)
            self.logger.info('new combat with Denia on field, hand over to Aemeath')
            aem.take_over(self)
            return
        aem.enemy_seen_now()
        step = aem.step()
        if step.startswith('den_'):
            getattr(self, step)()
            aem.next_step()
        self.switch_next_char()

    # ---- 达妮娅的步骤 ----

    def den_open(self):
        """开场: 普攻 1 秒确认还在战斗 (脱战会抛异常, on_combat_end 切回爱弥斯), 然后 R1 A1234 E1 E2 R2 Q。"""
        self.continues_normal_attack(self.OPEN_CHECK_TIME)
        self.check_combat()
        self.den_r1_e1e2_r2_q()

    def den_intro(self):
        self.continues_normal_attack(self.INTRO_TIME)

    def den_a_e(self):
        self.continues_normal_attack(self.A_BEFORE_E)
        self.press_e('E')

    def den_r1_e1e2_r2_q(self):
        """(R1) A1234 E1 E2 R2 Q 一次打完, 最后延奏切给爱弥斯。爱弥斯的强化重击 (炮) 靠这次延奏才会亮。
        Q 放在协奏满了之后、切人之前 (用户 2026-10-26: 满协奏才 Q, 然后马上切)。"""
        self.r2_unconfirmed = False
        # R 格显示的已经是 R2 就不放 (R1 放过了); 否则边普攻边试 R1 (R1 没好时多平 A)。
        # 不用 has_cd 跳过: 2026-10-18 实测循环轴里它判成冷却, R1 没放, 后面 R2 也放不出来, 整轮乱掉
        if self.task.find_one(Labels.denia_end_lib):
            self.logger.info('Denia R slot already shows R2, skip R1')
            self.lib_1_casted = True
        else:
            self.cast_r(self.aemeath().R1_ENERGY_WAIT)
        for _ in range(2):
            self.continues_normal_attack(self.A1234_TIME)
            if self.spam_e_r_a(self.R2_TIME_OUT, stop=lambda: self.aemeath().enemies_gone('Denia R2')) != 'r1':
                break
            # 这发 R 其实是 R1 (前面 R1 没放出来), 再打一遍 A1234 E1 E2 R2
            self.logger.info('that R was R1, do A1234 E1 E2 R2 again')
        self.finish_r2_after_r1()
        self.fill_con_before_outro()
        self.aemeath().fire_echo(self, self.Q_SPAM_TIME)

    def spam_e_r_a(self, time_out, stop=None):
        """E、R、普攻一起连点, 直到 R 放出来, 返回 'r1' / 'r2' / None。

        E1 E2 就这样按出来, R2 一好就放出去 (用户 2026-10-18: "按完 E1 后就 E2 R2 一起按")。
        不看 has_cd('resonance'): 2026-10-18 实测它误判 E2 已出, 结果 E2 一下没按。
        放出来的判据: 过场开始 (队伍 HUD 消失), 或者 R2 图标亮过之后灭了 (R2 不一定隐藏 HUD)。"""
        self.r2_icon_seen = False
        self.r2_gone_count = 0
        is_lib2 = self.lib_1_casted or bool(self.task.find_one(Labels.denia_end_lib))
        ok = self.aemeath().fire_liberation(self, time_out, fired=self.r2_fired if is_lib2 else None,
                                            click=True, extra=self.send_resonance_key, stop=stop)
        if not ok:
            self.logger.info(f'Denia {"R2" if is_lib2 else "R1"} did not fire while spamming E R A')
            return None
        return self.record_r(is_lib2)

    def r2_fired(self):
        """R2 图标 (denia_end_lib) 亮过、然后灭了。图标可能 E1 后就亮, 也可能 E2 后才亮, 所以记住亮过没有。"""
        visible = bool(self.task.find_one(Labels.denia_end_lib))
        if visible:
            self.r2_icon_seen = True
        gone = self.r2_icon_seen and not visible
        self.r2_gone_count = self.r2_gone_count + 1 if gone else 0
        return gone

    def finish_r2_after_r1(self):
        """R1 放了就一定要等 R2 放出来才切走 (用户 2026-10-19: 达妮娅也同理)。

        2026-10-19 实测: R1 之后丢了目标, R2 没攒满, R2 图标闪了一下被判成"放出来了", 协奏也已经满了, 结果直接切给爱弥斯。
        现在: R2 是靠图标灭了判出来的, 就边普攻边再看一会儿, 图标又亮了就是误判;
        R2 没放出来就继续 E、R、普攻连点等下一波, 最多 AFTER_R1_WAIT 秒 (脱战由框架打断)。"""
        start = time.time()
        aem = self.aemeath()
        gone = lambda: aem.enemies_gone('Denia R2 after R1')
        while time.time() - start < self.AFTER_R1_WAIT:
            if gone():
                return
            if not self.lib_1_casted:
                if not self.r2_lit_again():
                    return
                self.logger.info('Denia R2 icon lit again: R2 did not really fire, keep E R A')
                self.lib_1_casted = True
            left = self.AFTER_R1_WAIT - (time.time() - start)
            self.spam_e_r_a(min(self.R2_TIME_OUT, max(left, 0.5)), stop=gone)
        self.logger.info(f'Denia R2 still not fired {self.AFTER_R1_WAIT:.0f}s after R1, give up')

    def r2_lit_again(self):
        """R2 刚判成放出来时, 如果是靠"图标灭了"判的 (不是过场), 边普攻边按 R 复查 R2_RECHECK_TIME 秒:
        - 解放进了冷却 (has_cd('liberation')): 真放出来了, 返回 False
        - 过场开始 (队伍 HUD 消失): 这一下才真放出来, 等过场结束, 返回 False
        - 图标又亮了: 误判, 返回 True (接着 E R A 连点)
        都没看到就当放出来了, 但记下 r2_unconfirmed, 补协奏时继续按 R。
        R2 真放出来后能量是 0, 多按的 R 不会把 R1 按出去。不再在这里按 Q, Q 留到协奏满了、切人前。"""
        if self.r2_gone_count < self.aemeath().LIB_FIRED_CHECKS:
            return False
        self.r2_gone_count = 0
        aem = self.aemeath()
        start = time.time()
        self.task.in_liberation = True
        try:
            while time.time() - start < self.R2_RECHECK_TIME:
                if not self.task.in_team()[0]:
                    aem.wait_lib_anim(self)
                    self.logger.info(f'Denia R2 cutscene {time.time() - start:.1f}s into the recheck: fired now')
                    return False
                if self.task.find_one(Labels.denia_end_lib):
                    return True
                if self.task.has_cd('liberation'):
                    self.logger.info(f'Denia R2 confirmed: liberation on cooldown ({time.time() - start:.1f}s)')
                    return False
                self.send_liberation_key()
                self.sleep(0.05, check_combat=False)
                self.click()
                self.sleep(0.05, check_combat=False)
        finally:
            self.task.in_liberation = False
        self.logger.info(f'Denia R2 not confirmed in {self.R2_RECHECK_TIME:.1f}s (no cooldown, icon not back), '
                         f'keep pressing R while filling concerto')
        self.r2_unconfirmed = True
        return False

    def fill_con_before_outro(self):
        """切走前协奏要满, 延奏才会给到爱弥斯 (炮要靠这次延奏才亮)。
        2026-10-18 实测有一次 R2 判成放出来了, 切人时协奏却只有 0.11, 爱弥斯没吃到变奏, R1 能量攒了 3 轮。
        R2 没放出来的情况由 finish_r2_after_r1 管, 这里只普攻到协奏满。
        R2 没确认放出来 (r2_unconfirmed) 时一边普攻一边按 R: 能量满了就能放出来 (2026-10-26 实测这段时间里能量满了 R2 却没按)。"""
        if self.is_con_full():
            return
        start = time.time()
        while not self.is_con_full() and time.time() - start < self.CON_FILL_TIME:
            if self.r2_unconfirmed:
                if not self.task.in_team()[0]:
                    self.aemeath().wait_lib_anim(self)
                    self.r2_unconfirmed = False
                    self.logger.info(f'Denia R2 fired {time.time() - start:.1f}s into filling concerto')
                    continue
                self.send_liberation_key()
            self.click()
            # 按 R 时不做战斗判定: 过场开始那一下会被当成丢了目标 (过场由上面 in_team 判断)
            self.sleep(0.1, check_combat=not self.r2_unconfirmed)
        self.logger.info(f'Denia concerto full: {self.is_con_full()} '
                         f'(attacked {time.time() - start:.1f}s before outro)')

    def press_e(self, tag):
        self.send_resonance_key()
        self.record_resonance_use()
        self.sleep(self.E_SETTLE)
        self.logger.info(f'Denia {tag}')

    def cast_r(self, time_out):
        """边普攻边试 R 直到放出来 (爱弥斯的 attack_until_lib), 用来放 R1。返回 'r1' / 'r2' / None。

        不用框架的 click_liberation: 它只在"解放可用"检测通过时才按, 技能动画里那个检测常常不过。
        不原地连按: R 没好时原地连按就是站着发呆 (用户 2026-10-18: "愣了几秒")。"""
        is_lib2 = self.lib_1_casted or bool(self.task.find_one(Labels.denia_end_lib))
        self.r2_icon_seen = False
        tag = 'R2' if is_lib2 else 'R1'
        if not self.aemeath().attack_until_lib(self, time_out, fired=self.r2_fired if is_lib2 else None, tag=tag):
            self.logger.info(f'Denia {tag} did not fire')
            return None
        return self.record_r(is_lib2)

    def record_r(self, is_lib2=None):
        """记下刚放出来的 R 是 R1 还是 R2 (默认看这一段 R1 放过没有), 返回 'r1' / 'r2'。"""
        if is_lib2 is None:
            is_lib2 = self.lib_1_casted
        if is_lib2:
            self.lib_2 = time.time()
            self.lib_1_casted = False
        else:
            self.lib_1_casted = True
            self.last_r1 = time.time()
        self.logger.info(f'Denia R{"2" if is_lib2 else "1"}')
        return 'r2' if is_lib2 else 'r1'

    def on_combat_end(self, chars):
        """脱战时达妮娅在场就切回爱弥斯, 下一场由爱弥斯开炮。"""
        aem = self.aemeath()
        if aem is None:
            return super().on_combat_end(chars)
        start = time.time()
        while time.time() - start < 3:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == aem.index:
                self.is_current_char = False
                aem.is_current_char = True
                self.logger.info('combat end, switched back to Aemeath')
                return
            self.task.send_key(str(aem.index + 1))
            self.sleep(0.2, False)
        self.logger.warning('combat end, switch back to Aemeath timed out')
