# -*- coding: utf-8 -*-
"""5R双处决 V2.7 —— Mornye

结构对齐用户提供的红绿灯轴：
- 三个角色只共享同一份 task.five_r_double_execution_state / STEP；
- 本文件只保存 Mornye 自己负责的 STEP 与动作模块；
- 别的角色 STEP 只通过 STEP_ACTOR 排序与精确切人，不复制对方动作代码；
- 非指定三人队时回退 OK-WW 内置 Mornye。
- V2.7：引入5R Frozen Runtime；Mornye固定队动作路径不再依赖BaseChar/内置Mornye中层helper。
"""
import time

import cv2
import numpy as np

from src.Labels import Labels
from src.char.Mornye import Mornye as BuiltinMornye

class _FiveRFrozenRuntime:
    """5R 双处决 Frozen Runtime V1.

    固定队 FSM 只通过本层访问 OK-WW 的 task / frame / input 底层，
    不直接依赖 BaseChar 或官方角色中层动作 helper。
    Builtin 角色继承仅保留给 OK-WW 构造/加载以及非本队官方回退。
    """
    FIVE_R_RUNTIME_REV = 1
    FIVE_R_SKILL_TIMEOUT = 15.0
    FIVE_R_FORTE_WHITE_COLOR = {
        'r': (244, 255),
        'g': (246, 255),
        'b': (250, 255),
    }

    @property
    def name(self):
        return self.__class__.__name__

    def perform(self):
        """冻结战斗入口 wrapper，避免固定队依赖上游 BaseChar.perform。"""
        self.last_perform = time.time()
        self.do_perform()
        try:
            self.logger.debug(f'set current char false {self.index}')
        except Exception:
            pass

    def reset_state(self):
        """冻结 OK-WW 每次重读队伍时需要的最小角色状态。"""
        self.has_intro = False
        self.has_sub_dps_intro = False
        self.current_con = 0
        self.last_full_con_switch_time = -1
        self.has_tool_box = False
        self._liberation_available = False
        self._echo_available = False
        self._resonance_available = False

    def _fr_sleep(self, sec, check_combat=True):
        sec = max(0.0, float(sec))
        previous = bool(getattr(self.task, 'skip_combat_check', False))
        if not check_combat:
            self.task.skip_combat_check = True
        try:
            self.task.sleep(sec)
        finally:
            self.task.skip_combat_check = previous

    def _fr_check_combat(self):
        return self.task.check_combat()

    def _fr_add_freeze_duration(self, start, duration=-1.0, freeze_time=0.1):
        return self.task.add_freeze_duration(start, duration, freeze_time)

    def _fr_time_elapsed_accounting_for_freeze(self, start, intro_motion_freeze=False):
        return self.task.time_elapsed_accounting_for_freeze(start, intro_motion_freeze)

    def _fr_get_resonance_key(self):
        return self.task.get_resonance_key()

    def _fr_get_liberation_key(self):
        return self.task.get_liberation_key()

    def _fr_get_echo_key(self):
        return self.task.get_echo_key()

    def _fr_click(self, *args, **kwargs):
        kwargs['down_time'] = 0.01
        return self.task.click(*args, **kwargs)

    def _fr_click_with_interval(self, interval=0.1):
        return self._fr_click(interval=interval)

    def _fr_normal_attack(self):
        self._fr_check_combat()
        return self.task.click()

    def _fr_heavy_attack(self, duration=0.6):
        self._fr_check_combat()
        self.task.mouse_down()
        try:
            self._fr_sleep(duration)
        finally:
            self.task.mouse_up()
        self._fr_sleep(0.01)

    def _fr_heavy_click_forte(self, check_fun=None):
        if check_fun is None:
            check_fun = self._fr_is_forte_full
        if not check_fun():
            return False
        self.task.mouse_down()
        try:
            return bool(self.task.wait_until(lambda: not check_fun(), time_out=2))
        finally:
            self.task.mouse_up()
            self._fr_sleep(0.05)

    def _fr_has_cd(self, box_name):
        return bool(self.task.has_cd(box_name))

    def _fr_available(self, box, check_color=True, check_cd=True):
        if bool(getattr(self, 'is_current_char', False)):
            return bool(self.task.available(
                box, check_color=check_color, check_cd=check_cd
            ))
        return not bool(self.task.has_cd(box, self.index))

    def _fr_resonance_available(self):
        return self._fr_available('resonance', check_color=False)

    def _fr_echo_available(self):
        return self._fr_available('echo', check_color=False)

    def _fr_liberation_available(self, check_color=True):
        return self._fr_available('liberation', check_color=check_color)

    def _fr_get_current_con(self):
        if float(getattr(self, 'current_con', 0) or 0) == 1.0:
            return 1.0
        self.current_con = self.task.get_current_con()
        return self.current_con

    def _fr_is_con_full(self):
        if float(getattr(self, 'current_con', 0) or 0) == 1.0:
            return True
        return bool(self.task.is_con_full())

    def _fr_is_mouse_forte_full(self):
        return bool(self.task.find_mouse_forte())

    def _fr_is_forte_full(self):
        box = self.task.box_of_screen_scaled(
            3840, 2160, 2251, 1993, 2311, 2016,
            name='five_r_forte_full', hcenter=True,
        )
        white_percent = self.task.calculate_color_percentage(
            self.FIVE_R_FORTE_WHITE_COLOR, box
        )
        box.confidence = white_percent
        try:
            self.task.draw_boxes('five_r_forte_full', box)
        except Exception:
            pass
        return white_percent > 0.08

    def _fr_has_long_action2(self):
        names = self.task.get_target_names()
        if not names:
            return False
        return bool(self.task.find_one(
            names[0], box='target_box_long2', threshold=0.6
        ))

    def _fr_record_resonance_use(self):
        self.last_res = time.time()

    def _fr_record_liberation_use(self):
        self.last_liberation = time.time()

    def _fr_record_echo_use(self):
        self.last_echo = time.time()

    def _fr_send_resonance_key(self, post_sleep=0, interval=-1, down_time=0.01):
        self._resonance_available = False
        return self.task.send_key(
            self._fr_get_resonance_key(),
            interval=interval,
            down_time=down_time,
            after_sleep=post_sleep,
        )

    def _fr_send_echo_key(self, after_sleep=0, interval=-1, down_time=0.01):
        self._echo_available = False
        return self.task.send_key(
            self._fr_get_echo_key(),
            interval=interval,
            down_time=down_time,
            after_sleep=after_sleep,
        )

    def _fr_send_liberation_key(self, after_sleep=0, interval=-1, down_time=0.01):
        self._liberation_available = False
        return self.task.send_key(
            self._fr_get_liberation_key(),
            interval=interval,
            down_time=down_time,
            after_sleep=after_sleep,
        )

    def _fr_alert_skill_failed(self, tag='skill'):
        try:
            self.task.log_error(
                f'5R Frozen Runtime: {tag} input failed; check keybinding/input API.',
                notify=True,
            )
            self.task.screenshot('five_r_frozen_runtime_skill_failed')
        except Exception:
            pass

    def _fr_click_echo(self, duration=0, sleep_time=0, time_out=1):
        """冻结 Q 输入；当前固定轴主要使用 time_out=0 的机会型提交。"""
        if time_out == 0:
            if not self._fr_echo_available():
                return False
            self._fr_send_echo_key()
            self._fr_record_echo_use()
            return True

        if self._fr_has_cd('echo'):
            return False

        clicked = False
        start = time.time()
        last_send = -100.0
        deadline = max(0.0, float(time_out)) + max(0.0, float(duration))
        while time.time() - start <= deadline:
            now = time.time()
            available = self._fr_echo_available()
            if not available and (duration == 0 or not clicked):
                break
            if duration > 0 and now - start >= duration:
                break
            if available and now - last_send >= 0.10:
                if not clicked:
                    self._fr_record_echo_use()
                    clicked = True
                self._fr_send_echo_key()
                last_send = now
            self.task.next_frame()
        if clicked and sleep_time:
            self._fr_sleep(sleep_time)
        return clicked

    def _fr_click_liberation(
        self, con_less_than=-1, send_click=False, wait_if_cd_ready=0.1,
        animation_min_duration=0, click_f=True,
    ):
        """冻结 R 输入事务，直接使用 task/in_team/input 底层。"""
        if not bool(getattr(self.task, 'use_liberation', True)):
            return False
        if con_less_than > 0 and self._fr_get_current_con() > con_less_than:
            return False

        started_at = time.time()
        last_send = -100.0
        clicked = False

        if not bool(getattr(self.task, 'in_liberation', False)):
            while self._fr_liberation_available():
                if send_click:
                    self._fr_click(interval=0.10)
                now = time.time()
                if now - last_send >= 0.10:
                    self._fr_send_liberation_key()
                    clicked = True
                    last_send = now
                if now - started_at > self.FIVE_R_SKILL_TIMEOUT:
                    self._fr_alert_skill_failed('liberation')
                    return False
                self.task.next_frame()

            if clicked:
                entered = self.task.wait_until(
                    lambda: not self.task.in_team()[0],
                    time_out=0.40,
                    post_action=self._fr_click_with_interval if send_click else None,
                )
                self.task.in_liberation = bool(entered)
                if not entered:
                    return False
            else:
                probe_start = time.time()
                while (
                    not self._fr_has_cd('liberation')
                    and time.time() - probe_start < max(0.0, float(wait_if_cd_ready))
                ):
                    self._fr_send_liberation_key(after_sleep=0.05)
                    if self.task.wait_until(
                        lambda: not self.task.in_team()[0], time_out=0.10
                    ):
                        self.task.in_liberation = True
                        clicked = True
                        break
                if not bool(getattr(self.task, 'in_liberation', False)):
                    return False

        animation_start = time.time()
        last_f = -100.0
        while not self.task.in_team()[0]:
            self.task.in_liberation = True
            clicked = True
            if send_click:
                self._fr_click(interval=0.10)
            now = time.time()
            if (
                click_f
                and now - animation_start >= animation_min_duration
                and now - last_f >= 0.10
            ):
                self.task.send_key('f')
                last_f = now
            if now - animation_start > 7.0:
                self.task.in_liberation = False
                try:
                    self.task.raise_not_in_combat(
                        '5R Frozen Runtime: liberation animation too long'
                    )
                except Exception:
                    pass
                return False
            self.task.next_frame()

        duration = time.time() - animation_start
        self._fr_add_freeze_duration(animation_start, duration)
        self._fr_record_liberation_use()
        self.task.in_liberation = False
        self._liberation_available = False
        if clicked:
            self.logger.info(
                f'[{getattr(self, "FSM_VERSION", "5R")}] frozen click_liberation end {duration}'
            )
        return clicked

    def _fr_f_break(self, check_f_on_switch=False, force=False):
        if force:
            self.task.send_key('f', after_sleep=0.05)
        if check_f_on_switch and not bool(getattr(self, 'check_f_on_switch', False)):
            return False
        return bool(self.task.f_break())

    @staticmethod
    def _fr_role_type_value(obj):
        raw = getattr(obj, '_char_type', None)
        raw = getattr(raw, 'value', raw)
        return str(raw or '').replace('_', '').replace('-', '').casefold()

    def _fr_is_sub_dps(self):
        return self._fr_role_type_value(self) in {'subdps', 'chartype.subdps'}

    def _fr_is_healer(self):
        return self._fr_role_type_value(self) in {'healer', 'chartype.healer'}

    def _fr_switch_out(self, con_full=False):
        """冻结切下场 bookkeeping；实际切人仍由 FSM 的 _switch_to 控制。"""
        self.last_switch_time = time.time()
        switched_with_full_con = bool(
            con_full or float(getattr(self, 'current_con', 0) or 0) == 1.0
        )
        if self._fr_is_healer() and switched_with_full_con:
            self.last_full_con_switch_time = self.last_switch_time

        self.is_current_char = False
        self.has_intro = False
        self.has_sub_dps_intro = False

        if switched_with_full_con:
            if float(getattr(self, '_buff_time', 0) or 0) > 0:
                self.last_buff_time = self.last_switch_time
            self.current_con = 0

    def _fr_priority(self, name):
        """解析 OK-WW 当前版本的 SwitchPriority，而不直接 import BaseChar。"""
        wanted = str(name).upper()
        for cls in type(self).__mro__:
            fn = cls.__dict__.get('get_switch_priority')
            globals_map = getattr(fn, '__globals__', None) if fn else None
            if not isinstance(globals_map, dict):
                continue
            for symbol in ('SwitchPriority', 'Priority'):
                enum_cls = globals_map.get(symbol)
                if enum_cls is not None and hasattr(enum_cls, wanted):
                    return getattr(enum_cls, wanted)

        # 当前 IntEnum 版 OK-WW 的兼容后备值；正常情况下不会走到这里。
        return 400 if wanted == 'MUST' else 0


class Mornye(_FiveRFrozenRuntime, BuiltinMornye):
    """5R双处决V2.7：共享FSM + 角色本地动作模块。"""
    FSM_VERSION = '5R双处决V2.7'

    STATE_KEY = 'five_r_double_execution_state'

    SIGNATURE_KEY = 'five_r_double_execution_signature'

    ROLE_LUCY = 'Lucy'

    ROLE_REBECCA = 'Rebecca'

    ROLE_MORNYE = 'Mornye'

    P1_S1 = 'P1-1 等自动索敌-Lucy Z0.3-闪避-续Z1.2启动挑战'

    P1_S2A = 'P1-2A Lucy自然切Rebecca'

    P1_S2B = 'P1-2B Rebecca E进CD即自然切Mornye'

    P1_S3 = 'P1-3 Mornye攒特殊Z门-R预输入Z-切Rebecca'

    P1_S4 = 'P1-4 Rebecca第二发Z-切Lucy'

    P1_S5 = 'P1-5 Lucy E1-Z0.8且0.5开始切Rebecca'

    P1_S6 = 'P1-6 Rebecca第二发Z-切Lucy'

    P1_S7 = 'P1-7 Lucy E2-Z0.8且0.5开始切Rebecca'

    P1_S8 = 'P1-8 Rebecca第二发Z-预输入Z-切Lucy'

    P1_S9 = 'P1-9 Lucy继承Z持续0.8且0.5开始切Rebecca'

    P1_S10 = 'P1-10 继承强化Z确认-协奏50%门-立即R/HMG-切Lucy'

    P1_S11 = 'P1-11 Lucy等特殊E-F/Q机会窗并释放特殊E'

    P1_S12 = 'P1-12 Lucy持续补能-F/Q机会窗-双门完成'

    P1_S13 = 'P1-13 Lucy继承预输入特殊Z-额外0.1-R1未好A等待-R1-11A-HOLD1.5-干净特殊变奏Mornye'

    P2_S1 = 'P2-1 Mornye特殊变奏-A补协奏90%-E-特殊变奏Rebecca'

    P2_S2A = 'P2-2A Rebecca特殊变奏-A落地-0.2s武器监控-手枪E进CD-预输入Z'

    P2_S2B = 'P2-2B Rebecca预输入Z完成后自然切Lucy'

    P2_S3 = 'P2-3 Lucy E1-Z0.8且0.5开始切Rebecca'

    P2_S4 = 'P2-4 Rebecca霰弹枪Z补F-实时监测F随亮随插-F后立即切Lucy'

    P2_S5 = 'P2-5 Lucy E2后干净切Rebecca'

    P2_S6 = 'P2-6 Rebecca干净切Lucy-目标侧late预输入Z'

    P2_S7 = 'P2-7 Lucy继承Z持续0.8且0.5开始切Mornye'

    P2_S8 = 'P2-8 Mornye攒特殊Z门-R后按变奏决定Rebecca入场Z'

    P2_S9 = 'P2-9 本轮强化Z记账-必要时偏斜门强化Z-协奏50%-立即R/HMG-切Lucy'

    P2_S10 = 'P2-10 Lucy等特殊E-F/Q机会窗并释放特殊E'

    P2_S11 = 'P2-11 Lucy持续补能-F/Q机会窗-双门完成'

    P2_S12 = 'P2-12 Lucy继承预输入特殊Z-额外0.1-R1未好A等待-R1-11A-HOLD1.5-干净特殊变奏Mornye'

    STEP_ACTOR = {
        P1_S1: ROLE_LUCY,
        P1_S2A: ROLE_LUCY,
        P1_S2B: ROLE_REBECCA,
        P1_S3: ROLE_MORNYE,
        P1_S4: ROLE_REBECCA,
        P1_S5: ROLE_LUCY,
        P1_S6: ROLE_REBECCA,
        P1_S7: ROLE_LUCY,
        P1_S8: ROLE_REBECCA,
        P1_S9: ROLE_LUCY,
        P1_S10: ROLE_REBECCA,
        P1_S11: ROLE_LUCY,
        P1_S12: ROLE_LUCY,
        P1_S13: ROLE_LUCY,
        P2_S1: ROLE_MORNYE,
        P2_S2A: ROLE_REBECCA,
        P2_S2B: ROLE_REBECCA,
        P2_S3: ROLE_LUCY,
        P2_S4: ROLE_REBECCA,
        P2_S5: ROLE_LUCY,
        P2_S6: ROLE_REBECCA,
        P2_S7: ROLE_LUCY,
        P2_S8: ROLE_MORNYE,
        P2_S9: ROLE_REBECCA,
        P2_S10: ROLE_LUCY,
        P2_S11: ROLE_LUCY,
        P2_S12: ROLE_LUCY,
    }

    STATE_POLL = 0.04

    ACTION_RETRY = 0.08

    SWITCH_RETRY = 0.04

    SWITCH_TIMEOUT = 6.0

    SWITCH_UNTRUSTED_CONFIRM = 2

    CONCERTO_EFFECTIVE_FULL = 0.99

    INTRO_CONFIRM_FRAMES = 3

    INTRO_CONFIRM_TIMEOUT = 1.5

    INTRO_FILL_TIMEOUT = 6.0

    P1_S1_DODGE_OFFSET = 0.30

    P1_S1_POST_DODGE_HOLD = 1.20

    P1_S1_LUCY_Z_DURATION = P1_S1_DODGE_OFFSET + P1_S1_POST_DODGE_HOLD

    REBECCA_FORTE_OFF_CONFIRM_FRAMES = 2

    REBECCA_PREINPUT_FORTE_WATCH = 0.18

    P2_S1_CONCERTO_E_GATE = 0.90

    CONCERTO_GATE_FILL_TIMEOUT = 10.0

    # 偏斜状态来自共享FSM；5.5s固定CD仍是唯一主门。
    DEFLECTION_CD = 5.50
    DEFLECTION_VISUAL_READY_THRESHOLD = 0.90

    # V2.1偏斜视觉传感器：只采样/记录，不参与FSM决策。
    # ROI来自用户确认的Boss血条左侧圆圈；12点为0号扇区，顺时针编号。
    DEFLECTION_SENSOR_SAMPLE_INTERVAL = 0.20
    DEFLECTION_SENSOR_LOG_INTERVAL = 0.50
    DEFLECTION_SENSOR_SECTORS = 12
    DEFLECTION_SENSOR_ROI_3840 = (1176, 60, 1310, 194)
    DEFLECTION_SENSOR_INNER_RADIUS_RATIO = 0.65
    DEFLECTION_SENSOR_OUTER_RADIUS_RATIO = 0.93

    PREINPUT_REARM_LIMIT = 3

    def do_perform(self):
        """共享FSM只保存STEP；Mornye文件只执行属于Mornye自己的动作模块。"""
        if not self._five_r_team_matches():
            return super().do_perform()

        state = self._get_fsm_state()
        self._service_deflection_status(state)

        # 跨角色预输入/切人两阶段提交优先恢复；只恢复handoff，不重放已完成动作。
        if state.get('pending_handoff'):
            return self._resume_pending_handoff(state)

        step = state.get('step', self.P1_S1)
        expected = self.STEP_ACTOR.get(step)

        if expected != self.ROLE_MORNYE:
            return self._recover_wrong_actor(state)

        self.logger.info(
            f'[{self.FSM_VERSION}] Mornye FSM step={step} intro={self.has_intro} '
            f'instance={state.get("step_instance_id", 0)}'
        )

        if step == self.P1_S3:
            return self._p1_s3(state)
        if step == self.P2_S1:
            return self._p2_s1(state)
        if step == self.P2_S8:
            return self._p2_s8(state)

        self.logger.error(
            f'[{self.FSM_VERSION}] Mornye owns step={step} but has no handler; reset opening'
        )
        self._clear_five_r_fsm_state(clear_signature=False, reason='missing role handler')
        return None

    @classmethod
    def _expected_actor(cls, step):
        return cls.STEP_ACTOR.get(step)

    def _recover_wrong_actor(self, state):
        """对齐红绿灯轴：当前角色不属于当前STEP时，只切到STEP_ACTOR指定角色。"""
        step = state.get('step', self.P1_S1)
        actor = self._expected_actor(step)
        if actor and actor != self.ROLE_MORNYE:
            self.logger.warning(
                f'[{self.FSM_VERSION}] Mornye got step={step}, expected actor={actor}; '
                f'switch to expected actor'
            )
            return self._switch_to(actor, expect_intro=None)

        self.logger.error(
            f'[{self.FSM_VERSION}] Mornye unknown/unhandled FSM step={step}; reset opening'
        )
        self._clear_five_r_fsm_state(clear_signature=False, reason='unknown step')
        self._get_fsm_state()
        return None

    def _p1_s3(self, state):
        if not self._mornye_wait_special_z_gate():
            return
        if not self._cast_liberation_hud(preinput=True, label='P1-3 Mornye R'):
            return
        self._start_handoff(
            state, self.ROLE_REBECCA, self.P1_S4,
            expect_intro=None, preinput=True, existing_hold=True, target_hold=0.0
        )

    def _p2_s1(self, state):
        """Mornye特殊变奏入场；A补到90%协奏后E，再强制特殊变奏Rebecca。"""
        phase_key = 'p2_s1_phase'
        phase = state.get(phase_key, 'fill_90')

        if phase == 'fill_90':
            # 保留原轴的“特殊变奏升空后再开始A”语义；不使用wait_down。
            entry_key = 'p2_s1_entry_ready'
            if not state.get(entry_key, False):
                entry_start = time.time()
                while time.time() - entry_start < 1.2 and not self._fr_has_long_action2():
                    self.task.next_frame()
                    self._fr_sleep(self.STATE_POLL, check_combat=False)
                state[entry_key] = True

            if not self._fill_concerto_with_normal_attacks(
                threshold=self.P2_S1_CONCERTO_E_GATE,
                label='P2-1 Mornye before E',
            ):
                return
            state[phase_key] = 'cast_e'
            phase = 'cast_e'

        if phase == 'cast_e':
            if not self._cast_resonance_confirmed('P2-1 Mornye E at >=90% concerto'):
                return
            state[phase_key] = 'special_intro_rebecca'
            phase = 'special_intro_rebecca'

        if phase == 'special_intro_rebecca':
            if self._start_handoff(
                state, self.ROLE_REBECCA, self.P2_S2A, expect_intro=True
            ):
                state.pop(phase_key, None)
                state.pop('p2_s1_entry_ready', None)
            return

    def _p2_s8(self, state):
        self.logger.info(f'[{self.FSM_VERSION}] P2-8 Mornye entry preinput Z inherited -> INPUT_COMMITTED')
        if not self._mornye_wait_special_z_gate():
            return
        if not self._cast_liberation_hud(preinput=True, label='P2-8 Mornye R'):
            return

        # 自然切Rebecca前先看当前协奏。若会触发特殊变奏，特殊变奏本身会切枪，
        # 所以必须先取消跨角色Z预输入，等Rebecca入场后E纠枪，再Z。
        will_intro = self._concerto_effectively_full()
        state['p2_s9_expected_special_intro'] = bool(will_intro)
        if will_intro:
            self.logger.info(
                f'[{self.FSM_VERSION}] P2-8 natural switch predicted SPECIAL INTRO -> '
                f'release Mornye R preinput before switching Rebecca'
            )
            self._safe_mouse_up(state)
            self._start_handoff(
                state, self.ROLE_REBECCA, self.P2_S9,
                expect_intro=None, preinput=False,
            )
        else:
            self.logger.info(
                f'[{self.FSM_VERSION}] P2-8 natural switch predicted NORMAL -> '
                f'keep Z preinput into Rebecca'
            )
            self._start_handoff(
                state, self.ROLE_REBECCA, self.P2_S9,
                expect_intro=None, preinput=True, existing_hold=True, target_hold=0.0
            )

    def _fill_concerto_with_normal_attacks(self, threshold, label):
        """Mornye专属：持续A补协奏到指定阈值。"""
        start = time.time()
        last_attack = -100.0
        last_log = -100.0
        while self._fr_time_elapsed_accounting_for_freeze(start) < self.CONCERTO_GATE_FILL_TIMEOUT:
            self.task.next_frame()
            con = self._read_concerto_progress()
            if con >= threshold or self._raw_con_full():
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: concerto={con:.3f} >= {threshold:.2f} -> gate passed'
                )
                return True

            now = time.time()
            if now - last_log >= 0.5:
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: concerto={con:.3f} < {threshold:.2f} -> Mornye A fill'
                )
                last_log = now
            if now - last_attack >= 0.10:
                self._fr_normal_attack()
                last_attack = now
            self._fr_sleep(self.STATE_POLL, check_combat=False)

        self.logger.warning(
            f'[{self.FSM_VERSION}] {label}: concerto did not reach {threshold:.0%} within '
            f'{self.CONCERTO_GATE_FILL_TIMEOUT:.1f}s'
        )
        return False

    def _mornye_wait_special_z_gate(self):
        """只等 mouse_forte READY；本阶段不在 Mornye 身上消费特殊Z。"""
        start = time.time()
        while time.time() - start < 8.0:
            self.task.next_frame()
            if self._fr_is_mouse_forte_full():
                self.logger.info(f'[{self.FSM_VERSION}] Mornye special-Z gate READY')
                return True
            self._fr_normal_attack()
            self._fr_sleep(0.08)
        self.logger.warning(f'[{self.FSM_VERSION}] Mornye special-Z gate timeout')
        return False

    def _cast_resonance_confirmed(self, label):
        start = time.time()
        sent = False
        last_send = -100.0
        while time.time() - start < 1.2:
            self.task.next_frame()
            if sent and (self._fr_has_cd('resonance') or not self._fr_resonance_available()):
                self._fr_record_resonance_use()
                self.logger.info(f'[{self.FSM_VERSION}] {label} CONFIRMED')
                return True

            now = time.time()
            if self._fr_resonance_available() and now - last_send >= self.ACTION_RETRY:
                self._fr_send_resonance_key()
                sent = True
                last_send = now
            self._fr_sleep(self.STATE_POLL, check_combat=False)

        self.logger.warning(f'[{self.FSM_VERSION}] {label} timeout')
        return False

    def _cast_liberation_hud(self, preinput, label):
        """
        不使用 click_liberation 默认 click_f=True，避免把流程中明确调度的 F 偷偷打掉。
        连续两帧队伍HUD消失 -> R启动；HUD恢复 -> R结束。
        preinput=True 时，在 R 演出确认开始后按住鼠标，直到后续跨角色 handoff 消费。
        """
        start = time.time()
        last_send = -100.0
        off_frames = 0
        anim_start = None

        while time.time() - start < 2.0:
            self.task.next_frame()
            in_team = bool(self.task.in_team()[0])

            if not in_team:
                off_frames += 1
                if off_frames >= 2:
                    anim_start = time.time()
                    self.task.in_liberation = True
                    break
            else:
                off_frames = 0
                now = time.time()
                if now - last_send >= self.ACTION_RETRY:
                    self._fr_send_liberation_key()
                    last_send = now

            self._fr_sleep(self.STATE_POLL, check_combat=False)

        if anim_start is None:
            self.logger.warning(f'[{self.FSM_VERSION}] {label}: R start HUD ACK timeout')
            return False

        if preinput:
            self.task.mouse_down()
            state = self._get_fsm_state()
            state['mouse_hold_active'] = True
            self.logger.info(f'[{self.FSM_VERSION}] {label}: Z preinput ARMED during R animation')

        wait_start = time.time()
        while time.time() - wait_start < 10.0:
            self.task.next_frame()
            if self.task.in_team()[0]:
                self.task.in_liberation = False
                duration = max(0.0, time.time() - anim_start)
                self._fr_add_freeze_duration(anim_start, duration)
                self._fr_record_liberation_use()
                self.logger.info(
                    f'[{self.FSM_VERSION}] {label}: R HUD restored duration={duration:.2f}s'
                )
                return True
            self._fr_sleep(self.STATE_POLL, check_combat=False)

        self.task.in_liberation = False
        if preinput:
            self._safe_mouse_up(self._get_fsm_state())
        self.logger.warning(f'[{self.FSM_VERSION}] {label}: R HUD return timeout')
        return False

    def _role_name(self, char=None):
        char = self if char is None else char
        raw = str(getattr(char, 'char_name', '') or '').casefold().removeprefix('labels.')
        if raw == 'char_lucy':
            return self.ROLE_LUCY
        if raw == 'char_rebecca':
            return self.ROLE_REBECCA
        if raw in {'char_mornye', 'char_moning'}:
            return self.ROLE_MORNYE

        cls = char.__class__.__name__.casefold()
        if cls == 'lucy':
            return self.ROLE_LUCY
        if cls == 'rebecca':
            return self.ROLE_REBECCA
        if cls == 'mornye':
            return self.ROLE_MORNYE
        return char.__class__.__name__

    def _find_target_char(self, target_role):
        for char in getattr(self.task, 'chars', []):
            if char is not None and char is not self and self._role_name(char) == target_role:
                return char
        return None

    def _raw_con_full(self):
        try:
            return bool(self.task.is_con_full())
        except Exception:
            return False

    def _deflection_elapsed_shared(self, state):
        t0 = state.get('deflection_cd_started_at')
        if not isinstance(t0, (int, float)):
            return 999.0
        return max(0.0, float(self._fr_time_elapsed_accounting_for_freeze(t0)))

    def _deflection_visual_ready(self):
        """成熟f_break_full READY模板；只作辅助视觉证据。"""
        try:
            return bool(
                self.task.find_one(
                    Labels.f_break_full,
                    threshold=self.DEFLECTION_VISUAL_READY_THRESHOLD,
                )
            )
        except Exception:
            return False


    def _get_deflection_visual_sensor_box(self):
        """Boss血条左侧偏斜圆圈的用户确认ROI；仅用于被动采样。"""
        x1, y1, x2, y2 = self.DEFLECTION_SENSOR_ROI_3840
        return self.task.box_of_screen_scaled(
            3840, 2160, x1, y1, x2, y2,
            name='deflection_visual_sensor', hcenter=True,
        )

    def _sample_deflection_visual_raw(self):
        """
        被动采样偏斜圆圈。

        不在这里判断0~100%进度，也不产生READY/CD控制结论。
        只输出：成熟f_break_full命中 + 12个顺时针扇区的原始灰度统计，
        用下一轮实机日志标定是否能复用成熟圆环方案。
        """
        try:
            box = self._get_deflection_visual_sensor_box()
            frame = getattr(self.task, 'frame', None)
            if frame is None:
                return None
            crop = box.crop_frame(frame)
            if crop is None or crop.size == 0:
                return None

            gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
            h, w = gray.shape[:2]
            if h < 12 or w < 12:
                return None

            cx = (w - 1) / 2.0
            cy = (h - 1) / 2.0
            yy, xx = np.indices((h, w), dtype=np.float32)
            dx = xx - cx
            dy = yy - cy
            radius = np.sqrt(dx * dx + dy * dy)
            max_r = min(w, h) / 2.0
            annulus = (
                (radius >= max_r * self.DEFLECTION_SENSOR_INNER_RADIUS_RATIO)
                & (radius <= max_r * self.DEFLECTION_SENSOR_OUTER_RADIUS_RATIO)
            )

            # 0 rad = 12点；正方向 = 顺时针。
            angle = (np.arctan2(dx, -dy) + 2.0 * np.pi) % (2.0 * np.pi)
            sector_width = 2.0 * np.pi / float(self.DEFLECTION_SENSOR_SECTORS)
            sector_ids = np.floor(angle / sector_width).astype(np.int16)

            sector_p75 = []
            sector_mean = []
            for idx in range(self.DEFLECTION_SENSOR_SECTORS):
                vals = gray[annulus & (sector_ids == idx)]
                if vals.size == 0:
                    sector_p75.append(-1)
                    sector_mean.append(-1)
                    continue
                sector_p75.append(int(round(float(np.percentile(vals, 75)))))
                sector_mean.append(int(round(float(np.mean(vals)))))

            ring_vals = gray[annulus]
            if ring_vals.size == 0:
                return None

            try:
                ready_template = bool(
                    self.task.find_one(
                        Labels.f_break_full,
                        threshold=self.DEFLECTION_VISUAL_READY_THRESHOLD,
                    )
                )
            except Exception:
                ready_template = False

            return {
                'template_ready': ready_template,
                'sector_p75': tuple(sector_p75),
                'sector_mean': tuple(sector_mean),
                'ring_mean': float(np.mean(ring_vals)),
                'ring_p90': float(np.percentile(ring_vals, 90)),
            }
        except Exception:
            return None

    def _read_deflection_visual_progress(self, state=None):
        """测试骨架暂不把原始扇区亮度硬映射成0~1；待实机日志标定后再实现。"""
        return None

    def _service_deflection_visual_sensor(self, state, timer_ready=None, force=False):
        """
        被动偏斜视觉传感器。

        - 不改变deflection_cd_started_at；
        - 不改变5.5s主门；
        - 不提前放行强化Z；
        - 只把原始12扇区数据写入共享state并低频输出测试日志。
        """
        now = time.time()
        last_sample = float(state.get('deflection_sensor_sample_at', -100.0) or -100.0)
        if not force and now - last_sample < self.DEFLECTION_SENSOR_SAMPLE_INTERVAL:
            return state.get('deflection_sensor_latest')

        state['deflection_sensor_sample_at'] = now
        sample = self._sample_deflection_visual_raw()
        state['deflection_sensor_latest'] = sample
        if sample is None:
            return None

        state['deflection_visual_ready'] = bool(sample['template_ready'])
        if timer_ready is False:
            visual_state = 'CD_TIMER'
        elif sample['template_ready']:
            visual_state = 'F_READY_TEMPLATE'
        else:
            visual_state = 'BUILD_OR_UNKNOWN'
        state['deflection_sensor_visual_state'] = visual_state

        last_log = float(state.get('deflection_sensor_log_at', -100.0) or -100.0)
        previous_state = state.get('deflection_sensor_logged_state')
        template_changed = state.get('deflection_sensor_logged_template') != bool(sample['template_ready'])
        should_log = (
            force
            or visual_state != previous_state
            or template_changed
            or now - last_log >= self.DEFLECTION_SENSOR_LOG_INTERVAL
        )
        if should_log:
            p75 = ','.join(str(v) for v in sample['sector_p75'])
            self.logger.info(
                f'[{self.FSM_VERSION}] DEFLECTION_SENSOR raw state={visual_state} '
                f'template_ready={sample["template_ready"]} '
                f'ring_mean={sample["ring_mean"]:.1f} ring_p90={sample["ring_p90"]:.1f} '
                f'p75cw12=[{p75}]'
            )
            state['deflection_sensor_log_at'] = now
            state['deflection_sensor_logged_state'] = visual_state
            state['deflection_sensor_logged_template'] = bool(sample['template_ready'])
        return sample

    def _service_deflection_status(self, state, force=False):
        """5.5s固定CD是唯一主门；全局日志只在READY/COOLDOWN状态切换时输出。

        force只强制刷新视觉传感器，不再强制打印remaining。
        STEP自己的remaining决策日志继续保留。
        """
        ready = self._deflection_elapsed_shared(state) >= self.DEFLECTION_CD
        current = 'READY' if ready else 'COOLDOWN'
        previous = state.get('deflection_status_last')

        self._service_deflection_visual_sensor(state, timer_ready=ready, force=force)
        visual_ready = bool(state.get('deflection_visual_ready', False))

        if current != previous:
            if ready:
                self.logger.info(
                    f'[{self.FSM_VERSION}] DEFLECTION READY by fixed {self.DEFLECTION_CD:.2f}s timer '
                    f'visual_ready={visual_ready} (aux only)'
                )
            else:
                self.logger.info(
                    f'[{self.FSM_VERSION}] DEFLECTION CD START fixed={self.DEFLECTION_CD:.2f}s '
                    f'visual_ready={visual_ready} (aux only)'
                )
            state['deflection_status_last'] = current
        return ready

    def _read_concerto_progress(self):
        if self._raw_con_full():
            return 1.0
        try:
            value = float(self.task.get_current_con())
        except Exception:
            try:
                value = float(self._fr_get_current_con())
            except Exception:
                return 0.0
        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        return self._raw_con_full() or self._read_concerto_progress() >= self.CONCERTO_EFFECTIVE_FULL

    def _confirm_special_intro_ready(self, target_role):
        # 特殊变奏必须真的满；不足时用A补，不偷降级成普通切。
        fill_start = time.time()
        while time.time() - fill_start < self.INTRO_FILL_TIMEOUT and not self._raw_con_full():
            self._fr_normal_attack()
            self._fr_sleep(0.08)
            self.task.next_frame()

        start = time.time()
        full_frames = 0
        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            self.task.next_frame()
            if self._raw_con_full():
                full_frames += 1
                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'[{self.FSM_VERSION}] special intro -> {target_role}: '
                        f'raw full {full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                    )
                    return True
            else:
                full_frames = 0
            self._fr_sleep(self.STATE_POLL, check_combat=False)

        self.logger.warning(
            f'[{self.FSM_VERSION}] special intro -> {target_role}: concerto full confirm timeout'
        )
        return False

    def _switch_to(self, target_role, expect_intro=None):
        """
        expect_intro=None：自然切，当前真实协奏决定普通切/变奏。
        expect_intro=False：明确普通切。
        expect_intro=True：明确特殊变奏，协奏不满则先补满，绝不偷降级。
        """
        target = self._find_target_char(target_role)
        if target is None:
            self.logger.error(f'[{self.FSM_VERSION}] target not found: {target_role}')
            return False

        if expect_intro is True:
            if not self._confirm_special_intro_ready(target_role):
                return False
            has_intro = True
        elif expect_intro is False:
            if self._concerto_effectively_full():
                self.logger.warning(
                    f'[{self.FSM_VERSION}] block forced-normal switch -> {target_role}: concerto full'
                )
                return False
            has_intro = False
        else:
            # 自然切：沿用忌炎轴实机经验，raw full 或 0.99 都视为满。
            has_intro = self._concerto_effectively_full()

        target.has_intro = has_intro
        target.has_sub_dps_intro = has_intro and self._fr_is_sub_dps()

        start = time.time()
        last_send = -100.0
        untrusted_hits = 0
        send_count = 0
        team_size = len([c for c in getattr(self.task, 'chars', []) if c is not None])

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.task.next_frame()
            try:
                in_team, current_index, count = self.task.in_team()
            except Exception:
                in_team, current_index, count = False, -1, 0

            hit = in_team and current_index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0

            if hit and (trusted or untrusted_hits >= self.SWITCH_UNTRUSTED_CONFIRM):
                self.task.in_liberation = False
                target.is_current_char = True
                self._fr_switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self._fr_add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
                    self.last_outro_time = now

                self.logger.info(
                    f'[{self.FSM_VERSION}] switch ACK {self._role_name()} -> {target_role} '
                    f'intro={has_intro} trusted={trusted} sends={send_count}'
                )
                return True

            if in_team:
                self._fr_check_combat()

            now = time.time()
            if now - last_send >= self.SWITCH_RETRY:
                self.task.send_key(target.index + 1)
                last_send = now
                send_count += 1

            self._fr_sleep(self.SWITCH_RETRY, check_combat=False)

        self.logger.warning(
            f'[{self.FSM_VERSION}] exact switch timeout -> {target_role} sends={send_count}'
        )
        return False

    def _start_handoff(
        self,
        state,
        target_role,
        next_step,
        expect_intro=None,
        preinput=False,
        existing_hold=False,
        target_hold=0.0,
        release_at=None,
        watch_rebecca_enhanced=False,
        keep_hold_after_handoff=False,
    ):
        if state.get('pending_handoff'):
            return self._resume_pending_handoff(state)

        pending = {
            'source_step': state.get('step'),
            'target_role': target_role,
            'next_step': next_step,
            'expect_intro': expect_intro,
            'preinput': bool(preinput),
            'target_hold': max(0.0, float(target_hold or 0.0)),
            'release_at': release_at,
            'watch_rebecca_enhanced': bool(watch_rebecca_enhanced),
            'keep_hold_after_handoff': bool(keep_hold_after_handoff),
            'rearm_count': 0,
            'created_at': time.time(),
        }
        state['pending_handoff'] = pending

        if preinput and not existing_hold:
            self.task.mouse_down()
            state['mouse_hold_active'] = True
            self.logger.info(
                f'[{self.FSM_VERSION}] preinput Z ARMED -> {target_role}, next={next_step}'
            )
        elif preinput and existing_hold:
            state['mouse_hold_active'] = True

        return self._resume_pending_handoff(state)

    def _resume_pending_handoff(self, state):
        pending = state.get('pending_handoff')
        if not isinstance(pending, dict):
            state.pop('pending_handoff', None)
            return False

        target_role = pending.get('target_role')
        next_step = pending.get('next_step')
        preinput = bool(pending.get('preinput'))

        target = self if self._role_name() == target_role else self._find_target_char(target_role)
        if target is None:
            self.logger.error(f'[{self.FSM_VERSION}] pending target missing: {target_role}')
            self._safe_mouse_up(state)
            return False

        # 可能切人其实已经成功，只是在提交 STEP 前异常中断。
        try:
            in_team, current_index, _ = self.task.in_team()
            already_target = bool(in_team and current_index == target.index)
        except Exception:
            already_target = bool(getattr(target, 'is_current_char', False))

        if preinput and not state.get('mouse_hold_active', False) and not already_target:
            count = int(pending.get('rearm_count', 0))
            if count < self.PREINPUT_REARM_LIMIT:
                self.task.mouse_down()
                state['mouse_hold_active'] = True
                pending['rearm_count'] = count + 1
                self.logger.warning(
                    f'[{self.FSM_VERSION}] preinput Z REARM {count + 1}/{self.PREINPUT_REARM_LIMIT} '
                    f'-> {target_role}'
                )
            else:
                pending['preinput'] = False
                preinput = False
                self.logger.error(
                    f'[{self.FSM_VERSION}] preinput rearm budget exhausted -> '
                    f'degraded switch without Z to {target_role}'
                )

        success = already_target or self._switch_to(
            target_role,
            expect_intro=pending.get('expect_intro'),
        )

        if not success:
            # 失败时绝不让鼠标永久保持按下；保留 pending，下一轮只重试 handoff。
            if state.get('mouse_hold_active', False):
                self._safe_mouse_up(state)
            return False

        if preinput and state.get('mouse_hold_active', False):
            release_at = pending.get('release_at')
            if isinstance(release_at, (int, float)):
                self._wait_wall_until(float(release_at))
            else:
                hold = float(pending.get('target_hold', 0.0) or 0.0)
                if hold > 0:
                    self._fr_sleep(hold, check_combat=False)
                else:
                    # 至少让目标角色存在一个有效帧再松鼠标。
                    self.task.next_frame()

            # P1-S9 -> P1-S10专项：这发跨角色hold本身可能就是Rebecca强化Z。
            # 在松手前额外观察一小段mouse_forte；若见FULL，松手后必须追OFF，
            # 这样P1-S10就能知道强化Z已在入场预输入中完成，而不是继续无限Z。
            watch_rebecca = bool(
                pending.get('watch_rebecca_enhanced')
                and target_role == self.ROLE_REBECCA
            )
            seen_full = False
            if watch_rebecca:
                watch_start = time.time()
                while time.time() - watch_start < self.REBECCA_PREINPUT_FORTE_WATCH:
                    self.task.next_frame()
                    # V1.3：入场切换动画期间能量ROI可能短暂归零，不能拿它做强化Z主确认。
                    # 这里仅保留mouse_forte作为辅助观察；能量主判据从P1-S10本次Z尝试重新建基线。
                    if self._fr_is_mouse_forte_full():
                        seen_full = True
                        self.logger.info(
                            f'[{self.FSM_VERSION}] inherited Rebecca Z: AUX mouse_forte FULL '
                            f'before release at +{time.time() - watch_start:.3f}s'
                        )
                    self._fr_sleep(0.02, check_combat=False)

            keep_hold = bool(pending.get('keep_hold_after_handoff'))
            if keep_hold:
                self.logger.info(
                    f'[{self.FSM_VERSION}] inherited/preinput Z KEEPING mouse DOWN on {target_role}'
                )
            else:
                self._safe_mouse_up(state)

            if watch_rebecca and not keep_hold:
                # 即使松手前没抓到FULL，也继续短暂观察；某些情况下提示会在mouse_up后才出现，
                # 只要捕获到FULL->连续OFF，就把这发入场预输入记为已消费强化Z。
                observe_start = time.time()
                off_frames = 0
                while time.time() - observe_start < 0.45:
                    self.task.next_frame()
                    full = bool(self._fr_is_mouse_forte_full())
                    if full:
                        if not seen_full:
                            self.logger.info(
                                f'[{self.FSM_VERSION}] inherited Rebecca Z: mouse_forte FULL '
                                f'appeared after release at +{time.time() - observe_start:.3f}s'
                            )
                        seen_full = True
                        off_frames = 0
                    elif seen_full:
                        off_frames += 1
                        if off_frames >= self.REBECCA_FORTE_OFF_CONFIRM_FRAMES:
                            state['rebecca_enhanced_consumed_at'] = time.time()
                            state['rebecca_enhanced_consumed_label'] = 'Rebecca entry preinput enhanced Z'
                            self.logger.info(
                                f'[{self.FSM_VERSION}] Rebecca entry preinput enhanced Z: '
                                f'FULL->OFF consumption recorded in shared FSM state'
                            )
                            break
                    self._fr_sleep(0.02, check_combat=False)

            if keep_hold:
                self.logger.info(
                    f'[{self.FSM_VERSION}] inherited/preinput Z remains HELD on {target_role}'
                )
            else:
                self.logger.info(
                    f'[{self.FSM_VERSION}] inherited/preinput Z released on {target_role} '
                    f'-> INPUT_COMMITTED'
                )

        # 两阶段提交：先写新 STEP，再清 pending。
        self._set_step(state, next_step)
        state.pop('pending_handoff', None)
        return True

    def _safe_mouse_up(self, state):
        try:
            self.task.mouse_up()
        finally:
            state['mouse_hold_active'] = False

    def _set_step(self, state, step):
        old = state.get('step')
        state['step'] = step
        state['step_instance_id'] = int(state.get('step_instance_id', 0)) + 1
        self.logger.info(
            f'[{self.FSM_VERSION}] STEP COMMIT {old} -> {step} '
            f'instance={state["step_instance_id"]}'
        )

    def _clear_five_r_fsm_state(self, clear_signature=False, reason='clear'):
        """统一清理共享FSM。对齐红绿灯轴：离开指定队伍或战斗结束时必须丢弃旧进度。"""
        state = getattr(self.task, self.STATE_KEY, None)
        if isinstance(state, dict) and state.get('mouse_hold_active'):
            self._safe_mouse_up(state)
        if hasattr(self.task, self.STATE_KEY):
            delattr(self.task, self.STATE_KEY)
        if clear_signature and hasattr(self.task, self.SIGNATURE_KEY):
            delattr(self.task, self.SIGNATURE_KEY)
        self.logger.info(f'[{self.FSM_VERSION}] FSM state cleared reason={reason}')

    def _get_fsm_state(self):
        state = getattr(self.task, self.STATE_KEY, None)
        combat_start = float(getattr(self.task, 'combat_start', 0.0) or 0.0)

        # 额外保险：BaseCombatTask重新load_chars进入一场新战斗时会刷新combat_start。
        # 若框架某次没有及时走到on_combat_end，也不允许继承上一场的STEP。
        if isinstance(state, dict):
            saved_start = float(state.get('combat_start_token', 0.0) or 0.0)
            if combat_start > 0 and saved_start > 0 and abs(combat_start - saved_start) > 0.5:
                self._clear_five_r_fsm_state(
                    clear_signature=False,
                    reason=f'new combat_start {saved_start:.3f}->{combat_start:.3f}'
                )
                state = None

        if not isinstance(state, dict) or 'step' not in state:
            state = {
                'step': self.P1_S1,
                'step_instance_id': 1,
                'pending_handoff': None,
                'mouse_hold_active': False,
                'deflection_cd_started_at': None,
                'f_available': False,
                'last_f_check_at': -100.0,
                'rebecca_enhanced_consumed_at': None,
                'rebecca_enhanced_consumed_label': None,
                'combat_start_token': combat_start,
            }
            setattr(self.task, self.STATE_KEY, state)
            self.logger.info(
                f'[{self.FSM_VERSION}] initialize FSM -> {self.P1_S1} '
                f'combat_start={combat_start:.3f}'
            )
        return state

    def _five_r_team_matches(self):
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            self._clear_five_r_fsm_state(clear_signature=False, reason='chars unavailable')
            return False

        signature = tuple(
            (
                str(getattr(c, 'char_name', '') or '').casefold().removeprefix('labels.'),
                getattr(c, 'index', None),
            )
            for c in chars if c is not None
        )

        roles = {self._role_name(c) for c in chars if c is not None}
        matched = len(chars) == 3 and roles == {
            self.ROLE_LUCY, self.ROLE_REBECCA, self.ROLE_MORNYE
        }

        previous = getattr(self.task, self.SIGNATURE_KEY, None)
        if signature != previous:
            self._clear_five_r_fsm_state(clear_signature=False, reason='team signature changed')
            setattr(self.task, self.SIGNATURE_KEY, signature)
            self.logger.info(
                f'[{self.FSM_VERSION}] team signature changed matched={matched}: {signature}'
            )
        elif not matched:
            # 与用户提供的红绿灯轴一致：即便signature没变，只要当前不再匹配指定三人队，旧FSM也必须清掉。
            self._clear_five_r_fsm_state(clear_signature=False, reason='team temporarily not matched')
        return matched

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if not self._five_r_team_matches():
            return super().get_switch_priority(current_char, has_intro, target_low_con)

        state = self._get_fsm_state()
        pending = state.get('pending_handoff')
        expected = (
            pending.get('target_role')
            if isinstance(pending, dict)
            else self.STEP_ACTOR.get(state.get('step'))
        )
        return self._fr_priority('MUST') if self._role_name() == expected else self._fr_priority('NO')

    def on_combat_end(self, chars):
        # BaseCombatTask.combat_end()只调用当前角色的on_combat_end，因此共享FSM必须在这里无条件清理。
        # 不调用Mornye内置on_combat_end，避免其战斗结束自动switch_other_char副作用。
        self._clear_five_r_fsm_state(clear_signature=True, reason='combat end')
        return None

    def _wait_wall_until(self, deadline):
        while time.time() < deadline:
            self._fr_sleep(min(0.01, max(0.001, deadline - time.time())), check_combat=False)
