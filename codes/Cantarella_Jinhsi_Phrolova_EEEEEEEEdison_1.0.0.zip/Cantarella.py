import time
from src.char.BaseChar import BaseChar, SwitchPriority, forte_white_color


E2_TIME_OUT = 2.0


LOG_TICK = 1.0
HUD_GRACE = 5.0


class _FilteredLogger:
    """挡掉框架自身的英文日志行，其余原样转发。"""

    _BLOCKED = ('click_liberation end',)

    def __init__(self, inner):
        self._inner = inner

    def info(self, msg, *args, **kwargs):
        if not str(msg).startswith(self._BLOCKED):
            self._inner.info(msg, *args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._inner, name)

class Cantarella(BaseChar):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.logger = _FilteredLogger(self.logger)
        self.last_heavy = -1

        self.started = False

        self._startup_done = False
        self._force_switch_me = False
        self._entry_mode = None

    def f_break(self, check_f_on_switch=False, force=False):
        if force:
            return self.task.f_break()
        return False

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None

    def skip_combat_check(self):
        now = time.time()
        if self.task.in_team()[0]:
            self.task.jfk_hud_at = now
            self.task.jfk_hud_handed = False
            return True
        if not getattr(self.task, 'jfk_hud_at', 0):
            self.task.jfk_hud_at = now
        if now - self.task.jfk_hud_at < HUD_GRACE:
            return True
        if not getattr(self.task, 'jfk_hud_handed', False):
            self.task.jfk_hud_handed = True
            self._trace('脱战', '交还框架判定脱战',
                        reason=f'队伍界面连续 {HUD_GRACE:.0f} 秒读不到队伍', in_team=False)
        return False

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode=None):
        if target is None:
            self._log_switch_out()
            return super().switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            self._log_switch_out()
            return super().switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    def _log_switch_out(self):
        """交场读数一行（只留协奏列）。"""

        self._trace(getattr(self, '_last_trace_tag', None) or '切人',
                    '切人：发送切人键', con=self.get_current_con())

    CHAR_NAME = '坎特蕾拉'

    _TEAM_CHAR_NAMES = {'Phrolova': '弗洛洛', 'Jinhsi': '今汐'}

    _LOG_LABEL = {
        'res_pct': 'E图标',
        'cd': '冷却',
        'in_team': '在场',
        'avail': '可用',
        'con': '协奏',
        'lib': '大招就绪',
        'round': '轮次',
        'flying': '空中',
        'attacks': '左键',
        'forte': '强化条',
    }

    _RATIO_KEYS = ('res_pct', 'con')

    def _fmt_value(self, key, v):
        if isinstance(v, bool):
            return '是' if v else '否'
        if isinstance(v, float):
            return f'{v:.3f}' if key in self._RATIO_KEYS else f'{v:.2f}'
        return str(v)

    def _switch_label(self, class_name, mode):
        """拼「切{角色名}执行{节点}流程」标签。"""

        return f'切{self._TEAM_CHAR_NAMES.get(class_name, class_name)}执行{mode.upper()}流程'

    def _trace(self, tag, action, ok=None, reason=None, **data):
        """链路诊断埋点（只读，异常不外溢）。"""

        try:
            self._last_trace_tag = tag
            line = f'[{tag.upper()}]{self.CHAR_NAME}：{action}'
            if ok is not None:
                line += '成功' if ok else '失败'
                if not ok and reason:
                    line += f'，原因：{reason}'
            if data:
                line += '（' + '，'.join(
                    f'{self._LOG_LABEL.get(k, k)}{self._fmt_value(k, v)}' for k, v in data.items()) + '）'
            self.logger.info(line)
        except Exception:
            pass

    LIBER_EXTENDED_CONFIRM = 1.0
    LIBER_NO_EFFECT_HOLD = 2.0

    def _mark_liber_no_effect(self):
        """记下「按了 R 但没确认到演出」的时刻。"""

        self._liber_no_effect_at = time.time()

    def _recent_liber_no_effect(self):
        """2 秒内刚按过 R 但未确认演出。"""

        ts = getattr(self, '_liber_no_effect_at', 0)
        return bool(ts) and (time.time() - ts < self.LIBER_NO_EFFECT_HOLD)

    def _liberation_wait(self, tag, confirm=None, burst=1.0, press_interval=0.1):
        """发 R 并确认演出真的开始；未确认返回 False。"""

        self._trace(tag, '释放大招')
        if self.click_liberation(click_f=False):
            self._liber_no_effect_at = 0
            self._trace(tag, '释放大招', ok=True)
            return True
        start = time.time()
        confirm = self.LIBER_EXTENDED_CONFIRM if confirm is None else confirm

        if self.task.wait_until(lambda: not self.task.in_team()[0],
                                time_out=confirm,
                                post_action=self.click_with_interval):
            self._trace(tag, '释放大招', ok=True)
            self._trace(tag, '演出迟到，已自行接管收尾')
            self._wait_liberation_end(start)
            self._liber_no_effect_at = 0
            return True

        self._trace(tag, '释放大招', ok=False, reason='按R后未见演出',
                    con=self.get_current_con(), lib=bool(self.liberation_available()),
                    cd=bool(self.has_cd("liberation")), in_team=bool(self.task.in_team()[0]),
                    flying=bool(self.flying()))
        self._trace(tag, '补按压R')
        press_start = time.time()
        press_ts = press_start
        while time.time() - press_start < burst:
            if not self.task.in_team()[0]:
                self._trace(tag, '补按压R', ok=True)
                self._wait_liberation_end(press_ts)
                self._liber_no_effect_at = 0
                return True
            press_ts = time.time()
            self.send_liberation_key(after_sleep=press_interval)
            self.task.next_frame()
        self._trace(tag, '补按压R', ok=False, reason='补按后仍未确认演出',
                    lib=bool(self.liberation_available()),
                    cd=bool(self.has_cd("liberation")), in_team=bool(self.task.in_team()[0]),
                    flying=bool(self.flying()))

        self._mark_liber_no_effect()
        return False

    def _wait_liberation_end(self, start):
        """等迟到演出结束（框架已 return，收尾自己做）。"""

        self.task.in_liberation = True
        while not self.task.in_team()[0]:
            if time.time() - start > 7:
                break
            self.task.next_frame()
        self.task.in_liberation = False
        self.add_freeze_duration(start, time.time() - start)
        self.record_liberation_use()

    def _liberation_done_trace(self, tag):
        self._trace(tag, '大招未确认放出，仍照常交人')

    def _mark_startup_done(self):
        """循环轴一旦开始，整队标记「启动轴已完成」。"""

        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        if mode is None:
            if not self.started:
                mode = 'f1'
            elif getattr(self, '_startup_done', False):
                mode = 's1'
            else:
                self._trace('入口', '自然入场（启动轴进行中），交还框架切人')
                return self.switch_next_char()
        elif mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, f'perform_{mode}', None)
        if func is None:
            self._trace('入口', f'{mode} 未实现，交还框架切人')
            return self.switch_next_char()
        self._trace(mode, '进入动作体')
        func()

    def perform_f1(self):
        """启动轴 f1：E 裸发 → R → 强切弗洛洛 f1。"""

        if self.has_intro:
            self.wait_intro()
        self.send_resonance_key()
        self.record_resonance_use()
        self._trace('f1', '裸发普通E')
        self.task.next_frame()

        if not self._liberation_wait('f1'):
            self._liberation_done_trace('f1')
            return
        self._trace('f1', f'结束动作体，{self._switch_label("Phrolova", "f1")}')
        self._force_switch_to(self._find_teammate('Phrolova'), 'f1')

    def _icon_probe(self, tag, sample=0.3):
        """采样 E 图标基线并返回「是否已变化」判定闭包（当前无调用方）。"""

        """采样 E 图标基线，返回 (判定函数, base, threshold)——只读，不点击。

        判据（用户对弗洛洛同类场景的描述：「左键图标会变化，e 图标也会发生变化」）：
        `current_resonance()`（E 技能格白色像素比）相对基线变化 ≥ max(0.02, base*0.2)。
        base=0（HUD 还没渲染出来）时判定恒 False——此时任何“变化”都不可信（今汐 f1 踩过）。
        """
        base = 0.0
        start = time.time()
        while time.time() - start < sample:
            base = max(base, self.current_resonance())
            self.task.next_frame()
        threshold = max(0.02, base * 0.2) if base > 0 else 0.0
        self._trace(tag, '采样E图标基线')

        def changed():
            return threshold > 0 and abs(base - self.current_resonance()) >= threshold

        return changed, base, threshold

    def perform_f2(self):
        """启动轴 f2：重击 → 持续普攻 1.7s → 强切弗洛洛 f4。"""

        self._action_f2('f2', self._switch_label('Phrolova', 'f4'))
        self._force_switch_to(self._find_teammate('Phrolova'), 'f4')

    def perform_s1(self):
        """循环轴 s1：同 f2 动作体 → 强切弗洛洛 s4。"""

        self._action_f2('s1', self._switch_label('Phrolova', 's4'))
        self._force_switch_to(self._find_teammate('Phrolova'), 's4')

    def _action_f2(self, tag, nxt):
        """f2/s1 动作体：重击 → 持续普攻 1.7s → sleep 0.2s。"""

        if self.has_intro:
            self.wait_intro()
        self._trace(tag, '释放重击')
        heavy = self.heavy_click_forte(check_fun=self.is_mouse_forte_full)
        self.last_heavy = time.time()

        if heavy:
            self._trace(tag, '释放重击', ok=True)
        else:
            self._trace(tag, '释放重击', ok=False,
                        reason='进入时强化环未满，未蓄力' if heavy is None
                        else '按住 2 秒环未消耗')
        atk_start = time.time()

        log_tick = 0
        while time.time() - atk_start < 1.7:
            self.task.click()
            self.sleep(0.2)
            if time.time() - atk_start >= (log_tick + 1) * LOG_TICK:
                log_tick += 1
                self._trace(tag, f'持续普攻{log_tick}秒中')
            self.check_combat()
            self.task.next_frame()
        self.task.mouse_up()
        self._trace(tag, '松开左键')

        self._trace(tag, '持续普攻结束')

        self.sleep(0.2)
        self._trace(tag, '等待 0.2 秒，松开后落地再交场')
        self._trace(tag, f'结束动作体，{nxt}')

    def perform_f3(self):
        """启动轴 f3：E → sleep(1) → E → 强切今汐 f5。"""

        self._action_f3('f3', self._switch_label('Jinhsi', 'f5'))
        self._force_switch_to(self._find_teammate('Jinhsi'), 'f5')

    def perform_s2(self):
        """循环轴 s2：同 f3 动作体 → 强切今汐 s5。"""

        self._action_f3('s2', self._switch_label('Jinhsi', 's5'))
        self._force_switch_to(self._find_teammate('Jinhsi'), 's5')

    def _action_f3(self, tag, nxt):
        """f3/s2 动作体：单发 E1 → sleep(1) → click_resonance 放 E2。"""

        if self.has_intro:
            self.wait_intro()
        self.sleep(0.2)
        self._trace(tag, '等待 0.2 秒，入场稳定再发 E')
        self.send_resonance_key()
        self.record_resonance_use()
        self._trace(tag, '裸发强化E')
        self.task.next_frame()
        self.sleep(1)

        self._trace(tag, '释放普通E')
        clicked, _duration, _animated = self.click_resonance(send_click=False, time_out=E2_TIME_OUT)

        if self.has_cd('resonance'):
            self._trace(tag, '释放普通E', ok=True)
        else:
            self._trace(tag, '释放普通E', ok=False,
                        reason='E 没发出去（进入时图标不可用）' if not clicked
                        else f'E 发出去了但图标 {E2_TIME_OUT:g} 秒未灭')
            self._trace(tag, '坎特蕾拉双E失败，仍按链路交人')
        self.task.next_frame()
        self._trace(tag, f'结束动作体，{nxt}')

    def perform_f4(self):
        """启动轴 f4：声骸 Q → 尝试处决 → R → 强切今汐 f6（R 未确认也照切）。"""

        released = self._action_f4('f4', self._switch_label('Jinhsi', 'f6'))
        if not released:
            self._liberation_done_trace('f4')
        self._force_switch_to(self._find_teammate('Jinhsi'), 'f6')

    def perform_s3(self):
        """循环轴 s3：同 f4 动作体 → 强切今汐 s6。"""

        released = self._action_f4('s3', self._switch_label('Jinhsi', 's6'))
        if not released:
            self._liberation_done_trace('s3')
        self._force_switch_to(self._find_teammate('Jinhsi'), 's6')

    def _action_f4(self, tag, nxt, rounds=3):
        """f4/s3 动作体：声骸 Q → 尝试处决 → 等 R 可放 → R。"""

        if self.has_intro:
            self.wait_intro()

        self._trace(tag, '裸发声骸Q')
        self.send_echo_key()
        self.record_echo_use()
        self.task.next_frame()
        echo_avail = bool(self.echo_available())

        if echo_avail:
            self._trace(tag, '裸发声骸Q', ok=False, reason='发出后图标仍亮，未确认落地',
                        cd=bool(self.has_cd('echo')))
        else:
            self._trace(tag, '裸发声骸Q', ok=True)

        self._trace(tag, '尝试处决')
        try:
            fb_ready = bool(self.task.check_f_break())
        except Exception:
            fb_ready = False
        if fb_ready:
            fired = bool(self.f_break(force=True))
            self._trace(tag, '尝试处决', ok=fired,
                        reason=None if fired else '图标已命中但未发出 F',
                        in_team=bool(self.task.in_team()[0]))
        else:
            self._trace(tag, '尝试处决', ok=False, reason='未命中击破图标，未发 F',
                        con=self.get_current_con())
        released = False
        for rnd in range(1, rounds + 1):
            start = time.time()
            attacks = 0
            last_try = 0.0

            self._trace(tag, '等待大招就绪', lib=bool(self.liberation_available()),
                        cd=bool(self.has_cd('liberation')), con=self.get_current_con())

            log_tick = 0

            while time.time() - start < 10:
                if (bool(self.liberation_available()) or self._recent_liber_no_effect()) \
                        and time.time() - last_try >= self.LIBER_NO_EFFECT_HOLD:
                    last_try = time.time()

                    self._trace(tag, '大招可取，立即放R', attacks=attacks,
                                lib=bool(self.liberation_available()),
                                cd=bool(self.has_cd('liberation')),
                                con=self.get_current_con())
                    if self._liberation_wait(tag):
                        released = True
                        break
                    self._trace(tag, '大招未放出，继续普攻充能', attacks=attacks)

                self.continues_normal_attack(0.1, interval=0.1)
                attacks += 1
                if time.time() - start >= (log_tick + 1) * LOG_TICK:
                    log_tick += 1

                    self._trace(tag, f'持续普攻{log_tick}秒中', attacks=attacks,
                                lib=bool(self.liberation_available()),
                                cd=bool(self.has_cd('liberation')),
                                con=self.get_current_con(),
                                forte=bool(self.is_forte_full()))
                self.check_combat()
                self.task.next_frame()
            if released or rnd >= rounds:
                break
            self._trace(tag, '等待大招就绪', ok=False,
                        reason='10 秒内大招未确认放出',
                        attacks=attacks, con=self.get_current_con(), round=rnd)
            self._trace(tag, f'大招未放出，第 {rnd} 轮重新充能')
        self._trace(tag, f'结束动作体，{nxt}')
        return released

    def resonance_available(self, current=None, check_ready=False, check_cd=False):
        if not self.is_mouse_forte_full() and self.is_forte_full():
            return not self.has_cd('resonance')
        return super().resonance_available()

    def on_combat_end(self, chars):
        next_char = str((self.index + 1) % len(chars) + 1)
        self.logger.debug(f'坎特蕾拉：战斗结束，按下 {next_char} 号键切人（当前位 {self.index}）')
        self.task.send_key(next_char)

    def is_forte_full(self):
        box = self.task.box_of_screen_scaled(5120, 2880, 3034, 2640, 3090, 2700, name='forte_full', hcenter=True)
        white_percent = self.task.calculate_color_percentage(forte_white_color, box)
        self.logger.debug(f'坎特蕾拉：强化条白色像素比 {white_percent:.3f}（>0.06 视为满）')
        return white_percent > 0.06
