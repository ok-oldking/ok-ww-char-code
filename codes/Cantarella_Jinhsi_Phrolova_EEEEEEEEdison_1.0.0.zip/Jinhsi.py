import time
from src.char.BaseChar import BaseChar, SwitchPriority


LOG_TICK = 1.0
HUD_GRACE = 5.0


BASE_MIN = 0.06


E2_TIME_OUT = 2.0


class _FilteredLogger:
    """挡掉框架自身的英文日志行，其余原样转发。"""

    _BLOCKED = (
        'switch_out at full con',
        'click_echo time out',
        'click_liberation end',
        'In lock with',
        'erned outro from',
        'first engage',
    )

    def __init__(self, inner):
        self._inner = inner

    def info(self, msg, *args, **kwargs):
        if not str(msg).startswith(self._BLOCKED):
            self._inner.info(msg, *args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._inner, name)

class Jinhsi(BaseChar):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.logger = _FilteredLogger(self.logger)

        self.last_free_intro = 0
        self.has_free_intro = False
        self.incarnation = False
        self.incarnation_cd = False
        self.last_fly_e_time = 0

        self.started = False

        self._startup_done = False
        self._force_switch_me = False
        self._entry_mode = None

    def f_break(self, check_f_on_switch=False, force=False):
        return False

    def reset_state(self):
        super().reset_state()
        self.incarnation = False
        self.has_free_intro = False
        self.incarnation_cd = False
        self.started = False
        self._startup_done = False
        self._entry_mode = None

    def skip_combat_check(self):
        now = time.time()
        if self.task.in_team()[0]:
            self.task.jfk_hud_at = now
            self.task.jfk_hud_handed = False
            return True
        if not getattr(self.task, 'jfk_hud_at', 0):
            self.task.jfk_hud_at = now
        if now - self.task.jfk_hud_at < HUD_GRACE:
            return True
        if not getattr(self.task, 'jfk_hud_handed', False):
            self.task.jfk_hud_handed = True
            self._trace('脱战', '交还框架判定脱战',
                        reason=f'队伍界面连续 {HUD_GRACE:.0f} 秒读不到队伍', in_team=False)
        return False

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode=None, manual=False, tag=None):
        if target is None:
            self._log_switch_out()
            return super().switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            if manual:
                return self._switch_out_manual(target, tag or 's6')
            self._log_switch_out()
            return super().switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    def _switch_out_manual(self, target, tag, time_out=None):
        """自管切人：自己发键并等队伍界面，不因单帧读数抛脱战异常。"""

        task = self.task
        if time_out is None:
            time_out = getattr(task, 'switch_char_time_out', 5)
        task.update_lib_portrait_icon()

        con = self.get_current_con()
        if 0.8 < con < 1:
            self.sleep(0.05, check_combat=False)
            task.next_frame()
            con = self.get_current_con()
        has_intro = bool(con == 1)
        self._trace(tag, '切人：发送切人键', con=con)
        start = time.time()
        last_send = 0
        index, size = -1, 0
        in_team = False
        landed = False
        while time.time() - start < time_out:
            in_team, index, size = task.in_team()
            if in_team and index == target.index:
                landed = True
                break
            now = time.time()
            if now - last_send > 0.1:
                task.send_key(target.index + 1)
                self.sleep(0.001, check_combat=False)
                last_send = now
                task.click()
                self.sleep(0.001, check_combat=False)
            task.next_frame()
        if not landed:
            target._entry_mode = None
            self._trace(tag, '切人', ok=False,
                        reason=f'{time_out:.0f} 秒内队伍界面未认出目标位',
                        index=index, size=size, in_team=bool(in_team))
            return False

        now = time.time()
        task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.last_switch_in_time = now
        target.has_intro = has_intro
        target.has_sub_dps_intro = has_intro and self.is_sub_dps
        if has_intro:
            task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now
        self._trace(tag, '切人', ok=True, index=index, size=size, in_team=True)
        return True

    def _log_switch_out(self):
        """交场读数一行（只留协奏列）。"""

        self._trace(getattr(self, '_last_trace_tag', None) or '切人',
                    '切人：发送切人键', con=self.get_current_con())

    CHAR_NAME = '今汐'

    _TEAM_CHAR_NAMES = {'Phrolova': '弗洛洛', 'Cantarella': '坎特蕾拉'}

    _LOG_LABEL = {
        'res_pct': 'E图标',
        'cd': '冷却',
        'in_team': '在场',
        'avail': '可用',
        'con': '协奏',
        'lib': '大招就绪',
        'round': '轮次',
        'flying': '空中',
        'base': '图标基线',
        'mouse_forte': '左键光环',
        'forte': '强化条',
        'index': '当前位',
        'size': '人数',
        'has_intro': '变奏',
    }

    _RATIO_KEYS = ('res_pct', 'con', 'base')

    def _fmt_value(self, key, v):
        if isinstance(v, bool):
            return '是' if v else '否'
        if isinstance(v, float):
            return f'{v:.3f}' if key in self._RATIO_KEYS else f'{v:.2f}'
        return str(v)

    def _switch_label(self, class_name, mode):
        """拼「切{角色名}执行{节点}流程」标签。"""

        return f'切{self._TEAM_CHAR_NAMES.get(class_name, class_name)}执行{mode.upper()}流程'

    def _trace(self, tag, action, ok=None, reason=None, **data):
        """链路诊断埋点（只读，异常不外溢）。"""

        try:
            self._last_trace_tag = tag
            line = f'[{tag.upper()}]{self.CHAR_NAME}：{action}'
            if ok is not None:
                line += '成功' if ok else '失败'
                if not ok and reason:
                    line += f'，原因：{reason}'
            if data:
                line += '（' + '，'.join(
                    f'{self._LOG_LABEL.get(k, k)}{self._fmt_value(k, v)}' for k, v in data.items()) + '）'
            self.logger.info(line)
        except Exception:
            pass

    def _mark_startup_done(self):
        """循环轴一旦开始，整队标记「启动轴已完成」。"""

        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        if mode is None:
            if not self.started:
                mode = 'f1'
            elif getattr(self, '_startup_done', False):
                mode = 's1'
            else:
                self._trace('入口', '自然入场（启动轴进行中），交还框架切人')
                return self.switch_next_char()
        elif mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, f'perform_{mode}', None)
        if func is None:
            self._trace('入口', f'{mode} 未实现，交还框架切人')
            return self.switch_next_char()
        self._trace(mode, '进入动作体')
        func()

    def perform_f1(self):
        """启动轴 f1：声骸 Q → 左键充能至 E2 就绪 → E2 → R → 普通 E → 强切弗洛洛 f2。"""

        self._action_f1('f1', self._switch_label('Phrolova', 'f2'), with_echo=True)
        self._force_switch_to(self._find_teammate('Phrolova'), 'f2')

    def perform_s1(self):
        """循环轴 s1：同 f1 动作体但去声骸 Q → 强切弗洛洛 s2。"""

        self._action_f1('s1', self._switch_label('Phrolova', 's2'), with_echo=False)
        self._force_switch_to(self._find_teammate('Phrolova'), 's2')

    def _action_f1(self, tag, nxt, with_echo):
        """f1/s1 动作体：[声骸 Q] → 左键充能至 E2 就绪 → E2 → R → 普通 E。"""

        if self.has_intro:
            self.wait_intro()

        stable = self.task.wait_until(self.down, post_action=self.click_with_interval, time_out=1.5)
        if stable:
            self._trace(tag, '等待入场稳定', ok=True)
        else:
            self._trace(tag, '等待入场稳定', ok=False, reason='1.5 秒内 HUD 未就绪')
        if with_echo:
            self._trace(tag, '裸发声骸Q')
            self.send_echo_key()
            self.record_echo_use()
            if self.echo_available():
                self._trace(tag, '裸发声骸Q', ok=False, reason='发出后图标仍亮，未确认落地',
                            cd=bool(self.has_cd('echo')))
            else:
                self._trace(tag, '裸发声骸Q', ok=True)
            self.task.next_frame()

        base = 0.0
        start = time.time()
        while time.time() - start < 0.3:
            base = max(base, self.current_resonance())
            self.task.click()
            self.task.next_frame()

        resample_start = time.time()
        while base < BASE_MIN and time.time() - resample_start < 0.7:
            self.task.click()
            self.task.next_frame()
            base = max(base, self.current_resonance())
        base_ok = base >= BASE_MIN
        threshold = max(0.02, base * 0.2) if base_ok else 0.0
        self._trace(tag, '采样E图标基线', base=base)
        if not base_ok:
            self._trace(tag, '图标基线偏低，像素比不可信，本节点只认冷却读数判据', ok=False,
                        reason=f'基线 {base:.3f} < {BASE_MIN:g}')

        self._trace(tag, '持续普攻，等待E2')
        icon_ready = False
        changed_since = 0
        log_tick = 0
        while True:
            res = self.current_resonance()
            now = time.time()

            res_avail = bool(self.resonance_available())
            icon_changed = bool(self.is_e_forte_full()) or (threshold > 0 and abs(base - res) >= threshold)
            changed = res_avail and (icon_changed if base_ok else True)
            if changed:
                if changed_since == 0:
                    changed_since = now
                if now - changed_since >= 0.15:
                    icon_ready = True
                    break
            else:
                changed_since = 0
            if now - start > 10:
                break
            self.task.click()
            if now - start >= (log_tick + 1) * LOG_TICK:
                log_tick += 1
                self._trace(tag, f'持续普攻{log_tick}秒，等待E2')
            self.check_combat()
            self.task.next_frame()
        if icon_ready:
            self._trace(tag, '等待E2就绪', ok=True, cd=bool(self.has_cd('resonance')), res_pct=res)
        else:
            self._trace(tag, '等待E2就绪', ok=False, reason='10 秒内未同时满足冷却就绪与图标变化',
                        res_pct=self.current_resonance(), base=base, cd=bool(self.has_cd('resonance')))

        self._trace(tag, '裸发E2')
        self.send_resonance_key()
        self.record_resonance_use()
        self.task.next_frame()
        self._trace(tag, '裸发E2（发送后采样）', cd=bool(self.has_cd('resonance')),
                    res_pct=self.current_resonance(), avail=bool(self.resonance_available()))

        self._trace(tag, '释放大招')
        liberation = self.click_liberation(click_f=False)
        if liberation:
            self._trace(tag, '释放大招', ok=True)
        else:
            self._trace(tag, '释放大招', ok=False, reason='按R后未见演出',
                        in_team=bool(self.task.in_team()[0]))

        ok = self.task.wait_until(lambda: self.resonance_available() and self.task.in_team()[0],
                                  time_out=8, settle_time=0.1)
        if ok:
            self._trace(tag, '等待普通E就绪', ok=True)
        else:
            self._trace(tag, '等待普通E就绪', ok=False, reason='8 秒内 E 未就绪',
                        res_pct=self.current_resonance(), in_team=bool(self.task.in_team()[0]))
        self._trace(tag, '裸发普通E')
        self.send_resonance_key()
        self.record_resonance_use()
        self._trace(tag, f'结束动作体，{nxt}')

    def _attack_16(self, tag, nxt):
        """持续普攻 1.6s（f2 与 f5 共用）。"""

        if self.has_intro:
            self.wait_intro()
        self.continues_normal_attack(1.6)
        self._trace(tag, '持续普攻1.6秒')
        self._trace(tag, f'结束动作体，{nxt}')

    def perform_f2(self):
        """启动轴 f2：持续普攻 1.6s → 强切弗洛洛 f3。"""

        self._attack_16('f2', self._switch_label('Phrolova', 'f3'))
        self._force_switch_to(self._find_teammate('Phrolova'), 'f3')

    def perform_s2(self):
        """循环轴 s2：同 f2 → 强切弗洛洛 s3。"""

        self._attack_16('s2', self._switch_label('Phrolova', 's3'))
        self._force_switch_to(self._find_teammate('Phrolova'), 's3')

    def perform_f4(self):
        """启动轴 f4：E1 → 闪避 → E2 → 强切坎特蕾拉 f3。"""

        self._action_f4('f4', self._switch_label('Cantarella', 'f3'))
        self._force_switch_to(self._find_teammate('Cantarella'), 'f3')

    def perform_s4(self):
        """循环轴 s4：同 f4 → 强切坎特蕾拉 s2。"""

        self._action_f4('s4', self._switch_label('Cantarella', 's2'))
        self._force_switch_to(self._find_teammate('Cantarella'), 's2')

    def _action_f4(self, tag, nxt):
        """f4/s4 动作体：入场保护 → 确认 E 可放 → 单发 E1 → 闪避 → E2。"""

        if self.has_intro:
            self.wait_intro()
            self.sleep(0.8)
            self._trace(tag, '入场等待0.80秒')
        self._trace(tag, '裸发E2')
        self.send_resonance_key()
        self.record_resonance_use()
        self.task.next_frame()
        self.continues_right_click(0.05)
        self.sleep(0.1)

        self._trace(tag, '释放普通E')
        clicked, _duration, _animated = self.click_resonance(send_click=False, time_out=E2_TIME_OUT)

        if self.has_cd('resonance'):
            self._trace(tag, '释放普通E', ok=True)
        else:
            self._trace(tag, '释放普通E', ok=False,
                        reason='E 没发出去（进入时图标不可用）' if not clicked
                        else f'E 发出去了但图标 {E2_TIME_OUT:g} 秒未灭')
        self.task.next_frame()
        self._trace(tag, f'结束动作体，{nxt}')

    def perform_f5(self):
        """启动轴 f5：持续普攻 1.6s → 强切坎特蕾拉 f4。"""

        self._attack_16('f5', self._switch_label('Cantarella', 'f4'))
        self._force_switch_to(self._find_teammate('Cantarella'), 'f4')

    def perform_s5(self):
        """循环轴 s5：同 f5 → 强切坎特蕾拉 s3。"""

        self._attack_16('s5', self._switch_label('Cantarella', 's3'))
        self._force_switch_to(self._find_teammate('Cantarella'), 's3')

    def perform_f3(self):
        """启动轴 f3：E喷 → 强切坎特蕾拉 f2。"""

        self._action_f3('f3', self._switch_label('Cantarella', 'f2'))
        self._force_switch_to(self._find_teammate('Cantarella'), 'f2')

    def perform_s3(self):
        """循环轴 s3：同 f3 → 强切坎特蕾拉 s1。"""

        self._action_f3('s3', self._switch_label('Cantarella', 's1'))
        self._force_switch_to(self._find_teammate('Cantarella'), 's1')

    def _action_f3(self, tag, nxt):
        """f3/s3 动作体：单发 E喷。"""

        if self.has_intro:
            self.wait_intro()

        self._trace(tag, '裸发E喷')
        self.send_resonance_key()
        self.record_resonance_use()
        self.task.next_frame()
        ok = self.task.wait_until(lambda: self.task.in_team()[0], time_out=3, settle_time=0.1)
        if ok:
            self._trace(tag, '等待回到队伍', ok=True)
        else:
            self._trace(tag, '等待回到队伍', ok=False, reason='3 秒内未回到队伍',
                        con=self.get_current_con(), in_team=bool(self.task.in_team()[0]))
        self._trace(tag, f'结束动作体，{nxt}')

    def _release_echo(self, tag):
        """释放声骸 Q（框架模板判定）并等动作结束，返回是否确认放出。"""

        self._trace(tag, '释放声骸Q')
        start = time.time()
        cast = bool(self.click_echo())
        dur = round(time.time() - start, 2)
        if cast:
            self._trace(tag, '释放声骸Q', ok=True, t=dur, cd=bool(self.has_cd('echo')))
        else:
            self._trace(tag, '释放声骸Q', ok=False,
                        reason='1 秒上限内声骸图标未熄灭（图标未亮或在 CD 时框架不会发键）',
                        t=dur, cd=bool(self.has_cd('echo')))
        sent_at = time.time()
        anim = not bool(self.task.in_team()[0])
        if anim:
            while time.time() - sent_at < 6 and not self.task.in_team()[0]:
                self.task.next_frame()
        else:
            while time.time() - sent_at < 0.8:
                self.task.next_frame()
        self._trace(tag, '等待声骸动作结束')
        return cast

    def perform_f6(self):
        """启动轴 f6：声骸 Q → 左键 → E喷 → 填满协奏 → 强切弗洛洛 s1。"""

        self._action_f6('f6', self._switch_label('Phrolova', 's1'))
        if not self._force_switch_to(self._find_teammate('Phrolova'), 's1', manual=True, tag='f6'):
            return

    def perform_s6(self):
        """循环轴 s6：同 f6 → 强切弗洛洛 s1（闭环回起点）。"""

        self._action_f6('s6', self._switch_label('Phrolova', 's1'))
        if not self._force_switch_to(self._find_teammate('Phrolova'), 's1', manual=True, tag='s6'):
            return

    def _action_f6(self, tag, nxt):
        """f6/s6 动作体：声骸 Q → 左键 → E喷 → 保底左键 → 填满协奏。"""

        if self.has_intro:
            self.wait_intro()
        self._release_echo(tag)
        self.task.click()
        self._trace(tag, '单击左键1次')

        self._trace(tag, '裸发E喷')
        self.send_resonance_key()
        self.record_resonance_use()
        self.task.next_frame()

        self._trace(tag, 'E喷后保底左键1次')
        self.task.click()
        self.sleep(0.2)
        self.check_combat()
        self.task.next_frame()
        start = time.time()
        con_full = bool(self.is_con_full())
        self._trace(tag, '判断协奏是否已满')
        log_tick = 0
        while not con_full and time.time() - start < 10:
            self.task.click()
            self.sleep(0.2)
            if time.time() - start >= (log_tick + 1) * LOG_TICK:
                log_tick += 1
                self._trace(tag, f'持续普攻{log_tick}秒，直到协奏满')
            self.check_combat()
            self.task.next_frame()
            con_full = bool(self.is_con_full())
        if con_full:
            self._trace(tag, '等待协奏已满', ok=True)
        else:
            self._trace(tag, '等待协奏已满', ok=False, reason='10 秒上限仍未满',
                        con=self.get_current_con())
        self._trace(tag, f'结束动作体，{nxt}')

    def handle_incarnation(self):
        self.incarnation = False
        self.logger.info(f'handle_incarnation click_resonance start')
        start = time.time()
        animation_start = 0
        last_op = 'resonance'
        self.task.in_liberation = True
        while True:
            if time.time() - start > 6:
                self.logger.info(f'handle incarnation too long')
                break
            if self.task.in_team()[0]:
                if last_op == 'resonance':
                    self.task.click(interval=0.1)
                    last_op = 'click'
                else:
                    self.send_resonance_key()
                    last_op = 'resonance'
                if animation_start != 0:
                    self.logger.info(f'Jinhsi handle_incarnation done')
                    break
            else:
                if animation_start == 0:
                    self.logger.info(f'Jinhsi handle_incarnation start animation')
                    animation_start = time.time()
                self.task.in_liberation = True
            self.check_combat()
            self.task.next_frame()
        self.task.in_liberation = False

        if not self.click_echo():
            self.task.click()

        self.add_freeze_duration(animation_start)
        self.logger.info(f'handle_incarnation  click_resonance end {time.time() - start}')

    def handle_intro(self):
        self.logger.info(f'handle_intro start')
        start = time.time()
        while True:
            elapsed = time.time() - start
            if self.has_cd('resonance'):
                if 0.3 < elapsed < 1.5:
                    self.incarnation_cd = True
                    if not self.click_echo():
                        self.click()
                    return
                elif elapsed > 1.5:
                    break
            else:
                self.send_resonance_key(interval=0.1)
            self.task.next_frame()
            self.check_combat()

        self.last_fly_e_time = start
        if self.click_liberation(send_click=True):
            self.continues_normal_attack(0.3)
        else:
            self.continues_normal_attack(1.4)
        self.logger.info(f'handle_intro end {time.time() - start}')
        self.incarnation = True
        self.incarnation_cd = False

    def wait_resonance(self):
        while not self.resonance_available():
            self.send_resonance_key(interval=0.1)
