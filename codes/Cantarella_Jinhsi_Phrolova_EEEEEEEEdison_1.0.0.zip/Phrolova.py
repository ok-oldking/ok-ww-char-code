import time
from src.char.BaseChar import BaseChar, SwitchPriority


LOG_TICK = 1.0
HUD_GRACE = 5.0


class _FilteredLogger:
    """挡掉框架自身的英文日志行，其余原样转发。"""

    _BLOCKED = ('click_liberation end',)

    def __init__(self, inner):
        self._inner = inner

    def info(self, msg, *args, **kwargs):
        if not str(msg).startswith(self._BLOCKED):
            self._inner.info(msg, *args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._inner, name)

class Phrolova(BaseChar):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.logger = _FilteredLogger(self.logger)
        self.check_f_on_switch = False

        self.started = False

        self._startup_done = False
        self._force_switch_me = False
        self._entry_mode = None

    def f_break(self, check_f_on_switch=False, force=False):
        return False

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None

    def skip_combat_check(self):
        now = time.time()
        if self.task.in_team()[0]:
            self.task.jfk_hud_at = now
            self.task.jfk_hud_handed = False
            return True
        if not getattr(self.task, 'jfk_hud_at', 0):
            self.task.jfk_hud_at = now
        if now - self.task.jfk_hud_at < HUD_GRACE:
            return True
        if not getattr(self.task, 'jfk_hud_handed', False):
            self.task.jfk_hud_handed = True
            self._trace('脱战', '交还框架判定脱战',
                        reason=f'队伍界面连续 {HUD_GRACE:.0f} 秒读不到队伍', in_team=False)
        return False

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode=None):
        if target is None:
            self._log_switch_out()
            return super().switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            self._log_switch_out()
            return super().switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    def _log_switch_out(self):
        """交场读数一行（只留协奏列）。"""

        self._trace(getattr(self, '_last_trace_tag', None) or '切人',
                    '切人：发送切人键', con=self.get_current_con())

    CHAR_NAME = '弗洛洛'

    _TEAM_CHAR_NAMES = {'Cantarella': '坎特蕾拉', 'Jinhsi': '今汐'}

    _LOG_LABEL = {
        'res_pct': 'E图标',
        'cd': '冷却',
        'in_team': '在场',
        'avail': '可用',
        'con': '协奏',
        'lib': '大招就绪',
        'base': 'E图标基线',
        'current_index': '当前在场',
        'target_index': '目标位置',
        'round': '轮次',
        'flying': '空中',
    }

    _RATIO_KEYS = ('res_pct', 'con', 'base')

    def _fmt_value(self, key, v):
        if isinstance(v, bool):
            return '是' if v else '否'
        if isinstance(v, float):
            return f'{v:.3f}' if key in self._RATIO_KEYS else f'{v:.2f}'
        return str(v)

    def _switch_label(self, class_name, mode):
        """拼「切{角色名}执行{节点}流程」标签。"""

        return f'切{self._TEAM_CHAR_NAMES.get(class_name, class_name)}执行{mode.upper()}流程'

    def _trace(self, tag, action, ok=None, reason=None, **data):
        """链路诊断埋点（只读，异常不外溢）。"""

        try:
            self._last_trace_tag = tag
            line = f'[{tag.upper()}]{self.CHAR_NAME}：{action}'
            if ok is not None:
                line += '成功' if ok else '失败'
                if not ok and reason:
                    line += f'，原因：{reason}'
            if data:
                line += '（' + '，'.join(
                    f'{self._LOG_LABEL.get(k, k)}{self._fmt_value(k, v)}' for k, v in data.items()) + '）'
            self.logger.info(line)
        except Exception:
            pass

    def _mark_startup_done(self):
        """循环轴一旦开始，整队标记「启动轴已完成」。"""

        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        if mode is None:
            if not self.started:
                mode = 'f1'
            elif getattr(self, '_startup_done', False):
                mode = 's1'
            else:
                self._trace('入口', '自然入场（启动轴进行中），交还框架切人')
                return self.switch_next_char()
        elif mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, f'perform_{mode}', None)
        if func is None:
            self._trace('入口', f'{mode} 未实现，交还框架切人')
            return self.switch_next_char()
        self._trace(mode, '进入动作体')
        func()

    def _icon_probe(self, tag, sample=0.3):
        """采样「图标变化」基线，返回判定函数与阈值（只读）。"""

        forte_entered = bool(self.is_mouse_forte_full())
        res_base = 0.0
        start = time.time()
        while time.time() - start < sample:
            res_base = max(res_base, self.current_resonance())
            self.task.next_frame()
        threshold = max(0.02, res_base * 0.2) if res_base > 0 else 0.0
        self._trace(tag, '采样E图标基线', base=res_base)

        def changed():
            return (bool(self.is_mouse_forte_full()) != forte_entered
                    or (threshold > 0 and abs(res_base - self.current_resonance()) >= threshold))

        return changed, res_base, threshold, forte_entered

    def _trace_landed(self, tag, class_name):
        """切完当场核对游戏里是否真的换人。"""

        tgt = self._find_teammate(class_name)
        _, idx, _ = self.task.in_team()
        landed = bool(tgt is not None and idx == tgt.index)
        self._trace(tag, '切人事后校验', ok=landed,
                    reason=None if landed else '当前在场角色不是目标',
                    current_index=idx, target_index=tgt.index if tgt else None)

    def perform_f1(self):
        """启动轴 f1：左键×2 → 等图标变化 → 声骸 Q → 左键 → sleep 0.1s → 强切今汐 f1。"""

        self._action_f1('f1', self._switch_label('Jinhsi', 'f1'), clicks=2)
        self._force_switch_to(self._find_teammate('Jinhsi'), 'f1')

    def perform_s1(self):
        """循环轴 s1：同 f1 但只左键 1 次 → 强切今汐 s1。"""

        self._action_f1('s1', self._switch_label('Jinhsi', 's1'), clicks=1, entry_sleep=1.0)
        self._force_switch_to(self._find_teammate('Jinhsi'), 's1')

    def _action_f1(self, tag, nxt, clicks, entry_sleep=0.0):
        """f1/s1 动作体：左键×clicks → 等图标变化 → 声骸 Q → 左键 → sleep 0.3s。"""

        if self.has_intro:
            self.wait_intro()
        if entry_sleep > 0:
            self.sleep(entry_sleep)
            self._trace(tag, f'入场等待{entry_sleep:g}秒')

        pred, res_base, threshold, forte_entered = self._icon_probe(tag)
        self._trace(tag, f'单击左键{clicks}次')
        self.task.click()
        if clicks > 1:
            self.sleep(0.3)
            self._trace(tag, '等待0.3秒，让第二下左键成为独立的第二次攻击')
            self.task.click()

        self._trace(tag, '等待E图标变化')
        changed = self.task.wait_until(pred, time_out=2, settle_time=0.15)
        if changed:
            self._trace(tag, '等待E图标变化', ok=True)
        else:
            self._trace(tag, '等待E图标变化', ok=False, reason='2 秒内图标未变化',
                        res_pct=self.current_resonance(), base=res_base)

        self.sleep(0.4)
        self._trace(tag, '等待0.4秒，让前面的动作落地再发声骸Q')

        self._trace(tag, '采样声骸图标基线', avail=bool(self.echo_available()),
                    cd=bool(self.has_cd('echo')))
        sent_at = 0
        cast = False
        for attempt in range(3):
            self._trace(tag, '裸发声骸Q')
            self.send_echo_key()
            self.record_echo_use()
            sent_at = time.time()
            cast = bool(self.task.wait_until(lambda: not self.echo_available(), time_out=0.5))
            if cast:
                self._trace(tag, '裸发声骸Q', ok=True)
                break
            self._trace(tag, '裸发声骸Q', ok=False, reason='0.5 秒内图标仍亮，未确认落地',
                        cd=bool(self.has_cd('echo')))

        anim = not bool(self.task.in_team()[0])
        if anim:
            while time.time() - sent_at < 6 and not self.task.in_team()[0]:
                self.task.next_frame()
        else:
            while time.time() - sent_at < 0.8:
                self.task.next_frame()
        self._trace(tag, '等待声骸动作结束')

        ok = self.task.wait_until(lambda: self.task.in_team()[0], time_out=3, settle_time=0.1)
        if ok:
            self._trace(tag, '等待回到队伍', ok=True)
        else:
            self._trace(tag, '等待回到队伍', ok=False, reason='3 秒内未回到队伍',
                        in_team=bool(self.task.in_team()[0]))
        self.task.click()
        self._trace(tag, '单击左键1次')

        self.sleep(0.1)
        self._trace(tag, '等待0.1秒，让最后一发左键落地再交场')
        self._trace(tag, f'结束动作体，{nxt}')

    def perform_f2(self):
        """启动轴 f2：左键×2（间隔 0.8s）→ sleep 0.5s → 单发 E → 强切今汐 f2。"""

        self._action_f2('f2', self._switch_label('Jinhsi', 'f2'))
        self._force_switch_to(self._find_teammate('Jinhsi'), 'f2')
        self._trace_landed('f2', 'Jinhsi')

    def perform_s2(self):
        """循环轴 s2：同 f2 → 强切今汐 s2。"""

        self._action_f2('s2', self._switch_label('Jinhsi', 's2'))
        self._force_switch_to(self._find_teammate('Jinhsi'), 's2')
        self._trace_landed('s2', 'Jinhsi')

    def _action_f2(self, tag, nxt):
        """f2/s2 动作体：入场等待（down 稳定 → E 就绪）→ 左键×2 → sleep 0.5s → 单发 E。"""

        if self.has_intro:
            self.wait_intro()

        self._trace(tag, '等待入场稳定')
        rendered = self.task.wait_until(self.down, post_action=self.click_with_interval, time_out=1.5)
        if rendered:
            self._trace(tag, '等待入场稳定', ok=True)
        else:
            self._trace(tag, '等待入场稳定', ok=False, reason='1.5 秒内 HUD 未就绪',
                        res_pct=self.current_resonance(), lib=bool(self.liberation_available()))

        self._trace(tag, '等待E图标就绪')
        e_ready = self.task.wait_until(self.resonance_available,
                                       post_action=self.click_with_interval, time_out=2, settle_time=0.1)
        if e_ready:
            self._trace(tag, '等待E图标就绪', ok=True)
        else:
            self._trace(tag, '等待E图标就绪', ok=False, reason='2 秒内 E 仍在 CD',
                        res_pct=self.current_resonance(), cd=bool(self.has_cd('resonance')))

        self._trace(tag, '单击左键2次')
        self.task.click()
        self.sleep(0.8)
        self._trace(tag, '等待0.8秒，让第二下左键成为独立的第二次攻击')
        self.task.click()

        self.sleep(0.5)
        self._trace(tag, '等待0.5秒，让普攻落地再发E')

        self._trace(tag, '裸发E')
        self.send_resonance_key()
        self.record_resonance_use()

        ok = self.task.wait_until(lambda: self.task.in_team()[0], time_out=3, settle_time=0.1)
        if ok:
            self._trace(tag, '等待回到队伍', ok=True)
        else:
            self._trace(tag, '等待回到队伍', ok=False, reason='3 秒内未回到队伍',
                        in_team=bool(self.task.in_team()[0]))
        self._trace(tag, f'结束动作体，{nxt}')

    def perform_f3(self):
        """启动轴 f3：E×2 + 重击 0.5s → 强切今汐 f3。"""

        self._action_f3('f3', self._switch_label('Jinhsi', 'f3'))
        self._force_switch_to(self._find_teammate('Jinhsi'), 'f3')

    def perform_s3(self):
        """循环轴 s3：同 f3 → 强切今汐 s3。"""

        self._action_f3('s3', self._switch_label('Jinhsi', 's3'))
        self._force_switch_to(self._find_teammate('Jinhsi'), 's3')

    def _action_f3(self, tag, nxt):
        """f3/s3 动作体：入场稳定 → 单发 E×2 → 重击 0.5s。"""

        if self.has_intro:
            self.wait_intro()

        self._trace(tag, '等待入场稳定')
        rendered = self.task.wait_until(self.down, time_out=1.5)
        if rendered:
            self._trace(tag, '等待入场稳定', ok=True)
        else:
            self._trace(tag, '等待入场稳定', ok=False, reason='1.5 秒内 HUD 未就绪',
                        res_pct=self.current_resonance(), cd=bool(self.has_cd('resonance')))
        for i in (1, 2):
            self._trace(tag, f'裸发E{i}')
            self.send_resonance_key()
            self.record_resonance_use()
            if i == 1:
                self.sleep(0.3)
                self._trace(tag, '等待0.3秒，让E1落地再发E2')

        self.sleep(0.3)
        self._trace(tag, '等待0.3秒，让E2落地再释放重击')
        self.heavy_attack(0.5)
        self._trace(tag, '释放重击0.5秒')
        ok = self.task.wait_until(lambda: self.task.in_team()[0], time_out=3, settle_time=0.1)
        if ok:
            self._trace(tag, '等待回到队伍', ok=True)
        else:
            self._trace(tag, '等待回到队伍', ok=False, reason='3 秒内未回到队伍',
                        in_team=bool(self.task.in_team()[0]))
        self._trace(tag, f'结束动作体，{nxt}')

    def perform_f4(self):
        """启动轴 f4：等 R 就绪 → R → 强切今汐 f4。"""

        self._action_f4('f4', self._switch_label('Jinhsi', 'f4'))
        self._force_switch_to(self._find_teammate('Jinhsi'), 'f4')

    def perform_s4(self):
        """循环轴 s4：同 f4 → 强切今汐 s4。"""

        self._action_f4('s4', self._switch_label('Jinhsi', 's4'))
        self._force_switch_to(self._find_teammate('Jinhsi'), 's4')

    def _action_f4(self, tag, nxt):
        """f4/s4 动作体：入场稳定 → 等 R 就绪 → R。"""

        if self.has_intro:
            self.wait_intro()
        self._trace(tag, '等待入场稳定')

        rendered = self.task.wait_until(self.down, post_action=self.click_with_interval, time_out=1.5)
        if rendered:
            self._trace(tag, '等待入场稳定', ok=True)
        else:
            self._trace(tag, '等待入场稳定', ok=False, reason='1.5 秒内 HUD 未就绪',
                        res_pct=self.current_resonance(), lib=bool(self.liberation_available()))
        self._trace(tag, '等待大招就绪')
        ready = self.task.wait_until(self.liberation_available,
                                     post_action=self.click_with_interval, time_out=2, settle_time=0.1)
        if ready:
            self._trace(tag, '等待大招就绪', ok=True)
        else:
            self._trace(tag, '等待大招就绪', ok=False, reason='2 秒内大招未就绪',
                        lib=bool(self.liberation_available()), cd=bool(self.has_cd('liberation')))
        self._trace(tag, '释放大招')
        liberation = self.click_liberation(click_f=False)
        if liberation:
            self._trace(tag, '释放大招', ok=True)
        else:
            self._trace(tag, '释放大招', ok=False, reason='按R后未见演出',
                        in_team=bool(self.task.in_team()[0]))
        self._trace(tag, f'结束动作体，{nxt}')
