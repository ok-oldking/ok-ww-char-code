import time

from src.char.BaseChar import BaseChar, CharType, SwitchPriority, get_default_buff_time


class Suoming(BaseChar):
    """固定轴 2 号位：执行 QR 与三次普攻、强化 E 段。"""

    AXIS_SLOT = 2
    AXIS_PHASE_SLOTS = (3, 2, 1, 2, 1)

    NORMAL_INTERVAL = 0.12  # 普攻输入后的基础间隔，单位为秒。
    NORMAL_ATTACK_FINISH_WAIT = 0.25  # 锁的普攻动作收尾等待，单位为秒。
    KEY_DOWN = 0.02  # E/Q/R/Z 单键按下时长，单位为秒。
    KEY_INTERVAL = 0.10  # 连续技能键之间的间隔，单位为秒。
    KEY_BIANZOU1 = 1.50  # 保留原轴 QR 前等待时间
    KEY_BIANZOU2 = 1.50  # 保留原轴强化 E 前等待时间
    KEY_RLATER = 4.0 # R后等待
    KEY_EPRE = 0.5 # E前等待
    KEY_QLATER = 1.75 # Q后等待
    ENHANCED_E_HOLD = 5.25  # 强化 E 长按时长，可在此调整，单位为秒。
    SWITCH_TIMEOUT = 2.5  # 等待目标槽位出现在 HUD 的最长时间。
    AXIS_TARGET_REACQUIRE_TIMEOUT = 8.0  # 全屏大招期间目标 UI 不可见时的重锁上限。
    KEYS = {'E': 'e', 'Q': 'q', 'R': 'r', 'Z': 'z'}  # 轴使用的物理键名。

    def __init__(self, *args, **kwargs):
        """初始化锁的轴动作状态。"""
        super().__init__(*args, **kwargs)
        self._axis_reset_log_count = 0

    def _prepare_axis(self):
        """读取全队共享阶段；未初始化时从 3 号位启动段开始。"""
        self._extend_target_reacquire_timeout()
        if not getattr(self.task, '_catpaw_axis_initialized', False):
            self.task._catpaw_axis_phase = 0
            self.task._catpaw_axis_action_index = 0
            self.task._catpaw_axis_initialized = True
            self.logger.info('CatPaw 全队轴初始化：从维（3 号位）启动段开始。')
        return self.task._catpaw_axis_phase

    def _extend_target_reacquire_timeout(self):
        """大招遮挡目标 UI 时延长重锁窗口，不重放当前轴动作。"""
        if getattr(self.task, '_catpaw_target_reacquire_timeout_active', False):
            return
        original = getattr(self.task, 'target_enemy_time_out', None)
        if original is None:
            return
        adjusted = max(original, self.AXIS_TARGET_REACQUIRE_TIMEOUT)
        self.task._catpaw_original_target_reacquire_timeout = original
        self.task.target_enemy_time_out = adjusted
        self.task._catpaw_target_reacquire_timeout_active = True
        if adjusted != original:
            self.logger.info(f'CatPaw 全屏动画目标重锁上限：{original} 秒 -> {adjusted} 秒。')

    def reset_state(self):
        """框架结束战斗或重识别队伍时，重置全队共享轴状态。"""
        state_changed = (
            getattr(self.task, '_catpaw_axis_phase', 0) != 0
            or getattr(self.task, '_catpaw_axis_action_index', 0) != 0
        )
        super().reset_state()
        if getattr(self.task, '_catpaw_target_reacquire_timeout_active', False):
            self.task.target_enemy_time_out = self.task._catpaw_original_target_reacquire_timeout
            self.task._catpaw_original_target_reacquire_timeout = None
            self.task._catpaw_target_reacquire_timeout_active = False
        self.task._catpaw_axis_phase = 0
        self.task._catpaw_axis_action_index = 0
        self.task._catpaw_axis_initialized = False
        log_count = getattr(self, '_axis_reset_log_count', 0)
        if state_changed and log_count < 3:
            self.logger.info('CatPaw 全队轴状态已重置：下次进战从维（3 号位）启动段开始。')
            self._axis_reset_log_count = log_count + 1

    def is_dps_config(self):
        """读取队伍配置，判断锁是否按主输出职责运行。"""
        return bool(self.task and self.task.char_config.get('Suoming DPS', False))

    def get_char_type(self):
        """根据配置返回锁的主输出或副输出职责类型。"""
        return CharType.MAIN_DPS if self.is_dps_config() else CharType.SUB_DPS

    def get_buff_time(self):
        """按当前职责返回基类使用的增益持续时间。"""
        if self.is_dps_config():
            return get_default_buff_time(CharType.MAIN_DPS)
        return super().get_buff_time()

    def _normal_attack_with_wait(self):
        """执行一次普攻，并等待输入间隔和动作收尾。"""
        result = self.normal_attack()
        self.sleep(self.NORMAL_INTERVAL)
        self.sleep(self.NORMAL_ATTACK_FINISH_WAIT, False)
        return result is not False

    def _normal_chain(self, count):
        """连续执行指定次数的带等待普攻。"""
        for _ in range(count):
            if self._normal_attack_with_wait() is False:
                return False
        return True

    def _tap(self, key):
        """按下一个轴配置中的技能键，并等待后续技能输入间隔。"""
        result = self.task.send_key(self.KEYS[key], down_time=self.KEY_DOWN)
        self.sleep(self.KEY_INTERVAL, False)
        return result is not False

    def _wait_intro_if_needed(self):
        """仅在持有入场技状态时等待，并保持动作计划的固定长度。"""
        if not self.has_intro:
            return True
        return self.wait_intro(1.2)

    def _hold_enhanced_e(self):
        """按住强化 E 指定时长，并确保在异常或停止时释放 E 键。"""
        self.check_combat()
        down_result = None
        up_result = None
        try:
            down_result = self.task.send_key_down(self.KEYS['E'])
            self.sleep(self.ENHANCED_E_HOLD, False)
        finally:
            up_result = self.task.send_key_up(self.KEYS['E'])
        self.sleep(self.KEY_INTERVAL, False)
        return down_result is not False and up_result is not False

    def _run_axis_action(self, label, action):
        """只执行一次轴操作；失败时记录并交由计划推进游标。"""
        try:
            if action() is not False:
                return True
            error = '操作返回失败'
        except Exception as caught:
            error = str(caught)
        self.logger.warning(f'CatPaw 锁轴操作失败：{label}，不重试，原因={error}。')
        return False

    def _run_axis_plan(self, actions, next_slot):
        """失败动作不重放；确认末尾切人后推进全队阶段。"""
        self._prepare_axis()
        actions.append((f'切换到 {next_slot} 号位', lambda: self._switch_to_slot(next_slot)))
        while self.task._catpaw_axis_action_index < len(actions):
            action_index = self.task._catpaw_axis_action_index
            label, action = actions[action_index]
            if not self._run_axis_action(label, action):
                if action_index < len(actions) - 1:
                    self.task._catpaw_axis_action_index += 1
                return False
            self.task._catpaw_axis_action_index += 1
        self.task._catpaw_axis_action_index = 0
        self.task._catpaw_axis_phase += 1
        return True

    def _route_axis_phase(self, phase):
        """只切到当前全队阶段的执行槽位，不执行其他角色的阶段。"""
        slot = self.AXIS_PHASE_SLOTS[phase % len(self.AXIS_PHASE_SLOTS)]
        if slot == self.AXIS_SLOT:
            return True
        self._switch_to_slot(slot)
        return False

    def _log_qr_complete(self):
        """在 Q、R 两个键都输入后记录 QR 完成。"""
        self.logger.info('CatPaw 锁 QR 输入完成。')
        return True

    def _switch_to_slot(self, slot):
        """按槽位键切人，轮询 HUD 确认后同步当前角色和切入时间。"""
        target_index = slot - 1
        self.has_intro = False
        self.has_sub_dps_intro = False
        self._liberation_available = self.liberation_available()
        self.use_tool_box()

        started = time.monotonic()
        while time.monotonic() - started < self.SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == target_index:
                now = time.time()
                self.last_switch_time = now
                for char in getattr(self.task, 'chars', []):
                    if char:
                        char.is_current_char = char.index == target_index
                        if char.index == target_index:
                            char.last_switch_in_time = now
                return True
            self.task.send_key(str(slot))
            self.task.next_frame()
            self.sleep(0.1, False)
        self.logger.warning(f'CatPaw 锁轴切换到 {slot} 号位超时；阶段计数保持不变。')
        return False

    def _perform_segment(self, step):
        """构造 QR 或强化 E 段的逐操作计划，并处理固定槽位交接。"""
        actions = [('入场等待', self._wait_intro_if_needed)]
        is_startup_qr = step == 1
        is_loop_qr = step >= 5 and (step - 6) % 5 == 0
        if is_startup_qr or is_loop_qr:
            label = '启动段 2/5 QR' if is_startup_qr else '循环段 QR'
            self.logger.info(f'CatPaw {label}：锁（2 号位）QR，之后普通切心。')
            # 保留 QR 前置等待；False 只关闭等待期间的周期性战斗检查。
            actions.extend((
                ('QR 前置等待', lambda: self.sleep(self.KEY_BIANZOU1, False)),
                ('Q', lambda: self._tap('Q')),
                # ('Q 后等待', lambda: self.sleep(self.KEY_QLATER, False)),
                ('R', lambda: self._tap('R')),
                ('R收尾', lambda: self.sleep(self.KEY_RLATER, False)),
                ('QR 完成记录', self._log_qr_complete),

            ))
        else:
            label = '启动段 4/5 强化 E' if step == 3 else '循环段强化 E'
            self.logger.info(f'CatPaw {label}：锁（2 号位）aaa，E 长按 {self.ENHANCED_E_HOLD:.1f} 秒，之后普通切心。')
            # 保留强化 E 前置等待；False 只关闭等待期间的周期性战斗检查。
            actions.append(('变奏等待', lambda: self.sleep(self.KEY_BIANZOU2, False)))
            actions.extend((f'普攻 {index}/3', self._normal_attack_with_wait) for index in range(1, 7))
            actions.append(('R收尾', lambda: self.sleep(self.KEY_EPRE, False)))
            actions.append(('强化 E 长按', self._hold_enhanced_e))
        return self._run_axis_plan(actions, 1)

    def do_perform(self):
        """按全队阶段执行锁的段落，错位时只切至阶段执行槽位。"""
        phase = self._prepare_axis()
        if self._route_axis_phase(phase):
            self._perform_segment(phase)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """使用基类规则提供调度器所需的切人优先级。"""
        return super().get_switch_priority(current_char, has_intro, target_low_con)
