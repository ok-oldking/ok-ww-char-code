import time

from src.char.BaseChar import BaseChar, SwitchPriority


class NoEnemy(Exception):
    """場上沒怪 / 鎖不到怪: 這一圈到此為止, 交回框架(見 check_enemy_gone)。"""



class Verina(BaseChar):
    """維里奈 / 穗穗 / 緋雪 隊裡的維里奈。

    輪轉: 維里奈 -> 穗穗 -> 緋雪 -> 維里奈。每場戰鬥強制維里奈起手:
      她 do_perform 一開始就把 task.verina_opener_done 設成 True; 在那之前穗穗/緋雪空手上場
      會一下都不打直接切給她。三個角色的 on_combat_end 都會把標記清回 False。
    維里奈每次上場都要做完: E、Q 各放出一次 + 協奏打滿, 才把延奏交給穗穗(穗穗靠這個變奏直接進濯雨時)。
    R 不強制: 這輪 R 亮著就順手放一次, 沒亮不等。要改回強制就把 'R' 加進 MUST_CAST。

    【10-26 照技能說明重排】協奏的主要來源是"星星花綻放":
      有【光合能量】(上限 4)時放重擊或空中攻擊 -> 消耗 1 層, 回協奏 + 全隊治療;
      重擊星星花綻放之後短按普攻 -> 接空中攻擊星星花綻放, 一次吃 2 層。
      光合能量來源: 變奏入場 +1、放 E +1、普攻第 5 段命中 +1(第 1~4 段不給)。
    所以流程是:
      E(+1) -> Q -> R(亮才放) -> 星星花連段(重擊 -> 短按接空中) -> 協奏沒滿: 普攻打滿 5 段(+1) -> 再星星花連段 -> ...
      -> 必做的都齊了且協奏滿 -> 數字鍵直接切穗穗, 自己補交接記帳(同穗穗那套 direct_switch + handoff_to)
    舊版開場那 3 下普攻到不了第 5 段, 拿不到光合能量, 拿掉了; 重擊 8 秒間隔也拿掉了(有能量時重擊就是協奏來源)。
    必做的冷卻沒好就一直打著等; 站滿 FIELD_CAP 還沒齊就照樣切(日誌會寫差哪一樣)。
    大招開關(USE_LIBERATION 或任務設定裡關掉大招)關著時, R 一律不放, 也不算在必做清單裡。

    連招沿用 心/鎖暝/維里奈 那份, 改動:
      - E / R 都帶 click_f=False: 全隊處決只歸緋雪軸上那一處, 框架預設會在動畫期間連按 F
      - 循環加上總時長上限 FIELD_CAP: 原本 while True 沒有出口, 打不到東西(協奏不漲)會卡死
      - 離場不走框架切人: 直接按數字鍵切穗穗, 交接標記寫在 task 上(穗穗那邊有 note_intro_handoff)
    """

    # 重擊按住多久。原本 2 秒; 星星花綻放是"按住普攻"觸發, 按太久只是白等。重擊沒出來就往回調
    HEAVY_ATTACK_DURATION: float = 1.0
    # 重擊之後多久短按普攻接空中攻擊星星花綻放
    HEAVY_TO_AIR_TAP: float = 0.15
    # 兩次重擊之間至少隔多久。0 = 每一圈都打(有光合能量時重擊就是協奏的主要來源)
    HEAVY_ATTACK_INTERVAL: float = 0.0
    # ========== 可直接修改參數 ==========
    # 滿協奏時交棒的目標(char_name)
    SWITCH_TARGET_NAME: str = 'char_suisui'
    # 名字找不到時退回的槽位(1 起算)。隊伍排法: 1 穗穗 / 2 維里奈 / 3 緋雪
    DIRECT_SWITCH_INDEX: int = 1
    # 這個角色下場時, 維里奈優先上場(char_name)
    FOLLOW_AFTER_NAME: str = 'char_hiyuki'
    # 是否施放大招(R)
    USE_LIBERATION: bool = True
    # 星星花連段之後協奏還沒滿時打的普攻段數。要打滿 5 段: 第 5 段命中才給 1 層光合能量
    NORMAL_STRING_COUNT: int = 5
    # 地面普攻間隔(秒)
    NORMAL_ATTACK_GAP: float = 0.23
    # E/Q 施放確認的最長重試時間(秒), 超過則放棄進行下一步
    SKILL_CAST_TIMEOUT: float = 3.5
    # E/Q 每次按下後等待多久再檢查是否進入 CD(秒)
    SKILL_RETRY_GAP: float = 0.15
    # 每次上場必須放出的技能。R 不在裡面 = 不強制, 亮著才順手放; 要強制就改成 ('E', 'Q', 'R')
    MUST_CAST: tuple = ('E', 'Q')
    # 站場上限(秒, 從上場算, 扣掉動畫凍結)。到點必做的沒齊或協奏沒滿也照樣切人;
    # 協奏沒滿時穗穗空手入場, 改走醒春潮啟動軸
    FIELD_CAP: float = 15.0
    # 滿協奏後穩定延遲(秒), 兼顧觸發成功率與切人速度
    CON_FULL_STABLE_DELAY: float = 0.15
    # 空中攻擊星星花綻放之後等多久(下落 + 落地)再做下一個動作
    AIR_ATTACK_SETTLE: float = 0.5
    # 切人前輪詢協奏是否滿的上限(秒): 能量環讀數滯後
    HANDOFF_CON_WAIT: float = 0.8
    # 直接切人: 總上限 / 重發數字鍵間隔 / 輪詢間隔(同穗穗, 重發別再加密, 理由見穗穗那份)
    SWITCH_TIMEOUT: float = 2.0
    SWITCH_KEY_RESEND: float = 0.22
    SWITCH_POLL: float = 0.05
    # ==================================
    # 【10-30 用戶: 開場沒強制維里奈起手, 緋雪直接打】
    # 起手標記(verina_opener_done)和"本場放過 R2"(hiyuki_r2_used)以前只在 on_combat_end 清,
    # 但 on_combat_end 只有戰鬥結束時在場的那一個人會被叫到, 自動戰鬥中途被停掉/重開(log 07:52 那次)
    # 根本不會走到 —— 標記留著上一場的值: 不強制維里奈、緋雪直接走循環軸。
    # 現在三個角色上場時都先看"全隊上一次有動作是多久以前": 超過 NEW_FIGHT_GAP 秒 = 新的一場,
    # 標記全部重置。輪轉中途是直接切人, 兩個人之間幾乎沒有空檔, 不會誤判
    NEW_FIGHT_GAP = 8.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_heavy = -1
        self.check_f_on_switch = False

    def reset_state(self):
        super().reset_state()
        # 理由同緋雪/穗穗: apply_team_char_classes() 的 __dict__.update 會把 __init__ 裡的值打回內建值
        self.check_f_on_switch = False

    def on_combat_end(self, chars):
        # 緋雪的"本場放過 R2"存在 task 上, 戰鬥結束時誰在場誰負責清
        self.task.hiyuki_r2_used = False
        # 下一場重新強制維里奈起手
        self.task.verina_opener_done = False

    # ==================== 鎖定丟失自動重鎖 / 沒怪自動收手 ====================
    # (11-04 用戶, 照心鎖守/心鎖維 v1.0.1 那套搬過來)
    # 站場期間每 NO_ENEMY_CHECK_EVERY 秒讀一次畫面(掛在每一個等待裡: macro_wait / sleep):
    #   Boss 圖示 / 鎖定框在            -> 正常
    #   沒鎖定、但畫面上有怪物血條      -> 每 RELOCK_EVERY 秒按一次中鍵重鎖; 連續 RELOCK_GIVE_UP 秒鎖不到就收手
    #   Boss、鎖定框、血條都讀不到      -> 也每 RELOCK_EVERY 秒按中鍵試著鎖(沒血條的怪); 連續 NO_ENEMY_ABORT 秒就收手
    # Boss 戰只看 Boss 圖示, 不按中鍵(首領挑戰裡鎖定框整局都讀不到)。
    # 按住普攻 / 按住技能鍵的期間不按中鍵: PostMessage 每發一次鍵都投 WM_ACTIVATE, 會把按住打斷。
    # HUD 不在(大招演出 / 變奏入場 / 時停)讀不到, 計時全部從頭算。
    # 收手 = 丟 NoEnemy 例外, 這一圈到此為止, 按住的鍵由各自的 finally 鬆開, 交回框架(脫戰判定由框架接手)。
    # 切人(leave)期間不查: 緋雪 R2 後那段"等下一波再切"有自己的等待邏輯
    NO_ENEMY_ABORT = 5.0         # 0 = 關掉"沒怪自動收手"(重鎖照按)
    NO_ENEMY_CHECK_EVERY = 0.25
    RELOCK_EVERY = 0.40
    RELOCK_GIVE_UP = 4.00

    def enemy_watch_start(self):
        """這一圈開始盯怪。每次 do_perform 呼叫一次。"""
        now = time.time()
        self.enemy_watch = True
        self.enemy_seen_at = now
        self.enemy_check_at = 0.0
        self.unlocked_since = None
        self.relock_n = 0
        self.relock_at = 0.0
        self.attack_held = False
        self.keys_held = 0

    def enemy_watch_stop(self):
        self.enemy_watch = False

    def attack_down(self):
        """按住普攻(記下來, 按住期間不按中鍵)。"""
        self.attack_held = True
        self.task.mouse_down()

    def attack_up(self):
        self.task.mouse_up()
        self.attack_held = False

    def key_down(self, key):
        """按住技能鍵(記下來, 按住期間不按中鍵)。"""
        self.keys_held = getattr(self, 'keys_held', 0) + 1
        self.task.send_key_down(key)

    def key_up(self, key):
        self.task.send_key_up(key)
        self.keys_held = max(0, getattr(self, 'keys_held', 0) - 1)

    def sleep(self, sec, check_combat=True):
        """框架的 sleep, 睡完順手查一次場上還有沒有怪(check_enemy_gone)。"""
        super().sleep(sec, check_combat)
        self.check_enemy_gone()

    def heavy_attack(self, duration=0.6):
        """框架的重擊, 改成按住期間記下來(不按中鍵), 中途收手也一定鬆開。"""
        self.check_combat()
        self.attack_down()
        try:
            self.sleep(duration)
        finally:
            self.attack_up()
        self.sleep(0.01)

    def relock(self, now):
        """按一下中鍵重鎖。按住普攻/技能鍵的時候不按。"""
        if getattr(self, 'attack_held', False) or getattr(self, 'keys_held', 0) > 0:
            return
        if now - self.relock_at < self.RELOCK_EVERY:
            return
        self.relock_at = now
        self.relock_n += 1
        try:
            self.task.middle_click()
        except Exception as e:
            self.logger.info(f'{self.char_name}: middle click failed ({e})')

    def check_enemy_gone(self):
        """見上面那段說明。不刷新畫面, 讀當前幀(等待裡本來就一直在讀畫面)。"""
        if not getattr(self, 'enemy_watch', False):
            return
        now = time.time()
        if now - self.enemy_check_at < self.NO_ENEMY_CHECK_EVERY:
            return
        self.enemy_check_at = now
        t = self.task
        try:
            hud = bool(t.in_team()[0])
        except Exception:
            hud = False
        if not hud:
            self.enemy_seen_at = now
            self.unlocked_since = None
            return
        try:
            boss = bool(t.is_boss())
        except Exception:
            boss = False
        if boss or self.target_visible():
            self.enemy_seen_at = now
            if self.unlocked_since is not None:
                self.logger.info(f'{self.char_name}: 重新鎖定(中鍵 x{self.relock_n}, '
                                 f'{now - self.unlocked_since:.2f}s)')
            self.unlocked_since = None
            self.relock_n = 0
            return
        try:
            bar = bool(t.has_health_bar())
        except Exception:
            bar = False
        if self.unlocked_since is None:
            self.unlocked_since = now
            self.relock_n = 0
        self.relock(now)
        if bar:
            self.enemy_seen_at = now
            if now - self.unlocked_since >= self.RELOCK_GIVE_UP:
                self.enemy_watch = False
                raise NoEnemy(f'有血條但 {now - self.unlocked_since:.1f}s 鎖不到怪'
                              f'(中鍵 x{self.relock_n}, 怪太遠/血條誤讀?)')
            return
        if self.NO_ENEMY_ABORT > 0 and now - self.enemy_seen_at >= self.NO_ENEMY_ABORT:
            self.enemy_watch = False
            raise NoEnemy(f'場上 {now - self.enemy_seen_at:.1f}s 讀不到怪(這一波打完了), 收手')

    def target_visible(self):
        """鎖定目標在不在。照 CombatCheck.has_target() 的前三個讀框, 去掉它最後那個兜底分支 ——
        那個分支會 sleep(1) 再連按兩次 ESC, 不能在軸裡呼叫(同緋雪那份)。"""
        t = self.task
        try:
            has_name, no_name = t.get_target_names()
            for box in (t.get_box_by_name(has_name).scale(1.1), t.get_box_by_name('box_target_enemy_long'),
                        t.get_box_by_name('target_box_long2')):
                best = t.find_best_match_in_box(box, [has_name, no_name], threshold=0.6)
                if best:
                    return best.name == has_name
        except Exception as e:
            # 別的 ok-ww 版本這幾個讀框/方法可能改名了: 當成有怪, "沒怪自動收手"失效但不會誤收手
            if not getattr(self, '_target_visible_warned', False):
                self._target_visible_warned = True
                self.logger.warning(f'{self.char_name}: target_visible unsupported in this ok-ww version ({e!r}), '
                                    f'assuming a target is there')
            return True
        return False

    def do_perform(self):
        try:
            self.check_new_fight()
            # 起手完成的標記一上場就打: 之後穗穗/緋雪空手上場也不會再被拉回來
            self.task.verina_opener_done = True
            self.enemy_watch_start()
            con_full = self.perform_combat()
            self.leave(con_full)
        except NoEnemy as e:
            self.logger.warning(f'verina turn aborted ({e})')
        finally:
            self.enemy_watch_stop()
            self.mark_team_active()

    def check_new_fight(self):
        """全隊上一次有動作超過 NEW_FIGHT_GAP 秒 = 新的一場: 重置起手標記和"本場放過 R2"。Returns: 是不是新的一場。"""
        now = time.time()
        last = getattr(self.task, 'team_last_active', 0) or 0
        new = last <= 0 or now - last > self.NEW_FIGHT_GAP
        if new:
            self.task.verina_opener_done = False
            self.task.hiyuki_r2_used = False
            self.task.hiyuki_intro_handoff = 0
            self.task.suisui_intro_handoff = 0
            idle = f'{now - last:.0f}s' if last > 0 else 'first run'
            self.logger.info(f'{self.char_name}: new fight (team idle {idle}), opener re-armed')
        self.task.team_last_active = now
        return new

    def mark_team_active(self):
        self.task.team_last_active = time.time()

    def perform_combat(self):
        """單輪: 循環(補放這輪還沒放出去的 E/Q, R 亮著也放 -> 星星花連段 -> 協奏沒滿就普攻打滿 5 段)
        -> 必做的都放過且協奏滿就返回。Returns: 協奏滿了沒有(決定交棒時有沒有延奏)。"""
        start = time.time()
        need = [k for k in self.MUST_CAST if k != 'R' or self.r_enabled()]
        done = {k: False for k in need}
        r_cast = False  # 這輪放過 R 沒有; R 不在必做清單時也只放一次
        combos = 0

        def ready():
            return all(done.values()) and self.is_con_full()

        while True:
            # 這輪還沒放出去的才放; 放出去了就記下, 冷卻沒好就下一圈再試。E 先放: 它給 1 層光合能量
            if 'E' in done and not done['E'] and self.cast_resonance():
                done['E'] = True
            if 'Q' in done and not done['Q'] and self.cast_echo():
                done['Q'] = True
            # R: 亮著就放(不強制時沒亮就算了, 不等); 放過一次就不再放
            if not r_cast and self.cast_liberation():
                r_cast = True
                if 'R' in done:
                    done['R'] = True

            if ready():
                self.sleep(self.CON_FULL_STABLE_DELAY)
                self.logger.info(f'verina done: {"".join(need)} cast + con full, R {"cast" if r_cast else "skipped"}, '
                                 f'starflower combos x{combos} ({self.time_elapsed_accounting_for_freeze(start):.1f}s)')
                return True

            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= self.FIELD_CAP:
                missing = [k for k, v in done.items() if not v]
                con_full = self.is_con_full()
                self.logger.warning(f'verina hit FIELD_CAP {elapsed:.1f}s, missing {missing or "-"}, '
                                    f'con {self.get_current_con():.2f}, leaving anyway')
                return con_full

            # 協奏沒滿: 星星花連段(有光合能量才回協奏; 沒有就是普通重擊 + 空中攻擊, 不虧多少)
            if not self.is_con_full() and self.can_heavy_attack():
                self.starflower_combo()
                combos += 1
                if ready():
                    continue
            # 還差東西: 普攻打滿 5 段補 1 層光合能量(同時也在等 E/Q 冷卻)
            self.ground_attack(self.NORMAL_STRING_COUNT, ready)

    def starflower_combo(self):
        """重擊星星花綻放 -> 短按普攻接空中攻擊星星花綻放。有光合能量時各吃 1 層、各回一次協奏。"""
        self.heavy_attack(self.HEAVY_ATTACK_DURATION)
        self.last_heavy = time.time()
        self.sleep(self.HEAVY_TO_AIR_TAP)
        self.normal_attack()
        self.sleep(self.AIR_ATTACK_SETTLE)

    def r_enabled(self):
        return self.USE_LIBERATION and self.task.use_liberation

    def ground_attack(self, count, stop):
        """地面普攻 N 下, 每下檢查 stop(), 成立就立即停止。第 5 段命中給 1 層光合能量。"""
        for _ in range(count):
            self.normal_attack()
            self.sleep(self.NORMAL_ATTACK_GAP)
            if stop():
                return

    def cast_resonance(self):
        """共鳴(E): 可用才放; 按下後確認圖示進入 CD 才算成功, 被擊退等原因沒放出則重試, 直到成功或逾時。"""
        if not self.resonance_available():
            return False
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.SKILL_CAST_TIMEOUT:
            self.click_resonance(send_click=True, time_out=0, click_f=False)
            self.sleep(self.SKILL_RETRY_GAP)
            if not self.resonance_available():
                return True
        return False

    def cast_echo(self):
        """聲骸(Q): 可用才放; 按下後確認圖示進入 CD 才算成功, 被擊退等原因沒放出則重試, 直到成功或逾時。"""
        if not self.echo_available():
            return False
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.SKILL_CAST_TIMEOUT:
            self.click_echo(time_out=0)
            self.sleep(self.SKILL_RETRY_GAP)
            if not self.echo_available():
                return True
        return False

    def cast_liberation(self):
        """大招(R): 可用才放; click_liberation 內部會重試並等動畫結束回到隊伍畫面。
        click_f=False: 預設會在大招動畫期間每 0.1 秒按一次 F, 會把緋雪軸上那一處處決提前吃掉。"""
        if not self.r_enabled() or not self.liberation_available():
            return False
        return self.click_liberation(click_f=False)

    def can_heavy_attack(self):
        """距上次重擊是否已超過最小間隔(扣除凍結時間)。HEAVY_ATTACK_INTERVAL = 0 時永遠成立。"""
        if self.HEAVY_ATTACK_INTERVAL <= 0:
            return True
        return self.time_elapsed_accounting_for_freeze(self.last_heavy) >= self.HEAVY_ATTACK_INTERVAL

    def leave(self, con_full):
        """離場: 優先按數字鍵直接切穗穗, 失敗才退回框架切人。"""
        self.enemy_watch_stop()
        if not self.direct_switch(assume_intro=con_full):
            self.switch_next_char()

    def direct_switch(self, assume_intro=False):
        """按數字鍵直接切給交棒對象, 並按框架約定標記離場。"""
        target = self.switch_target()
        if target is None or target is self:
            return False
        has_intro = True if assume_intro else self.wait_con_full()
        if not self.switch_to_index(target.index):
            self.logger.warning(f'verina direct switch to slot {target.index + 1} failed')
            return False
        self.logger.info(f'verina direct switched to slot {target.index + 1} (intro={has_intro})')
        self.handoff_to(target, has_intro)
        return True

    def switch_to_index(self, index, timeout=None):
        """按數字鍵切到指定隊伍位置, 重發到 in_team 確認切過去了為止。輪詢快、重發慢(理由見穗穗那份)。"""
        timeout = self.SWITCH_TIMEOUT if timeout is None else timeout
        start = time.time()
        last_send = 0.0
        while time.time() - start < timeout:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == index:
                return True
            if time.time() - last_send >= self.SWITCH_KEY_RESEND:
                self.task.send_key(index + 1)
                last_send = time.time()
            self.sleep(self.SWITCH_POLL, check_combat=False)
        return False

    def handoff_to(self, target, has_intro):
        """複刻 switch_next_char() 內部那套交接記帳(同穗穗)。

        Args:
            has_intro: 離場時協奏是否滿, 必須在按切人鍵之前讀好 ——
                切走之後能量環顯示的已經是新角色的了。
        """
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = time.time()
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        """短暫輪詢協奏是否滿。能量環讀數滯後, 只讀一次會把 has_intro 誤判成 False。"""
        if self.task.wait_until(self.is_con_full, time_out=self.HANDOFF_CON_WAIT):
            return True
        self.logger.info('verina: con not full before switch, next char gets no intro')
        return False

    def switch_target(self):
        """交棒對象: 先按角色名找, 找不到再退回寫死的槽位(排除自己)。"""
        for char in self.task.chars:
            if char is not None and char is not self and char.char_name == self.SWITCH_TARGET_NAME:
                return char
        index = self.DIRECT_SWITCH_INDEX - 1
        return next((c for c in self.task.chars
                     if c is not None and c is not self and c.index == index), None)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """本場還沒起手: MUST。緋雪下場時維里奈接棒: 帶變奏 MUST, 不帶 HIGH。"""
        if not getattr(self.task, 'verina_opener_done', False):
            return SwitchPriority.MUST
        if current_char is not None and current_char.char_name == self.FOLLOW_AFTER_NAME:
            return SwitchPriority.MUST if has_intro else SwitchPriority.HIGH
        return super().get_switch_priority(current_char, has_intro, target_low_con)