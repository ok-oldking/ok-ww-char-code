import time

from src.char.BaseChar import BaseChar, SwitchPriority


class NoEnemy(Exception):
    """場上沒怪 / 鎖不到怪: 這一圈到此為止, 交回框架(見 check_enemy_gone)。"""



class Hiyuki(BaseChar):
    """緋雪主C: 放R變身 -> 爆發宏 -> 切人。

    爆發宏分兩段:
      定時段  A3 -> 閃避 -> A3 -> 長按E升空 -> 空中居合x2(第2發後點E下落)
              -> A3 -> [處決 -> A1]  (方括號內只在真有處決提示時走)
      收尾段  閃避進架勢 -> 居合x3(GROUND_KENDO_COUNT_FIRST / GROUND_KENDO_COUNT) -> 預輸入重擊 -> 重擊中按住R -> R2
    啟動軸(本場第一輪)和循環軸各自選版本, 見 OPENER_KIND / LOOP_KIND(10-30 起兩者預設都是 'short'):
      'ee'    R1 -> E點按升空 -> E長按落地 -> 收尾段(居合x3)       (2鏈以上)
      'short' A3 -> 處決(有提示時)/閃避 -> E點按升空 -> E長按落地 -> 收尾段(居合x3)
      'guide' E(霜罰) x2 -> 預求身普攻 5 段 -> 收尾段(居合x3)       (攻略標準軸)
    省掉空中兩刀、處決和兩條A鏈, 那幾處都是 ±0.1 秒級的窗口, 開場被打斷最容易在那裡斷

    兩段都按秒走: 空中居合、處決後那發A、重擊接R 的容錯都在 ±0.1 秒級,
    而 executor.sleep 每 0.4 秒插一次 next_frame 截圖且位置不可控, 排不了這種時序。
    寬鬆的普攻連段仍然走框架的 continues_normal_attack。
    收尾段(10-26 起預設讀屏, 見 READING_FINISH): 閃避 -> 等架勢圖標 -> 居合 -> 枯霜重擊 -> R 亮才按 -> 確認 R2 出去才切人。

    隊伍: 維里奈 / 穗穗 / 緋雪。輪轉 維里奈 -> 穗穗 -> 緋雪 -> 維里奈, 每場戰鬥強制維里奈起手:
    緋雪沒帶變奏上場、而本場維里奈還沒起過手時, 不打任何東西, 直接切維里奈(見 hand_to_opener)。
    """

    FIELD_TIME_OUT = 16.0
    INTRO_HOLD_TIMEOUT = 8.0
    STANDARD_LIB_CD_MAX = 3.5
    STANDARD_HOLD_SLICE = 1.0
    HEAVY_FORTE_TIME_OUT = 1.2

    # 定時段。標定: A3鏈 1.10 太早(特效沒出就閃避), 1.20~1.35 都出
    M_A_CHAIN = 1.20
    M_A_INTERVAL = 0.15
    M_A_ONE = 0.55  # 處決後那發A: 接第三段, 不是新連段
    M_AFTER_DODGE = 0.35
    M_HOLD_E_RISE = 0.85  # 要夠長按判定, 否則退化成點按飛不起來
    M_HOLD_E_LAND = 0.85
    M_AFTER_RISE = 0.28  # 壓小第一發空中居合會被吞
    M_AIR_KENDO_INTERVAL = 0.60  # 空中動作更長, 用地面的 0.45 會吃掉第二刀
    M_KENDO_LAND = 0.55  # 小了就是拿E把最後一刀取消掉
    M_AFTER_PLUNGE = 0.90
    M_LAND_RECOVER = 0.20
    M_EXECUTE_ANIM = 1.60  # 時停期間畫面靜止, 找圖無效只能按秒等
    AIR_KENDO_COUNT = 2
    RISE_E_WAIT = 1.2

    # 啟動軸用哪一版, 只管本場第一輪, 循環軸不受影響:
    #   'ee'    = R1 後直接 EE 三居合(10-08 晚)。幀表: R1 給 50 寒意, 地面E/空中E 各 75、2鏈各再 +50,
    #             50+125+125 = 300 = 正好三刀(居合架勢要 ≥100, 每刀扣 100), A3 就不用打了。
    #             【要 2 鏈以上】: 不到 2 鏈只有 200, 第三刀出不來, 用 'short'
    #             【還要共效夠高】: 少了 A3 那幾下, R2 打完協奏不滿, 延奏給不出去(10-08 19:00 實機)
    #   'short' = A3 -> 處決/閃避 -> EE 三居合(10-08 下午, 實機跑通過)
    #   'full'  = 原來的五居合
    OPENER_KIND = 'short'
    # 循環軸(本場第二輪起)用哪一版, 選項同上。【10-26 改成 'short'】: 對照技能說明 ——
    #   R1 只給 50 寒意、3 點武霜; 每刀居合吃 100 寒意 + 1 點武霜換 1 層淬寒; 淬寒滿 3 層重擊才是枯霜,
    #   枯霜重擊才給 1 點鍛雪。'full' 是空中 2 刀 + 地面 2 刀 = 4 刀要 400 寒意, 中間只靠幾段 A3 補,
    #   寒意不夠時點下去不出刀 = "居合打到一半停住"; 空中兩刀被吞, 淬寒疊不滿, R2 也接不上。
    #   'short' 是首輪實機跑通的那條, 3 刀正好用完 3 點武霜、疊滿 3 層淬寒
    # 【10-26 第二次 log 改成 'guide'】: 'short' 在循環軸每輪都要補救, 而且補救的成功模式一致 ——
    #   閃避進架勢 -> 居合 x3~4 -> 枯霜重擊 -> R2 才放得出去。也就是定時收尾那 3 刀根本沒砍到
    #   (補救時架勢還進得去、還砍得出刀 = 寒意還在, 沒被花掉)。首輪看起來正常, 是因為脫戰 4 秒
    #   固有技能會送 1 點鍛雪、開場大招能量也是滿的, 把問題蓋掉了。
    #   'short' 的 E點按 -> E長按: 霜罰之後長按 E 本身就會進居合架勢, 收尾段緊接著又閃避一次,
    #   很可能把剛進的架勢閃掉; 寒意也只有 R1 的 50 + 一條 A3 + 一發 E, 不保證夠 300。
    #   'guide' = 攻略標準軸: R1 -> E(霜罰) x2 -> 預求身普攻 5 段攢滿 300 寒意 -> 收尾段(閃避進架勢 -> 居合 x3
    #             -> 枯霜重擊 -> R2)。E 不長按, 架勢只靠收尾段那一下閃避進
    # 【10-30 第二份 log 改回 'short'】: 收尾改成讀屏之後, short 每輪 4.9 秒(一次架勢砍滿 3 刀 + 枯霜重擊),
    # guide 大多 12~20 秒(5 段普攻攢不滿 300 寒意, 架勢砍一兩刀就沒了, 枯霜重擊出不來, 普攻乾等 R 亮)
    LOOP_KIND = 'short'
    GUIDE_E_SETTLE = 0.45  # 每發霜罰之後等多久再接下一個動作
    GUIDE_E_COUNT = 2  # 霜罰最多放幾發(第二發沒好就跳過)
    GUIDE_A_STRING = 2.30  # 預求身普攻打多久(5 段)。補救裡常看到"架勢還進得去"就往上加
    EE_AFTER_R1 = 0.10
    # 'ee' 版沒有 A3 了, 處決也就沒地方插; 改成 True 會在 R1 之後、EE 之前有提示就按一次 F
    EE_EXECUTE_FIRST = False
    # 短版的 E E 照搬緋雪單人軸(09-29 實機一次過): 預求地面E 第20F轉空中、派生35F,
    # 之後按的第二個 E 才是空中E; 空中E 下落 16F 起判定、持續 30F, 落地派生 6F。
    # 8 月這條隊標定過"長按 0.85s 才升空、點按飛不起來"(那時E緊跟在A鏈後面);
    # 10-08 'short' 版實機點按升得起來。'ee' 版 E 緊跟在 R1 後面, 要是沒把人頂上天就改成 0.85
    EE_TAP = 0.03
    EE_E1_TO_E2 = 0.45
    EE_E2_HOLD = 0.75
    EE_E2_AFTER = 0.10
    # 短版 A3 之後有處決提示就用處決代替閃避。M_EXECUTE_ANIM 是按"處決後接一下A不被吞"標定的,
    # 處決動畫長度又隨敵人變; 後面那下E點按只有一發, 落在演出裡就升不了空, 所以再等 HUD 回來
    EXEC_HUD_WAIT = 3.0
    EXEC_TO_E = 0.05

    # 收尾段, 純定時。居合間隔要略小於居合動畫(約0.5s)讓點擊排隊, 但不能小於動畫一半否則丟刀
    M_KENDO_INTERVAL = 0.45
    # 閃避之後馬上接居合。只留 3 幀, 讓閃避和第一刀落在不同的遊戲幀裡, 同一幀裡只認一個
    M_DODGE_TO_KENDO = 0.05
    GROUND_KENDO_COUNT_FIRST = 3  # 啟動軸
    # 循環軸。【10-26 由 2 改 3】: 枯霜重擊要 3 層淬寒 = 3 刀吃到武霜的居合, 少一刀這輪就沒有鍛雪
    # (LOOP_KIND 改回 'full' 時, 空中已經有 2 刀, 這裡可以改回 2)
    GROUND_KENDO_COUNT = 3
    # 收尾段全部從【閃避】算起, 按幀表排, 不讀屏:
    #   第一刀出刀   閃避後 KENDO1_DELAY
    #   第 N 刀出刀  再加 (N-1)*39F  —— 幀表 居合派生幀39F(0.65): 3 刀 78F, 2 刀 39F
    #   重擊起手     最後一刀再過 39F(預輸入的重擊在最後一刀派生那一幀起手)
    # 閃避到第一刀出刀這段幀表裡沒有, 實機反推: 07:10 閃避後 0.31 秒才點第一刀嫌慢(<0.31);
    # 07:29 按"點了就出刀"排、閃避後 1.40 秒按住攻擊, 第三刀被頂掉(>0.10)
    KENDO1_DELAY = 0.20
    KENDO_DERIVE = 0.65
    KENDO_SPAM_INTERVAL = 0.10  # 連點, 派生幀那一刻緩存裡總有一下; 刀變少就往 0.25 調
    KENDO_SPAM_LAST_GAP = 0.05  # 最後一下點擊離按住攻擊至少這麼遠, 太近兩下會連成一下
    # 按住攻擊(預輸入重擊)放在最後一刀出刀和它派生幀的正中: 早了頂掉最後一刀, 晚了重擊
    # 接不上。KENDO1_DELAY 是估的, 取正中兩邊各留 0.3 秒, 估偏一點也不出事
    KENDO_OUT_TO_HOLD = 0.30
    # 按住 R 從重擊起手算, 按下的同時鬆攻擊。R 必須在重擊起手之後才第一次按下:
    # 07:29 重擊之前就按住 R, 重擊後 R2 沒起; 接得上的只有"起手後 0.8 秒按"這一種。
    # 舊標定: <=0.35 必頂掉重擊, 0.6/0.7 偶發, 0.95 停頓明顯
    HEAVY_TO_R = 0.80
    HEAVY_ANIM = 2.50  # 幀表: 強化重擊 派生幀150F, 演完才進 R2 蓄力
    # 蓄力時長沿用之前實機放得出來的值: 舊 R 按住 9.05/4.05, 減去當時 R 按下到重擊演完的 1.70
    R2_CHARGE_FIRST = 7.35  # 啟動軸: 2鏈以上能蓄 3 段(幀表 3 層 210F)
    R2_CHARGE = 2.35  # 循環軸: 只能蓄 1 段(幀表 1 層 96F)
    # 只給兜底路徑 hold_liberation 用; 收尾段的蓄力時長看 R2_CHARGE_FIRST / R2_CHARGE
    R2_HOLD_FIRST = 9.05
    # 【11-05 log】循環軸 R2 演出都在按下 R 後 2.1 秒出來(3 輪一樣); 按滿 4.05 秒還沒演出 = 這一下沒接上,
    # 多按的那 2 秒就是站著發呆。改成 3.0, 沒接上時少站 1 秒
    R2_HOLD = 3.0

    # 【收尾段的兩道檢查】(10-25 用戶: 第二輪起居合打到一半停住發呆 / 沒收尾大招就切人 / 大招能量不足)
    # 收尾段是純定時的, 有兩種情況會讓按住的 R 放不出 R2, 人原地站到 R 鬆開:
    #   a. 居合刀數寫死, 寒意不夠時刀數對不上 / 架勢裡還剩刀 -> 按住攻擊不出強化重擊
    #   b. R2 的大招能量還沒滿 -> R 圖標是暗的, 按了沒反應
    #   檢查 1(按 R 之前): 讀兩幀, 架勢圖標還亮著(a) 或 R 是暗的而且沒在冷卻(b) -> 這次不按 R, 走 recover_r2()
    #   檢查 2(R 鬆開之後): 大招還沒進冷卻 = R2 沒放出去 -> 走 recover_r2()
    #   recover_r2(): 讀屏一直打到大招能量滿 —— 有架勢打居合, 有強化重擊圖標出重擊, 其餘普攻連段 ——
    #                 R 一亮就按住放 R2 收尾
    # 判斷 R2 有沒有放出去: 見 r2_out() —— 先看形態(回到常世身 = 放出去了), 判不了才看大招冷卻。
    # has_long_action() / has_long_action2() 是"鎖定框落在哪個位置": 兩個形態的回路條長短不同, 所以有鎖到
    # 敵人時能分出常世身/預求身; 沒鎖到敵人(換波空檔)兩個都讀不到, 這時形態判不了
    VERIFY_KENDO_DONE = True
    STANCE_CHECK_LEAD = 0.25  # 檢查 1 在按 R 之前這麼久做, 讀屏時間不會把按 R 的時刻往後推
    STANCE_CHECK_GAP = 0.08  # 兩次讀屏之間的間隔, 兩次都成立才算(單幀誤判不算)
    R2_READY_CHECK_GAP = 0.15
    # 大招冷卻超過這個值 = R2 已經放出去了(同框架原版 hold_liberation 的判斷: 沒放之前冷卻 <= 1.5)
    R2_DONE_CD = 1.5
    # 形態判不了(沒鎖到敵人)時, 冷卻要到這麼大才當成 R2 已經放出去(R1 的長冷卻)。
    # 03:59:08 / 04:00:15 兩輪預求身裡就讀到冷卻 > 1.5, 用 1.5 當門檻會誤判成已放出
    R2_DONE_CD_STRONG = 10.0
    # 【10-26 用戶: 共鳴效率 119%(攻略建議 125%), R2 偶爾能量不夠 —— 要打到 R2 確實放出去才准切人】
    # 補救的總上限拉到 25 秒, 實際上只有兩種情況會提早放棄:
    #   場上連續 NO_TARGET_GIVEUP 秒找不到敵人(打不到東西就攢不了能量, 多半是整場打完了)
    #   超過 RECOVER_CAP(防呆, 正常不會碰到)
    # 放棄後交回 do_perform: perform_lib 兜底 -> 還是不行才離場
    RECOVER_CAP = 25.0
    NO_TARGET_GIVEUP = 6.0
    RETARGET_INTERVAL = 0.5  # 補救中找不到敵人時按中鍵重新鎖定的間隔
    # 補救裡沒架勢、沒強化重擊時的普攻: 每 M_A_INTERVAL 點一下, 一段最多打這麼久再回頭看狀態
    RECOVER_ATTACK_SLICE = 1.2
    # 補救裡用來進居合架勢的兩個手段(有寒意才進得去, 沒有就只是一次普通閃避/霜罰, 不影響):
    #   架勢提示圖標(hiyuki_right, 框架原版 perform_lib 同款判斷)亮著 -> 按一下閃避
    #   霜罰(E)沒在冷卻 -> 點一下 E: 回寒意 + 聚怪, 之後一段時間內閃避就能進架勢
    RECOVER_E_SETTLE = 0.35
    RECOVER_DODGE_SETTLE = 0.10
    # 【10-26 log】03:03:30 那輪補救按了 R(R 亮著), 但 0.2 秒就切走、HUD 沒被 R2 演出藏起來,
    # 下一輪緋雪上場沒放 R1 直接走兜底 = 上一輪 R2 其實沒出去(按鍵被當時的普攻動作吞了)。
    # 所以按 R 之後一定要看大招進沒進冷卻; 沒進就回補救迴圈重來, 最多按這麼多次
    R2_PRESS_TRIES = 3
    # 【10-26 第二次 log】技能說明: 鬆開 R 時還沒消耗到鍛雪, 會"繼續蓄力一定時間後自動施放"。
    # 以前鬆開 0.1 秒就判"R2 沒出去"、補救馬上再按一次 R —— 正好按在蓄力/自動施放中間, 又白按住 4 秒,
    # 這兩段就是"第二段大招時站著發呆"。現在鬆開後最多等這麼久: 期間 HUD 被藏起來(R2 演出)
    # 或大招進冷卻, 都算放出去了
    R2_SETTLE = 3.0
    # 補救裡最多自己閃避進架勢幾次(進架勢的提示可能一直亮, 不設上限會一直砍下去不放 R)
    RECOVER_STANCE_TRIES = 2

    # 【10-26 第三次 log: 收尾段改成讀屏】
    # 三份 log 裡每一輪(啟動軸/循環軸、short/guide 都一樣)R2 都是在補救裡、而且都是照
    #   "閃避進架勢 -> 看到架勢圖標才連點居合 -> 枯霜重擊 -> R 亮了才按"
    # 這個順序才放出去的; 定時收尾那一套(閃避後 0.05 秒就開始盲點)沒有一輪真的砍出居合 ——
    # 補救時架勢都還進得去、還砍得出 3~4 刀。所以收尾段整段改成跟補救同一套讀屏流程:
    #   READING_FINISH = True : 閃避 -> 等架勢圖標出現才點居合 -> 架勢沒了 -> 枯霜重擊(只出一次)
    #                           -> R 亮了才按(按住到蓄滿, 鬆開後確認進冷卻) -> 切人
    #   READING_FINISH = False: 退回原本的定時收尾(hold_heavy_into_r2), 失敗再補救
    READING_FINISH = True
    STANCE_APPEAR_WAIT = 0.6  # 閃避之後等架勢圖標出現的上限; 等不到就當這下閃避沒進架勢
    # 枯霜重擊: 按住攻擊到圖標滅、最多 HEAVY_HOLD_CAP 秒; 鬆開後不再發任何輸入, 等圖標滅最多 HEAVY_CLEAR_WAIT 秒。
    # 以前一直按住攻擊重試(log 裡的 heavy x2~x3 + wait_until timeout 1.2s): 圖標在重擊演出期間不會馬上滅
    HEAVY_HOLD_CAP = 1.2
    HEAVY_CLEAR_WAIT = 2.0
    # 枯霜重擊起手後至少這麼久才按 R(舊標定: 重擊起手 <=0.35 秒按 R 會把重擊頂掉)
    HEAVY_TO_R_MIN = 0.8
    # 居合砍完但一直沒讀到枯霜重擊圖標(圖標辨識失敗)時, 等這麼久就不等了, R 亮就按
    HEAVY_MISSING_GRACE = 2.5
    # 【03:38:07 那輪】補救一開始 R 就亮了、按下去沒出去, 空按住 4 秒 + 等 3 秒。
    # 現在枯霜重擊沒出之前不按 R; 只有居合/重擊一直做不出來(超過這麼久)才退而求其次直接按
    R_BEFORE_HEAVY_AFTER = 8.0

    # 【人在空中】(10-25 用戶: 打到人物停在空中沒落地也會出問題)
    # 收尾段的閃避/居合/預輸入重擊全是照地面幀表排的, 人在空中時同樣的按鍵會變成空中動作, 整段對不上。
    # 進收尾段之前、補救過程中都先確認落地。
    # 【10-26 改用"按住攻擊下落"】: 技能說明裡空中按住普攻 = 空中下落攻擊; 空中點 E 是霜罰·落華(聚怪),
    # 不保證下落。按住攻擊逐幀看, 一落地立刻鬆; 按滿 PLUNGE_HOLD_CAP 還在空中才補點一次 E
    # 判斷在不在空中用框架的 flying(): 【只有帶著"控物"探索工具時才判得出來】, 沒帶永遠當成在地上
    GROUND_CAP = 2.0  # 等落地的總上限, 超了照樣往下走
    PLUNGE_HOLD_CAP = 0.9  # 按住攻擊最多這麼久; 還在空中就點 E 再試
    GROUND_POLL = 0.03

    LIB2_KENDO_COUNT = 3
    HOLD_LIB_TIME_OUT = 8.0
    HOLD_LIB_CD_WAIT = 1.5
    POST_LIB2_TEAM_WAIT = 1.0
    WAIT_LOCK_TIME_OUT = 2.0

    OUTRO_HARD_LIMIT = 25.0
    OUTRO_STALL_TIME = 6.0
    CON_TOP_UP_CHAIN = 0.5
    SWITCH_TARGET_NAME = 'char_verina'
    # 名字找不到時退回的槽位(1 起算)。隊伍排法: 1 穗穗 / 2 維里奈 / 3 緋雪
    DIRECT_SWITCH_INDEX = 2
    LIB_ANIM_WAIT = 4.0
    LEAVE_SWITCH_TIMEOUT = 3.5
    # R2 之後場上沒目標(這一波打完了)時, 等新怪刷出來再切維里奈的上限; 超了照切(可能整場打完了)
    WAVE_WAIT = 4.0
    TARGET_GONE_CONFIRM = 2  # 連著這麼多次讀不到鎖定目標才算沒怪, 單幀被特效擋住不算
    WAVE_LOCK_INTERVAL = 0.3  # 等新怪時按中鍵鎖目標的間隔
    # 穗穗用 handoff_to() 直接切給緋雪時打在 task 上的交接標記的保質期(同穗穗那套)
    INTRO_HANDOFF_TTL = 4.0
    # 強制起手的角色。本場它還沒上過場時, 緋雪空手上場就直接切給它
    OPENER_NAME = 'char_verina'
    OPENER_SWITCH_TIMEOUT = 2.0
    SWITCH_KEY_RESEND = 0.22  # 重發數字鍵的間隔, 別再加密(理由見穗穗那份)
    SWITCH_POLL = 0.05
    # 【10-30 用戶: 開場沒強制維里奈起手, 緋雪直接打】
    # 起手標記(verina_opener_done)和"本場放過 R2"(hiyuki_r2_used)以前只在 on_combat_end 清,
    # 但 on_combat_end 只有戰鬥結束時在場的那一個人會被叫到, 自動戰鬥中途被停掉/重開(log 07:52 那次)
    # 根本不會走到 —— 標記留著上一場的值: 不強制維里奈、緋雪直接走循環軸。
    # 現在三個角色上場時都先看"全隊上一次有動作是多久以前": 超過 NEW_FIGHT_GAP 秒 = 新的一場,
    # 標記全部重置。輪轉中途是直接切人, 兩個人之間幾乎沒有空檔, 不會誤判
    NEW_FIGHT_GAP = 8.0
    # 【10-30 晚 log: 拿掉"按住 1.2 秒 R 還亮就當沒接上"那道檢查】
    # 5 輪循環軸每一輪第一次按 R 都被它判成"沒接上"(log: R not taken after 1.2s) —— 正常蓄力時
    # HUD 本來就在、R 圖標也還亮着, 這道檢查根本分不出來。被它提早鬆開之後 R2 其實放出去了,
    # 程式卻以為沒有, 又去打普攻、再按一次 R, 這 6~10 秒就是"打完第二段大招發呆才切人"。
    # 改成反過來看: 按住 R 期間逐幀讀, HUD 被藏起來(R2 演出開始)連著 R2_HIDDEN_CONFIRM 幀就立刻鬆開,
    # 不再傻按到 r2_press_time() 滿; 蓄力中 HUD 一直在, 不會被誤鬆
    R2_HOLD_POLL = 0.1
    R2_HIDDEN_CONFIRM = 2
    # 【11-05 log 05:43:29】枯霜重擊沒出(heavy x0 = 沒有鍛雪)也按住 R 4 秒: 沒鍛雪可吃, 按住期間什麼都不會發生,
    # 鬆開之後才"繼續蓄力一段時間後自動施放", 前後站了 7 秒。沒出枯霜重擊時改成點一下 R, 讓它直接自動蓄力施放
    R2_TAP_WITHOUT_HEAVY = True
    R2_TAP = 0.10

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.lib_permission = True
        self.lib2_count = 0
        self.just_transformed = False
        # r2_used 不在這裡初始化: 它是存在 task 上的 property, 見下面
        self.macro_t0 = 0.0
        self.macro_marks = []
        # 關掉框架的切人自動按F: 默認 not is_healer 對主C是True, 會在每次交棒時
        # 替她按掉處決, 等她走到軸上那個F位時已經 skip F 了
        self.check_f_on_switch = False

    # 本場是否放過R2, 決定蓄力檔位和地面居合刀數。
    # 【存在 task 上, 不存在 self 上】: load_chars() 每次重讀隊伍都會把角色對象整個換掉
    # (apply_team_char_classes 建新實例), 掛在 self 上的值會回到初始值; reset_state() 也會跑。
    # 戰鬥中途重讀一次隊伍, 下一輪就會被當成啟動軸(3 刀 + 7.35 秒蓄力)。
    # 清零放在 on_combat_end: 戰鬥結束時在場的可能是任何一個人, 所以三個角色的 on_combat_end 都清。
    # property 是 data descriptor, 優先於實例 __dict__, __dict__.update 帶進來同名字段也蓋不掉它
    @property
    def r2_used(self):
        return bool(getattr(self.task, 'hiyuki_r2_used', False))

    @r2_used.setter
    def r2_used(self, value):
        self.task.hiyuki_r2_used = bool(value)

    def on_combat_end(self, chars):
        self.task.hiyuki_r2_used = False
        # 下一場重新強制維里奈起手
        self.task.verina_opener_done = False

    def switch_out(self, con_full=False):
        super().switch_out(con_full)
        self.lib2_count = 0
        self.just_transformed = False

    def reset_state(self):
        super().reset_state()
        # 【v3.5.32 起這一句必須在 reset_state 裡重申, 只寫 __init__ 保不住】:
        # CharFactory.apply_team_char_classes() 換成自定義類的寫法是
        # `replacement.__dict__.update(內置實例.__dict__)` —— __init__ 裡所有跟內置版
        # 取值不同的字段會被整個打回內置值。BaseChar.__init__ 是 `not self.is_healer`,
        # 所以非治療角色一律被打回 True, 框架就會在 switch_next_char() 裡替她按 F。
        # reset_state() 跑在那次 update 之後(load_chars: apply_team_char_classes -> 逐個
        # reset_state), 而且每次重讀隊伍都會再跑一遍, 放這裡才真的保得住。
        # 緋雪的處決由她自己在軸上那一處 send_key('f'), 不要框架代按。
        self.check_f_on_switch = False

    def check_new_fight(self):
        """全隊上一次有動作超過 NEW_FIGHT_GAP 秒 = 新的一場: 重置起手標記和"本場放過 R2"。Returns: 是不是新的一場。"""
        now = time.time()
        last = getattr(self.task, 'team_last_active', 0) or 0
        new = last <= 0 or now - last > self.NEW_FIGHT_GAP
        if new:
            self.task.verina_opener_done = False
            self.task.hiyuki_r2_used = False
            self.task.hiyuki_intro_handoff = 0
            self.task.suisui_intro_handoff = 0
            idle = f'{now - last:.0f}s' if last > 0 else 'first run'
            self.logger.info(f'{self.char_name}: new fight (team idle {idle}), opener re-armed')
        self.task.team_last_active = now
        return new

    def mark_team_active(self):
        self.task.team_last_active = time.time()

    def note_intro_handoff(self):
        """穗穗用直接切人的方式交接進場時調用。has_intro 會被 reset_state()/換實例清掉,
        標記寫在 task 上才扛得住(同穗穗)。"""
        self.task.hiyuki_intro_handoff = time.time()

    def took_intro_handoff(self):
        stamp = getattr(self.task, 'hiyuki_intro_handoff', 0) or 0
        return 0 < stamp and time.time() - stamp <= self.INTRO_HANDOFF_TTL

    def clear_intro_handoff(self):
        self.task.hiyuki_intro_handoff = 0

    # ==================== 鎖定丟失自動重鎖 / 沒怪自動收手 ====================
    # (11-04 用戶, 照心鎖守/心鎖維 v1.0.1 那套搬過來)
    # 站場期間每 NO_ENEMY_CHECK_EVERY 秒讀一次畫面(掛在每一個等待裡: macro_wait / sleep):
    #   Boss 圖示 / 鎖定框在            -> 正常
    #   沒鎖定、但畫面上有怪物血條      -> 每 RELOCK_EVERY 秒按一次中鍵重鎖; 連續 RELOCK_GIVE_UP 秒鎖不到就收手
    #   Boss、鎖定框、血條都讀不到      -> 也每 RELOCK_EVERY 秒按中鍵試著鎖(沒血條的怪); 連續 NO_ENEMY_ABORT 秒就收手
    # Boss 戰只看 Boss 圖示, 不按中鍵(首領挑戰裡鎖定框整局都讀不到)。
    # 按住普攻 / 按住技能鍵的期間不按中鍵: PostMessage 每發一次鍵都投 WM_ACTIVATE, 會把按住打斷。
    # HUD 不在(大招演出 / 變奏入場 / 時停)讀不到, 計時全部從頭算。
    # 收手 = 丟 NoEnemy 例外, 這一圈到此為止, 按住的鍵由各自的 finally 鬆開, 交回框架(脫戰判定由框架接手)。
    # 切人(leave)期間不查: 緋雪 R2 後那段"等下一波再切"有自己的等待邏輯
    NO_ENEMY_ABORT = 5.0         # 0 = 關掉"沒怪自動收手"(重鎖照按)
    NO_ENEMY_CHECK_EVERY = 0.25
    RELOCK_EVERY = 0.40
    RELOCK_GIVE_UP = 4.00

    def enemy_watch_start(self):
        """這一圈開始盯怪。每次 do_perform 呼叫一次。"""
        now = time.time()
        self.enemy_watch = True
        self.enemy_seen_at = now
        self.enemy_check_at = 0.0
        self.unlocked_since = None
        self.relock_n = 0
        self.relock_at = 0.0
        self.attack_held = False
        self.keys_held = 0

    def enemy_watch_stop(self):
        self.enemy_watch = False

    def attack_down(self):
        """按住普攻(記下來, 按住期間不按中鍵)。"""
        self.attack_held = True
        self.task.mouse_down()

    def attack_up(self):
        self.task.mouse_up()
        self.attack_held = False

    def key_down(self, key):
        """按住技能鍵(記下來, 按住期間不按中鍵)。"""
        self.keys_held = getattr(self, 'keys_held', 0) + 1
        self.task.send_key_down(key)

    def key_up(self, key):
        self.task.send_key_up(key)
        self.keys_held = max(0, getattr(self, 'keys_held', 0) - 1)

    def sleep(self, sec, check_combat=True):
        """框架的 sleep, 睡完順手查一次場上還有沒有怪(check_enemy_gone)。"""
        super().sleep(sec, check_combat)
        self.check_enemy_gone()

    def heavy_attack(self, duration=0.6):
        """框架的重擊, 改成按住期間記下來(不按中鍵), 中途收手也一定鬆開。"""
        self.check_combat()
        self.attack_down()
        try:
            self.sleep(duration)
        finally:
            self.attack_up()
        self.sleep(0.01)

    def relock(self, now):
        """按一下中鍵重鎖。按住普攻/技能鍵的時候不按。"""
        if getattr(self, 'attack_held', False) or getattr(self, 'keys_held', 0) > 0:
            return
        if now - self.relock_at < self.RELOCK_EVERY:
            return
        self.relock_at = now
        self.relock_n += 1
        try:
            self.task.middle_click()
        except Exception as e:
            self.logger.info(f'{self.char_name}: middle click failed ({e})')

    def check_enemy_gone(self):
        """見上面那段說明。不刷新畫面, 讀當前幀(等待裡本來就一直在讀畫面)。"""
        if not getattr(self, 'enemy_watch', False):
            return
        now = time.time()
        if now - self.enemy_check_at < self.NO_ENEMY_CHECK_EVERY:
            return
        self.enemy_check_at = now
        t = self.task
        try:
            hud = bool(t.in_team()[0])
        except Exception:
            hud = False
        if not hud:
            self.enemy_seen_at = now
            self.unlocked_since = None
            return
        try:
            boss = bool(t.is_boss())
        except Exception:
            boss = False
        if boss or self.target_visible():
            self.enemy_seen_at = now
            if self.unlocked_since is not None:
                self.logger.info(f'{self.char_name}: 重新鎖定(中鍵 x{self.relock_n}, '
                                 f'{now - self.unlocked_since:.2f}s)')
            self.unlocked_since = None
            self.relock_n = 0
            return
        try:
            bar = bool(t.has_health_bar())
        except Exception:
            bar = False
        if self.unlocked_since is None:
            self.unlocked_since = now
            self.relock_n = 0
        self.relock(now)
        if bar:
            self.enemy_seen_at = now
            if now - self.unlocked_since >= self.RELOCK_GIVE_UP:
                self.enemy_watch = False
                raise NoEnemy(f'有血條但 {now - self.unlocked_since:.1f}s 鎖不到怪'
                              f'(中鍵 x{self.relock_n}, 怪太遠/血條誤讀?)')
            return
        if self.NO_ENEMY_ABORT > 0 and now - self.enemy_seen_at >= self.NO_ENEMY_ABORT:
            self.enemy_watch = False
            raise NoEnemy(f'場上 {now - self.enemy_seen_at:.1f}s 讀不到怪(這一波打完了), 收手')

    def do_perform(self):
        try:
            self._do_perform()
        except NoEnemy as e:
            self.logger.warning(f'hiyuki turn aborted ({e}), timeline: {self.macro_timeline()}')
        finally:
            self.enemy_watch_stop()
            self.mark_team_active()

    def _do_perform(self):
        new_fight = self.check_new_fight()
        if self.flying():
            self.wait_down()
        # 新的一場: 上一場留下來的變奏記號全部作廢(新一場的第一個動作不可能帶變奏)
        intro = (self.has_intro or self.took_intro_handoff()) and not new_fight
        self.clear_intro_handoff()
        # 強制維里奈起手: 只在"空手上場"時讓出去。帶變奏上來的一定是穗穗交棒, 照常打 ——
        # 這樣就算戰鬥判定抖一下把起手標記清掉了, 輪轉中途也不會被拉回維里奈
        if not intro and self.opener_pending() and self.hand_to_opener():
            return
        self.enemy_watch_start()
        self.click_echo(time_out=0)

        # 帶變奏入場時先按住 intro_motion_freeze_duration 秒再讀大招圖標:
        # 入場動畫期間 HUD 假陽性 -> click_liberation 空放 -> 一路點普攻到超時
        if intro or not self.liberation_available():
            self.hold_attack_until_lib(
                min_hold=self.intro_motion_freeze_duration if intro else 0.0)

        if self.has_long_action() and self.task.get_cd('liberation') <= self.STANDARD_LIB_CD_MAX:
            self.perform_standard()

        lib_ok = False
        # 只看"這次站場變身了沒有"。掛在 has_long_action2() 下面的話,
        # 變身瞬間那個判定常常是 False, 整段爆發會被跳過
        if self.just_transformed:
            self.just_transformed = False
            lib_ok = self.transform_macro()

        if not lib_ok and not self.just_transformed and self.form_state() == 'trans':
            # 上場時就已經在預求身(上一輪 R2 沒放出去): 直接走讀屏收尾把 R2 打出來, 不走舊的兜底
            previous = getattr(self.task, 'skip_combat_check', False)
            self.task.skip_combat_check = True
            try:
                self.macro_start()
                self.logger.warning('hiyuki: entered already in Foreclaimed Self, finishing it by reading the screen')
                lib_ok = self.recover_r2('leftover transform', open_with_dodge=False)
            finally:
                self.task.skip_combat_check = previous
        if not lib_ok and self.has_long_action2():
            lib_ok = self.perform_lib()
        if not lib_ok and self.lib_permission and self.liberation_available():
            lib_ok = self.hold_liberation()

        self.leave(skip_outro=lib_ok)

    def hold_attack_until_lib(self, min_hold=0.0, timeout=None):
        """按住攻擊鍵直到大招亮起。心念靠長按打出的強化重擊攢, 點普攻攢得慢。"""
        timeout = self.INTRO_HOLD_TIMEOUT if timeout is None else timeout
        start = time.time()
        self.attack_down()
        try:
            while self.time_elapsed_accounting_for_freeze(start) < timeout:
                if self.time_elapsed_accounting_for_freeze(start) >= min_hold \
                        and self.liberation_available():
                    return True
                self.sleep(0.1)
        finally:
            self.attack_up()
        return False

    def perform_standard(self):
        """常世身: 按住攻擊鍵攢心念 -> 放大招變身。這裡一下普攻都不點。"""
        while self.has_long_action() and self.field_elapsed() < self.FIELD_TIME_OUT:
            if self.liberation_available() and self.click_liberation(click_f=False):
                self.just_transformed = True
                return
            self.click_echo(time_out=0)
            self.click_resonance(send_click=False, time_out=0, click_f=False)
            self.hold_attack_until_lib(timeout=self.STANDARD_HOLD_SLICE)
            self.sleep(0.05)

    def field_elapsed(self):
        return self.time_elapsed_accounting_for_freeze(self.last_perform)

    def transform_macro(self):
        """變身後的爆發。Returns: R2 是否放出去了。"""
        ground = self.GROUND_KENDO_COUNT_FIRST if not self.r2_used else self.GROUND_KENDO_COUNT
        kind = self.LOOP_KIND if self.r2_used else self.OPENER_KIND
        axis = 'loop' if self.r2_used else 'opener'
        short = kind == 'short'
        ee = kind == 'ee'
        guide = kind == 'guide'
        if guide:
            self.logger.info(f'hiyuki macro [guide {axis}]: R1 -> E x{self.GUIDE_E_COUNT} -> A x5 '
                             f'-> dodge -> kendo x{ground} -> heavy -> R2')
        elif ee:
            self.logger.info(f'hiyuki macro [ee {axis}]: R1 -> {"[execute] -> " if self.EE_EXECUTE_FIRST else ""}'
                             f'E tap -> E hold land -> dodge -> kendo x{ground} -> heavy -> R2')
        elif short:
            self.logger.info(f'hiyuki macro [short {axis}]: A3 -> [execute | dodge] -> E tap -> E hold land '
                             f'-> dodge -> kendo x{ground} -> heavy -> R2')
        else:
            self.logger.info(f'hiyuki macro: A3-dodge-A3 -> rise -> air kendo x{self.AIR_KENDO_COUNT} '
                             f'-> A3 -> [execute] -> dodge -> kendo x{ground} -> heavy -> R2')
        # 整段關掉脫戰判定: 爆發期間常有"目標丟失"誤報, 一拋異常 R2 就沒了
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        try:
            self.macro_start()
            if guide:
                # 攻略標準軸: 霜罰 x2 + 預求身普攻 5 段把寒意攢到 300, 再交給收尾段閃避進架勢
                for i in range(self.GUIDE_E_COUNT):
                    self.task.next_frame()
                    if i and not self.resonance_available():
                        self.macro_mark('E_skip')
                        break
                    self.macro_tap_e(self.GUIDE_E_SETTLE)
                self.continues_normal_attack(self.GUIDE_A_STRING, interval=self.M_A_INTERVAL)
                self.macro_mark('a5')
                return self.finish_with_r2()
            if ee:
                # R1 變身演出(隱藏 HUD 240F)結束幀就是 240F, 沒有更晚的派生幀, HUD 回來就能動;
                # 再留幾幀, 防 HUD 讀數比動作結束早一兩幀。E 點按只有一發, 落在演出裡就升不了空
                self.macro_wait(self.EE_AFTER_R1)
                if self.EE_EXECUTE_FIRST and self.macro_execute():
                    self.wait_hud_after_execute()
                self.macro_ee_land()
                return self.finish_with_r2()
            self.attack_chain()
            if short:
                # 有處決提示就拿處決取消 A3 後搖, 多吃一次處決傷害; 沒提示照舊閃避
                if self.macro_execute():
                    self.wait_hud_after_execute()
                else:
                    self.macro_dodge(self.M_AFTER_DODGE)
                self.macro_ee_land()
                # 收尾段原樣複用: 它本來就從"閃避進架勢"開始, 單人軸落地後也是先閃再出刀
                return self.finish_with_r2()
            self.macro_dodge(self.M_AFTER_DODGE)
            self.attack_chain()
            self.macro_rise()

            for i in range(self.AIR_KENDO_COUNT):
                last = i == self.AIR_KENDO_COUNT - 1
                self.macro_kendo(self.M_KENDO_LAND if last else self.M_AIR_KENDO_INTERVAL)
            # "第二發居合的同時點E下落"落到宏裡是"這一刀揮出去之後緊接著按E",
            # 真按在同一瞬間 E 會把居合取消掉。點按不是長按
            self.macro_tap_e(self.M_AFTER_PLUNGE)
            # 下落那發 E 被吞(按在居合動畫裡/冷卻)人就還在空中, 後面的 A 鏈和收尾段全會變成空中動作
            self.ensure_grounded('after plunge')

            self.attack_chain()
            if self.macro_execute():
                # 只有處決真打出來才補: 處決打斷A鏈, 這一發重接第三段回寒意。
                # 沒處決時補它就是硬接第四段, 緊接著又被閃避切掉
                self.click()
                self.macro_mark('a_after_f')
                self.macro_wait(self.M_A_ONE)
            return self.finish_with_r2()
        finally:
            self.task.skip_combat_check = previous

    def attack_chain(self):
        """一條普攻連段, 點到 A3 特效出現。收招時刻從第一下點擊算起, 跟點了幾下無關。"""
        self.continues_normal_attack(self.M_A_CHAIN, interval=self.M_A_INTERVAL)
        self.macro_mark('a3')

    def finish_with_r2(self):
        """收尾段。READING_FINISH = True(預設): 交給 recover_r2() 讀屏走完 閃避進架勢 -> 居合 -> 枯霜重擊 -> R2。
        READING_FINISH = False: 下面這套舊的定時收尾 —— 閃避進架勢 -> 連點居合 -> 預輸入重擊 -> 重擊起手後按住R。

        刀數: 啟動軸 GROUND_KENDO_COUNT_FIRST、循環軸 GROUND_KENDO_COUNT(都是 3)。所有時刻從閃避算起(推算方式見 KENDO1_DELAY 上面的註釋)。
        """
        count = self.GROUND_KENDO_COUNT_FIRST if not self.r2_used else self.GROUND_KENDO_COUNT
        # 收尾段全是地面幀表, 人在空中就先落地再開始算時間
        self.ensure_grounded('before finish')
        if self.READING_FINISH:
            return self.recover_r2('reading finish', open_with_dodge=True)
        dodge_at = time.time()
        self.macro_dodge(self.M_DODGE_TO_KENDO)
        last_kendo_out = dodge_at + self.KENDO1_DELAY + (count - 1) * self.KENDO_DERIVE
        hold_at = last_kendo_out + self.KENDO_OUT_TO_HOLD
        heavy_start = last_kendo_out + self.KENDO_DERIVE

        self.macro_mark('kendo_spam')
        clicks = 0
        last_click_by = hold_at - self.KENDO_SPAM_LAST_GAP
        while True:
            self.click()
            clicks += 1
            next_click = time.time() + self.KENDO_SPAM_INTERVAL
            if next_click > last_click_by:
                break
            self.macro_wait(max(0.0, next_click - time.time()))
        self.macro_mark(f'kendo_end{clicks}')
        self.macro_wait(max(0.0, hold_at - time.time()))
        return self.hold_heavy_into_r2(heavy_start)

    def in_kendo_stance(self):
        return bool(self.task.find_one('hiyuki_left', threshold=0.5))

    def lib_heavy_available(self):
        return bool(self.task.find_one('hiyuki_lib_forte', threshold=0.7))

    def r2_press_time(self):
        return self.R2_HOLD if self.r2_used else self.R2_HOLD_FIRST

    def hold_heavy_into_r2(self, heavy_start):
        """按住攻擊預輸入終結重擊 -> 重擊起手後鬆攻擊、按住R -> 蓄滿自動釋放 -> 鬆R。

        調用時刻就是該按住攻擊的時刻; heavy_start 是推算出的重擊起手時刻:
          heavy_start + HEAVY_TO_R                  鬆攻擊, 按下 R(只按一次, 一直按住)
          heavy_start + HEAVY_ANIM + 蓄力時長       鬆 R。蓄滿會自動釋放, 這個時刻只要蓋得住
        等待用 macro_wait: BaseChar.sleep 每 0.4 秒插一次截圖, 結尾還會把
        skip_combat_check 置回 False, 蓄力那幾秒會重新暴露在脫戰誤判裡。
        """
        charge = self.R2_CHARGE if self.r2_used else self.R2_CHARGE_FIRST
        start = time.time()
        release_r = heavy_start + self.HEAVY_ANIM + charge
        r_at = heavy_start + self.HEAVY_TO_R
        blocker = ''
        self.attack_down()
        self.macro_mark('heavy')
        try:
            if self.VERIFY_KENDO_DONE:
                # 檢查 1: 在按 R 之前 STANCE_CHECK_LEAD 秒讀兩幀, 讀完再等到原定的按 R 時刻
                self.macro_wait(max(0.0, r_at - self.STANCE_CHECK_LEAD - time.time()))
                blocker = self.finish_blocker()
            self.macro_wait(max(0.0, r_at - time.time()))
        finally:
            self.attack_up()

        if blocker:
            self.macro_mark(f'blocked_{blocker}')
            self.logger.warning(f'hiyuki macro: R2 not ready when R was due ({blocker}), '
                                f'timeline: {self.macro_timeline()}')
            self.add_freeze_duration(start, time.time() - start)
            return self.recover_r2(f'R2 not ready ({blocker})')

        # R 只按下一次然後一直按住, 中途【不重發】: 每一發 WM_KEYDOWN 遊戲都當一次新按下,
        # 長按判定被反覆打斷, 蓄力永遠起不來, 鬆開那一刻才當短按放出去 —— 07:36 之前
        # 每 0.2 秒重發一次, 一輪都沒蓄上。長按 E 升空(macro_hold_e)就是按一次 + 等 + 鬆
        key = self.get_liberation_key()
        r_down_at = time.time()
        self.key_down(key)
        self.macro_mark('R_down')
        self.logger.info(f'hiyuki macro timeline: {self.macro_timeline()}')
        try:
            self.macro_wait(max(0.0, release_r - time.time()))
        finally:
            self.key_up(key)
        press_time = time.time() - r_down_at

        self.task.in_liberation = True
        self.task.wait_until(lambda: self.task.in_team()[0], time_out=self.POST_LIB2_TEAM_WAIT)
        self.task.in_liberation = False
        self.add_freeze_duration(start, time.time() - start)

        # 檢查 2: R 鬆開了大招還沒進冷卻 = R2 沒放出去
        if self.VERIFY_KENDO_DONE and self.r2_pending():
            self.macro_mark('r2_pending')
            self.logger.warning(f'hiyuki macro: R held {press_time:.1f}s but R2 did not go out '
                                f'(lib cd {self.task.get_cd("liberation"):.1f}, '
                                f'r2_lit={self.liberation_available()}), timeline: {self.macro_timeline()}')
            return self.recover_r2('R2 did not go out')

        self.r2_used = True
        self.record_liberation_use()
        self.lib2_count = 0
        self.logger.info(f'hiyuki macro: R2 released (held {press_time:.1f}s)')
        return True

    def form_state(self):
        """現在是哪個形態: 'base' = 常世身, 'trans' = 預求身, None = 判不了(沒鎖到敵人)。
        框架原版就是這樣分形態的: perform_standard 跑在 has_long_action() 下、perform_lib 跑在
        has_long_action2() 下 —— 兩個形態的回路條長短不同, 鎖定框落在不同位置, 有鎖到敵人時只會中一個。"""
        trans = self.has_long_action2()
        if trans:
            return 'trans'
        if self.has_long_action():
            return 'base'
        return None

    def r2_out(self):
        """R2 已經放出去了沒有。R2 放出去會退出預求身, 所以【優先看形態】:
          回到常世身 -> True; 還在預求身 -> False; HUD 不在 -> None(判不了)
          形態判不了(沒鎖到敵人)才退回看大招冷卻 + R 是暗的。
        【10-26 第四次 log】只看冷卻會誤判: 03:59:08 / 04:00:15 兩輪閃避才 0.2 秒就讀到冷卻 > 1.5,
        當成 R2 已經出去直接切人 —— 其實還在預求身, 下一輪緋雪上場連 R1 都不用放, 直接掉進兜底。"""
        if not self.task.in_team()[0]:
            return None
        form = self.form_state()
        if form == 'base':
            return True
        if form == 'trans':
            return False
        return self.task.get_cd('liberation') >= self.R2_DONE_CD_STRONG and not self.liberation_available()

    def energy_short(self):
        """R2 的大招能量還沒滿: R 圖標是暗的, 而且不是因為冷卻(冷卻 = R2 已經放過了)。"""
        return self.task.in_team()[0] and not self.liberation_available() \
            and self.task.get_cd('liberation') <= self.R2_DONE_CD

    def finish_blocker(self):
        """按 R 之前讀兩幀, 兩幀都成立才算: 'stance' = 居合沒打完(重擊沒出), 'heavy' = 枯霜重擊沒出,
        'energy' = 大招能量不足。
        重擊起手之後架勢圖標就該滅了; R 在重擊起手 0.35 秒內就接受輸入(按早了會頂掉重擊), 那時能量夠就是亮的。
        Returns: 擋住 R2 的原因, 沒有就是空字串。"""
        reasons = []
        for i in range(2):
            if i:
                self.macro_wait(self.STANCE_CHECK_GAP)
            self.task.next_frame()
            if self.in_kendo_stance():
                reasons.append('stance')
            elif self.lib_heavy_available():
                reasons.append('heavy')  # 枯霜重擊圖標還亮著 = 重擊沒出(淬寒沒被吃掉)
            elif self.energy_short():
                reasons.append('energy')
            else:
                return ''
        return reasons[-1]

    def r2_pending(self):
        """R 鬆開之後 R2 還沒放出去。最多等 R2_SETTLE 秒(鬆開時沒吃到鍛雪會繼續蓄力再自動放):
        期間看到 HUD 被藏起來(R2 演出)或大招進冷卻, 就算放出去了。"""
        start = time.time()
        hidden = False
        while time.time() - start < self.R2_SETTLE:
            self.task.next_frame()
            out = self.r2_out()
            if out:
                return False
            if out is None:
                hidden = True
            elif hidden:
                # HUD 藏過又回來了, 冷卻還是 0: 再讀一次確認
                self.macro_wait(self.R2_READY_CHECK_GAP)
                self.task.next_frame()
                return self.r2_out() is False
            self.macro_wait(0.1)
        self.task.next_frame()
        return self.r2_out() is False and not hidden

    def ensure_grounded(self, where):
        """人在空中就先落地: 按住攻擊(空中按住普攻 = 空中下落攻擊), 逐幀看, 一落地立刻鬆開返回。
        按滿 PLUNGE_HOLD_CAP 還在空中就點一次 E 再按, 總共最多 GROUND_CAP 秒。Returns: 落地了沒有。"""
        self.task.next_frame()
        if not self.flying():
            return True
        self.logger.warning(f'hiyuki macro: airborne at {where}, plunging')
        start = time.time()
        tries = 0
        while time.time() - start < self.GROUND_CAP:
            tries += 1
            hold_start = time.time()
            self.attack_down()
            try:
                while time.time() - hold_start < self.PLUNGE_HOLD_CAP:
                    self.macro_wait(self.GROUND_POLL)
                    self.task.next_frame()
                    if not self.flying():
                        self.macro_mark(f'landed[{where}]+{time.time() - start:.2f}/try{tries}')
                        return True
            finally:
                self.attack_up()
            self.task.send_key(self.get_resonance_key())
            self.record_resonance_use()
            self.macro_wait(self.GROUND_POLL)
        self.task.next_frame()
        landed = not self.flying()
        self.macro_mark(f'{"landed" if landed else "still_airborne"}[{where}]/try{tries}')
        if not landed:
            self.logger.warning(f'hiyuki macro: still airborne after {self.GROUND_CAP:.1f}s at {where}')
        return landed

    def recover_r2(self, why, open_with_dodge=False):
        """讀屏收尾 / 補救: 一直打到 R2 放出去才返回(= 才准切人)。每一圈先看狀態再決定按什麼:
          R2 已經放出去(回到常世身, 連讀兩次) -> 結束
          HUD 不在(演出/時停)                -> 等
          找不到敵人                         -> 按中鍵重新鎖定; 連續 NO_TARGET_GIVEUP 秒都沒有才放棄
          人在空中                           -> 先落地
          居合架勢在                         -> 連點居合, 架勢沒了就停
          枯霜重擊圖標亮(這輪還沒出過)      -> 出一次枯霜重擊(換鍛雪)
          進架勢提示亮(最多 2 次)            -> 閃避進居合架勢, 等架勢圖標出現
          R 亮了, 且枯霜重擊已出(或等太久)  -> 按住 R 放 R2(沒出枯霜重擊就只點一下), 鬆開後確認放出去
          E 沒在冷卻                         -> 點 E(回寒意/大招能量, 之後閃避就能進架勢)
          其餘(寒意/大招能量不足)            -> 普攻連段, 架勢/重擊圖標/進架勢提示/R 亮/空中 任一出現就停
        open_with_dodge: 讀屏收尾從閃避進架勢開始(前面剛打完普攻/霜罰, 正是能進架勢的時機)。
        Returns: R2 有沒有放出去。沒有就交回 do_perform, 走 perform_lib 兜底。"""
        self.logger.info(f'hiyuki macro: {why}, attacking until R2 is out')
        start = time.time()
        kendo = heavy = attack = dodges = skills = presses = stances = 0
        heavy_done = False
        heavy_at = 0.0
        last_kendo_end = 0.0
        last_target = time.time()
        next_retarget = 0.0

        def tally():
            return (f'kendo clicks x{kendo}, heavy x{heavy}, dodge x{dodges}, E x{skills}, A x{attack}, '
                    f'{time.time() - start:.1f}s')

        if open_with_dodge:
            stances += 1
            dodges += 1
            self.dodge_into_stance()

        while time.time() - start < self.RECOVER_CAP:
            self.task.next_frame()
            out = self.r2_out()
            if out is None:
                self.macro_wait(0.1)
                continue
            if out and not self.liberation_available():
                # 連讀兩次都成立才算, 單幀誤判不算
                self.macro_wait(self.R2_READY_CHECK_GAP)
                self.task.next_frame()
                if self.r2_out():
                    self.r2_used = True
                    self.logger.info(f'hiyuki macro: R2 already out (form={self.form_state()}, '
                                     f'lib cd {self.task.get_cd("liberation"):.1f}), ({tally()})')
                    return True
                continue
            if self.target_visible():
                last_target = time.time()
            else:
                if time.time() - last_target >= self.NO_TARGET_GIVEUP:
                    self.logger.warning(f'hiyuki macro: no target for {self.NO_TARGET_GIVEUP:.0f}s, '
                                        f'giving up ({tally()}), timeline: {self.macro_timeline()}')
                    return False
                if time.time() >= next_retarget:
                    self.task.middle_click()
                    next_retarget = time.time() + self.RETARGET_INTERVAL
                self.macro_wait(0.1)
                continue
            if self.flying():
                self.ensure_grounded('recover')
                continue
            if self.in_kendo_stance():
                kendo += self.spam_kendo_while_stance(start + self.RECOVER_CAP)
                last_kendo_end = time.time()
                continue
            if not heavy_done and self.lib_heavy_available():
                heavy += 1
                heavy_at = self.kusou_heavy()
                heavy_done = True
                continue
            if not heavy_done and stances < self.RECOVER_STANCE_TRIES \
                    and self.task.find_one('hiyuki_right', threshold=0.5):
                stances += 1
                dodges += 1
                self.dodge_into_stance()
                continue
            now = time.time()
            r_allowed = heavy_done \
                or (last_kendo_end and now - last_kendo_end >= self.HEAVY_MISSING_GRACE) \
                or now - start >= self.R_BEFORE_HEAVY_AFTER
            if r_allowed and self.liberation_available():
                if presses >= self.R2_PRESS_TRIES:
                    self.logger.warning(f'hiyuki macro: pressed R {presses} times but R2 never went out '
                                        f'({tally()}), timeline: {self.macro_timeline()}')
                    return False
                if heavy_done:
                    self.macro_wait(max(0.0, heavy_at + self.HEAVY_TO_R_MIN - time.time()))
                presses += 1
                self.macro_mark(f'R_k{kendo}_h{heavy}_d{dodges}_e{skills}_a{attack}')
                if self.press_r2(f'{why} ({tally()}, R press #{presses})', charged=heavy_done):
                    return True
                continue
            # 霜罰也回大招能量: 枯霜重擊出完、等 R 亮的時候也放(03:57 那輪重擊後純普攻等了 11 秒 R 才亮)
            if self.resonance_available():
                skills += 1
                self.macro_tap_e(self.RECOVER_E_SETTLE)
                continue
            attack += self.attack_while(
                lambda: not (self.in_kendo_stance() or self.flying()
                             or (not heavy_done and (self.lib_heavy_available()
                                                     or self.task.find_one('hiyuki_right', threshold=0.5)))
                             or (r_allowed and self.liberation_available())),
                min(self.RECOVER_ATTACK_SLICE, max(0.0, start + self.RECOVER_CAP - time.time())))
        self.logger.warning(f'hiyuki macro: R2 still not out after {self.RECOVER_CAP:.0f}s ({tally()}, '
                            f'lib cd {self.task.get_cd("liberation"):.1f}), timeline: {self.macro_timeline()}')
        return False

    def dodge_into_stance(self):
        """閃避進居合架勢, 然後等架勢圖標出現(最多 STANCE_APPEAR_WAIT 秒)。Returns: 進架勢了沒有。"""
        self.macro_dodge(0.0)
        start = time.time()
        while time.time() - start < self.STANCE_APPEAR_WAIT:
            self.macro_wait(self.GROUND_POLL)
            self.task.next_frame()
            if self.in_kendo_stance():
                self.macro_mark(f'stance+{time.time() - start:.2f}')
                return True
        self.macro_mark('no_stance')
        return False

    def kusou_heavy(self):
        """枯霜重擊, 只出一次: 按住攻擊到圖標滅(最多 HEAVY_HOLD_CAP 秒)就鬆, 之後不發任何輸入,
        等圖標滅最多 HEAVY_CLEAR_WAIT 秒。Returns: 重擊起手的時刻(按住攻擊那一刻)。"""
        at = time.time()
        self.attack_down()
        self.macro_mark('kusou_heavy')
        try:
            while time.time() - at < self.HEAVY_HOLD_CAP:
                self.macro_wait(self.GROUND_POLL)
                self.task.next_frame()
                if not self.lib_heavy_available():
                    break
        finally:
            self.attack_up()
        while time.time() - at < self.HEAVY_HOLD_CAP + self.HEAVY_CLEAR_WAIT:
            self.task.next_frame()
            if not self.lib_heavy_available():
                break
            self.macro_wait(0.05)
        return at

    def spam_kendo_while_stance(self, deadline):
        """架勢在就照收尾段的節奏連點(KENDO_SPAM_INTERVAL), 每點一下讀一幀; 架勢沒了就停。
        架勢圖標要等下一個動作才滅, 所以最後會多點一下: 刀用完了那一下就是一發普攻, 也正好把架勢收掉。
        Returns: 點了幾下。"""
        clicks = 0
        while time.time() < deadline:
            self.click()
            clicks += 1
            self.macro_wait(self.KENDO_SPAM_INTERVAL)
            self.task.next_frame()
            if not self.in_kendo_stance():
                break
        self.macro_mark(f'recover_kendo{clicks}')
        return clicks

    def attack_while(self, keep, cap):
        """普攻連段: 每 M_A_INTERVAL 點一下, 點完讀一幀, keep() 不成立或到 cap 秒就停。Returns: 點了幾下。"""
        start = time.time()
        clicks = 0
        while time.time() - start < cap:
            self.click()
            clicks += 1
            self.macro_wait(self.M_A_INTERVAL)
            self.task.next_frame()
            if not keep():
                break
        return clicks

    def press_r2(self, how, charged=True):
        """按下 R 一次並按住(蓄力), 最多 r2_press_time() 秒; 期間 HUD 被藏起來(= R2 演出開始)就立刻鬆開。
        charged=False(這輪沒出枯霜重擊 = 沒鍛雪可蓄)且 R2_TAP_WITHOUT_HEAVY: 只點一下 R, 讓它自己蓄力施放。
        只在 R2 亮著時調用。鬆開後確認 R2 真的出去了才返回 True; 沒出去 = 按鍵被吞, 返回 False 讓調用方重來。"""
        key = self.get_liberation_key()
        start = time.time()
        hidden = 0
        hold = self.r2_press_time()
        if not charged and self.R2_TAP_WITHOUT_HEAVY:
            hold = self.R2_TAP
        self.key_down(key)
        self.macro_mark('R_down' if hold > self.R2_TAP else 'R_tap')
        try:
            while time.time() - start < hold:
                self.macro_wait(self.R2_HOLD_POLL)
                self.task.next_frame()
                if self.task.in_team()[0]:
                    hidden = 0
                    continue
                hidden += 1
                if hidden >= self.R2_HIDDEN_CONFIRM:
                    self.macro_mark(f'R2_anim+{time.time() - start:.1f}')
                    break
        finally:
            self.key_up(key)
        self.task.in_liberation = True
        self.task.wait_until(lambda: self.task.in_team()[0], time_out=self.POST_LIB2_TEAM_WAIT)
        self.task.in_liberation = False
        self.add_freeze_duration(start, time.time() - start)
        if self.r2_pending():
            self.macro_mark('R_swallowed')
            self.logger.warning(f'hiyuki macro: R held but R2 did not go out (lib cd '
                                f'{self.task.get_cd("liberation"):.1f}, r2_lit={self.liberation_available()}), '
                                f'{how}')
            return False
        self.r2_used = True
        self.record_liberation_use()
        self.lib2_count = 0
        self.logger.info(f'hiyuki macro: R2 released by {how}, timeline: {self.macro_timeline()}')
        return True

    def macro_wait(self, sec):
        """精確等待。

        不走 executor.sleep: 它每 sleep_check_interval(0.4s) 會無條件插一次
        next_frame 截圖(skip_combat_check 只跳過判定邏輯, 跳不過截圖), 插入位置不可控。
        空中居合/重擊接R 的容錯在 ±0.1 秒級, 排不了這種時序。
        切成 0.1 秒一片並在片間檢查任務是否被停用, 精度保持在 10 毫秒。
        """
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)
            self.check_enemy_gone()

    def macro_start(self):
        self.macro_t0 = time.time()
        self.macro_marks = []

    def macro_mark(self, name):
        """記一筆輸入發出的時刻。對著錄像就能看出是哪一下被吞了:
        某個輸入的時刻比畫面上那段動作的起點還早, 就是它把前一段取消掉了。"""
        self.macro_marks.append(f'{name}@{time.time() - self.macro_t0:.2f}')

    def macro_timeline(self):
        return ' '.join(self.macro_marks)

    def macro_rise(self):
        """長按E升空。空中那兩刀全指著這一下, 白按一次整段就沒了, 而日誌上看不出來
        (E_down/E_up 只證明鍵發出去了), 所以把CD讀出來記進日誌區分兩種毛病。"""
        cd = self.task.get_cd('resonance')
        if cd > 0 and self.RISE_E_WAIT > 0:
            self.logger.warning(f'hiyuki macro: resonance on cd {cd:.1f}s at rise, waiting')
            self.task.wait_until(lambda: self.task.get_cd('resonance') <= 0,
                                 post_action=self.click, time_out=self.RISE_E_WAIT)
        self.macro_hold_e(self.M_HOLD_E_RISE, self.M_AFTER_RISE)

    def wait_hud_after_execute(self):
        """處決之後等隊伍 HUD 回來(= 演出結束、能接輸入了)再往下走。只花時間, 不發鍵。"""
        start = time.time()
        while time.time() - start < self.EXEC_HUD_WAIT:
            if self.task.in_team()[0]:
                break
            self.macro_wait(0.03)
        self.macro_mark(f'hud_back+{time.time() - start:.2f}')
        self.macro_wait(self.EXEC_TO_E)

    def macro_ee_land(self):
        """短版啟動軸: E 點按升空 -> E 長按落地。"""
        e = self.get_resonance_key()
        self.task.send_key(e, down_time=self.EE_TAP)
        self.record_resonance_use()
        self.macro_mark('E1')
        self.macro_wait(self.EE_E1_TO_E2)
        self.macro_hold_e(self.EE_E2_HOLD, self.EE_E2_AFTER)

    def macro_dodge(self, settle):
        self.task.click(key='right')
        self.macro_mark('dodge')
        self.macro_wait(settle)

    def macro_hold_e(self, hold, settle):
        self.key_down(self.get_resonance_key())
        self.macro_mark('E_down')
        try:
            # macro_wait 現在會在任務被停用時拋異常, 長按必須放在 finally 裡鬆開
            self.macro_wait(hold)
        finally:
            self.key_up(self.get_resonance_key())
        self.record_resonance_use()
        self.macro_mark('E_up')
        self.macro_wait(settle)

    def macro_tap_e(self, settle):
        self.task.send_key(self.get_resonance_key())
        self.record_resonance_use()
        self.macro_mark('E_tap')
        self.macro_wait(settle)

    def macro_kendo(self, settle=None):
        self.click()
        self.macro_mark('kendo')
        self.macro_wait(self.M_KENDO_INTERVAL if settle is None else settle)

    def macro_execute(self):
        """處決。沒有提示就跳過 —— F 同時是拾取鍵, 空按會點到場景物件。
        框架的 can_break 只在帶戰鬥判定的 sleep 裡刷新, 定時段用不到, 所以自己抓幀現查。
        Returns: 處決是否真按出去了。
        """
        if not self.execute_available():
            return False
        start = time.time()
        self.task.send_key('f')
        self.macro_mark('F')
        self.task.can_break = False  # 自己按掉的, 別讓切人時再按一次
        # 提示消失=確實觸發; 之後時停畫面靜止, 找圖看不出演到哪, 只能按秒等
        self.task.wait_until(lambda: not self.execute_prompt(), time_out=0.8)
        self.macro_wait(self.M_EXECUTE_ANIM)
        self.add_freeze_duration(start, time.time() - start)
        return True

    def execute_available(self):
        """只認屏幕中央那個F提示。另外兩個信號都不能當判據:
        can_break 是粘滯標記(別的角色場上看到一次擊破就一直是True, 實測五輪五次空按F);
        f_break_full 是頓感條滿, 條滿但處決窗口沒開時按下去會被當成拾取吃掉。
        """
        self.task.next_frame()
        prompt = bool(self.execute_prompt())
        if prompt and not self.task.is_pick_f():
            return True
        bar_full = bool(self.task.find_one('f_break_full', threshold=0.92))
        self.logger.info(f'hiyuki macro: skip F (f_break={prompt} bar_full={bar_full})')
        return False

    def execute_prompt(self):
        box = self.task.box_of_screen(0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True)
        return bool(self.task.find_one('f_break', box=box, target_height=720))

    def perform_lib(self):
        """宏沒走通時的兜底: 原版的反應式循環。"""
        timeout = self.FIELD_TIME_OUT
        while self.has_long_action2() and self.field_elapsed() < timeout:
            self.click_echo(time_out=0)
            lib_heavy_avail = self.lib_heavy_available()
            is_timeout = self.field_elapsed() >= timeout - 0.5

            if self.lib_permission and self.liberation_available() and (
                    self.lib2_count >= self.LIB2_KENDO_COUNT or is_timeout):
                if self.hold_liberation():
                    self.lib2_count = 0
                    return True

            res = self.click_resonance(send_click=False, time_out=0, click_f=False)
            if res and res[0]:
                if is_timeout:
                    break
                self.macro_hold_e(self.M_HOLD_E_LAND, self.M_LAND_RECOVER)
            elif lib_heavy_avail:
                if is_timeout:
                    break
                if self.wait_locked(self.WAIT_LOCK_TIME_OUT):
                    self.heavy_forte_fast(self.lib_heavy_available)
                if self.task.wait_until(self.liberation_available, post_action=self.click,
                                        time_out=0.5):
                    if self.wait_locked(self.WAIT_LOCK_TIME_OUT) and self.hold_liberation():
                        self.lib2_count = 0
                        return True
                self.lib2_count += 1
                self.sleep(0.1)
            elif self.in_kendo_stance():
                self.task.wait_until(lambda: not self.in_kendo_stance(),
                                     post_action=self.click, time_out=3.0)
                if is_timeout:
                    break
                self.sleep(0.1)
            elif bool(self.task.find_one('hiyuki_right', threshold=0.5)):
                self.task.click(key='right', interval=1.0)
                self.sleep(0.1)
            else:
                self.click()
            self.sleep(0.05)

        if self.lib_permission and self.liberation_available() and self.hold_liberation():
            self.lib2_count = 0
            return True
        return False

    def hold_liberation(self):
        """長按大招鍵放R2。相對原版三處修補: 返回值要代表真的按下去了;
        補 record_liberation_use(); 循環退出後繼續按住蓄力(循環條件是
        liberation_available(), R2一放出去它立刻變False, 當場鬆手等於一點沒蓄)。
        """
        if not self.task.use_liberation:
            return False

        sent = False
        start = time.time()
        while self.task.in_team()[0] and time.time() - start < self.HOLD_LIB_TIME_OUT:
            if self.liberation_available():
                self.key_down(self.get_liberation_key())
                sent = True
                break
            if self.task.get_cd('liberation') > self.HOLD_LIB_CD_WAIT:
                break
            self.sleep(0.05, check_combat=False)

        if not sent:
            return False

        # 按下一次一直按住, 不重發: 重發的每一下都是新按下, 蓄力起不來(見 hold_heavy_into_r2)
        try:
            self.macro_wait(self.r2_press_time())
        finally:
            self.key_up(self.get_liberation_key())
        self.r2_used = True

        self.task.in_liberation = True
        self.task.wait_until(lambda: self.task.in_team()[0], time_out=self.POST_LIB2_TEAM_WAIT)
        self.task.in_liberation = False
        self.add_freeze_duration(start, time.time() - start)
        self.logger.info(f'hold_liberation end {time.time() - start:.1f}s')
        # 兜底路徑也要確認 R2 真的出去了(同 press_r2): 沒出去就進補救, 打到放出去才准切人
        if self.r2_pending():
            self.logger.warning('hiyuki hold_liberation: R2 did not go out, entering recovery')
            return self.recover_r2('R2 did not go out (fallback path)')
        self.record_liberation_use()
        return True

    def leave(self, skip_outro=False):
        """唯一的離場口。整段關掉脫戰判定: 打完爆發常有"目標丟失->判定脫戰"的誤報,
        那時 check_combat() 一拋異常切人就再也執行不到了。"""
        self.enemy_watch_stop()
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        try:
            if skip_outro and self.direct_switch(assume_intro=True):
                return
            if not skip_outro:
                self.ensure_outro()
            self.switch_next_char()
        except Exception as e:
            # assume_intro 要跟著原來那次一起傳: 補救這一下也是緊接在 R2 後面的,
            # 協奏讀數照樣滯後。之前寫死 False, 補救成功也會告訴下一個人"你空手上場"
            self.logger.warning(f'hiyuki leave failed ({e}), trying direct switch')
            if not self.direct_switch(assume_intro=skip_outro):
                raise
        finally:
            self.task.skip_combat_check = previous

    def ensure_outro(self):
        """協奏不滿就不離場。兩個安全閥: 協奏卡住不漲, 或站夠絕對上限。"""
        # 先等讀數穩定: 大招剛放完時協奏往往已經滿了, 只是能量環還沒渲染回來
        if self.task.wait_until(self.is_con_full, time_out=0.8):
            return True

        start = time.time()
        best_con = self.get_current_con()
        last_gain = time.time()
        while True:
            if self.is_con_full():
                return True
            if self.time_elapsed_accounting_for_freeze(start) >= self.OUTRO_HARD_LIMIT:
                self.logger.warning('hiyuki hit outro hard limit, switching without outro')
                return False
            con = self.get_current_con()
            if con > best_con + 0.01:
                best_con = con
                last_gain = time.time()
            elif time.time() - last_gain > self.OUTRO_STALL_TIME:
                self.logger.warning(f'hiyuki con stuck at {con:.2f}, switching without outro')
                return False

            if self.echo_available():
                self.click_echo(time_out=0)
                continue
            res = self.click_resonance(send_click=False, time_out=0, click_f=False)
            if res and res[0]:
                self.macro_hold_e(self.M_HOLD_E_LAND, self.M_LAND_RECOVER)
                self.macro_kendo()
                continue
            if self.is_mouse_forte_full():
                self.heavy_forte_fast(self.is_mouse_forte_full)
                continue
            self.continues_normal_attack(self.CON_TOP_UP_CHAIN, until_con_full=True)

    def direct_switch(self, assume_intro=False):
        """按數字鍵直接切給交棒對象。不走 switch_next_char(): 那個內部有三處
        continues_normal_attack/click, 大招之後不想要那幾下多餘的A。

        【不因為"隊伍讀不出來"就放棄】: R2 剛結束那幾秒頭像欄是讀不到的
        (in_team() 假、隊伍識別退化成 unknown), switch_target() 會同時落空。
        以前那樣直接 return False, 調用方就退回框架切人 —— 而框架切人在同一個
        讀不到頭像的窗口裡必然拋 not in_team, 一路把戰鬥判定打斷, 接棒角色的變奏記帳
        就整個丟了。所以目標解析不出來時改成盲發寫死的槽位鍵, 切成之後再補記帳。
        """
        target = self.switch_target()
        slot = self.DIRECT_SWITCH_INDEX if target is None else target.index + 1
        if slot - 1 == self.index:
            self.logger.warning(f'hiyuki direct switch: slot {slot} is myself, '
                                f'team={self.team_roster()}')
            return False
        # 剛放完大招時直接認定協奏滿: 讀數滯後會把 has_intro 誤判成 False,
        # 那樣接棒角色會以為自己空手入場
        has_intro = True if assume_intro else self.wait_con_full()

        # 大招動畫期間就按住普攻並狂發切人鍵, 不乾等動畫演完: 按住普攻讓動畫一結束
        # 攻擊立刻接上; 切人鍵在動畫期間發出去看似白發, 但換來"能切的第一幀就切走"
        deadline = self.LIB_ANIM_WAIT + self.LEAVE_SWITCH_TIMEOUT
        start = time.time()
        switched = False
        ambiguous = 0
        own = self.index if 0 <= self.index < 3 else None
        # 【場上沒怪就先別切】(10-08 用戶): R2 打死這一波、新怪還沒刷出來時切過去, 穗穗的變奏打空,
        # 協奏一點沒回, 放完 R 也不滿, 下一個人就沒有變奏。17:28 / 17:29 兩次都是緋雪切走後 0.02s
        # 框架就報 target lost, 新怪在 0.9~1.5s 後才被鎖到。緋雪協奏是滿的, 留著等新怪出來再切。
        # 所以切人鍵要等"判完有沒有怪"才發 —— 演出裡提前發的鍵會在能動的第一幀被接受, 等不到判斷
        gate = None  # None=還沒判, 'go'=可以切了
        no_target = 0
        waited_at = None
        next_mid = 0.0
        gate_note = ''
        self.attack_down()
        try:
            while time.time() - start < deadline:
                # 【成立條件: 目標那格沒有數字牌, 並且緋雪自己那格讀得到數字牌】, 不用 in_team()。
                # in_team() 拿"第一個讀不到數字牌的格子"當在場的人, 數字牌被擋住的那格也算 ——
                # 10-08 17:16/17:19 兩次 R2 打死 boss, 1 號位數字牌被擋、讀成"穗穗在場", 這裡當場
                # 停了發鍵, 人還是緋雪, 之後 5 秒是穗穗的代碼在操控她(按住攻擊 = 那幾下 A)。
                # 讀得到緋雪自己的數字牌才證明她真的下場了, 遮擋騙不到這一條
                labels = self.slot_labels()
                if not labels[slot - 1]:
                    if own is None or labels[own]:
                        note = f', ignored {ambiguous} ambiguous reads' if ambiguous else ''
                        self.logger.info(f'hiyuki direct switched to slot {slot} '
                                         f'(intro={has_intro}, {time.time() - start:.1f}s{note}{gate_note})')
                        switched = True
                        break
                    if any(labels):
                        ambiguous += 1  # 目標那格和自己那格都沒數字牌: 有一格是被擋住的, 分不清誰在場
                now = time.time()
                if gate is None:
                    if any(labels):
                        # 頭像欄回來了 = 演出結束, 這時才判得了有沒有怪
                        if self.target_visible():
                            gate = 'go'
                            if waited_at is not None:
                                gate_note = f', waited {now - waited_at:.1f}s for the next wave'
                        else:
                            no_target += 1
                            if no_target >= self.TARGET_GONE_CONFIRM:
                                if waited_at is None:
                                    waited_at = now
                                    deadline += self.WAVE_WAIT
                                    self.attack_up()  # 沒怪可打, 別按著空揮
                                    self.logger.info('hiyuki: no target after R2, holding the outro '
                                                     'until the next wave shows up')
                                if now - waited_at >= self.WAVE_WAIT:
                                    gate = 'go'
                                    gate_note = f', no target for {self.WAVE_WAIT:.0f}s, switched anyway'
                                elif now >= next_mid:
                                    self.task.middle_click()  # 和框架 retarget 一樣按中鍵鎖新目標
                                    next_mid = now + self.WAVE_LOCK_INTERVAL
                    elif now - start >= self.LIB_ANIM_WAIT:
                        gate = 'go'  # 頭像欄一直讀不到: 判不了, 照原來盲發(見上面 docstring)
                        gate_note = ', HUD never came back, blind'
                if gate == 'go':
                    self.task.send_key(slot)
                self.sleep(0.12, check_combat=False)
        finally:
            self.attack_up()

        if not switched:
            self.logger.warning(f'hiyuki direct switch to slot {slot} failed')
            return False

        if target is None:
            # 盲發那條路: 人已經過去了, 現在頭像欄也讀得到了(上面那次數字牌讀數是真的),
            # 重讀一次隊伍把對象認出來。必須在打 has_intro 之前讀 ——
            # load_chars() 末尾會對每個角色 reset_state(), 順序反了標記當場被抹掉
            self.task.load_chars()
            target = self.char_at_index(slot - 1)
        if target is None or target is self:
            self.logger.warning(f'hiyuki switched to slot {slot} but could not resolve the char, '
                                f'team={self.team_roster()}')
            return True  # 人確實切過去了, 不能再讓調用方去 switch_next_char()
        self.handoff_to(target, has_intro)
        return True

    def target_visible(self):
        """鎖定目標在不在。照 CombatCheck.has_target() 的前三個讀框, 去掉它最後那個兜底分支 ——
        那個分支會 sleep(1) 再連按兩次 ESC, 不能在軸裡調。"""
        t = self.task
        try:
            has_name, no_name = t.get_target_names()
            for box in (t.get_box_by_name(has_name).scale(1.1), t.get_box_by_name('box_target_enemy_long'),
                        t.get_box_by_name('target_box_long2')):
                best = t.find_best_match_in_box(box, [has_name, no_name], threshold=0.6)
                if best:
                    return best.name == has_name
        except Exception as e:
            # 別的 ok-ww 版本這幾個讀框/方法可能改名了: 當成有怪, 退回"不等下一波、直接切"
            if not getattr(self, '_target_visible_warned', False):
                self._target_visible_warned = True
                self.logger.warning(f'hiyuki target_visible unsupported in this ok-ww version ({e!r}), '
                                    f'assuming a target is there')
            return True
        return False

    def slot_labels(self):
        """隊伍欄「1」「2」「3」數字牌各自讀沒讀到(在場的人那一格沒有)。閾值和 in_team() 一樣。"""
        return [bool(self.task.find_one(f'char_{i}_text', threshold=0.8)) for i in (1, 2, 3)]

    def handoff_to(self, target, has_intro):
        """復刻 switch_next_char() 內部那套交接記帳。直接按數字鍵切人繞開了框架邏輯,
        不補的話沒人的 is_current_char 是 True, get_current_char() 返回 None 會崩。

        Args:
            has_intro: 離場時協奏是否滿, 必須在按切人鍵之前讀好 ——
                切走之後能量環顯示的已經是新角色的了。
        """
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            # has_intro 是易失的: reset_state() 每次重讀隊伍都會清掉它,
            # 而戰鬥判定一抖動就會重進戰鬥重讀隊伍。給對方一個它自己保管的持久標記
            target.note_intro_handoff()
        target.last_switch_in_time = time.time()
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        return bool(self.task.wait_until(self.is_con_full, time_out=0.5))

    def opener_char(self):
        return next((c for c in self.task.chars if c is not None and c is not self
                     and c.char_name == self.OPENER_NAME), None)

    def opener_pending(self):
        """本場維里奈還沒起過手(她 do_perform 一開始就會把標記設成 True)。隊裡沒有她就不強制。"""
        if getattr(self.task, 'verina_opener_done', False):
            return False
        return self.opener_char() is not None

    def hand_to_opener(self):
        """一下都不打, 直接切給維里奈起手。切不過去就返回 False, 照原流程打。"""
        target = self.opener_char()
        if target is None:
            return False
        self.logger.info('hiyuki: opener pending, handing the field to verina')
        if not self.switch_to_index(target.index, self.OPENER_SWITCH_TIMEOUT):
            self.logger.warning(f'hiyuki: switch to verina (slot {target.index + 1}) failed, playing on')
            return False
        self.handoff_to(target, False)
        return True

    def switch_to_index(self, index, timeout):
        """按數字鍵切到指定隊伍位置, 重發到 in_team 確認切過去了為止。輪詢快、重發慢。"""
        start = time.time()
        last_send = 0.0
        while time.time() - start < timeout:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == index:
                return True
            if time.time() - last_send >= self.SWITCH_KEY_RESEND:
                self.task.send_key(index + 1)
                last_send = time.time()
            self.sleep(self.SWITCH_POLL, check_combat=False)
        return False

    def switch_target(self):
        """交棒對象: 先按角色名找(不假設隊伍順序), 找不到再退回寫死的槽位。

        【槽位那條路必須排除自己】: 以前不查, 緋雪自己站 1 號位時它返回的就是本人,
        direct_switch 在 50 毫秒內靜默 return False —— 日誌上只表現為"沒走直接切人",
        沒有任何線索。解析不出來時打一條隊伍名單, 這類問題只有這一行能一次定位。
        """
        for char in self.task.chars:
            if char is not None and char is not self and char.char_name == self.SWITCH_TARGET_NAME:
                return char
        slot_char = self.char_at_index(self.DIRECT_SWITCH_INDEX - 1)
        if slot_char is not None:
            return slot_char
        self.logger.warning(f'hiyuki switch target unresolved '
                            f'(name={self.SWITCH_TARGET_NAME} slot={self.DIRECT_SWITCH_INDEX}), '
                            f'team={self.team_roster()}')
        return None

    def char_at_index(self, index):
        return next((c for c in self.task.chars
                     if c is not None and c is not self and c.index == index), None)

    def team_roster(self):
        return [None if c is None else (c.index, str(c.char_name)) for c in self.task.chars]

    def heavy_forte_fast(self, check_fun, time_out=None):
        """強化重擊。BaseChar.heavy_click_forte 的 wait_until 寫死2秒, 迴路一直沒打掉時白按滿。"""
        time_out = self.HEAVY_FORTE_TIME_OUT if time_out is None else time_out
        if not check_fun():
            return False
        self.attack_down()
        try:
            success = self.task.wait_until(lambda: not check_fun(), time_out=time_out)
        finally:
            self.attack_up()
        self.sleep(0.05)
        return bool(success)

    def wait_locked(self, time_out):
        return bool(self.task.wait_until(self.has_long_action2, post_action=self.click,
                                         time_out=time_out))

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_linnai', 'char_suisui'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)