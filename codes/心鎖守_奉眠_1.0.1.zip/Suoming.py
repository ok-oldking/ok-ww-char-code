from src.char.BaseChar import SwitchPriority
from src.char.Suoming import Suoming as NativeSuoming


class Suoming(NativeSuoming):
    """心鎖守(心/鎖暝/守岸人)裡的鎖暝。非本隊時整套走原版。

    宏體在同目錄的 Hsin.py, 這裡只轉發。宏散了被框架呼叫到時也轉給心的 drive()(循環軸先把場子交給守岸人)。
    自訂角色檔案互相 import 不到, 用 task.chars 裡的實例找。
    """

    @property
    def is_in_xss(self) -> bool:
        members = 0
        for char in self.task.chars:
            if char and char.name in {'Hsin', 'ShoreKeeper'}:
                members += 1
        return members == 2

    def macro(self):
        """持宏的心。心那份自訂沒啟用時返回 None, 走原版。
        只認名字是 Hsin 且有 drive/quick_switch 的(防將來別的角色檔加了同名方法被誤認)。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if char.name == 'Hsin' and hasattr(char, 'drive') and hasattr(char, 'quick_switch'):
                return char
        return None

    def reset_state(self):
        super().reset_state()
        # 自訂欄位會被打回內建值, 在這裡重申: 這條軸不在切人時按處決
        self.check_f_on_switch = False

    def do_perform(self):
        if not self.is_in_xss:
            return super().do_perform()
        macro = self.macro()
        if macro is None:
            self.logger.warning('xss: Hsin custom code is off, falling back to the native rotation')
            return super().do_perform()
        macro.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """啟動軸待跑時返回 NO。【要寫在 super() 之前】: 原版有自己的切人優先級。"""
        if self.is_in_xss:
            macro = self.macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)