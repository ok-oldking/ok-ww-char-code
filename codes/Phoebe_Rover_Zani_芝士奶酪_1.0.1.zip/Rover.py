"""
赞菲光固定轴 V3.0 - Spectro Rover（衍射漂泊者 / 光主）

定位：
- P1开场：菲比R/E/Q后，光主E/Q/R回菲比。
- P1 N1后：零等待机会槽，只看当前帧“强化E > 普通E > 空过”，绝不AZ、绝不等CD。
- P1 N2后：时间极紧，继续保留快照式“有什么放什么”并尽快回赞妮；V3.0不收紧此处。
- P2：三终夜时间更宽裕，采用动作完整优先；R/E确认后留短结算保护再Q/切赞妮。
- F处决主要由光主承担，但P1两个极限短窗口禁主动F，避免吞掉赞妮20秒R时间。

"""


import time
import math

import cv2
import numpy as np

from src.char.BaseChar import SwitchPriority, Elements
from src.char.Rover import Rover as BuiltinRover


class _ZFGFSM:
    ACTOR = None

    STATE_KEY = 'zanfei_rotation_state'  # 共享FSM主体：step/phase/cycle等都放这里
    TEAM_SIGNATURE_KEY = 'zanfei_rotation_team_signature'  # 队伍变化检测；换队后重置固定轴
    SWITCH_LOG_KEY = 'zanfei_rotation_switch_logged'  # 避免重复刷同一条切人日志
    PHOEBE_PREHOLD_E_KEY = 'phoebe_prehold_e_active'  # 跨角色按住E：是否仍应保持按键
    PHOEBE_PREHOLD_SOURCE_KEY = 'phoebe_prehold_e_source'  # 记录是谁发起的预输入，便于查日志
    P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY = 'p1_phoebe_forte_expected_empty'

    PHOEBE_LAST_CONFESSION_TIME_KEY = 'phoebe_last_confession_time'
    PHOEBE_LAST_R_CAST_TIME_KEY = 'phoebe_last_r_cast_time'
    P2_CONFESSION_AZ_USED_KEY = 'p2_confession_az_detour_used'  # 兼容旧日志：本轮是否至少走过一次光主等待槽
    P2_CONFESSION_AZ_COUNT_KEY = 'p2_confession_az_count'
    P2_CONFESSION_AZ_TARGET_KEY = 'p2_confession_az_target'
    P2_CONFESSION_RETRY_AFTER_KEY = 'p2_confession_retry_after'

    PHOEBE_R_COOLDOWN = 25.0
    ZANI_R2_HARD_DEADLINE_SHARED = 19.50
    P2_CONFESSION_R2_RESERVE = 6.00  # 给告解+R动画+切赞妮+N3/R2留出的尾端保护
    P2_CONFESSION_AZ_COST = 0.85
    P2_CONFESSION_SWITCH_TOTAL = 0.35
    P2_CONFESSION_PLAN_SAFETY = 0.25
    P2_CONFESSION_MAX_AZ = 6


    STEP_P1_ZANI_OPEN_AE_TO_PHOEBE = 'P1_ZANI_OPEN_AE_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER = 'P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER'
    STEP_P1_ROVER_EQR_TO_PHOEBE = 'P1_ROVER_EQR_TO_PHOEBE'
    STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI = 'P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI'

    STEP_P1_ZANI_EFORTE_PREP = 'P1_ZANI_EFORTE_PREP'
    STEP_P1_ZANI_R1_N1_TO_ROVER = 'P1_ZANI_R1_N1_TO_ROVER'
    STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE = 'P1_ROVER_OPPORTUNITY_E_TO_PHOEBE'
    STEP_P1_PHOEBE_STAR_TO_ZANI = 'P1_PHOEBE_STAR_TO_ZANI'
    STEP_P1_ZANI_N2_TO_ROVER_R = 'P1_ZANI_N2_TO_ROVER_R'
    STEP_P1_ROVER_R_TO_ZANI = 'P1_ROVER_R_TO_ZANI'
    STEP_P1_ZANI_N3_TO_PHOEBE = 'P1_ZANI_N3_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI = 'P1_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P1_ZANI_N4_R2_E_TO_PHOEBE = 'P1_ZANI_N4_R2_E_TO_PHOEBE'

    STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI = 'P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI'
    STEP_P2_ZANI_EFORTE_PREP = 'P2_ZANI_EFORTE_PREP'
    STEP_P2_ZANI_R1_N1_TO_ROVER = 'P2_ZANI_R1_N1_TO_ROVER'
    STEP_P2_ROVER_SLOT_TO_ZANI = 'P2_ROVER_SLOT_TO_ZANI'
    STEP_P2_ZANI_N2_TO_PHOEBE = 'P2_ZANI_N2_TO_PHOEBE'

    STEP_P2_PHOEBE_CONFESSION_CHECK = 'P2_PHOEBE_CONFESSION_CHECK'
    STEP_P2_ROVER_AZ_WAIT_CONFESSION = 'P2_ROVER_AZ_WAIT_CONFESSION'
    STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI = 'P2_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P2_ZANI_N3_R2_E_TO_PHOEBE = 'P2_ZANI_N3_R2_E_TO_PHOEBE'

    STEP_RECOVER_ZANI_LIBERATION = 'RECOVER_ZANI_LIBERATION'
    STEP_RECOVER_P2_PHOEBE = 'RECOVER_P2_PHOEBE'

    STEP_ACTOR = {
        STEP_P1_ZANI_OPEN_AE_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER: 'Phoebe',
        STEP_P1_ROVER_EQR_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI: 'Phoebe',

        STEP_P1_ZANI_EFORTE_PREP: 'Zani',
        STEP_P1_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_STAR_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N2_TO_ROVER_R: 'Zani',
        STEP_P1_ROVER_R_TO_ZANI: 'Rover',
        STEP_P1_ZANI_N3_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N4_R2_E_TO_PHOEBE: 'Zani',

        STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_EFORTE_PREP: 'Zani',
        STEP_P2_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P2_ROVER_SLOT_TO_ZANI: 'Rover',
        STEP_P2_ZANI_N2_TO_PHOEBE: 'Zani',
        STEP_P2_PHOEBE_CONFESSION_CHECK: 'Phoebe',
        STEP_P2_ROVER_AZ_WAIT_CONFESSION: 'Rover',
        STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_N3_R2_E_TO_PHOEBE: 'Zani',

        STEP_RECOVER_ZANI_LIBERATION: 'Zani',
        STEP_RECOVER_P2_PHOEBE: 'Phoebe',
    }

    SPECIAL_INTRO_TARGET = {
        'Phoebe': 'Zani',
        'Zani': 'Rover',
        'Rover': 'Phoebe',
    }

    CONCERTO_EFFECTIVE_FULL = 0.99
    INTRO_CONFIRM_FRAMES = 3
    INTRO_CONFIRM_TIMEOUT = 1.0
    POLL = 0.05

    SWITCH_TIMEOUT = 6.0
    SWITCH_RETRY_INTERVAL = 0.04

    def _release_phoebe_prehold(self, state, reason='cleanup'):
        if not isinstance(state, dict) or not state.get(self.PHOEBE_PREHOLD_E_KEY):
            return False
        try:
            self.task.send_key_up(self.get_resonance_key())
        except Exception:
            pass
        source = state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)
        state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
        self.logger.info(
            f'ZFG Phoebe-E prehold RELEASE reason={reason} source={source}'
        )
        return True

    def _clear_zfg_state(self):
        state = getattr(self.task, self.STATE_KEY, None)
        self._release_phoebe_prehold(state, reason='clear-zfg-state')
        for key in (self.STATE_KEY, self.SWITCH_LOG_KEY):
            if hasattr(self.task, key):
                delattr(self.task, key)

    def _zfg_team_matches(self):
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            return False

        chars = tuple(char for char in chars if char is not None)

        signature = tuple(
            (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.'),
                getattr(char, 'index', None),
            )
            for char in chars
        )

        required = {
            'char_zani',
            'char_phoebe',
            'char_rover',
        }

        identity_ok = (
            len(chars) == 3
            and {name for name, _ in signature} == required
            and any(char is self for char in chars)
        )

        rover = None
        for char in chars:
            name = (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.')
            )
            if name == 'char_rover':
                rover = char
                break

        rover_form = -1
        if rover is not None:
            try:
                if hasattr(self.task, 'get_known_ring_index'):
                    rover_form = self.task.get_known_ring_index(rover)
                else:
                    rover_form = getattr(rover, 'ring_index', -1)
            except Exception:
                rover_form = getattr(rover, 'ring_index', -1)

        form_ok = rover_form < 0 or rover_form == Elements.SPECTRO
        matched = identity_ok and form_ok

        previous = getattr(self.task, self.TEAM_SIGNATURE_KEY, None)

        if signature != previous:
            self._clear_zfg_state()
            setattr(self.task, self.TEAM_SIGNATURE_KEY, signature)
            self.logger.info(
                f'ZFG team changed matched={matched} '
                f'rover_form={rover_form} members={signature}'
            )
        elif not matched:
            self._clear_zfg_state()

        return matched

    def _zfg_state(self):
        """Return shared FSM state.

        First creation starts from P1.  If an already-existing state is damaged,
        do not replay the one-time opening: route to the agreed recovery entry.
        """
        state = getattr(self.task, self.STATE_KEY, None)

        if state is None:
            state = {
                'step': self.STEP_P1_ZANI_OPEN_AE_TO_PHOEBE,
                'cycle': 1,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self.logger.info(
                'ZFG FSM initialize -> P1_ZANI_OPEN_AE_TO_PHOEBE'
            )
            return state

        if not isinstance(state, dict) or 'step' not in state:
            old_cycle = state.get('cycle', 1) if isinstance(state, dict) else 1
            state = {
                'cycle': old_cycle,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self._route_broken_state_to_recovery(
                state,
                reason='state-missing-step',
            )

        return state


    def _advance_step(self, state, next_step):
        old = state.get('step')
        state['step'] = next_step
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        self.logger.info(
            f'ZFG FSM advance {old} -> {next_step} '
            f'cycle={state.get("cycle", 1)} '
            f'nightfall={state.get("nightfall_count", 0)}'
        )

    def _expected_actor(self, state):
        if state.get('detour_active'):
            return state.get('detour_actor')
        return self.STEP_ACTOR.get(state.get('step'))

    def _route_broken_state_to_recovery(self, state, reason='unknown'):
        """Route a damaged FSM without replaying the one-time P1 opening.

        - Zani still in R state -> RECOVER_ZANI_LIBERATION.
        - Otherwise -> RECOVER_P2_PHOEBE.
        """
        if not isinstance(state, dict):
            return 'Phoebe'

        self._clear_detour(state)
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        zani = self if self.ACTOR == 'Zani' else self._find_target_char('Zani')
        if zani is not None and getattr(zani, 'in_liberation', False):
            state['step'] = self.STEP_RECOVER_ZANI_LIBERATION
            actor = 'Zani'
        else:
            state['step'] = self.STEP_RECOVER_P2_PHOEBE
            actor = 'Phoebe'

        self.logger.error(
            f'ZFG broken FSM recovery reason={reason} '
            f'-> step={state.get("step")} actor={actor}'
        )
        return actor

    def get_switch_priority(
        self,
        current_char=None,
        has_intro=False,
        target_low_con=False,
    ):
        if not self._zfg_team_matches():
            return super().get_switch_priority(
                current_char,
                has_intro,
                target_low_con,
            )

        state = self._zfg_state()
        expected = self._expected_actor(state)

        if expected is None:
            expected = self._route_broken_state_to_recovery(
                state,
                reason=f'unknown-step:{state.get("step")}',
            )

        if not getattr(self.task, self.SWITCH_LOG_KEY, False):
            self.logger.info(
                f'ZFG FSM-exclusive switching enabled '
                f'step={state.get("step")} expected={expected}'
            )
            setattr(self.task, self.SWITCH_LOG_KEY, True)

        return (
            SwitchPriority.MUST
            if expected == self.ACTOR
            else SwitchPriority.NO
        )

    def _find_target_char(self, target_name):
        target_name = target_name.casefold()

        for char in getattr(self.task, 'chars', []):
            if char is None or char is self:
                continue

            names = (
                getattr(char, 'name', None),
                char.__class__.__name__,
                getattr(char, 'display_name', None),
            )

            for name in names:
                if name and str(name).casefold() == target_name:
                    return char

        return None

    def _raw_con_full(self):
        try:
            return bool(self.task.is_con_full())
        except Exception:
            return bool(self.is_con_full())

    def _read_concerto(self):
        if self._raw_con_full():
            return 1.0

        try:
            value = float(self.get_current_con())
        except Exception:
            try:
                value = float(self.task.get_current_con())
            except Exception:
                value = 0.0

        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        return (
            self._raw_con_full()
            or self._read_concerto() >= self.CONCERTO_EFFECTIVE_FULL
        )

    def _confirm_hard_intro_ready(self, target_name):
        start = time.time()
        full_frames = 0

        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            if self._raw_con_full():
                full_frames += 1

                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'ZFG hard-intro guard passed '
                        f'{self.ACTOR}->{target_name} '
                        f'{full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                    )
                    return True
            else:
                full_frames = 0

            self.sleep(self.POLL)
            self.task.next_frame()

        self.logger.warning(
            f'ZFG hard-intro guard failed '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _switch_to(self, target_name, expect_intro=None):
        target = self._find_target_char(target_name)

        if target is None:
            self.logger.error(
                f'ZFG {self.ACTOR}: target not found -> {target_name}'
            )
            return False

        if expect_intro is True:
            allowed = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

            if target_name != allowed:
                self.logger.error(
                    f'ZFG invalid special intro '
                    f'{self.ACTOR}->{target_name}; '
                    f'allowed={allowed}'
                )
                return False

            if not self._confirm_hard_intro_ready(target_name):
                return False

            has_intro = True

        elif expect_intro is False:
            if self._concerto_effectively_full():
                self.logger.warning(
                    f'ZFG block forced-normal switch '
                    f'{self.ACTOR}->{target_name}: concerto full'
                )
                return False
            has_intro = False

        else:
            has_intro = self._concerto_effectively_full()

        target.has_intro = has_intro
        target.has_sub_dps_intro = (
            has_intro and getattr(self, 'is_sub_dps', False)
        )

        start = time.time()
        last_send = 0.0

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.check_combat()

            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, -1

            if in_team and current_index == target.index:
                self.task.in_liberation = False
                target.is_current_char = True

                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(
                        now,
                        target.intro_motion_freeze_duration,
                        -100,
                    )
                    self.last_outro_time = now

                self.logger.info(
                    f'ZFG exact switch success '
                    f'{self.ACTOR}->{target_name} '
                    f'intro={has_intro}'
                )
                return True

            if (
                in_team
                and current_index == self.index
                and not target.wait_switch()
            ):
                now = time.time()

                if now - last_send >= self.SWITCH_RETRY_INTERVAL:
                    self.task.send_key(target.index + 1)
                    last_send = now

            self.sleep(self.SWITCH_RETRY_INTERVAL)
            self.task.next_frame()

        self.logger.error(
            f'ZFG exact switch timeout '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _clear_detour(self, state):
        for key in (
            'detour_active',
            'detour_actor',
            'detour_final_target',
            'detour_next_step',
            'detour_resume_step',
            'detour_resume_phase',
        ):
            state.pop(key, None)

    def _switch_route(
        self,
        state,
        planned_target,
        next_step,
        force_intro=False,
    ):
        """
        正常切人入口。

        若协奏满，但planned_target不是当前角色正确的特殊变奏目标：
        保存主轴step/phase -> 先让正确角色吃特殊变奏
        -> 再自然切planned_target -> 进入next_step。
        """

        if force_intro:
            if self._switch_to(planned_target, expect_intro=True):
                self._advance_step(state, next_step)
                return True
            return False

        full = self._concerto_effectively_full()
        special_target = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

        if (
            full
            and special_target
            and planned_target != special_target
        ):
            if planned_target == 'Phoebe' and state.get(self.PHOEBE_PREHOLD_E_KEY):
                self.logger.info(
                    f'ZFG Phoebe-E prehold PRESERVE across detour '
                    f'{self.ACTOR}->{special_target}->Phoebe'
                )
            resume_step = state.get('step')
            resume_phase = state.get('phase')

            self.logger.warning(
                f'ZFG intro detour required: '
                f'source={self.ACTOR} '
                f'planned={planned_target} '
                f'correct_intro={special_target} '
                f'resume={resume_step}/{resume_phase}'
            )

            if not self._switch_to(
                special_target,
                expect_intro=None,
            ):
                return False

            state['detour_active'] = True
            state['detour_actor'] = special_target
            state['detour_final_target'] = planned_target
            state['detour_next_step'] = next_step
            state['detour_resume_step'] = resume_step
            state['detour_resume_phase'] = resume_phase
            return True

        if self._switch_to(planned_target, expect_intro=None):
            self._advance_step(state, next_step)
            return True

        return False

    def _run_detour_if_needed(self, state):
        if not state.get('detour_active'):
            return False

        expected = state.get('detour_actor')

        if expected != self.ACTOR:
            self._recover_wrong_actor(state)
            return True

        final_target = state.get('detour_final_target')
        next_step = state.get('detour_next_step')
        resume_step = state.get('detour_resume_step')
        resume_phase = state.get('detour_resume_phase')

        self.logger.info(
            f'ZFG detour actor={self.ACTOR} '
            f'return={final_target} '
            f'resume={resume_step}/{resume_phase}'
        )

        if self._switch_to(final_target, expect_intro=None):
            self._clear_detour(state)
            self._advance_step(state, next_step)

        return True

    def _recover_wrong_actor(self, state):
        expected = self._expected_actor(state)

        if expected and expected != self.ACTOR:
            self.logger.warning(
                f'ZFG wrong actor: current={self.ACTOR} '
                f'step={state.get("step")} expected={expected}'
            )
            return self._switch_to(
                expected,
                expect_intro=None,
            )

        recovery_actor = self._route_broken_state_to_recovery(
            state,
            reason=f'unhandled-step:{state.get("step")}',
        )

        if recovery_actor != self.ACTOR:
            return self._switch_to(
                recovery_actor,
                expect_intro=None,
            )

        return False


    def on_combat_end(self, chars):
        self._clear_zfg_state()

        if hasattr(self.task, self.TEAM_SIGNATURE_KEY):
            delattr(self.task, self.TEAM_SIGNATURE_KEY)

        return super().on_combat_end(chars)


class Rover(_ZFGFSM, BuiltinRover):
    ACTOR = 'Rover'


    R_TO_Q_SETTLE = 0.60  # R后给UI恢复的短稳定窗；只用于需要继续判Q/E的阶段
    ROVER_R_COOLDOWN = 20.0
    ROVER_LAST_R_CAST_KEY = 'rover_last_r_cast_time'
    P1_R_WAIT_MAX = 0.30
    P1_R_WAIT_POLL = 0.03
    ROVER_R_ENERGY_READY = 0.95
    ROVER_R_RING_BINS = 72
    ROVER_R_RING_HSV_LOWER = (14, 50, 85)
    ROVER_R_RING_HSV_UPPER = (44, 255, 255)
    ROVER_R_ICON_RADIUS_SCALE = 1.35
    ROVER_R_RING_INNER_RATIO = 0.88
    ROVER_R_RING_OUTER_RATIO = 1.10
    ROVER_R_ROI_SCALE = 1.60
    ROVER_R_BIN_MIN_COVERAGE = 0.05
    ROVER_R_BIN_RELATIVE_COVERAGE = 0.25
    AZ_A_TO_Z_GAP = 0.08
    AZ_SETTLE = 0.12

    P2_R_ACTION_SETTLE = 0.60
    P2_E_ACTION_SETTLE = 0.25

    REQUIRED_E_TIMEOUT = 1.8
    REQUIRED_Q_TIMEOUT = 1.8
    REQUIRED_R_TIMEOUT = 2.8
    REQUIRED_EFORTE_TIMEOUT = 2.2

    F_CHECK_INTERVAL = 0.18
    F_POST_ACTION_SETTLE_TIME = 0.12

    def f_break(
        self,
        check_f_on_switch=False,
        force=False,
    ):
        if self._zfg_team_matches():
            return False
        return super().f_break(
            check_f_on_switch=check_f_on_switch,
            force=force,
        )

    def do_perform(self):
        self.init()

        if not self._zfg_team_matches():
            return super().do_perform()

        state = self._zfg_state()

        if self._run_detour_if_needed(state):
            return

        step = state.get('step')

        if (
            step not in (
                self.STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE,
                self.STEP_P1_ROVER_R_TO_ZANI,
                self.STEP_P2_ROVER_AZ_WAIT_CONFESSION,
            )
            and self._field_f_check(resume_label=f'step={step}')
        ):
            return

        self.logger.info(
            f'ZFG V3.0 Rover step={step} phase={state.get("phase")} '
            f'intro={self.has_intro} forte={self.is_forte_full()} '
            f'E={self.resonance_available()} R={self.liberation_available()}'
        )

        if step == self.STEP_P1_ROVER_EQR_TO_PHOEBE:
            return self._p1_eqr_to_phoebe(state)

        if step == self.STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE:
            return self._p1_opportunity_e_to_phoebe(state)

        if step == self.STEP_P1_ROVER_R_TO_ZANI:
            return self._p1_r_to_zani(state)

        if step == self.STEP_P2_ROVER_SLOT_TO_ZANI:
            return self._p2_rover_slot(
                state,
                self.STEP_P2_ZANI_N2_TO_PHOEBE,
            )

        if step == self.STEP_P2_ROVER_AZ_WAIT_CONFESSION:
            return self._p2_az_wait_confession(state)

        return self._recover_wrong_actor(state)


    def _run_f_break_with_freeze(self, label):
        f_start = time.time()
        if not super().f_break(check_f_on_switch=False, force=False):
            return False
        f_duration = max(0.0, time.time() - f_start)
        if self.F_POST_ACTION_SETTLE_TIME > 0:
            self.sleep(self.F_POST_ACTION_SETTLE_TIME)
            self.task.next_frame()
        blocked = max(0.0, time.time() - f_start)
        self.add_freeze_duration(f_start, blocked)
        self.logger.info(
            f'ZFG V3.0 Rover F execution during {label}; '
            f'F={f_duration:.2f}s freeze={blocked:.2f}s'
        )
        return True

    def _field_f_check(self, force=False, resume_label='Rover on-field'):
        if not self.is_current_char:
            return False
        now = time.time()
        last = getattr(self, '_zfg_last_f_check', -100.0)
        if not force and now - last < self.F_CHECK_INTERVAL:
            return False
        self._zfg_last_f_check = now
        self.task.next_frame()
        return self._run_f_break_with_freeze(resume_label)


    def _cast_normal_e_once(self):
        if not self.resonance_available():
            return False

        clicked, _, _ = self.click_resonance(
            send_click=True,
            time_out=0.8,
        )
        if clicked:
            self.logger.info('ZFG V3.0 Rover normal/available E confirmed')
        return bool(clicked)

    def _cast_enhanced_e_once(self):
        if not (
            self.is_forte_full()
            and self.resonance_available()
        ):
            return False

        clicked, _, _ = self.click_resonance(
            send_click=True,
            time_out=0.8,
        )
        if clicked:
            self.logger.info('ZFG V3.0 Rover enhanced E confirmed')
        return bool(clicked)

    def _cast_any_e_required(self, tag):
        start = time.time()

        while time.time() - start < self.REQUIRED_E_TIMEOUT:
            self.task.next_frame()

            if self.is_forte_full() and self.resonance_available():
                if self._cast_enhanced_e_once():
                    return True

            if self.resonance_available():
                if self._cast_normal_e_once():
                    return True

            self.task.click()
            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V3.0 Rover {tag}: E not confirmed'
        )
        return False

    def _cast_q_required(self, tag):
        start = time.time()

        while time.time() - start < self.REQUIRED_Q_TIMEOUT:
            self.task.next_frame()

            if self.echo_available():
                result = self.click_echo(time_out=0.8)
                self.task.next_frame()
                consumed = not self.echo_available()

                if result or consumed:
                    self.logger.info(
                        f'ZFG V3.0 Rover {tag}: Q confirmed '
                        f'base_result={bool(result)} consumed={consumed}'
                    )
                    return True

            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V3.0 Rover {tag}: Q not confirmed'
        )
        return False


    def _record_rover_r_cast(self, input_time, tag):
        state = self._zfg_state()
        state[self.ROVER_LAST_R_CAST_KEY] = float(input_time)
        self.logger.info(f'ZFG V3.0 Rover {tag}: R cooldown timestamp armed at input')

    def _rover_r_remaining(self, state):
        predicted = None
        last = state.get(self.ROVER_LAST_R_CAST_KEY)
        if isinstance(last, (int, float)) and last > 0:
            elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(last)))
            predicted = max(0.0, self.ROVER_R_COOLDOWN - elapsed)
        try:
            ui_cd = max(0.0, float(self.task.get_cd('liberation', self.index)))
        except Exception:
            ui_cd = None
        if ui_cd is not None and ui_cd > 0.0:
            return ui_cd
        if predicted is not None:
            return predicted
        return ui_cd

    def _sample_rover_r_energy(self):
        """72-bin黄色外环占用率；>=95%才认为有足够R能量。"""
        try:
            box = self.task.get_box_by_name('box_liberation')
            frame = self.task.frame
            bx, by = float(box.x), float(box.y)
            bw, bh = float(box.width), float(box.height)
        except Exception:
            return None
        if frame is None or getattr(frame, 'ndim', 0) < 3:
            return None

        base_r = min(bw, bh) / 2.0
        if base_r < 4:
            return None
        cx0, cy0 = bx + bw / 2.0, by + bh / 2.0
        half = base_r * self.ROVER_R_ROI_SCALE
        fh, fw = frame.shape[:2]
        x0 = max(0, int(math.floor(cx0 - half)))
        x1 = min(fw, int(math.ceil(cx0 + half)))
        y0 = max(0, int(math.floor(cy0 - half)))
        y1 = min(fh, int(math.ceil(cy0 + half)))
        if x1 - x0 < 8 or y1 - y0 < 8:
            return None

        image = frame[y0:y1, x0:x1, :3]
        cx, cy = cx0 - x0, cy0 - y0
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(
            hsv,
            np.array(self.ROVER_R_RING_HSV_LOWER, dtype=np.uint8),
            np.array(self.ROVER_R_RING_HSV_UPPER, dtype=np.uint8),
        )
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        h, w = mask.shape[:2]
        yy, xx = np.ogrid[:h, :w]
        dx = xx - float(cx)
        dy = yy - float(cy)
        radius = np.sqrt(dx ** 2 + dy ** 2)
        true_r = base_r * self.ROVER_R_ICON_RADIUS_SCALE
        annulus = (
            (radius >= true_r * self.ROVER_R_RING_INNER_RATIO)
            & (radius <= true_r * self.ROVER_R_RING_OUTER_RATIO)
        )
        angle = (np.arctan2(dy, dx) + 2 * np.pi) % (2 * np.pi)
        colored = mask > 0
        bins = int(self.ROVER_R_RING_BINS)
        coverages = []
        for i in range(bins):
            lo = 2 * np.pi * i / bins
            hi = 2 * np.pi * (i + 1) / bins
            sector = annulus & (angle >= lo) & (angle < hi)
            total = int(np.count_nonzero(sector))
            if total <= 0:
                coverages.append(0.0)
            else:
                coverages.append(int(np.count_nonzero(colored & sector)) / total)
        if not coverages:
            return None
        peak = max(coverages)
        threshold = max(self.ROVER_R_BIN_MIN_COVERAGE, peak * self.ROVER_R_BIN_RELATIVE_COVERAGE)
        active_bins = sum(1 for value in coverages if value >= threshold)
        energy = max(0.0, min(1.0, active_bins / float(bins)))
        self.logger.info(
            f'ZFG V3.0 Rover R-energy arc={active_bins}/{bins} energy={energy:.3f} '
            f'gate={self.ROVER_R_ENERGY_READY:.2f}'
        )
        return energy

    def _cast_r_required(self, tag):
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.REQUIRED_R_TIMEOUT:
            self.task.next_frame()
            if self._field_f_check(resume_label=f'{tag}-wait-R'):
                continue
            if self.liberation_available():
                input_time = time.time()
                result = self.click_liberation(send_click=True)
                if result:
                    self._record_rover_r_cast(input_time, tag)
                    self.logger.info(f'ZFG V3.0 Rover {tag}: R confirmed')
                    return True
            self.task.click()
            self.sleep(self.POLL)
        self.logger.warning(f'ZFG V3.0 Rover {tag}: R not confirmed')
        return False

    def _cast_q_soft(self, tag):
        if not self.echo_available():
            self.logger.info(f'ZFG V3.0 Rover {tag}: soft Q skip cooldown')
            return False
        result = self.click_echo(time_out=0)
        self.logger.info(f'ZFG V3.0 Rover {tag}: soft Q result={result}')
        return bool(result)

    def _cast_az_slot(self):
        self.logger.info('ZFG V3.0 Rover AZ start')
        self.task.click()
        self.sleep(self.AZ_A_TO_Z_GAP)
        self.task.next_frame()
        self.heavy_attack()
        self.sleep(self.AZ_SETTLE)
        self.logger.info('ZFG V3.0 Rover AZ end')
        return True


    def _p1_eqr_to_phoebe(self, state):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self.wait_down()
            state['phase'] = 'e'
            phase = 'e'

        if phase == 'e':
            if not self._cast_any_e_required('P1 EQR'):
                return
            state['phase'] = 'q'
            phase = 'q'

        if phase == 'q':
            if not self._cast_q_required('P1 EQR'):
                return
            state['phase'] = 'r'
            phase = 'r'

        if phase == 'r':
            if not self._cast_r_required('P1 EQR'):
                return
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            self._switch_route(
                state,
                'Phoebe',
                self.STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI,
            )


    def _p1_opportunity_e_to_phoebe(self, state):
        """
        P1 N1后的光主只做“当前帧机会动作”，绝不为了强化E站场等待。

        优先级：
          1) 当前已经满足强化E条件 -> 尝试一次强化E；
          2) 否则当前普通E可用 -> 尝试一次普通E；
          3) 两者都没有 -> 空过。

        明确禁止：AZ、A补回路、等待未来CD、等待强化E、R、Q、主动F。
        不论E是否成功，随后都立即切菲比。
        """
        phase = state.get('phase', 'snapshot')

        if phase == 'snapshot':
            if self.has_intro:
                self.wait_intro(time_out=0.8, click=False)

            self.task.next_frame()
            forte_now = bool(self.is_forte_full())
            e_now = bool(self.resonance_available())
            primary = 'NONE'

            if forte_now and e_now:
                clicked, _, _ = self.click_resonance(
                    send_click=False,
                    time_out=0.55,
                )
                primary = 'ENHANCED_E' if clicked else 'ENHANCED_E_ATTEMPT_FAILED'
            elif e_now:
                clicked, _, _ = self.click_resonance(
                    send_click=False,
                    time_out=0.55,
                )
                primary = 'NORMAL_E' if clicked else 'NORMAL_E_ATTEMPT_FAILED'

            self.logger.info(
                f'ZFG V3.0 Rover P1 N1 OPPORTUNITY-SLOT '
                f'forte_now={forte_now} e_now={e_now} primary={primary}; '
                f'NO-AZ NO-WAIT NO-Q NO-F -> Phoebe'
            )

            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            self._switch_route(
                state,
                'Phoebe',
                self.STEP_P1_PHOEBE_STAR_TO_ZANI,
            )


    def _p1_r_to_zani(self, state):
        """P1 N2后：R优先；只有能量>=95%且R在0.30s内转好才短等，否则立即走E/离场。"""
        phase = state.get('phase', 'snapshot')

        if phase == 'snapshot':
            self.task.next_frame()
            primary = 'NONE'
            r_cast = False

            if self.liberation_available():
                input_time = time.time()
                result = self.click_liberation(send_click=False, click_f=False)
                if result:
                    self._record_rover_r_cast(input_time, 'P1 FAST-SNAPSHOT')
                    primary = 'R'
                    r_cast = True
                else:
                    primary = 'R_ATTEMPT_FAILED'
            else:
                energy = self._sample_rover_r_energy()
                r_left = self._rover_r_remaining(state)
                should_wait = (
                    energy is not None
                    and energy >= self.ROVER_R_ENERGY_READY
                    and r_left is not None
                    and r_left <= self.P1_R_WAIT_MAX
                )
                self.logger.info(
                    f'ZFG V3.0 Rover P1 R decision ready_now=False '
                    f'energy={"unknown" if energy is None else f"{energy:.3f}"} '
                    f'R_left={"unknown" if r_left is None else f"{r_left:.3f}"} '
                    f'wait={should_wait}'
                )
                if should_wait:
                    wait_start = time.time()
                    while time.time() - wait_start < self.P1_R_WAIT_MAX:
                        self.task.next_frame()
                        if self.liberation_available():
                            input_time = time.time()
                            result = self.click_liberation(send_click=False, click_f=False)
                            if result:
                                self._record_rover_r_cast(input_time, 'P1 short-wait')
                                primary = 'R_AFTER_SHORT_WAIT'
                                r_cast = True
                            else:
                                primary = 'R_SHORT_WAIT_ATTEMPT_FAILED'
                            break
                        self.sleep(self.P1_R_WAIT_POLL)

            if not r_cast:
                if self.is_forte_full() and self.resonance_available():
                    primary = 'ENHANCED_E' if self._cast_enhanced_e_once() else 'ENHANCED_E_ATTEMPT_FAILED'
                elif self.resonance_available():
                    primary = 'NORMAL_E' if self._cast_normal_e_once() else 'NORMAL_E_ATTEMPT_FAILED'

            self.logger.info(
                f'ZFG V3.0 Rover P1 FAST-SNAPSHOT primary={primary}; soft-Q -> Zani'
            )
            self._cast_q_soft(f'P1 FAST-SNAPSHOT after {primary}')
            state['phase'] = 'switch_zani'
            phase = 'switch_zani'

        if phase == 'switch_zani':
            self._switch_route(state, 'Zani', self.STEP_P1_ZANI_N3_TO_PHOEBE)

    def _p2_confession_prayer_remaining_rover(self, state):
        last = state.get(self.PHOEBE_LAST_CONFESSION_TIME_KEY)
        if not isinstance(last, (int, float)) or last <= 0:
            return None
        return max(0.0, 24.0 - max(0.0, time.time() - last))

    def _p2_confession_r_remaining_rover(self, state):
        last = state.get(self.PHOEBE_LAST_R_CAST_TIME_KEY)
        if not isinstance(last, (int, float)) or last <= 0:
            return None
        elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(last)))
        return max(0.0, self.PHOEBE_R_COOLDOWN - elapsed)

    def _p2_confession_fill_room_rover(self, state):
        start = float(state.get('zani_r1_timer_start', 0) or 0)
        if start <= 0:
            return None, None
        elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(start)))
        r2_left = max(0.0, self.ZANI_R2_HARD_DEADLINE_SHARED - elapsed)
        return r2_left, max(0.0, r2_left - self.P2_CONFESSION_R2_RESERVE)

    def _p2_az_wait_confession(self, state):
        """V3.0动态填轴：AZ×n，每发后重算；离场前E可用则E->立刻切菲比。"""
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self.wait_down()
            state['phase'] = 'az_loop'
            phase = 'az_loop'

        if phase == 'az_loop':
            target = int(state.get(self.P2_CONFESSION_AZ_TARGET_KEY, 0) or 0)
            done = int(state.get(self.P2_CONFESSION_AZ_COUNT_KEY, 0) or 0)

            while done < target and done < self.P2_CONFESSION_MAX_AZ:
                prayer = self._p2_confession_prayer_remaining_rover(state)
                r_rem = self._p2_confession_r_remaining_rover(state)
                retry_after = float(state.get(self.P2_CONFESSION_RETRY_AFTER_KEY, 0.0) or 0.0)
                retry_wait = max(0.0, retry_after - time.time())
                known = [x for x in (prayer, r_rem) if isinstance(x, (int, float))]
                if retry_wait > 0:
                    known.append(retry_wait)
                need = max(known) if known else None
                r2_left, fill_room = self._p2_confession_fill_room_rover(state)

                if need is not None and need <= self.P2_CONFESSION_AZ_COST + self.P2_CONFESSION_PLAN_SAFETY:
                    self.logger.info(
                        f'ZFG V3.0 Rover P2 CONFESSION-WAIT stop AZ: need={need:.2f}s too short'
                    )
                    break
                if fill_room is not None and fill_room < self.P2_CONFESSION_AZ_COST + self.P2_CONFESSION_PLAN_SAFETY:
                    self.logger.warning(
                        f'ZFG V3.0 Rover P2 CONFESSION-WAIT stop AZ for R2 reserve '
                        f'R2_left={r2_left:.2f}s fill_room={fill_room:.2f}s'
                    )
                    break

                self.logger.info(
                    f'ZFG V3.0 Rover P2 CONFESSION-WAIT AZ #{done + 1}/{target} start '
                    f'Prayer={prayer} Rrem={r_rem} need={need} R2left={r2_left}'
                )
                self._cast_az_slot()
                done += 1
                state[self.P2_CONFESSION_AZ_COUNT_KEY] = done
                state[self.P2_CONFESSION_AZ_USED_KEY] = True

            state['phase'] = 'exit_e'
            phase = 'exit_e'

        if phase == 'exit_e':
            e_result = False
            if self.is_forte_full() and self.resonance_available():
                e_result = self._cast_enhanced_e_once()
                e_kind = 'ENHANCED_E' if e_result else 'ENHANCED_E_FAILED'
            elif self.resonance_available():
                e_result = self._cast_normal_e_once()
                e_kind = 'NORMAL_E' if e_result else 'NORMAL_E_FAILED'
            else:
                e_kind = 'NONE'
            self.logger.info(
                f'ZFG V3.0 Rover P2 CONFESSION-WAIT exit E={e_kind}; '
                'NO settle -> Phoebe immediately'
            )
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            state.pop(self.P2_CONFESSION_AZ_TARGET_KEY, None)
            self._switch_route(
                state, 'Phoebe', self.STEP_P2_PHOEBE_CONFESSION_CHECK,
            )


    def _cast_r_slot(self):
        if not self.liberation_available():
            return False
        result = self.click_liberation(send_click=True)
        self.logger.info(f'ZFG V3.0 Rover P2 SLOT=R result={result}')
        return bool(result)

    def _wait_enhanced_e_after_az(self, tag):
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.REQUIRED_EFORTE_TIMEOUT:
            self.task.next_frame()
            if self._field_f_check(resume_label=f'{tag}-wait-enhanced-E'):
                continue
            if self._cast_enhanced_e_once():
                return True
            self.task.click()
            self.sleep(self.POLL)
        self.logger.warning(f'ZFG V3.0 Rover {tag}: enhanced E not confirmed after AZ')
        return False

    def _p2_rover_slot(self, state, zani_next_step):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.continues_normal_attack(0.12)
            self.wait_down()
            state['phase'] = 'choose'
            phase = 'choose'

        if phase == 'choose':
            if self.liberation_available() and self._cast_r_slot():
                state['rover_last_slot'] = 'R'
                state['phase'] = 'post_r_e_snapshot'
                phase = 'post_r_e_snapshot'
            else:
                state['phase'] = 'az'
                phase = 'az'

        if phase == 'post_r_e_snapshot':
            self.logger.info(
                f'ZFG V3.0 Rover P2 R confirmed -> action settle '
                f'{self.P2_R_ACTION_SETTLE:.2f}s before E snapshot'
            )
            self.sleep(self.P2_R_ACTION_SETTLE)
            self.task.next_frame()

            e_after_r = 'NONE'
            if self.resonance_available():
                if self.is_forte_full():
                    if self._cast_enhanced_e_once():
                        e_after_r = 'ENHANCED_E'
                    else:
                        e_after_r = 'ENHANCED_E_ATTEMPT_FAILED'
                else:
                    if self._cast_normal_e_once():
                        e_after_r = 'NORMAL_E'
                    else:
                        e_after_r = 'NORMAL_E_ATTEMPT_FAILED'

            if e_after_r in ('ENHANCED_E', 'NORMAL_E'):
                self.logger.info(
                    f'ZFG V3.0 Rover P2 after R: {e_after_r} confirmed -> '
                    f'action settle {self.P2_E_ACTION_SETTLE:.2f}s'
                )
                self.sleep(self.P2_E_ACTION_SETTLE)
                self.task.next_frame()

            self.logger.info(
                f'ZFG V3.0 Rover P2 after R: E snapshot={e_after_r}; '
                f'action-complete -> Q -> Zani'
            )
            state['rover_last_slot'] = f'R+{e_after_r}'
            state['phase'] = 'q'
            phase = 'q'

        if phase == 'az':
            self._cast_az_slot()
            self._field_f_check(resume_label='P2 after AZ')
            state['phase'] = 'enhanced_e'
            phase = 'enhanced_e'

        if phase == 'enhanced_e':
            if not self._wait_enhanced_e_after_az('P2 AZ+E'):
                return
            state['rover_last_slot'] = 'AZ+ENHANCED_E'
            state['phase'] = 'q'
            phase = 'q'

        if phase == 'q':
            self._cast_q_soft(
                f'P2 after {state.get("rover_last_slot", "slot")}'
            )
            if getattr(self, 'buff_time', 0) > 0:
                self.last_buff_time = time.time()
            state['phase'] = 'switch_zani'
            phase = 'switch_zani'

        if phase == 'switch_zani':
            self._switch_route(
                state,
                'Zani',
                zani_next_step,
            )
