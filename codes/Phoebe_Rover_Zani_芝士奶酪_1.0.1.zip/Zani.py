"""
赞菲光固定轴 V3.0 - Zani（赞妮）

定位：
- P1：负责四终夜启动轴的 A-E 开场、强化E准备、R1计时、N1~N4、R2与收尾E。
- P2：负责三终夜循环轴的强化E准备、R1、N1~N3、R2与收尾E。
- 赞妮在 R 持续期内禁止主动 F；R 外站场允许机会型 F 检测，F 后原 phase 续轴。
- 手动闪避不会直接修改 STEP/phase，但可能取消当前技能动画；V3.0 的强化E提交锁可在被打断后续接，
  仍建议不要在强化E/R/终夜的关键提交瞬间手动闪避。

P1 主链：
赞妮 A-E -> 菲比告解R/E/Q -> 光主E/Q/R -> 菲比3A重击、3A存重击、满协奏
-> 特殊变奏赞妮 -> 强化E准备 -> R1+Q+N1确认切出
-> 光主机会E -> 菲比重击 -> 赞妮N2 -> 光主快照技能
-> 赞妮N3(菲比E预输入) -> 菲比告解R -> 赞妮N4 -> R2 -> E -> 菲比

P2 主链：
菲比双重击+满协奏 -> 特殊变奏赞妮 -> 强化E准备 -> R1+Q+N1
-> 光主资源短轴 -> 赞妮N2 -> 菲比告解R -> 赞妮N3 -> R2 -> E -> 菲比。

"""


import time

from src.char.BaseChar import SwitchPriority, Elements
from src.char.Zani import Zani as BuiltinZani


class _ZFGFSM:
    ACTOR = None

    STATE_KEY = 'zanfei_rotation_state'  # 共享FSM主体：step/phase/cycle等都放这里
    TEAM_SIGNATURE_KEY = 'zanfei_rotation_team_signature'  # 队伍变化检测；换队后重置固定轴
    SWITCH_LOG_KEY = 'zanfei_rotation_switch_logged'  # 避免重复刷同一条切人日志
    PHOEBE_PREHOLD_E_KEY = 'phoebe_prehold_e_active'  # 跨角色按住E：是否仍应保持按键
    PHOEBE_PREHOLD_SOURCE_KEY = 'phoebe_prehold_e_source'  # 记录是谁发起的预输入，便于查日志
    P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY = 'p1_phoebe_forte_expected_empty'

    PHOEBE_LAST_CONFESSION_TIME_KEY = 'phoebe_last_confession_time'
    PHOEBE_LAST_R_CAST_TIME_KEY = 'phoebe_last_r_cast_time'
    P2_CONFESSION_AZ_USED_KEY = 'p2_confession_az_detour_used'  # 兼容旧日志：本轮是否至少走过一次光主等待槽
    P2_CONFESSION_AZ_COUNT_KEY = 'p2_confession_az_count'
    P2_CONFESSION_AZ_TARGET_KEY = 'p2_confession_az_target'
    P2_CONFESSION_RETRY_AFTER_KEY = 'p2_confession_retry_after'

    PHOEBE_R_COOLDOWN = 25.0
    ZANI_R2_HARD_DEADLINE_SHARED = 19.50
    P2_CONFESSION_R2_RESERVE = 6.00  # 给告解+R动画+切赞妮+N3/R2留出的尾端保护
    P2_CONFESSION_AZ_COST = 0.85
    P2_CONFESSION_SWITCH_TOTAL = 0.35
    P2_CONFESSION_PLAN_SAFETY = 0.25
    P2_CONFESSION_MAX_AZ = 6


    STEP_P1_ZANI_OPEN_AE_TO_PHOEBE = 'P1_ZANI_OPEN_AE_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER = 'P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER'
    STEP_P1_ROVER_EQR_TO_PHOEBE = 'P1_ROVER_EQR_TO_PHOEBE'
    STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI = 'P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI'

    STEP_P1_ZANI_EFORTE_PREP = 'P1_ZANI_EFORTE_PREP'
    STEP_P1_ZANI_R1_N1_TO_ROVER = 'P1_ZANI_R1_N1_TO_ROVER'
    STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE = 'P1_ROVER_OPPORTUNITY_E_TO_PHOEBE'
    STEP_P1_PHOEBE_STAR_TO_ZANI = 'P1_PHOEBE_STAR_TO_ZANI'
    STEP_P1_ZANI_N2_TO_ROVER_R = 'P1_ZANI_N2_TO_ROVER_R'
    STEP_P1_ROVER_R_TO_ZANI = 'P1_ROVER_R_TO_ZANI'
    STEP_P1_ZANI_N3_TO_PHOEBE = 'P1_ZANI_N3_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI = 'P1_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P1_ZANI_N4_R2_E_TO_PHOEBE = 'P1_ZANI_N4_R2_E_TO_PHOEBE'

    STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI = 'P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI'
    STEP_P2_ZANI_EFORTE_PREP = 'P2_ZANI_EFORTE_PREP'
    STEP_P2_ZANI_R1_N1_TO_ROVER = 'P2_ZANI_R1_N1_TO_ROVER'
    STEP_P2_ROVER_SLOT_TO_ZANI = 'P2_ROVER_SLOT_TO_ZANI'
    STEP_P2_ZANI_N2_TO_PHOEBE = 'P2_ZANI_N2_TO_PHOEBE'

    STEP_P2_PHOEBE_CONFESSION_CHECK = 'P2_PHOEBE_CONFESSION_CHECK'
    STEP_P2_ROVER_AZ_WAIT_CONFESSION = 'P2_ROVER_AZ_WAIT_CONFESSION'
    STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI = 'P2_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P2_ZANI_N3_R2_E_TO_PHOEBE = 'P2_ZANI_N3_R2_E_TO_PHOEBE'

    STEP_RECOVER_ZANI_LIBERATION = 'RECOVER_ZANI_LIBERATION'
    STEP_RECOVER_P2_PHOEBE = 'RECOVER_P2_PHOEBE'

    STEP_ACTOR = {
        STEP_P1_ZANI_OPEN_AE_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER: 'Phoebe',
        STEP_P1_ROVER_EQR_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI: 'Phoebe',

        STEP_P1_ZANI_EFORTE_PREP: 'Zani',
        STEP_P1_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_STAR_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N2_TO_ROVER_R: 'Zani',
        STEP_P1_ROVER_R_TO_ZANI: 'Rover',
        STEP_P1_ZANI_N3_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N4_R2_E_TO_PHOEBE: 'Zani',

        STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_EFORTE_PREP: 'Zani',
        STEP_P2_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P2_ROVER_SLOT_TO_ZANI: 'Rover',
        STEP_P2_ZANI_N2_TO_PHOEBE: 'Zani',
        STEP_P2_PHOEBE_CONFESSION_CHECK: 'Phoebe',
        STEP_P2_ROVER_AZ_WAIT_CONFESSION: 'Rover',
        STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_N3_R2_E_TO_PHOEBE: 'Zani',

        STEP_RECOVER_ZANI_LIBERATION: 'Zani',
        STEP_RECOVER_P2_PHOEBE: 'Phoebe',
    }

    SPECIAL_INTRO_TARGET = {
        'Phoebe': 'Zani',
        'Zani': 'Rover',
        'Rover': 'Phoebe',
    }

    CONCERTO_EFFECTIVE_FULL = 0.99
    INTRO_CONFIRM_FRAMES = 3
    INTRO_CONFIRM_TIMEOUT = 1.0
    POLL = 0.05

    SWITCH_TIMEOUT = 6.0
    SWITCH_RETRY_INTERVAL = 0.04

    def _release_phoebe_prehold(self, state, reason='cleanup'):
        if not isinstance(state, dict) or not state.get(self.PHOEBE_PREHOLD_E_KEY):
            return False
        try:
            self.task.send_key_up(self.get_resonance_key())
        except Exception:
            pass
        source = state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)
        state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
        self.logger.info(
            f'ZFG Phoebe-E prehold RELEASE reason={reason} source={source}'
        )
        return True

    def _clear_zfg_state(self):
        state = getattr(self.task, self.STATE_KEY, None)
        self._release_phoebe_prehold(state, reason='clear-zfg-state')
        for key in (self.STATE_KEY, self.SWITCH_LOG_KEY):
            if hasattr(self.task, key):
                delattr(self.task, key)

    def _zfg_team_matches(self):
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            return False

        chars = tuple(char for char in chars if char is not None)

        signature = tuple(
            (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.'),
                getattr(char, 'index', None),
            )
            for char in chars
        )

        required = {
            'char_zani',
            'char_phoebe',
            'char_rover',
        }

        identity_ok = (
            len(chars) == 3
            and {name for name, _ in signature} == required
            and any(char is self for char in chars)
        )

        rover = None
        for char in chars:
            name = (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.')
            )
            if name == 'char_rover':
                rover = char
                break

        rover_form = -1
        if rover is not None:
            try:
                if hasattr(self.task, 'get_known_ring_index'):
                    rover_form = self.task.get_known_ring_index(rover)
                else:
                    rover_form = getattr(rover, 'ring_index', -1)
            except Exception:
                rover_form = getattr(rover, 'ring_index', -1)

        form_ok = rover_form < 0 or rover_form == Elements.SPECTRO
        matched = identity_ok and form_ok

        previous = getattr(self.task, self.TEAM_SIGNATURE_KEY, None)

        if signature != previous:
            self._clear_zfg_state()
            setattr(self.task, self.TEAM_SIGNATURE_KEY, signature)
            self.logger.info(
                f'ZFG team changed matched={matched} '
                f'rover_form={rover_form} members={signature}'
            )
        elif not matched:
            self._clear_zfg_state()

        return matched

    def _zfg_state(self):
        """Return shared FSM state.

        First creation starts from P1.  If an already-existing state is damaged,
        do not replay the one-time opening: route to the agreed recovery entry.
        """
        state = getattr(self.task, self.STATE_KEY, None)

        if state is None:
            state = {
                'step': self.STEP_P1_ZANI_OPEN_AE_TO_PHOEBE,
                'cycle': 1,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self.logger.info(
                'ZFG FSM initialize -> P1_ZANI_OPEN_AE_TO_PHOEBE'
            )
            return state

        if not isinstance(state, dict) or 'step' not in state:
            old_cycle = state.get('cycle', 1) if isinstance(state, dict) else 1
            state = {
                'cycle': old_cycle,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self._route_broken_state_to_recovery(
                state,
                reason='state-missing-step',
            )

        return state


    def _advance_step(self, state, next_step):
        old = state.get('step')
        state['step'] = next_step
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        self.logger.info(
            f'ZFG FSM advance {old} -> {next_step} '
            f'cycle={state.get("cycle", 1)} '
            f'nightfall={state.get("nightfall_count", 0)}'
        )

    def _expected_actor(self, state):
        if state.get('detour_active'):
            return state.get('detour_actor')
        return self.STEP_ACTOR.get(state.get('step'))

    def _route_broken_state_to_recovery(self, state, reason='unknown'):
        """Route a damaged FSM without replaying the one-time P1 opening.

        - Zani still in R state -> RECOVER_ZANI_LIBERATION.
        - Otherwise -> RECOVER_P2_PHOEBE.
        """
        if not isinstance(state, dict):
            return 'Phoebe'

        self._clear_detour(state)
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        zani = self if self.ACTOR == 'Zani' else self._find_target_char('Zani')
        if zani is not None and getattr(zani, 'in_liberation', False):
            state['step'] = self.STEP_RECOVER_ZANI_LIBERATION
            actor = 'Zani'
        else:
            state['step'] = self.STEP_RECOVER_P2_PHOEBE
            actor = 'Phoebe'

        self.logger.error(
            f'ZFG broken FSM recovery reason={reason} '
            f'-> step={state.get("step")} actor={actor}'
        )
        return actor

    def get_switch_priority(
        self,
        current_char=None,
        has_intro=False,
        target_low_con=False,
    ):
        if not self._zfg_team_matches():
            return super().get_switch_priority(
                current_char,
                has_intro,
                target_low_con,
            )

        state = self._zfg_state()
        expected = self._expected_actor(state)

        if expected is None:
            expected = self._route_broken_state_to_recovery(
                state,
                reason=f'unknown-step:{state.get("step")}',
            )

        if not getattr(self.task, self.SWITCH_LOG_KEY, False):
            self.logger.info(
                f'ZFG FSM-exclusive switching enabled '
                f'step={state.get("step")} expected={expected}'
            )
            setattr(self.task, self.SWITCH_LOG_KEY, True)

        return (
            SwitchPriority.MUST
            if expected == self.ACTOR
            else SwitchPriority.NO
        )

    def _find_target_char(self, target_name):
        target_name = target_name.casefold()

        for char in getattr(self.task, 'chars', []):
            if char is None or char is self:
                continue

            names = (
                getattr(char, 'name', None),
                char.__class__.__name__,
                getattr(char, 'display_name', None),
            )

            for name in names:
                if name and str(name).casefold() == target_name:
                    return char

        return None

    def _raw_con_full(self):
        try:
            return bool(self.task.is_con_full())
        except Exception:
            return bool(self.is_con_full())

    def _read_concerto(self):
        if self._raw_con_full():
            return 1.0

        try:
            value = float(self.get_current_con())
        except Exception:
            try:
                value = float(self.task.get_current_con())
            except Exception:
                value = 0.0

        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        return (
            self._raw_con_full()
            or self._read_concerto() >= self.CONCERTO_EFFECTIVE_FULL
        )

    def _confirm_hard_intro_ready(self, target_name):
        start = time.time()
        full_frames = 0

        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            if self._raw_con_full():
                full_frames += 1

                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'ZFG hard-intro guard passed '
                        f'{self.ACTOR}->{target_name} '
                        f'{full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                    )
                    return True
            else:
                full_frames = 0

            self.sleep(self.POLL)
            self.task.next_frame()

        self.logger.warning(
            f'ZFG hard-intro guard failed '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _switch_to(self, target_name, expect_intro=None):
        target = self._find_target_char(target_name)

        if target is None:
            self.logger.error(
                f'ZFG {self.ACTOR}: target not found -> {target_name}'
            )
            return False

        if expect_intro is True:
            allowed = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

            if target_name != allowed:
                self.logger.error(
                    f'ZFG invalid special intro '
                    f'{self.ACTOR}->{target_name}; '
                    f'allowed={allowed}'
                )
                return False

            if not self._confirm_hard_intro_ready(target_name):
                return False

            has_intro = True

        elif expect_intro is False:
            if self._concerto_effectively_full():
                self.logger.warning(
                    f'ZFG block forced-normal switch '
                    f'{self.ACTOR}->{target_name}: concerto full'
                )
                return False
            has_intro = False

        else:
            has_intro = self._concerto_effectively_full()

        target.has_intro = has_intro
        target.has_sub_dps_intro = (
            has_intro and getattr(self, 'is_sub_dps', False)
        )

        start = time.time()
        last_send = 0.0

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.check_combat()

            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, -1

            if in_team and current_index == target.index:
                self.task.in_liberation = False
                target.is_current_char = True

                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(
                        now,
                        target.intro_motion_freeze_duration,
                        -100,
                    )
                    self.last_outro_time = now

                self.logger.info(
                    f'ZFG exact switch success '
                    f'{self.ACTOR}->{target_name} '
                    f'intro={has_intro}'
                )
                return True

            if (
                in_team
                and current_index == self.index
                and not target.wait_switch()
            ):
                now = time.time()

                if now - last_send >= self.SWITCH_RETRY_INTERVAL:
                    self.task.send_key(target.index + 1)
                    last_send = now

            self.sleep(self.SWITCH_RETRY_INTERVAL)
            self.task.next_frame()

        self.logger.error(
            f'ZFG exact switch timeout '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _clear_detour(self, state):
        for key in (
            'detour_active',
            'detour_actor',
            'detour_final_target',
            'detour_next_step',
            'detour_resume_step',
            'detour_resume_phase',
        ):
            state.pop(key, None)

    def _switch_route(
        self,
        state,
        planned_target,
        next_step,
        force_intro=False,
    ):
        """
        正常切人入口。

        若协奏满，但planned_target不是当前角色正确的特殊变奏目标：
        保存主轴step/phase -> 先让正确角色吃特殊变奏
        -> 再自然切planned_target -> 进入next_step。
        """

        if force_intro:
            if self._switch_to(planned_target, expect_intro=True):
                self._advance_step(state, next_step)
                return True
            return False

        full = self._concerto_effectively_full()
        special_target = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

        if (
            full
            and special_target
            and planned_target != special_target
        ):
            if planned_target == 'Phoebe' and state.get(self.PHOEBE_PREHOLD_E_KEY):
                self.logger.info(
                    f'ZFG Phoebe-E prehold PRESERVE across detour '
                    f'{self.ACTOR}->{special_target}->Phoebe'
                )
            resume_step = state.get('step')
            resume_phase = state.get('phase')

            self.logger.warning(
                f'ZFG intro detour required: '
                f'source={self.ACTOR} '
                f'planned={planned_target} '
                f'correct_intro={special_target} '
                f'resume={resume_step}/{resume_phase}'
            )

            if not self._switch_to(
                special_target,
                expect_intro=None,
            ):
                return False

            state['detour_active'] = True
            state['detour_actor'] = special_target
            state['detour_final_target'] = planned_target
            state['detour_next_step'] = next_step
            state['detour_resume_step'] = resume_step
            state['detour_resume_phase'] = resume_phase
            return True

        if self._switch_to(planned_target, expect_intro=None):
            self._advance_step(state, next_step)
            return True

        return False

    def _run_detour_if_needed(self, state):
        if not state.get('detour_active'):
            return False

        expected = state.get('detour_actor')

        if expected != self.ACTOR:
            self._recover_wrong_actor(state)
            return True

        final_target = state.get('detour_final_target')
        next_step = state.get('detour_next_step')
        resume_step = state.get('detour_resume_step')
        resume_phase = state.get('detour_resume_phase')

        self.logger.info(
            f'ZFG detour actor={self.ACTOR} '
            f'return={final_target} '
            f'resume={resume_step}/{resume_phase}'
        )

        if self._switch_to(final_target, expect_intro=None):
            self._clear_detour(state)
            self._advance_step(state, next_step)

        return True

    def _recover_wrong_actor(self, state):
        expected = self._expected_actor(state)

        if expected and expected != self.ACTOR:
            self.logger.warning(
                f'ZFG wrong actor: current={self.ACTOR} '
                f'step={state.get("step")} expected={expected}'
            )
            return self._switch_to(
                expected,
                expect_intro=None,
            )

        recovery_actor = self._route_broken_state_to_recovery(
            state,
            reason=f'unhandled-step:{state.get("step")}',
        )

        if recovery_actor != self.ACTOR:
            return self._switch_to(
                recovery_actor,
                expect_intro=None,
            )

        return False


    def on_combat_end(self, chars):
        self._clear_zfg_state()

        if hasattr(self.task, self.TEAM_SIGNATURE_KEY):
            delattr(self.task, self.TEAM_SIGNATURE_KEY)

        return super().on_combat_end(chars)


class Zani(_ZFGFSM, BuiltinZani):
    ACTOR = 'Zani'


    OPEN_A_TO_E_GAP = 0.08  # 开场A后到E的最短间隔；太大浪费P1时间，太小可能吞E

    ENHANCED_E_PREP_TIMEOUT = 7.0
    ENHANCED_E_CONFIRM_TIMEOUT = 1.50
    ENHANCED_E_CLEAR_STABLE_SECONDS = 0.35
    ENHANCED_E_AMBIGUOUS_SETTLE_TIMEOUT = 0.70

    EFORTE_NORMAL_E_LAST_CAST_KEY = 'zani_eforte_normal_e_last_cast'
    EFORTE_NORMAL_E_CASTS_KEY = 'zani_eforte_normal_e_casts'
    EFORTE_ENHANCED_READY_SEEN_KEY = 'zani_eforte_enhanced_ready_seen'
    EFORTE_COMMIT_LOCK_KEY = 'zani_eforte_commit_lock'
    EFORTE_FIRST_INPUT_TIME_KEY = 'zani_eforte_first_input_time'
    EFORTE_COMMIT_ATTEMPTS_KEY = 'zani_eforte_commit_attempts'

    NORMAL_E_REAL_CD = 5.0
    NORMAL_E_RECAST_MIN_ELAPSED = 4.80
    NORMAL_E_ATTACK_INTERVAL = 0.08
    NORMAL_E_POST_CAST_SETTLE = 0.08
    NORMAL_E_CONFIRM_TIMEOUT = 0.45
    NORMAL_E_CLEAR_CONFIRM_FRAMES = 2

    LIBERATION_READY_TIMEOUT = 2.5  # R1等待上限；失败不推进phase
    POST_R2_E_TIMEOUT = 2.5         # R2后E的硬等待上限；E成功后才允许切菲比

    N1_ICON_ACQUIRE_TIMEOUT = 3.5
    NIGHTFALL_COMMIT_MIN_AFTER_TRIGGER = 0.30
    NIGHTFALL_COMMIT_TIMEOUT = 1.25
    NIGHTFALL_E_FALL_CONFIRM_FRAMES = 2
    NIGHTFALL_ICON_CLEAR_CONFIRM_FRAMES = 4
    NIGHTFALL_ICON_AUX_MIN_AFTER_TRIGGER = 0.35
    NIGHTFALL_TIME_AUX_AFTER_TRIGGER = 0.95
    LIBER_ECHO_WATCH_INTERVAL = 0.10
    LIBER_ECHO_DEADLINE_GUARD = 0.35
    NIGHTFALL_COMMIT_CTX_KEY = 'zani_nightfall_commit_ctx'

    F_CHECK_INTERVAL = 0.20
    F_POST_ACTION_SETTLE_TIME = 0.12

    FINAL_N_ICON_TIMEOUT = 3.0
    R2_HARD_DEADLINE = 19.50  # 从R1确认时刻计时；给20s形态尾端留0.5s输入安全余量
    FINAL_N_SMASH_DONE_LEFT = 0.08

    NIGHTFALL_DONE = 'DONE'
    NIGHTFALL_FAILED = 'FAILED'
    NIGHTFALL_LIBERATION_ENDED = 'LIBERATION_ENDED'
    NIGHTFALL_R2_TRIGGERED = 'R2_TRIGGERED'
    NIGHTFALL_R2_DEADLINE = 'R2_DEADLINE'

    def _init_eforte_state(self, state, tag):
        """初始化一次新的强化E准备，不在重试时重复清零。"""
        state[self.EFORTE_NORMAL_E_LAST_CAST_KEY] = -1.0
        state[self.EFORTE_NORMAL_E_CASTS_KEY] = 0
        state[self.EFORTE_ENHANCED_READY_SEEN_KEY] = False
        state[self.EFORTE_COMMIT_LOCK_KEY] = False
        state[self.EFORTE_FIRST_INPUT_TIME_KEY] = 0.0
        state[self.EFORTE_COMMIT_ATTEMPTS_KEY] = 0
        self.logger.info(
            f'ZFG V3.0 {tag}: EFORTE state initialized; manual F/dodge recovery enabled'
        )

    def _clear_eforte_state(self, state):
        """强化E阶段完成后清理临时状态，避免污染下一轮P1/P2。"""
        for key in (
            self.EFORTE_NORMAL_E_LAST_CAST_KEY,
            self.EFORTE_NORMAL_E_CASTS_KEY,
            self.EFORTE_ENHANCED_READY_SEEN_KEY,
            self.EFORTE_COMMIT_LOCK_KEY,
            self.EFORTE_FIRST_INPUT_TIME_KEY,
            self.EFORTE_COMMIT_ATTEMPTS_KEY,
        ):
            state.pop(key, None)

    def _eforte_commit_locked(self, state):
        """仅在当前确实处于P1/P2 EFORTE阶段时启用提交锁。

        自动F在这个窗口必须让路。手动闪避/F无法被脚本物理禁止，
        但提交锁会保证被打断后只重试强化E，不回普通E。
        """
        if state.get('step') not in (
            self.STEP_P1_ZANI_EFORTE_PREP,
            self.STEP_P2_ZANI_EFORTE_PREP,
        ):
            return False
        if state.get('phase') not in ('prepare_e', 'buff_settle'):
            return False
        return bool(state.get(self.EFORTE_COMMIT_LOCK_KEY, False))

    def f_break(
        self,
        check_f_on_switch=False,
        force=False,
    ):
        if self._zfg_team_matches():
            return False
        return super().f_break(
            check_f_on_switch=check_f_on_switch,
            force=force,
        )

    def _run_f_break_with_freeze(self, label):
        f_start = time.time()
        if not super().f_break(check_f_on_switch=False, force=False):
            return False
        f_duration = max(0.0, time.time() - f_start)
        if self.F_POST_ACTION_SETTLE_TIME > 0:
            self.sleep(self.F_POST_ACTION_SETTLE_TIME)
            self.task.next_frame()
        blocked = max(0.0, time.time() - f_start)
        self.add_freeze_duration(f_start, blocked)
        self.logger.info(
            f'ZFG V3.0 Zani F execution outside liberation during {label}; '
            f'F={f_duration:.2f}s freeze={blocked:.2f}s'
        )
        return True

    def _field_f_check(self, force=False, resume_label='Zani on-field'):
        if self.in_liberation or self.has_intro or not self.is_current_char:
            return False
        now = time.time()
        last = getattr(self, '_zfg_last_f_check', -100.0)
        if not force and now - last < self.F_CHECK_INTERVAL:
            return False
        self._zfg_last_f_check = now
        self.task.next_frame()
        return self._run_f_break_with_freeze(resume_label)

    def do_perform(self):
        if not self._zfg_team_matches():
            return super().do_perform()

        self._zanfei_guang = True
        state = self._zfg_state()

        if self._run_detour_if_needed(state):
            return

        step = state.get('step')
        phase = state.get('phase')

        if not self.in_liberation:
            if not self._eforte_commit_locked(state):
                if self._field_f_check(resume_label=f'step={step} phase={phase}'):
                    return
            else:
                self.logger.debug(
                    'ZFG V3.0 Zani E_COMMIT_LOCK active -> skip automatic F'
                )

        self.logger.info(
            f'ZFG V3.0 Zani step={step} phase={phase} '
            f'intro={self.has_intro} liber={self.in_liberation} '
            f'N={state.get("nightfall_count", 0)}'
        )

        if step == self.STEP_P1_ZANI_OPEN_AE_TO_PHOEBE:
            return self._p1_open_ae(state)

        if step == self.STEP_P1_ZANI_EFORTE_PREP:
            return self._enhanced_e_prep_step(
                state,
                self.STEP_P1_ZANI_R1_N1_TO_ROVER,
                tag='P1-EFORTE',
            )

        if step == self.STEP_P1_ZANI_R1_N1_TO_ROVER:
            return self._r1_n1_early_handoff(
                state,
                self.STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE,
                tag='P1-N1',
            )

        if step == self.STEP_P1_ZANI_N2_TO_ROVER_R:
            return self._nightfall_then_switch(
                state,
                nightfall_number=2,
                target='Rover',
                next_step=self.STEP_P1_ROVER_R_TO_ZANI,
                tag='P1-N2',
            )

        if step == self.STEP_P1_ZANI_N3_TO_PHOEBE:
            return self._nightfall_then_switch(
                state,
                nightfall_number=3,
                target='Phoebe',
                next_step=self.STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI,
                tag='P1-N3',
                prehold_phoebe=True,
            )

        if step == self.STEP_P1_ZANI_N4_R2_E_TO_PHOEBE:
            return self._final_nightfall_r2_e(
                state,
                nightfall_number=4,
                next_phoebe_step=self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI,
                tag='P1-N4',
                mark_new_cycle=True,
                r2_policy='p1_deadline',
            )

        if step == self.STEP_P2_ZANI_EFORTE_PREP:
            return self._enhanced_e_prep_step(
                state,
                self.STEP_P2_ZANI_R1_N1_TO_ROVER,
                tag='P2-EFORTE',
            )

        if step == self.STEP_P2_ZANI_R1_N1_TO_ROVER:
            return self._r1_n1_early_handoff(
                state,
                self.STEP_P2_ROVER_SLOT_TO_ZANI,
                tag='P2-N1',
            )

        if step == self.STEP_P2_ZANI_N2_TO_PHOEBE:
            if state.get('phase') is None:
                state[self.P2_CONFESSION_AZ_USED_KEY] = False
                state[self.P2_CONFESSION_AZ_COUNT_KEY] = 0
                state.pop(self.P2_CONFESSION_AZ_TARGET_KEY, None)
                state.pop(self.P2_CONFESSION_RETRY_AFTER_KEY, None)
            return self._nightfall_then_switch(
                state,
                nightfall_number=2,
                target='Phoebe',
                next_step=self.STEP_P2_PHOEBE_CONFESSION_CHECK,
                tag='P2-N2',
                prehold_phoebe=False,
            )

        if step == self.STEP_P2_ZANI_N3_R2_E_TO_PHOEBE:
            return self._final_nightfall_r2_e(
                state,
                nightfall_number=3,
                next_phoebe_step=self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI,
                tag='P2-N3',
                mark_new_cycle=True,
                r2_policy='p2_after_n3_or_deadline',
            )

        if step == self.STEP_RECOVER_ZANI_LIBERATION:
            return self._recover_liberation(state)

        return self._recover_wrong_actor(state)


    def _arm_phoebe_prehold(self, state, tag, require_zani_e_locked=True):
        if state.get(self.PHOEBE_PREHOLD_E_KEY):
            return True
        if require_zani_e_locked and self.resonance_available():
            self.logger.info(
                f'ZFG V3.0 {tag}: skip Phoebe-E prehold for now; Zani E still available'
            )
            return False
        self.task.send_key_down(self.get_resonance_key())
        state[self.PHOEBE_PREHOLD_E_KEY] = True
        state[self.PHOEBE_PREHOLD_SOURCE_KEY] = self.ACTOR
        self.logger.info(f'ZFG V3.0 {tag}: Phoebe-E PREHOLD armed')
        return True

    def _p1_open_ae(self, state):
        phase = state.get('phase', 'a')

        if phase == 'a':
            self.task.click()
            self.sleep(self.OPEN_A_TO_E_GAP, check_combat=False)
            self.logger.info('ZFG V3.0 P1 opening: A sent')
            state['phase'] = 'e'
            phase = 'e'

        if phase == 'e':
            if not self.resonance_available():
                self.task.click()
                self.sleep(0.03)
                self.task.next_frame()
                return

            clicked, _, _ = self.click_resonance(
                send_click=False,
                time_out=0.7,
            )
            if not clicked:
                return

            self.logger.info(
                'ZFG V3.0 P1 opening: E confirmed -> no chair delay; prehold E for Phoebe'
            )
            self._arm_phoebe_prehold(
                state,
                'P1-opening',
                require_zani_e_locked=False,
            )
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            if not state.get(self.PHOEBE_PREHOLD_E_KEY):
                self._arm_phoebe_prehold(
                    state,
                    'P1-opening-retry',
                    require_zani_e_locked=False,
                )
            switched = self._switch_route(
                state,
                'Phoebe',
                self.STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER,
            )
            if not switched:
                self._release_phoebe_prehold(state, reason='P1-opening-switch-failed')


    def _cast_normal_e_once(self):
        """普通E：发送后必须看到“普通E进入不可用”或“强化E接管图标”才算成功。"""
        if self.is_e_forte_full():
            return False
        if not self.resonance_available():
            return False

        clicked, _, _ = self.click_resonance(
            send_click=False,
            time_out=0.7,
        )
        if not clicked:
            return False

        confirm_start = time.time()
        clear_frames = 0
        while time.time() - confirm_start < self.NORMAL_E_CONFIRM_TIMEOUT:
            self.task.next_frame()

            if self.is_e_forte_full():
                self.logger.info(
                    'ZFG V3.0 Zani normal E RELEASE confirmed -> enhanced-E became ready'
                )
                return True

            if not self.resonance_available():
                clear_frames += 1
                if clear_frames >= self.NORMAL_E_CLEAR_CONFIRM_FRAMES:
                    self.logger.info(
                        'ZFG V3.0 Zani normal E RELEASE confirmed -> E entered cooldown'
                    )
                    return True
            else:
                clear_frames = 0

            self.sleep(self.POLL)

        self.logger.warning(
            'ZFG V3.0 Zani normal E input sent but release NOT confirmed; do not start 5s CD lock'
        )
        return False

    def _cast_enhanced_e_release(self, state=None, tag='EFORTE'):
        """强化E提交：图标持续消失才算成功，并记录跨轮次的提交进度。

        手动F/手动闪避/受击都可能让E输入被延迟或取消。这里不把“按键已发送”
        当成功；失败后由 E_COMMIT_LOCK 继续重试强化E，绝不回普通E。
        """
        if not self.is_e_forte_full():
            return False

        start = time.time()
        last_send = 0.0
        sent = False
        first_send_time = None
        clear_since = None

        if state is not None:
            state[self.EFORTE_COMMIT_LOCK_KEY] = True
            state[self.EFORTE_ENHANCED_READY_SEEN_KEY] = True
            state[self.EFORTE_COMMIT_ATTEMPTS_KEY] = int(
                state.get(self.EFORTE_COMMIT_ATTEMPTS_KEY, 0) or 0
            ) + 1
            self.logger.info(
                f'ZFG V3.0 {tag}: E_COMMIT_LOCK attempt='
                f'{state[self.EFORTE_COMMIT_ATTEMPTS_KEY]} '
                '-> NO auto-F / NO normal-E fallback'
            )

        while time.time() - start < self.ENHANCED_E_CONFIRM_TIMEOUT:
            self.task.next_frame()
            forte_now = bool(self.is_e_forte_full())

            if forte_now:
                clear_since = None
                now = time.time()
                if now - last_send >= 0.06:
                    self.send_resonance_key()
                    last_send = now
                    if not sent:
                        sent = True
                        first_send_time = now
                        if state is not None and not state.get(
                            self.EFORTE_FIRST_INPUT_TIME_KEY
                        ):
                            state[self.EFORTE_FIRST_INPUT_TIME_KEY] = now
                        self.logger.info(
                            'ZFG V3.0 Zani enhanced E input started'
                        )
            elif sent:
                if clear_since is None:
                    clear_since = time.time()
                clear_for = time.time() - clear_since
                if clear_for >= self.ENHANCED_E_CLEAR_STABLE_SECONDS:
                    try:
                        self.record_resonance_use()
                    except Exception:
                        pass

                    self.crisis_time = (
                        first_send_time
                        if first_send_time is not None
                        else time.time()
                    )
                    self.logger.info(
                        f'ZFG V3.0 Zani enhanced E RELEASE confirmed; '
                        f'icon-clear-stable={clear_for:.2f}s hit/blazes NOT required'
                    )
                    return True

            self.sleep(self.POLL)

        self.logger.warning(
            'ZFG V3.0 Zani enhanced E release not confirmed; '
            'enter ambiguous settle under E_COMMIT_LOCK'
        )
        return False

    def _confirm_ambiguous_enhanced_e_release(self, state, tag):
        """强化E确认超时后的恢复观察窗。

        - 图标重新稳定出现：说明大概率没放出去，下一轮只重试强化E。
        - 图标持续消失：说明可能被手动F/闪避/动作锁延迟后才真正释放，按成功处理。
        - 无论哪种情况，都不回普通E/A准备链。
        """
        start = time.time()
        clear_since = None

        while time.time() - start < self.ENHANCED_E_AMBIGUOUS_SETTLE_TIMEOUT:
            self.task.next_frame()
            if self.is_e_forte_full():
                self.logger.warning(
                    f'ZFG V3.0 {tag}: enhanced-E icon returned during ambiguous settle '
                    '-> keep E_COMMIT_LOCK and retry enhanced-E only'
                )
                return False

            if clear_since is None:
                clear_since = time.time()
            clear_for = time.time() - clear_since
            if clear_for >= self.ENHANCED_E_CLEAR_STABLE_SECONDS:
                try:
                    self.record_resonance_use()
                except Exception:
                    pass
                first_input = float(
                    state.get(self.EFORTE_FIRST_INPUT_TIME_KEY, 0.0) or 0.0
                )
                self.crisis_time = first_input if first_input > 0 else time.time()
                self.logger.info(
                    f'ZFG V3.0 {tag}: delayed enhanced-E RELEASE confirmed '
                    f'after interruption; icon-clear-stable={clear_for:.2f}s'
                )
                return True

            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V3.0 {tag}: enhanced-E state still ambiguous; '
            'keep E_COMMIT_LOCK, no normal-E fallback'
        )
        return False

    def _prepare_and_cast_enhanced_e(self, state, tag):
        """V3.0：EFORTE资源准备 + 持久化提交锁。

        正常优先级仍是：强化E > 真正转好的普通E > A。

        关键恢复规则：
        1) 普通E最后释放时间和次数写入共享 state，不会因 do_perform() 重进而清零；
        2) 一旦任何一帧看到强化E READY，就进入 E_COMMIT_LOCK；
        3) 提交锁期间禁止自动F、禁止普通E、禁止A补资源，只处理强化E；
        4) 手动F/闪避若打断强化E，下一轮只重试强化E；若图标延迟消失则按延迟成功处理。
        """
        start = time.time()
        last_attack = -100.0

        normal_e_cast_count = int(
            state.get(self.EFORTE_NORMAL_E_CASTS_KEY, 0) or 0
        )
        last_normal_e_cast_at = float(
            state.get(self.EFORTE_NORMAL_E_LAST_CAST_KEY, -1.0) or -1.0
        )
        ready_seen = bool(
            state.get(self.EFORTE_ENHANCED_READY_SEEN_KEY, False)
        )

        self.logger.info(
            f'ZFG V3.0 {tag}: enhanced-E prep RESUME '
            f'ready_seen={ready_seen} normal_e_casts={normal_e_cast_count} '
            f'commit_lock={bool(state.get(self.EFORTE_COMMIT_LOCK_KEY, False))}'
        )

        while time.time() - start < self.ENHANCED_E_PREP_TIMEOUT:
            self.task.next_frame()

            if state.get(self.EFORTE_ENHANCED_READY_SEEN_KEY, False):
                state[self.EFORTE_COMMIT_LOCK_KEY] = True

                if self.is_e_forte_full():
                    if self._cast_enhanced_e_release(state=state, tag=tag):
                        return True
                    if self._confirm_ambiguous_enhanced_e_release(state, tag):
                        return True
                    return False

                if self._confirm_ambiguous_enhanced_e_release(state, tag):
                    return True
                return False

            if self.is_e_forte_full():
                state[self.EFORTE_ENHANCED_READY_SEEN_KEY] = True
                state[self.EFORTE_COMMIT_LOCK_KEY] = True
                self.logger.info(
                    f'ZFG V3.0 {tag}: enhanced-E READY -> E_COMMIT_LOCK '
                    f'elapsed={time.time()-start:.2f}s '
                    f'normal_e_casts={normal_e_cast_count}'
                )
                if self._cast_enhanced_e_release(state=state, tag=tag):
                    return True
                if self._confirm_ambiguous_enhanced_e_release(state, tag):
                    return True
                return False

            if self._field_f_check(resume_label='enhanced-E prep'):
                last_attack = time.time()
                continue

            normal_ready = bool(self.resonance_available())
            last_normal_e_cast_at = float(
                state.get(self.EFORTE_NORMAL_E_LAST_CAST_KEY, -1.0) or -1.0
            )
            normal_e_cast_count = int(
                state.get(self.EFORTE_NORMAL_E_CASTS_KEY, 0) or 0
            )

            if last_normal_e_cast_at < 0:
                normal_recast_allowed = True
                normal_elapsed = 999.0
            else:
                normal_elapsed = self.time_elapsed_accounting_for_freeze(
                    last_normal_e_cast_at
                )
                normal_recast_allowed = (
                    normal_elapsed >= self.NORMAL_E_RECAST_MIN_ELAPSED
                )

            if normal_ready and normal_recast_allowed:
                if self._cast_normal_e_once():
                    normal_e_cast_count += 1
                    last_normal_e_cast_at = time.time()
                    state[self.EFORTE_NORMAL_E_CASTS_KEY] = normal_e_cast_count
                    state[self.EFORTE_NORMAL_E_LAST_CAST_KEY] = last_normal_e_cast_at
                    self.logger.info(
                        f'ZFG V3.0 {tag}: normal-E CAST #{normal_e_cast_count}; '
                        'state persisted, immediately re-sample enhanced-E'
                    )
                    self.sleep(self.NORMAL_E_POST_CAST_SETTLE)
                    self.task.next_frame()
                    continue
            elif normal_ready and last_normal_e_cast_at >= 0:
                if int(normal_elapsed * 10) % 10 == 0:
                    self.logger.debug(
                        f'ZFG V3.0 {tag}: normal-E UI ready ignored during real CD '
                        f'elapsed={normal_elapsed:.2f}/{self.NORMAL_E_REAL_CD:.2f}s'
                    )

            now = time.time()
            if now - last_attack >= self.NORMAL_E_ATTACK_INTERVAL:
                self.task.click()
                last_attack = now
            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V3.0 {tag}: enhanced-E prepare timeout '
            f'normal_e_casts={state.get(self.EFORTE_NORMAL_E_CASTS_KEY, 0)} '
            f'ready_seen={state.get(self.EFORTE_ENHANCED_READY_SEEN_KEY, False)}; '
            'keep EFORTE step with persistent state'
        )
        return False

    def _wait_enhanced_e_buff_window(self):
        self.logger.info(
            'ZFG V3.0 Zani wait enhanced-E action/buff window; '
            'damage hit is irrelevant'
        )
        self.wait_crisis_protocol_end()
        self.logger.info(
            'ZFG V3.0 Zani enhanced-E buff window ready -> allow R1'
        )
        return True

    def _enhanced_e_prep_step(self, state, next_step, tag):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.5, click=False)
            self._init_eforte_state(state, tag)
            state['phase'] = 'prepare_e'
            phase = 'prepare_e'

        if phase == 'prepare_e':
            if not self._prepare_and_cast_enhanced_e(state, tag):
                return
            state['phase'] = 'buff_settle'
            phase = 'buff_settle'

        if phase == 'buff_settle':
            self._wait_enhanced_e_buff_window()
            self.logger.info(f'ZFG V3.0 {tag}: enhanced-E step complete -> R1 step')
            self._clear_eforte_state(state)
            self._advance_step(state, next_step)


    def _try_liber_echo_soft(self, tag, force=False):
        """R1~R2期间的Q机会监听：有就尝试，不形成phase硬门。"""
        if not self.in_liberation or not self.is_current_char:
            return False
        now = time.time()
        last = getattr(self, '_zfg_last_liber_echo_watch', -100.0)
        if not force and now - last < self.LIBER_ECHO_WATCH_INTERVAL:
            return False
        self._zfg_last_liber_echo_watch = now
        if not self.echo_available():
            return False
        result = self.click_echo(time_out=0)
        self.logger.info(f'ZFG V3.0 {tag}: R-window Q opportunity result={bool(result)}')
        return bool(result)

    def _cast_r1(self):
        start = time.time()

        while time.time() - start < self.LIBERATION_READY_TIMEOUT:
            if self._field_f_check(resume_label='R1 pre-cast wait'):
                continue

            if self.liberation_available():
                if self.click_liberation(send_click=True):
                    self._start_liberation()
                    self._liber_phase = 1
                    self.logger.info(
                        'ZFG V3.0 Zani R1 confirmed -> liberation state'
                    )
                    return True

            self.task.click()
            self.sleep(self.POLL)
            self.task.next_frame()

        self.logger.warning(
            'ZFG V3.0 Zani R1 unavailable/failed; keep phase'
        )
        return False

    def _clear_nightfall_commit_ctx(self, state, tag=None):
        ctx = state.get(self.NIGHTFALL_COMMIT_CTX_KEY)
        if tag is None or not isinstance(ctx, dict) or ctx.get('tag') == tag:
            state.pop(self.NIGHTFALL_COMMIT_CTX_KEY, None)

    def _continue_nightfall_commit(self, state, tag, prehold_phoebe=False, final=False):
        """续接已经开始的终夜提交；超时只结束本次检查切片，不回退到重新寻找READY。"""
        ctx = state.get(self.NIGHTFALL_COMMIT_CTX_KEY)
        if not isinstance(ctx, dict) or ctx.get('tag') != tag:
            return self.NIGHTFALL_FAILED

        slice_start = time.time()
        while time.time() - slice_start < self.NIGHTFALL_COMMIT_TIMEOUT:
            if not self.in_liberation:
                self._clear_nightfall_commit_ctx(state, tag)
                return self.NIGHTFALL_LIBERATION_ENDED

            if final and self._r2_deadline_reached(state):
                self.logger.warning(
                    f'ZFG {tag}: R2 hard deadline preempts Nightfall confirm '
                    f'R_elapsed={self._r1_elapsed(state):.2f}s'
                )
                self._clear_nightfall_commit_ctx(state, tag)
                return self.NIGHTFALL_R2_DEADLINE

            now = time.time()
            if now - float(ctx.get('last_attack', -100.0)) >= 0.045:
                self.task.click()
                ctx['last_attack'] = now

            protected_for = now - float(ctx.get('trigger_start', now))
            if (
                prehold_phoebe
                and protected_for >= self.NIGHTFALL_COMMIT_MIN_AFTER_TRIGGER
                and not state.get(self.PHOEBE_PREHOLD_E_KEY)
            ):
                self._arm_phoebe_prehold(
                    state,
                    tag,
                    require_zani_e_locked=False,
                )

            self.sleep(0.015)
            self.task.next_frame()

            e_now = bool(self.resonance_available())
            if e_now:
                ctx['e_ready_seen'] = True
                ctx['e_fall_frames'] = 0
            elif ctx.get('e_ready_seen'):
                ctx['e_fall_frames'] = int(ctx.get('e_fall_frames', 0)) + 1

            icon_cleared = not self.is_nightfall_ready(threshold=0.035)
            if icon_cleared:
                ctx['icon_clear_frames'] = int(ctx.get('icon_clear_frames', 0)) + 1
            else:
                ctx['icon_clear_frames'] = 0

            protected_for = time.time() - float(ctx.get('trigger_start', time.time()))
            e_fall_frames = int(ctx.get('e_fall_frames', 0))
            icon_clear_frames = int(ctx.get('icon_clear_frames', 0))
            e_ready_seen = bool(ctx.get('e_ready_seen', False))

            if (
                protected_for >= self.NIGHTFALL_COMMIT_MIN_AFTER_TRIGGER
                and e_ready_seen
                and e_fall_frames >= self.NIGHTFALL_E_FALL_CONFIRM_FRAMES
            ):
                self.logger.info(
                    f'ZFG {tag}: Nightfall COMMIT signal=E_FALL '
                    f'E_locked={e_fall_frames}frames icon_clear={icon_clear_frames} '
                    f'after_trigger={protected_for:.3f}s'
                )
                self._clear_nightfall_commit_ctx(state, tag)
                self.sleep(0.04, check_combat=False)
                return self.NIGHTFALL_DONE

            if (
                protected_for >= self.NIGHTFALL_ICON_AUX_MIN_AFTER_TRIGGER
                and icon_clear_frames >= self.NIGHTFALL_ICON_CLEAR_CONFIRM_FRAMES
            ):
                self.logger.info(
                    f'ZFG {tag}: Nightfall COMMIT signal=ICON_CLEAR '
                    f'icon_clear={icon_clear_frames}frames E_seen_ready={e_ready_seen} '
                    f'after_trigger={protected_for:.3f}s'
                )
                self._clear_nightfall_commit_ctx(state, tag)
                self.sleep(0.04, check_combat=False)
                return self.NIGHTFALL_DONE

            if (
                protected_for >= self.NIGHTFALL_TIME_AUX_AFTER_TRIGGER
                and icon_cleared
            ):
                self.logger.info(
                    f'ZFG {tag}: Nightfall COMMIT signal=TIME_PLUS_ICON '
                    f'after_trigger={protected_for:.3f}s E_seen_ready={e_ready_seen}'
                )
                self._clear_nightfall_commit_ctx(state, tag)
                self.sleep(0.04, check_combat=False)
                return self.NIGHTFALL_DONE

        # 本次切片到时后做一次短最终复核。只要已经开始提交，就不回退到重新找READY。
        final_clear = 0
        for _ in range(2):
            self.task.next_frame()
            e_now = bool(self.resonance_available())
            if e_now:
                ctx['e_ready_seen'] = True
                ctx['e_fall_frames'] = 0
            elif ctx.get('e_ready_seen'):
                ctx['e_fall_frames'] = int(ctx.get('e_fall_frames', 0)) + 1
            icon_cleared = not self.is_nightfall_ready(threshold=0.035)
            if icon_cleared:
                final_clear += 1
                ctx['icon_clear_frames'] = int(ctx.get('icon_clear_frames', 0)) + 1
            else:
                final_clear = 0
                ctx['icon_clear_frames'] = 0
            if final_clear < 2:
                self.sleep(0.02)

        protected_for = time.time() - float(ctx.get('trigger_start', time.time()))
        if (
            protected_for >= self.NIGHTFALL_COMMIT_MIN_AFTER_TRIGGER
            and ctx.get('e_ready_seen')
            and int(ctx.get('e_fall_frames', 0)) >= self.NIGHTFALL_E_FALL_CONFIRM_FRAMES
        ):
            self.logger.info(
                f'ZFG {tag}: Nightfall COMMIT signal=E_FALL_FINAL '
                f'after_trigger={protected_for:.3f}s'
            )
            self._clear_nightfall_commit_ctx(state, tag)
            return self.NIGHTFALL_DONE

        if (
            protected_for >= self.NIGHTFALL_ICON_AUX_MIN_AFTER_TRIGGER
            and final_clear >= 2
        ):
            self.logger.info(
                f'ZFG {tag}: Nightfall COMMIT signal=TIMEOUT_FINAL_ICON '
                f'after_trigger={protected_for:.3f}s'
            )
            self._clear_nightfall_commit_ctx(state, tag)
            return self.NIGHTFALL_DONE

        self.logger.warning(
            f'ZFG {tag}: Nightfall commit slice timeout '
            f'{self.NIGHTFALL_COMMIT_TIMEOUT:.2f}s; preserve COMMITTING context'
        )
        return self.NIGHTFALL_FAILED

    def _trigger_nightfall_commit(
        self,
        state,
        tag,
        acquire_timeout,
        min_acquire_time=0.0,
        prehold_phoebe=False,
        final=False,
    ):
        """统一终夜确认：READY -> COMMITTING -> DONE；E下降沿主判据，图标消失辅助。"""
        if not self.in_liberation:
            self._clear_nightfall_commit_ctx(state)
            return self.NIGHTFALL_LIBERATION_ENDED

        ctx = state.get(self.NIGHTFALL_COMMIT_CTX_KEY)
        if isinstance(ctx, dict):
            if ctx.get('tag') == tag:
                return self._continue_nightfall_commit(
                    state,
                    tag,
                    prehold_phoebe=prehold_phoebe,
                    final=final,
                )
            self.logger.warning(
                f'ZFG {tag}: discard stale Nightfall COMMITTING context tag={ctx.get("tag")}'
            )
            self._clear_nightfall_commit_ctx(state)

        start = time.time()
        while time.time() - start < acquire_timeout:
            if not self.in_liberation:
                return self.NIGHTFALL_LIBERATION_ENDED

            if final and self._r2_deadline_reached(state):
                self.logger.warning(
                    f'ZFG {tag}: R2 hard deadline reached before Nightfall commit '
                    f'R_elapsed={self._r1_elapsed(state):.2f}s'
                )
                return self.NIGHTFALL_R2_DEADLINE

            if not final or (
                self.R2_HARD_DEADLINE - self._r1_elapsed(state)
                > self.LIBER_ECHO_DEADLINE_GUARD
            ):
                self._try_liber_echo_soft(f'{tag}-wait-Nightfall')

            elapsed = time.time() - start
            if bool(self.is_nightfall_ready()) and elapsed >= min_acquire_time:
                label = 'FINAL Nightfall' if final else 'Nightfall'
                trigger_start = time.time()
                self.nightfall_time = trigger_start
                state[self.NIGHTFALL_COMMIT_CTX_KEY] = {
                    'tag': tag,
                    'trigger_start': trigger_start,
                    'last_attack': -100.0,
                    'e_ready_seen': bool(self.resonance_available()),
                    'e_fall_frames': 0,
                    'icon_clear_frames': 0,
                }
                self.logger.info(
                    f'ZFG {tag}: {label} icon detected elapsed={elapsed:.2f}s '
                    '-> COMMITTING'
                )
                return self._continue_nightfall_commit(
                    state,
                    tag,
                    prehold_phoebe=prehold_phoebe,
                    final=final,
                )

            self.task.click()
            self.sleep(0.025)
            self.task.next_frame()

            if not final and self.should_end_liberation(time_only=True):
                r2_result = self.click_liber2()
                self.logger.warning(
                    f'ZFG {tag}: time guard triggered R2 result={r2_result}'
                )
                self._clear_nightfall_commit_ctx(state, tag)
                return self.NIGHTFALL_R2_TRIGGERED

        self.logger.warning(
            f'ZFG {tag}: Nightfall icon acquire timeout {acquire_timeout:.2f}s'
        )
        return self.NIGHTFALL_FAILED

    def _run_nightfall_step(
        self,
        state,
        tag,
        cancel_last_smash=False,
        acquire_timeout=7.0,
        cancel_with_dodge=True,
        prehold_phoebe=False,
    ):
        result = self._trigger_nightfall_commit(
            state,
            tag,
            acquire_timeout=acquire_timeout,
            min_acquire_time=0.0,
            prehold_phoebe=prehold_phoebe,
            final=False,
        )
        if result != self.NIGHTFALL_DONE:
            return result

        if cancel_last_smash:
            self.sleep(0.25, check_combat=False)
            if cancel_with_dodge:
                self.continues_right_click(0.1)

        self.check_liber()
        if not self.in_liberation:
            return self.NIGHTFALL_LIBERATION_ENDED

        self.logger.info(f'ZFG {tag}: Nightfall result=DONE')
        return self.NIGHTFALL_DONE

    def _handle_nightfall_failure(self, state, result, tag):
        if result == self.NIGHTFALL_DONE:
            return False

        if result == self.NIGHTFALL_FAILED:
            self.logger.warning(
                f'ZFG {tag}: Nightfall failed -> keep current phase for retry'
            )
            return True

        self.logger.warning(
            f'ZFG {tag}: abnormal result={result} -> RECOVER_P2_PHOEBE'
        )
        state['step'] = self.STEP_RECOVER_P2_PHOEBE
        state.pop('phase', None)
        return True

    def _r1_n1_early_handoff(self, state, rover_step, tag):
        phase = state.get('phase', 'r1')

        if phase == 'r1':
            if not self._cast_r1():
                return
            state['nightfall_count'] = 0
            state['zani_r1_timer_start'] = float(getattr(self, 'liberation_time', 0) or time.time())
            self.logger.info(
                f'ZFG V3.0 {tag}: R1 TIMER armed -> R2 hard deadline T+{self.R2_HARD_DEADLINE:.2f}s'
            )
            self._try_liber_echo_soft(f'{tag}-after-R1')
            state['phase'] = 'nightfall1_trigger'
            phase = 'nightfall1_trigger'

        if phase == 'nightfall1_trigger':
            self._liber_phase = 1
            result = self._trigger_nightfall_commit(
                state,
                tag,
                acquire_timeout=self.N1_ICON_ACQUIRE_TIMEOUT,
                min_acquire_time=0.0,
                final=False,
            )
            if self._handle_nightfall_failure(state, result, tag):
                return
            state['nightfall_count'] = 1
            state['phase'] = 'switch_rover'
            phase = 'switch_rover'

        if phase == 'switch_rover':
            self._switch_route(
                state,
                'Rover',
                rover_step,
            )

    def _nightfall_then_switch(
        self,
        state,
        nightfall_number,
        target,
        next_step,
        tag,
        prehold_phoebe=False,
    ):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._try_liber_echo_soft(f'{tag}-entry')
            state['phase'] = 'nightfall'
            phase = 'nightfall'

        if phase == 'nightfall':
            if not self.in_liberation:
                state['step'] = self.STEP_RECOVER_P2_PHOEBE
                state.pop('phase', None)
                return

            self._liber_phase = min(3, max(1, int(nightfall_number)))
            result = self._run_nightfall_step(state, tag, prehold_phoebe=prehold_phoebe)

            if self._handle_nightfall_failure(state, result, tag):
                return

            state['nightfall_count'] = nightfall_number
            state['phase'] = 'switch'
            phase = 'switch'
            self.logger.info(
                f'ZFG V3.0 Zani Nightfall #{nightfall_number} complete'
            )

        if phase == 'switch':
            self._switch_route(
                state,
                target,
                next_step,
            )


    def _cast_post_r2_e_required(self):
        start = time.time()

        while time.time() - start < self.POST_R2_E_TIMEOUT:
            self.task.next_frame()

            if self.resonance_available():
                clicked, _, _ = self.click_resonance(
                    send_click=False,
                    time_out=0.8,
                )
                if clicked:
                    self.logger.info(
                        'ZFG V3.0 Zani post-R2 E confirmed'
                    )
                    return True

            self.task.click()
            self.sleep(self.POLL)

        self.logger.warning(
            'ZFG V3.0 Zani post-R2 E not ready/confirmed -> keep phase'
        )
        return False

    def _r1_elapsed(self, state):
        start = float(state.get('zani_r1_timer_start', 0) or 0)
        if start <= 0:
            start = float(getattr(self, 'liberation_time', 0) or 0)
        if start <= 0:
            return 0.0
        return max(0.0, float(self.time_elapsed_accounting_for_freeze(start)))

    def _r2_deadline_reached(self, state):
        return self._r1_elapsed(state) >= self.R2_HARD_DEADLINE

    def _trigger_final_nightfall_fast(self, state, tag):
        return self._trigger_nightfall_commit(
            state,
            tag,
            acquire_timeout=self.FINAL_N_ICON_TIMEOUT,
            min_acquire_time=0.0,
            final=True,
        )

    def _wait_final_nightfall_r2_gate(self, state, tag, policy):
        """
        P1: N4完成后继续压到T+19.50s再R2。
        P2: N3完整下砸后立即R2；若N3未完成但到T+19.50s则强制R2。
        """
        while self.in_liberation:
            r_elapsed = self._r1_elapsed(state)
            if self.R2_HARD_DEADLINE - r_elapsed > self.LIBER_ECHO_DEADLINE_GUARD:
                self._try_liber_echo_soft(f'{tag}-R2-buffer')
            smash_left = max(0.0, float(self.nightfall_time_left()))
            deadline = r_elapsed >= self.R2_HARD_DEADLINE
            smash_done = smash_left <= self.FINAL_N_SMASH_DONE_LEFT

            if policy == 'p1_deadline':
                if deadline:
                    self.logger.info(
                        f'ZFG {tag}: R2 gate=P1_DEADLINE '
                        f'R_elapsed={r_elapsed:.2f}s smash_left={smash_left:.2f}s'
                    )
                    return True
            else:
                if smash_done or deadline:
                    reason = 'N3_DONE' if smash_done else 'HARD_DEADLINE'
                    self.logger.info(
                        f'ZFG {tag}: R2 gate={reason} '
                        f'R_elapsed={r_elapsed:.2f}s smash_left={smash_left:.2f}s'
                    )
                    return True

            self.sleep(0.02)
            self.task.next_frame()

        return True

    def _final_nightfall_r2_e(
        self,
        state,
        nightfall_number,
        next_phoebe_step,
        tag,
        mark_new_cycle,
        r2_policy,
    ):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            state['phase'] = 'final_nightfall'
            phase = 'final_nightfall'

        if phase == 'final_nightfall':
            result = self._trigger_final_nightfall_fast(state, tag)
            if result == self.NIGHTFALL_FAILED:
                return
            if result == self.NIGHTFALL_R2_DEADLINE:
                self.logger.warning(
                    f'ZFG {tag}: skip unfinished final Nightfall and protect R2 at hard deadline'
                )
                state['phase'] = 'r2'
                phase = 'r2'
            elif result != self.NIGHTFALL_DONE:
                self.logger.warning(
                    f'ZFG {tag}: final Nightfall lost liberation result={result} '
                    '-> recovery'
                )
                state['step'] = self.STEP_RECOVER_P2_PHOEBE
                state.pop('phase', None)
                return
            else:
                state['nightfall_count'] = nightfall_number
                state['phase'] = 'r2_buffer'
                phase = 'r2_buffer'

        if phase == 'r2_buffer':
            self._wait_final_nightfall_r2_gate(state, tag, r2_policy)
            state['phase'] = 'r2'
            phase = 'r2'

        if phase == 'r2':
            result = self.click_liber2()
            self.task.next_frame()
            still_liber = bool(self.check_liber())
            if not result and still_liber:
                self.logger.warning(
                    f'ZFG V3.0 {tag}: R2 not confirmed -> keep R2 phase'
                )
                return

            self.in_liberation = False
            self._liber_phase = 0
            self.logger.info(
                f'ZFG V3.0 {tag}: R2 complete result={result} still_liber={still_liber}'
            )
            state['phase'] = 'post_r2_e'
            phase = 'post_r2_e'

        if phase == 'post_r2_e':
            if not self._cast_post_r2_e_required():
                return
            if mark_new_cycle:
                state['new_cycle_pending'] = True
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            self._switch_route(
                state,
                'Phoebe',
                next_phoebe_step,
            )


    def _recover_liberation(self, state):
        phase = state.get('phase', 'safe_finish')

        if not self.in_liberation:
            state['step'] = self.STEP_RECOVER_P2_PHOEBE
            state.pop('phase', None)
            return

        if phase == 'safe_finish':
            self.logger.warning(
                'ZFG V3.0 RECOVER_ZANI_LIBERATION: '
                'attempt one safe Nightfall then R2'
            )
            self._liber_phase = 3

            if (
                self.is_nightfall_ready()
                or self.liberation_time_left() > 2.5
            ):
                result = self._run_nightfall_step(state, 'RECOVER-N')
                if result in (
                    self.NIGHTFALL_LIBERATION_ENDED,
                    self.NIGHTFALL_R2_TRIGGERED,
                ):
                    state['phase'] = 'switch_phoebe'
                    phase = 'switch_phoebe'
                else:
                    state['phase'] = 'q_r2'
                    phase = 'q_r2'
            else:
                state['phase'] = 'q_r2'
                phase = 'q_r2'

        if phase == 'q_r2':
            if self.in_liberation:
                self.should_end_liberation(force_finish=True)
                if self.echo_available():
                    self.click_echo(time_out=0)
                self.click_liber2()

            self.in_liberation = False
            self._liber_phase = 0
            state['phase'] = 'post_r2_e'
            phase = 'post_r2_e'

        if phase == 'post_r2_e':
            if not self._cast_post_r2_e_required():
                return
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            self._switch_route(
                state,
                'Phoebe',
                self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI,
            )
