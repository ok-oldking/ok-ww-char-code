"""
赞菲光固定轴 V3.0 - Phoebe（菲比）

定位：
- 告解：支持赞妮跨角色“预按住E”；V3.0只判断“当前是否已处于告解”，使用原版两格forte + 严格核心蓝条结构双硬门，不再捕捉进入过程。
- P1：告解R/E/Q；3A->Starflash；再3A存下一发Starflash；N1插入交一个重击；N3后告解R。
- P2：两个Starflash硬保护后才允许变奏赞妮；N2后告解R补焰光。
- 菲比不抢F，Q在中段多为软动作：有就放，没有不阻塞主轴。

V3.0 稳定版的 3A->Z：
- 第一组采用完整3A后，再进入原版Starflash安全释放流程。
- 不使用A3尾段长按预输入，避免UI瞬时漏识别造成“Z假成功”。
- 第二组仍然只负责3A造出并保存下一发Starflash，不能提前消费。

"""


import time
import cv2
import numpy as np

from src.char.BaseChar import SwitchPriority, Elements
from src.char.Phoebe import Phoebe as BuiltinPhoebe


class _ZFGFSM:
    ACTOR = None

    STATE_KEY = 'zanfei_rotation_state'  # 共享FSM主体：step/phase/cycle等都放这里
    TEAM_SIGNATURE_KEY = 'zanfei_rotation_team_signature'  # 队伍变化检测；换队后重置固定轴
    SWITCH_LOG_KEY = 'zanfei_rotation_switch_logged'  # 避免重复刷同一条切人日志
    PHOEBE_PREHOLD_E_KEY = 'phoebe_prehold_e_active'  # 跨角色按住E：是否仍应保持按键
    PHOEBE_PREHOLD_SOURCE_KEY = 'phoebe_prehold_e_source'  # 记录是谁发起的预输入，便于查日志
    P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY = 'p1_phoebe_forte_expected_empty'

    PHOEBE_LAST_CONFESSION_TIME_KEY = 'phoebe_last_confession_time'
    PHOEBE_LAST_R_CAST_TIME_KEY = 'phoebe_last_r_cast_time'
    P2_CONFESSION_AZ_USED_KEY = 'p2_confession_az_detour_used'  # 兼容旧日志：本轮是否至少走过一次光主等待槽
    P2_CONFESSION_AZ_COUNT_KEY = 'p2_confession_az_count'
    P2_CONFESSION_AZ_TARGET_KEY = 'p2_confession_az_target'
    P2_CONFESSION_RETRY_AFTER_KEY = 'p2_confession_retry_after'

    PHOEBE_R_COOLDOWN = 25.0
    ZANI_R2_HARD_DEADLINE_SHARED = 19.50
    P2_CONFESSION_R2_RESERVE = 6.00  # 给告解+R动画+切赞妮+N3/R2留出的尾端保护
    P2_CONFESSION_AZ_COST = 0.85
    P2_CONFESSION_SWITCH_TOTAL = 0.35
    P2_CONFESSION_PLAN_SAFETY = 0.25
    P2_CONFESSION_MAX_AZ = 6


    STEP_P1_ZANI_OPEN_AE_TO_PHOEBE = 'P1_ZANI_OPEN_AE_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER = 'P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER'
    STEP_P1_ROVER_EQR_TO_PHOEBE = 'P1_ROVER_EQR_TO_PHOEBE'
    STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI = 'P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI'

    STEP_P1_ZANI_EFORTE_PREP = 'P1_ZANI_EFORTE_PREP'
    STEP_P1_ZANI_R1_N1_TO_ROVER = 'P1_ZANI_R1_N1_TO_ROVER'
    STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE = 'P1_ROVER_OPPORTUNITY_E_TO_PHOEBE'
    STEP_P1_PHOEBE_STAR_TO_ZANI = 'P1_PHOEBE_STAR_TO_ZANI'
    STEP_P1_ZANI_N2_TO_ROVER_R = 'P1_ZANI_N2_TO_ROVER_R'
    STEP_P1_ROVER_R_TO_ZANI = 'P1_ROVER_R_TO_ZANI'
    STEP_P1_ZANI_N3_TO_PHOEBE = 'P1_ZANI_N3_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI = 'P1_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P1_ZANI_N4_R2_E_TO_PHOEBE = 'P1_ZANI_N4_R2_E_TO_PHOEBE'

    STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI = 'P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI'
    STEP_P2_ZANI_EFORTE_PREP = 'P2_ZANI_EFORTE_PREP'
    STEP_P2_ZANI_R1_N1_TO_ROVER = 'P2_ZANI_R1_N1_TO_ROVER'
    STEP_P2_ROVER_SLOT_TO_ZANI = 'P2_ROVER_SLOT_TO_ZANI'
    STEP_P2_ZANI_N2_TO_PHOEBE = 'P2_ZANI_N2_TO_PHOEBE'

    STEP_P2_PHOEBE_CONFESSION_CHECK = 'P2_PHOEBE_CONFESSION_CHECK'
    STEP_P2_ROVER_AZ_WAIT_CONFESSION = 'P2_ROVER_AZ_WAIT_CONFESSION'
    STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI = 'P2_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P2_ZANI_N3_R2_E_TO_PHOEBE = 'P2_ZANI_N3_R2_E_TO_PHOEBE'

    STEP_RECOVER_ZANI_LIBERATION = 'RECOVER_ZANI_LIBERATION'
    STEP_RECOVER_P2_PHOEBE = 'RECOVER_P2_PHOEBE'

    STEP_ACTOR = {
        STEP_P1_ZANI_OPEN_AE_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER: 'Phoebe',
        STEP_P1_ROVER_EQR_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI: 'Phoebe',

        STEP_P1_ZANI_EFORTE_PREP: 'Zani',
        STEP_P1_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_STAR_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N2_TO_ROVER_R: 'Zani',
        STEP_P1_ROVER_R_TO_ZANI: 'Rover',
        STEP_P1_ZANI_N3_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N4_R2_E_TO_PHOEBE: 'Zani',

        STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_EFORTE_PREP: 'Zani',
        STEP_P2_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P2_ROVER_SLOT_TO_ZANI: 'Rover',
        STEP_P2_ZANI_N2_TO_PHOEBE: 'Zani',
        STEP_P2_PHOEBE_CONFESSION_CHECK: 'Phoebe',
        STEP_P2_ROVER_AZ_WAIT_CONFESSION: 'Rover',
        STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_N3_R2_E_TO_PHOEBE: 'Zani',

        STEP_RECOVER_ZANI_LIBERATION: 'Zani',
        STEP_RECOVER_P2_PHOEBE: 'Phoebe',
    }

    SPECIAL_INTRO_TARGET = {
        'Phoebe': 'Zani',
        'Zani': 'Rover',
        'Rover': 'Phoebe',
    }

    CONCERTO_EFFECTIVE_FULL = 0.99
    INTRO_CONFIRM_FRAMES = 3
    INTRO_CONFIRM_TIMEOUT = 1.0
    POLL = 0.05

    SWITCH_TIMEOUT = 6.0
    SWITCH_RETRY_INTERVAL = 0.04

    def _release_phoebe_prehold(self, state, reason='cleanup'):
        if not isinstance(state, dict) or not state.get(self.PHOEBE_PREHOLD_E_KEY):
            return False
        try:
            self.task.send_key_up(self.get_resonance_key())
        except Exception:
            pass
        source = state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)
        state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
        self.logger.info(
            f'ZFG Phoebe-E prehold RELEASE reason={reason} source={source}'
        )
        return True

    def _clear_zfg_state(self):
        state = getattr(self.task, self.STATE_KEY, None)
        self._release_phoebe_prehold(state, reason='clear-zfg-state')
        for key in (self.STATE_KEY, self.SWITCH_LOG_KEY):
            if hasattr(self.task, key):
                delattr(self.task, key)

    def _zfg_team_matches(self):
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            return False

        chars = tuple(char for char in chars if char is not None)

        signature = tuple(
            (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.'),
                getattr(char, 'index', None),
            )
            for char in chars
        )

        required = {
            'char_zani',
            'char_phoebe',
            'char_rover',
        }

        identity_ok = (
            len(chars) == 3
            and {name for name, _ in signature} == required
            and any(char is self for char in chars)
        )

        rover = None
        for char in chars:
            name = (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.')
            )
            if name == 'char_rover':
                rover = char
                break

        rover_form = -1
        if rover is not None:
            try:
                if hasattr(self.task, 'get_known_ring_index'):
                    rover_form = self.task.get_known_ring_index(rover)
                else:
                    rover_form = getattr(rover, 'ring_index', -1)
            except Exception:
                rover_form = getattr(rover, 'ring_index', -1)

        form_ok = rover_form < 0 or rover_form == Elements.SPECTRO
        matched = identity_ok and form_ok

        previous = getattr(self.task, self.TEAM_SIGNATURE_KEY, None)

        if signature != previous:
            self._clear_zfg_state()
            setattr(self.task, self.TEAM_SIGNATURE_KEY, signature)
            self.logger.info(
                f'ZFG team changed matched={matched} '
                f'rover_form={rover_form} members={signature}'
            )
        elif not matched:
            self._clear_zfg_state()

        return matched

    def _zfg_state(self):
        """Return shared FSM state.

        First creation starts from P1.  If an already-existing state is damaged,
        do not replay the one-time opening: route to the agreed recovery entry.
        """
        state = getattr(self.task, self.STATE_KEY, None)

        if state is None:
            state = {
                'step': self.STEP_P1_ZANI_OPEN_AE_TO_PHOEBE,
                'cycle': 1,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self.logger.info(
                'ZFG FSM initialize -> P1_ZANI_OPEN_AE_TO_PHOEBE'
            )
            return state

        if not isinstance(state, dict) or 'step' not in state:
            old_cycle = state.get('cycle', 1) if isinstance(state, dict) else 1
            state = {
                'cycle': old_cycle,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self._route_broken_state_to_recovery(
                state,
                reason='state-missing-step',
            )

        return state


    def _advance_step(self, state, next_step):
        old = state.get('step')
        state['step'] = next_step
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        self.logger.info(
            f'ZFG FSM advance {old} -> {next_step} '
            f'cycle={state.get("cycle", 1)} '
            f'nightfall={state.get("nightfall_count", 0)}'
        )

    def _expected_actor(self, state):
        if state.get('detour_active'):
            return state.get('detour_actor')
        return self.STEP_ACTOR.get(state.get('step'))

    def _route_broken_state_to_recovery(self, state, reason='unknown'):
        """Route a damaged FSM without replaying the one-time P1 opening.

        - Zani still in R state -> RECOVER_ZANI_LIBERATION.
        - Otherwise -> RECOVER_P2_PHOEBE.
        """
        if not isinstance(state, dict):
            return 'Phoebe'

        self._clear_detour(state)
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        zani = self if self.ACTOR == 'Zani' else self._find_target_char('Zani')
        if zani is not None and getattr(zani, 'in_liberation', False):
            state['step'] = self.STEP_RECOVER_ZANI_LIBERATION
            actor = 'Zani'
        else:
            state['step'] = self.STEP_RECOVER_P2_PHOEBE
            actor = 'Phoebe'

        self.logger.error(
            f'ZFG broken FSM recovery reason={reason} '
            f'-> step={state.get("step")} actor={actor}'
        )
        return actor

    def get_switch_priority(
        self,
        current_char=None,
        has_intro=False,
        target_low_con=False,
    ):
        if not self._zfg_team_matches():
            return super().get_switch_priority(
                current_char,
                has_intro,
                target_low_con,
            )

        state = self._zfg_state()
        expected = self._expected_actor(state)

        if expected is None:
            expected = self._route_broken_state_to_recovery(
                state,
                reason=f'unknown-step:{state.get("step")}',
            )

        if not getattr(self.task, self.SWITCH_LOG_KEY, False):
            self.logger.info(
                f'ZFG FSM-exclusive switching enabled '
                f'step={state.get("step")} expected={expected}'
            )
            setattr(self.task, self.SWITCH_LOG_KEY, True)

        return (
            SwitchPriority.MUST
            if expected == self.ACTOR
            else SwitchPriority.NO
        )

    def _find_target_char(self, target_name):
        target_name = target_name.casefold()

        for char in getattr(self.task, 'chars', []):
            if char is None or char is self:
                continue

            names = (
                getattr(char, 'name', None),
                char.__class__.__name__,
                getattr(char, 'display_name', None),
            )

            for name in names:
                if name and str(name).casefold() == target_name:
                    return char

        return None

    def _raw_con_full(self):
        try:
            return bool(self.task.is_con_full())
        except Exception:
            return bool(self.is_con_full())

    def _read_concerto(self):
        if self._raw_con_full():
            return 1.0

        try:
            value = float(self.get_current_con())
        except Exception:
            try:
                value = float(self.task.get_current_con())
            except Exception:
                value = 0.0

        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        return (
            self._raw_con_full()
            or self._read_concerto() >= self.CONCERTO_EFFECTIVE_FULL
        )

    def _confirm_hard_intro_ready(self, target_name):
        start = time.time()
        full_frames = 0

        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            if self._raw_con_full():
                full_frames += 1

                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'ZFG hard-intro guard passed '
                        f'{self.ACTOR}->{target_name} '
                        f'{full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                    )
                    return True
            else:
                full_frames = 0

            self.sleep(self.POLL)
            self.task.next_frame()

        self.logger.warning(
            f'ZFG hard-intro guard failed '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _switch_to(self, target_name, expect_intro=None):
        target = self._find_target_char(target_name)

        if target is None:
            self.logger.error(
                f'ZFG {self.ACTOR}: target not found -> {target_name}'
            )
            return False

        if expect_intro is True:
            allowed = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

            if target_name != allowed:
                self.logger.error(
                    f'ZFG invalid special intro '
                    f'{self.ACTOR}->{target_name}; '
                    f'allowed={allowed}'
                )
                return False

            if not self._confirm_hard_intro_ready(target_name):
                return False

            has_intro = True

        elif expect_intro is False:
            if self._concerto_effectively_full():
                self.logger.warning(
                    f'ZFG block forced-normal switch '
                    f'{self.ACTOR}->{target_name}: concerto full'
                )
                return False
            has_intro = False

        else:
            has_intro = self._concerto_effectively_full()

        target.has_intro = has_intro
        target.has_sub_dps_intro = (
            has_intro and getattr(self, 'is_sub_dps', False)
        )

        start = time.time()
        last_send = 0.0

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.check_combat()

            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, -1

            if in_team and current_index == target.index:
                self.task.in_liberation = False
                target.is_current_char = True

                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(
                        now,
                        target.intro_motion_freeze_duration,
                        -100,
                    )
                    self.last_outro_time = now

                self.logger.info(
                    f'ZFG exact switch success '
                    f'{self.ACTOR}->{target_name} '
                    f'intro={has_intro}'
                )
                return True

            if (
                in_team
                and current_index == self.index
                and not target.wait_switch()
            ):
                now = time.time()

                if now - last_send >= self.SWITCH_RETRY_INTERVAL:
                    self.task.send_key(target.index + 1)
                    last_send = now

            self.sleep(self.SWITCH_RETRY_INTERVAL)
            self.task.next_frame()

        self.logger.error(
            f'ZFG exact switch timeout '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _clear_detour(self, state):
        for key in (
            'detour_active',
            'detour_actor',
            'detour_final_target',
            'detour_next_step',
            'detour_resume_step',
            'detour_resume_phase',
        ):
            state.pop(key, None)

    def _switch_route(
        self,
        state,
        planned_target,
        next_step,
        force_intro=False,
    ):
        """
        正常切人入口。

        若协奏满，但planned_target不是当前角色正确的特殊变奏目标：
        保存主轴step/phase -> 先让正确角色吃特殊变奏
        -> 再自然切planned_target -> 进入next_step。
        """

        if force_intro:
            if self._switch_to(planned_target, expect_intro=True):
                self._advance_step(state, next_step)
                return True
            return False

        full = self._concerto_effectively_full()
        special_target = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

        if (
            full
            and special_target
            and planned_target != special_target
        ):
            if planned_target == 'Phoebe' and state.get(self.PHOEBE_PREHOLD_E_KEY):
                self.logger.info(
                    f'ZFG Phoebe-E prehold PRESERVE across detour '
                    f'{self.ACTOR}->{special_target}->Phoebe'
                )
            resume_step = state.get('step')
            resume_phase = state.get('phase')

            self.logger.warning(
                f'ZFG intro detour required: '
                f'source={self.ACTOR} '
                f'planned={planned_target} '
                f'correct_intro={special_target} '
                f'resume={resume_step}/{resume_phase}'
            )

            if not self._switch_to(
                special_target,
                expect_intro=None,
            ):
                return False

            state['detour_active'] = True
            state['detour_actor'] = special_target
            state['detour_final_target'] = planned_target
            state['detour_next_step'] = next_step
            state['detour_resume_step'] = resume_step
            state['detour_resume_phase'] = resume_phase
            return True

        if self._switch_to(planned_target, expect_intro=None):
            self._advance_step(state, next_step)
            return True

        return False

    def _run_detour_if_needed(self, state):
        if not state.get('detour_active'):
            return False

        expected = state.get('detour_actor')

        if expected != self.ACTOR:
            self._recover_wrong_actor(state)
            return True

        final_target = state.get('detour_final_target')
        next_step = state.get('detour_next_step')
        resume_step = state.get('detour_resume_step')
        resume_phase = state.get('detour_resume_phase')

        self.logger.info(
            f'ZFG detour actor={self.ACTOR} '
            f'return={final_target} '
            f'resume={resume_step}/{resume_phase}'
        )

        if self._switch_to(final_target, expect_intro=None):
            self._clear_detour(state)
            self._advance_step(state, next_step)

        return True

    def _recover_wrong_actor(self, state):
        expected = self._expected_actor(state)

        if expected and expected != self.ACTOR:
            self.logger.warning(
                f'ZFG wrong actor: current={self.ACTOR} '
                f'step={state.get("step")} expected={expected}'
            )
            return self._switch_to(
                expected,
                expect_intro=None,
            )

        recovery_actor = self._route_broken_state_to_recovery(
            state,
            reason=f'unhandled-step:{state.get("step")}',
        )

        if recovery_actor != self.ACTOR:
            return self._switch_to(
                recovery_actor,
                expect_intro=None,
            )

        return False


    def on_combat_end(self, chars):
        self._clear_zfg_state()

        if hasattr(self.task, self.TEAM_SIGNATURE_KEY):
            delattr(self.task, self.TEAM_SIGNATURE_KEY)

        return super().on_combat_end(chars)


class Phoebe(_ZFGFSM, BuiltinPhoebe):
    ACTOR = 'Phoebe'


    CONFESSION_HOLD_TIMEOUT = 1.60

    CONFESSION_CORE_X0 = 1633
    CONFESSION_CORE_Y0 = 1996
    CONFESSION_CORE_X1 = 2160
    CONFESSION_CORE_Y1 = 2016

    CONFESSION_CORE_BLUE_HSV_LOWER = (95, 45, 90)
    CONFESSION_CORE_BLUE_HSV_UPPER = (150, 255, 255)

    CONFESSION_CORE_BLUE_STRONG_RATIO_MIN = 0.12
    CONFESSION_CORE_BLUE_WEAK_RATIO_MIN = 0.075
    CONFESSION_CORE_COLUMN_PIXEL_RATIO_MIN = 0.20
    CONFESSION_CORE_STRONG_ACTIVE_COLUMN_FRACTION_MIN = 0.20
    CONFESSION_CORE_WEAK_ACTIVE_COLUMN_FRACTION_MIN = 0.12

    CONFESSION_SEGMENT_CONFIRM_FRAMES = 2
    CONFESSION_STRONG_BLUE_CONFIRM_FRAMES = 3
    CONFESSION_RING_ARM_CONFIRM_FRAMES = 1
    CONFESSION_RING_FALL_CONFIRM_FRAMES = 2
    CONFESSION_RING_WEAK_BLUE_RECENCY = 0.40

    P2_CONFESSION_PRAYER_REFILL = 24.0
    P2_CONFESSION_AZ_THRESHOLD = 1.60   # 预计还差更多时间 -> 光主AZ一次
    P2_CONFESSION_A_WAIT_GAP = 0.18     # 差得不多 -> 菲比A一下再复查
    P2_CONFESSION_FAILED_PROBE_BACKOFF = 0.80
    P2_CONFESSION_E_READY_FRAMES = 2

    # P2时间更宽裕：不允许任何单一视觉信号单独授权告解R。
    P2_CONFESSION_ENTRY_SUPPORT_FRAMES = 2
    P2_CONFESSION_ENTRY_FALL_RECENCY = 0.50
    P2_CONFESSION_ENTRY_FALLBACK_RING_CLEAR_FRAMES = 2
    P2_CONFESSION_PRE_R_CONFIRM_FRAMES = 2
    P2_CONFESSION_PRE_R_TRANSITION_BACKED_FRAMES = 3
    P2_CONFESSION_PRE_R_TIMEOUT = 0.45
    P2_CONFESSION_PRE_R_MAX_FAILED_SLICES = 3

    THREE_A_GAP = 0.12
    P2_STAR_NOT_READY_CONFIRM_FRAMES = 3
    P2_STAR_CONFIRM_TIMEOUT = 0.75
    P2_FINAL_EMPTY_CONFIRM_FRAMES = 3
    P2_FINAL_EMPTY_TIMEOUT = 0.80

    CONCERTO_FILL_TIMEOUT = 9.0
    FULL_CON_TAIL = 0.20
    REQUIRED_E_TIMEOUT = 1.6
    REQUIRED_Q_TIMEOUT = 1.6

    P1_CONFESSION_R_READY_FRAMES = 2
    P1_CONFESSION_R_WAIT_SLICE = 0.80
    P1_CONFESSION_R_FAST_RETRY_POLL = 0.03
    P1_CONFESSION_R_FAST_RETRY_WINDOW = 0.55


    def f_break(
        self,
        check_f_on_switch=False,
        force=False,
    ):
        if self._zfg_team_matches():
            return False
        return super().f_break(
            check_f_on_switch=check_f_on_switch,
            force=force,
        )

    def do_perform(self):
        if not self._zfg_team_matches():
            return super().do_perform()

        if (
            getattr(self, 'team', 0) != 1
            or getattr(self, 'attribute', 0) != 2
        ):
            self.decide_teammate()

        state = self._zfg_state()

        if self._run_detour_if_needed(state):
            return

        step = state.get('step')
        self.logger.info(
            f'ZFG V3.0 Phoebe step={step} phase={state.get("phase")} '
            f'intro={self.has_intro} forte={self.is_forte_full()} '
            f'con={self._read_concerto():.3f}'
        )

        if step == self.STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER:
            return self._p1_confession_r_eq_to_rover(state)

        if step == self.STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI:
            return self._p1_3a_star_save_fill_to_zani(state)

        if step == self.STEP_P1_PHOEBE_STAR_TO_ZANI:
            return self._single_star_to_target(
                state,
                target='Zani',
                next_step=self.STEP_P1_ZANI_N2_TO_ROVER_R,
                tag='P1-N1-insert',
            )

        if step == self.STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI:
            return self._confession_r_to_target(
                state,
                target='Zani',
                next_step=self.STEP_P1_ZANI_N4_R2_E_TO_PHOEBE,
                tag='P1-before-N4',
            )

        if step == self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI:
            return self._p2_double_star_fill_to_zani(state)

        if step == self.STEP_P2_PHOEBE_CONFESSION_CHECK:
            return self._p2_confession_check(state)

        if step == self.STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI:
            return self._p2_confession_r_to_zani(state)

        if step == self.STEP_RECOVER_P2_PHOEBE:
            self.logger.warning(
                'ZFG V3.0 RECOVER_P2_PHOEBE '
                '-> P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI'
            )
            self._advance_step(
                state,
                self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI,
            )
            return

        return self._recover_wrong_actor(state)


    def _read_confession_forte_segments(self):
        """读取菲比告解形态的两格蓝色特殊能量。

        继续复用OK-WW原版Phoebe.judge_forte()：
        attribute=2时会在血条上方forte区域按两格统计蓝色能量。
        V3.0把它作为辅助证据；新增主证据是整个forte条的蓝色像素占比。
        """
        if self.attribute != 2:
            self.attribute = 2
        try:
            segments = int(self.judge_forte())
        except Exception as exc:
            self.logger.debug(
                f'ZFG V3.0 Phoebe confession forte segment read failed: {exc}'
            )
            return 0
        return max(0, min(2, segments))

    def _read_confession_blue_bar_evidence(self):
        try:
            box = self.task.box_of_screen_scaled(
                3840, 2160,
                self.CONFESSION_CORE_X0, self.CONFESSION_CORE_Y0,
                self.CONFESSION_CORE_X1, self.CONFESSION_CORE_Y1,
                name='phoebe_confession_core_blue_bar', hcenter=True,
            )
            cropped = box.crop_frame(self.task.frame)
            if cropped is None or getattr(cropped, 'size', 0) == 0:
                return False, False, 0.0, 0, 0, 0

            hsv = cv2.cvtColor(cropped, cv2.COLOR_BGR2HSV)
            lower = np.array(self.CONFESSION_CORE_BLUE_HSV_LOWER, dtype=np.uint8)
            upper = np.array(self.CONFESSION_CORE_BLUE_HSV_UPPER, dtype=np.uint8)
            mask = cv2.inRange(hsv, lower, upper)

            ratio = float(np.count_nonzero(mask)) / float(mask.size)
            column_ratio = np.count_nonzero(mask, axis=0) / float(mask.shape[0])
            active_cols = int(np.count_nonzero(
                column_ratio >= self.CONFESSION_CORE_COLUMN_PIXEL_RATIO_MIN
            ))
            width = int(mask.shape[1])
            weak_required = max(6, int(round(
                width * self.CONFESSION_CORE_WEAK_ACTIVE_COLUMN_FRACTION_MIN
            )))
            strong_required = max(6, int(round(
                width * self.CONFESSION_CORE_STRONG_ACTIVE_COLUMN_FRACTION_MIN
            )))

            weak_ok = (
                ratio >= self.CONFESSION_CORE_BLUE_WEAK_RATIO_MIN
                and active_cols >= weak_required
            )
            strong_ok = (
                ratio >= self.CONFESSION_CORE_BLUE_STRONG_RATIO_MIN
                and active_cols >= strong_required
            )

            box.confidence = ratio
            try:
                self.task.draw_boxes('phoebe_confession_core_blue_bar', box)
            except Exception:
                pass

            return (
                bool(strong_ok), bool(weak_ok), ratio, active_cols,
                weak_required, strong_required,
            )
        except Exception as exc:
            self.logger.debug(
                f'ZFG V3.0 Phoebe confession blue-bar read failed: {exc}'
            )
            return False, False, 0.0, 0, 0, 0

    def _read_confession_ring_visible(self):
        checker = getattr(self, 'confession_ready', None)
        if not callable(checker):
            return False
        try:
            return bool(checker())
        except Exception as exc:
            self.logger.debug(
                f'ZFG V3.0 Phoebe confession ring read failed: {exc}'
            )
            return False

    def _finalize_confession_state_success(
        self, state, key, via, segments, strong_blue, weak_blue,
        blue_ratio, active_cols, weak_required, strong_required,
        ring_armed=False, ring_fall=False,
    ):
        self.task.send_key_up(key)
        state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
        state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)
        state.pop(self.P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY, None)

        state[self.PHOEBE_LAST_CONFESSION_TIME_KEY] = time.time()
        self.logger.info(
            f'ZFG V3.0 Phoebe CONFESSION STATE CONFIRMED via={via} '
            f'segments={segments}/2 strong_blue={strong_blue} weak_blue={weak_blue} '
            f'ratio={blue_ratio:.3f} active_cols={active_cols} '
            f'weak_need={weak_required} strong_need={strong_required} '
            f'ring_armed={ring_armed} ring_fall={ring_fall} -> release held E'
        )

        self.star_available = True
        self.reset_action(new_rotation=False)
        self._refill_form_charges()
        self.state['enter_status'] += 1
        return True

    def _hold_e_until_confession_state(self):
        if self.attribute != 2:
            self.attribute = 2

        state = self._zfg_state()
        key = self.get_resonance_key()
        start = time.time()
        inherited_prehold = bool(state.get(self.PHOEBE_PREHOLD_E_KEY))

        segment_frames = 0
        strong_blue_frames = 0
        ring_visible_frames = 0
        ring_clear_frames = 0
        ring_armed = False
        ring_fall_time = -100.0
        last_weak_blue_time = -100.0
        last_fusion_log = -100.0

        self.task.send_key_down(key)
        self.logger.info(
            'ZFG V3.0 Phoebe confession hold START visual-fusion '
            f'inherited_prehold={inherited_prehold}'
        )

        last = {
            'segments': 0, 'strong': False, 'weak': False, 'ratio': 0.0,
            'active': 0, 'weak_need': 0, 'strong_need': 0,
            'ring': False,
        }

        try:
            while time.time() - start < self.CONFESSION_HOLD_TIMEOUT:
                self.task.next_frame()
                now = time.time()

                segments = self._read_confession_forte_segments()
                (
                    strong_blue, weak_blue, blue_ratio, active_cols,
                    weak_required, strong_required,
                ) = self._read_confession_blue_bar_evidence()
                ring_visible = self._read_confession_ring_visible()

                last.update(
                    segments=segments, strong=strong_blue, weak=weak_blue,
                    ratio=blue_ratio, active=active_cols,
                    weak_need=weak_required, strong_need=strong_required,
                    ring=ring_visible,
                )

                if segments >= 1:
                    segment_frames += 1
                else:
                    segment_frames = 0
                if segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES:
                    return self._finalize_confession_state_success(
                        state, key, 'FORTE_SEGMENTS', segments,
                        strong_blue, weak_blue, blue_ratio, active_cols,
                        weak_required, strong_required, ring_armed, False,
                    )

                if strong_blue:
                    strong_blue_frames += 1
                else:
                    strong_blue_frames = 0
                if strong_blue_frames >= self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES:
                    return self._finalize_confession_state_success(
                        state, key, 'STRONG_BLUE_BAR', segments,
                        strong_blue, weak_blue, blue_ratio, active_cols,
                        weak_required, strong_required, ring_armed, False,
                    )

                if weak_blue:
                    last_weak_blue_time = now

                if not ring_armed:
                    if ring_visible:
                        ring_visible_frames += 1
                        if ring_visible_frames >= self.CONFESSION_RING_ARM_CONFIRM_FRAMES:
                            ring_armed = True
                            ring_clear_frames = 0
                            self.logger.info(
                                'ZFG V3.0 Phoebe confession ring ARMED (auxiliary)'
                            )
                    else:
                        ring_visible_frames = 0
                else:
                    if ring_visible:
                        ring_clear_frames = 0
                    else:
                        ring_clear_frames += 1
                        if ring_clear_frames >= self.CONFESSION_RING_FALL_CONFIRM_FRAMES:
                            ring_fall_time = now
                            ring_armed = False
                            ring_visible_frames = 0
                            ring_clear_frames = 0
                            self.logger.info(
                                'ZFG V3.0 Phoebe confession ring FALL (auxiliary)'
                            )

                ring_fall_recent = (
                    now - ring_fall_time <= self.CONFESSION_RING_WEAK_BLUE_RECENCY
                )
                weak_blue_recent = (
                    now - last_weak_blue_time <= self.CONFESSION_RING_WEAK_BLUE_RECENCY
                )
                if ring_fall_recent and weak_blue_recent:
                    return self._finalize_confession_state_success(
                        state, key, 'RING_FALL_PLUS_WEAK_BLUE', segments,
                        strong_blue, weak_blue, blue_ratio, active_cols,
                        weak_required, strong_required, True, True,
                    )

                if (
                    segments >= 1 or strong_blue or weak_blue or ring_visible or ring_fall_recent
                ) and now - last_fusion_log >= 0.12:
                    self.logger.info(
                        f'ZFG V3.0 Phoebe confession fusion sample '
                        f'seg={segments}/2 seg_frames={segment_frames}/'
                        f'{self.CONFESSION_SEGMENT_CONFIRM_FRAMES} '
                        f'strong={strong_blue} strong_frames={strong_blue_frames}/'
                        f'{self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES} '
                        f'weak={weak_blue} ratio={blue_ratio:.3f} '
                        f'cols={active_cols} weak_need={weak_required} strong_need={strong_required} '
                        f'ring={ring_visible} armed={ring_armed} fall_recent={ring_fall_recent}'
                    )
                    last_fusion_log = now

                self.sleep(0.01)
        finally:
            self.task.send_key_up(key)
            state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
            state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)

        self.logger.warning(
            f'ZFG V3.0 Phoebe confession visual-fusion timeout '
            f'segments={last["segments"]}/2 strong={last["strong"]} weak={last["weak"]} '
            f'ratio={last["ratio"]:.3f} active_cols={last["active"]} '
            f'weak_need={last["weak_need"]} strong_need={last["strong_need"]} '
            f'ring={last["ring"]} inherited_prehold={inherited_prehold}'
        )
        return False

    def _clear_p2_confession_proof(self, state):
        for key in (
            'p2_confession_entry_verified',
            'p2_confession_entry_transition',
            'p2_confession_entry_via',
            'p2_confession_pre_r_failed_slices',
        ):
            state.pop(key, None)

    def _hold_e_until_p2_confession_strict(self):
        """P2严格入口门：先证明进入告解，再允许进入R等待阶段。

        正常路径：E圈 ARMED->FALL +（两格能量 或 强蓝条）的稳定当前证据。
        转换漏帧兜底：两格能量 + 强蓝条 + E圈当前消失同时稳定。
        弱蓝条和R READY只做辅助/日志，不能单独放行。
        """
        if self.attribute != 2:
            self.attribute = 2

        state = self._zfg_state()
        self._clear_p2_confession_proof(state)
        key = self.get_resonance_key()
        start = time.time()
        inherited_prehold = bool(state.get(self.PHOEBE_PREHOLD_E_KEY))

        segment_frames = 0
        strong_blue_frames = 0
        ring_visible_frames = 0
        ring_clear_frames = 0
        ring_absent_frames = 0
        ring_armed = False
        ring_fall_time = -100.0
        transition_support_frames = 0
        fallback_joint_frames = 0
        last_log = -100.0

        self.task.send_key_down(key)
        self.logger.info(
            'ZFG V3.0 P2 confession STRICT hold START '
            f'inherited_prehold={inherited_prehold}'
        )

        last = {
            'segments': 0, 'strong': False, 'weak': False, 'ratio': 0.0,
            'active': 0, 'ring': False,
        }

        try:
            while time.time() - start < self.CONFESSION_HOLD_TIMEOUT:
                self.task.next_frame()
                now = time.time()

                segments = self._read_confession_forte_segments()
                (
                    strong_blue, weak_blue, blue_ratio, active_cols,
                    weak_required, strong_required,
                ) = self._read_confession_blue_bar_evidence()
                ring_visible = self._read_confession_ring_visible()

                last.update(
                    segments=segments, strong=strong_blue, weak=weak_blue,
                    ratio=blue_ratio, active=active_cols, ring=ring_visible,
                )

                segment_frames = segment_frames + 1 if segments >= 1 else 0
                strong_blue_frames = strong_blue_frames + 1 if strong_blue else 0
                ring_absent_frames = 0 if ring_visible else ring_absent_frames + 1

                if not ring_armed:
                    if ring_visible:
                        ring_visible_frames += 1
                        if ring_visible_frames >= self.CONFESSION_RING_ARM_CONFIRM_FRAMES:
                            ring_armed = True
                            ring_clear_frames = 0
                            self.logger.info('ZFG V3.0 P2 confession ring ARMED')
                    else:
                        ring_visible_frames = 0
                else:
                    if ring_visible:
                        ring_clear_frames = 0
                    else:
                        ring_clear_frames += 1
                        if ring_clear_frames >= self.CONFESSION_RING_FALL_CONFIRM_FRAMES:
                            ring_fall_time = now
                            ring_armed = False
                            ring_visible_frames = 0
                            ring_clear_frames = 0
                            self.logger.info('ZFG V3.0 P2 confession ring FALL')

                ring_fall_recent = (
                    now - ring_fall_time <= self.P2_CONFESSION_ENTRY_FALL_RECENCY
                )
                current_support = (
                    segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES
                    or strong_blue_frames >= self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES
                )
                if ring_fall_recent and current_support:
                    transition_support_frames += 1
                else:
                    transition_support_frames = 0

                if transition_support_frames >= self.P2_CONFESSION_ENTRY_SUPPORT_FRAMES:
                    if (
                        segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES
                        and strong_blue_frames >= self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES
                    ):
                        via = 'P2_RING_FALL_PLUS_SEGMENT_AND_STRONG_BLUE'
                    elif segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES:
                        via = 'P2_RING_FALL_PLUS_SEGMENTS'
                    else:
                        via = 'P2_RING_FALL_PLUS_STRONG_BLUE'

                    state['p2_confession_entry_verified'] = True
                    state['p2_confession_entry_transition'] = True
                    state['p2_confession_entry_via'] = via
                    state['p2_confession_pre_r_failed_slices'] = 0
                    return self._finalize_confession_state_success(
                        state, key, via, segments,
                        strong_blue, weak_blue, blue_ratio, active_cols,
                        weak_required, strong_required, True, True,
                    )

                fallback_ok = (
                    segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES
                    and strong_blue_frames >= self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES
                    and ring_absent_frames >= self.P2_CONFESSION_ENTRY_FALLBACK_RING_CLEAR_FRAMES
                )
                fallback_joint_frames = fallback_joint_frames + 1 if fallback_ok else 0

                if fallback_joint_frames >= self.P2_CONFESSION_ENTRY_SUPPORT_FRAMES:
                    via = 'P2_SEGMENT_AND_STRONG_BLUE_RING_CLEAR_FALLBACK'
                    state['p2_confession_entry_verified'] = True
                    state['p2_confession_entry_transition'] = False
                    state['p2_confession_entry_via'] = via
                    state['p2_confession_pre_r_failed_slices'] = 0
                    return self._finalize_confession_state_success(
                        state, key, via, segments,
                        strong_blue, weak_blue, blue_ratio, active_cols,
                        weak_required, strong_required, False, False,
                    )

                if (
                    segments >= 1 or strong_blue or weak_blue
                    or ring_visible or ring_fall_recent
                ) and now - last_log >= 0.12:
                    self.logger.info(
                        f'ZFG V3.0 P2 confession STRICT sample '
                        f'seg={segments}/2 seg_frames={segment_frames}/'
                        f'{self.CONFESSION_SEGMENT_CONFIRM_FRAMES} '
                        f'strong={strong_blue} strong_frames={strong_blue_frames}/'
                        f'{self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES} '
                        f'weak={weak_blue} ratio={blue_ratio:.3f} cols={active_cols} '
                        f'ring={ring_visible} armed={ring_armed} fall_recent={ring_fall_recent} '
                        f'transition_support={transition_support_frames}/'
                        f'{self.P2_CONFESSION_ENTRY_SUPPORT_FRAMES} '
                        f'fallback_joint={fallback_joint_frames}/'
                        f'{self.P2_CONFESSION_ENTRY_SUPPORT_FRAMES}'
                    )
                    last_log = now

                self.sleep(0.01)
        finally:
            self.task.send_key_up(key)
            state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
            state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)

        self._clear_p2_confession_proof(state)
        self.logger.warning(
            f'ZFG V3.0 P2 confession STRICT timeout '
            f'segments={last["segments"]}/2 strong={last["strong"]} '
            f'weak={last["weak"]} ratio={last["ratio"]:.3f} '
            f'active_cols={last["active"]} ring={last["ring"]}'
        )
        return False

    def _confirm_p2_confession_current_before_r(self, state, tag):
        """P2第二道硬门：R真正输入前再次确认当前仍在告解。"""
        if not state.get('p2_confession_entry_verified'):
            self.logger.warning(
                f'ZFG V3.0 Phoebe {tag}: pre-R confession gate missing entry proof'
            )
            return False

        transition_verified = bool(state.get('p2_confession_entry_transition'))
        start = time.time()
        strict_frames = 0
        transition_backed_frames = 0
        last_log = -100.0

        while time.time() - start < self.P2_CONFESSION_PRE_R_TIMEOUT:
            self.task.next_frame()

            segments = self._read_confession_forte_segments()
            (
                strong_blue, weak_blue, blue_ratio, active_cols,
                weak_required, strong_required,
            ) = self._read_confession_blue_bar_evidence()
            ring_visible = self._read_confession_ring_visible()

            strict_frames = strict_frames + 1 if (segments >= 1 and strong_blue) else 0
            transition_backed_ok = (
                transition_verified
                and not ring_visible
                and (segments >= 1 or strong_blue)
            )
            transition_backed_frames = (
                transition_backed_frames + 1 if transition_backed_ok else 0
            )

            if strict_frames >= self.P2_CONFESSION_PRE_R_CONFIRM_FRAMES:
                self.logger.info(
                    f'ZFG V3.0 Phoebe {tag}: P2 PRE-R CONFESSION CONFIRMED '
                    f'via=SEGMENTS_AND_STRONG_BLUE frames={strict_frames} '
                    f'seg={segments}/2 ratio={blue_ratio:.3f} '
                    f'cols={active_cols} ring={ring_visible}'
                )
                return True

            if (
                transition_backed_frames
                >= self.P2_CONFESSION_PRE_R_TRANSITION_BACKED_FRAMES
            ):
                self.logger.info(
                    f'ZFG V3.0 Phoebe {tag}: P2 PRE-R CONFESSION CONFIRMED '
                    f'via=TRANSITION_BACKED_CURRENT_SUPPORT '
                    f'frames={transition_backed_frames} seg={segments}/2 '
                    f'strong={strong_blue} weak={weak_blue} '
                    f'ratio={blue_ratio:.3f} cols={active_cols} ring={ring_visible}'
                )
                return True

            now = time.time()
            if (segments >= 1 or strong_blue or weak_blue or ring_visible) and now - last_log >= 0.12:
                self.logger.info(
                    f'ZFG V3.0 Phoebe {tag}: P2 pre-R sample '
                    f'seg={segments}/2 strong={strong_blue} weak={weak_blue} '
                    f'ratio={blue_ratio:.3f} cols={active_cols} ring={ring_visible} '
                    f'transition_verified={transition_verified} '
                    f'strict={strict_frames}/{self.P2_CONFESSION_PRE_R_CONFIRM_FRAMES} '
                    f'transition_backed={transition_backed_frames}/'
                    f'{self.P2_CONFESSION_PRE_R_TRANSITION_BACKED_FRAMES}'
                )
                last_log = now

            self.sleep(0.02)

        self.logger.warning(
            f'ZFG V3.0 Phoebe {tag}: P2 PRE-R confession current-state '
            'NOT confirmed -> R BLOCKED'
        )
        return False


    def _three_a(self, tag):
        """普通3A：只负责把A1/A2/A3完整打出，不主动把下一发重击消费掉。

        这个版本专门用于“3A后要存Z”的阶段。因为第二组3A的目的就是让
        Starflash进入可用状态并保留下来，所以这里绝不能偷偷长按A。
        """
        self.logger.info(f'ZFG V3.0 Phoebe {tag}: AAA start')
        for index in range(3):
            self.task.click()
            self.logger.debug(f'ZFG V3.0 Phoebe {tag}: A{index + 1} sent')
            self.sleep(self.THREE_A_GAP)
            self.task.next_frame()
        self.logger.info(f'ZFG V3.0 Phoebe {tag}: AAA end')


    def _cast_control_e_required(self, tag):
        start = time.time()

        while time.time() - start < self.REQUIRED_E_TIMEOUT:
            self.task.next_frame()

            if self.resonance_available():
                clicked, duration, animated = self.click_resonance(
                    send_click=False,
                    time_out=0.8,
                    click_f=False,
                )
                if clicked:
                    self.logger.info(
                        f'ZFG V3.0 Phoebe {tag}: control E confirmed '
                        f'duration={duration:.2f} animated={animated}'
                    )
                    return True

            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V3.0 Phoebe {tag}: control E not confirmed'
        )
        return False

    def _cast_echo_required(self, tag):
        start = time.time()

        while time.time() - start < self.REQUIRED_Q_TIMEOUT:
            self.task.next_frame()

            if self.echo_available():
                base_result = self.click_echo(time_out=0.8)
                self.task.next_frame()
                consumed = not self.echo_available()

                if base_result or consumed:
                    self.logger.info(
                        f'ZFG V3.0 Phoebe {tag}: Q confirmed '
                        f'base_result={bool(base_result)} consumed={consumed}'
                    )
                    return True

            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V3.0 Phoebe {tag}: Q not confirmed'
        )
        return False

    def _wait_p1_confession_r_ready(self, tag):
        """等待P1告解后的菲比R真正READY。

        设计目的：
        - 旧版会在R图标尚未亮时直接调用可靠R输入，产生 no-effect + 长确认等待；
        - V3.0改为“READY是输入前置条件”，不再拿失败输入试CD；
        - 连续2帧READY才通过，过滤单帧UI抖动；
        - 一个slice没等到就返回False并保留r_cancel phase，下轮继续等，不推进STEP。
        """
        start = time.time()
        stable = 0
        first_log = True

        while time.time() - start < self.P1_CONFESSION_R_WAIT_SLICE:
            self.task.next_frame()
            ready = bool(self.liberation_available())

            if ready:
                stable += 1
                if stable >= self.P1_CONFESSION_R_READY_FRAMES:
                    self.logger.info(
                        f'ZFG V3.0 Phoebe {tag}: R READY stable '
                        f'{stable}/{self.P1_CONFESSION_R_READY_FRAMES} -> allow input'
                    )
                    return True
            else:
                stable = 0
                if first_log:
                    self.logger.info(
                        f'ZFG V3.0 Phoebe {tag}: R not ready -> WAIT, no blind input'
                    )
                    first_log = False

            self.sleep(self.POLL)

        self.logger.info(
            f'ZFG V3.0 Phoebe {tag}: R still cooling -> keep r_cancel phase'
        )
        return False

    def _record_phoebe_r_shared_time(self, input_time, tag):
        state = self._zfg_state()
        state[self.PHOEBE_LAST_R_CAST_TIME_KEY] = float(input_time)
        self.logger.info(
            f'ZFG V3.0 Phoebe {tag}: R cooldown timestamp armed at input'
        )

    def _cast_confession_r_required(self, tag):
        """通用可靠R：保留原版扩展确认；成功后记录共享R起始时刻供P2算25s CD。"""
        input_time = time.time()
        if not self._click_liberation_reliable(
            send_click=False,
            tag=f' {tag}',
        ):
            self.logger.warning(
                f'ZFG V3.0 Phoebe {tag}: R failed -> keep phase'
            )
            return False

        self._record_phoebe_r_shared_time(input_time, tag)
        self._record_liberation_cast()
        self.logger.info(
            f'ZFG V3.0 Phoebe {tag}: confession R confirmed (NO-A R input)'
        )
        return True

    def _cast_p1_confession_r_fast_required(self, tag):
        """P1四终夜专用：R第一次no-effect后不再固定等1s，图标重新READY就立刻retry。"""
        for attempt in (1, 2):
            if attempt > 1:
                start = time.time()
                stable = 0
                while time.time() - start < self.P1_CONFESSION_R_FAST_RETRY_WINDOW:
                    self.task.next_frame()
                    if self.liberation_available():
                        stable += 1
                        if stable >= 1:
                            self.logger.info(
                                f'ZFG V3.0 Phoebe {tag}: R re-READY -> FAST retry now'
                            )
                            break
                    else:
                        stable = 0
                    self.sleep(self.P1_CONFESSION_R_FAST_RETRY_POLL)
                else:
                    self.logger.warning(
                        f'ZFG V3.0 Phoebe {tag}: R fast-retry window expired -> keep phase'
                    )
                    return False

            if not self.liberation_available():
                self.logger.info(
                    f'ZFG V3.0 Phoebe {tag}: R not READY at attempt={attempt} -> keep phase'
                )
                return False

            input_time = time.time()
            self.logger.info(
                f'ZFG V3.0 Phoebe {tag}: R FAST input attempt={attempt}'
            )
            if self.click_liberation(
                send_click=False, wait_if_cd_ready=0, click_f=False
            ):
                self.state['liber_no_effect_at'] = 0
                self._record_phoebe_r_shared_time(input_time, tag)
                self._record_liberation_cast()
                self.logger.info(
                    f'ZFG V3.0 Phoebe {tag}: confession R FAST confirmed attempt={attempt}'
                )
                return True

            self.logger.warning(
                f'ZFG V3.0 Phoebe {tag}: R FAST no-effect attempt={attempt}; '
                'NO fixed 1.0s extended wait'
            )

        self._mark_liber_no_effect()
        return False

    def _cast_echo_soft(self, tag):
        """脱手Q机会动作：有就放，没有直接通过。"""
        if not self.echo_available():
            self.logger.info(f'ZFG V3.0 Phoebe {tag}: soft Q skip cooldown')
            return False
        result = self.click_echo(time_out=0)
        self.logger.info(f'ZFG V3.0 Phoebe {tag}: soft Q result={result}')
        return bool(result)

    def _charge_starflash_without_recover_e(self, timeout=5.0):
        """P2双Z保护：只用A充重击，不允许自动长E恢复，保留E给后续告解。"""
        start = time.time()
        attacks = 0
        while not self.is_forte_full() and time.time() - start < timeout:
            self.task.click()
            attacks += 1
            self.sleep(0.05)
            self.task.next_frame()
        self.logger.info(
            f'ZFG V3.0 Phoebe no-recover star charge end '
            f'ready={bool(self.is_forte_full())} attacks={attacks}'
        )
        return bool(self.is_forte_full())

    def _cast_star_required(self, tag, allow_recover_e=True):
        if not self.is_forte_full():
            if allow_recover_e:
                self._charge_starflash_until_full(
                    finish_with_right_click=False,
                )
            else:
                self._charge_starflash_without_recover_e()

        if not self.is_forte_full():
            self.logger.warning(
                f'ZFG V3.0 Phoebe {tag}: Starflash not ready'
            )
            return False

        self.starflash_combo()
        self.task.next_frame()

        if self.is_forte_full():
            self.logger.warning(
                f'ZFG V3.0 Phoebe {tag}: Starflash not consumed'
            )
            return False

        self.logger.info(
            f'ZFG V3.0 Phoebe {tag}: Starflash consumed'
        )
        return True

    def heavy_attack_ready(self):
        """兼容不同OK-WW版本：菲比特殊Z可用性统一映射到forte满判定。"""
        try:
            return bool(self.is_forte_full())
        except Exception:
            return False

    def _phoebe_star_ready(self):
        return self.heavy_attack_ready()

    def _read_p2_blue_forte_cells(self):
        """读取P2双Z阶段的两格蓝色特殊能量，识别异常时保守按2格处理。"""
        if self.attribute != 2:
            self.attribute = 2
        try:
            return max(0, min(2, int(self.judge_forte())))
        except Exception as exc:
            self.logger.warning(
                f'ZFG V3.0 Phoebe P2 blue-forte read failed: {exc}'
            )
            return 2

    def _confirm_p2_star_not_ready(self, before_count, tag):
        start = time.time()
        stable_not_ready = 0
        while time.time() - start < self.P2_STAR_CONFIRM_TIMEOUT:
            self.task.next_frame()
            ready = bool(self._phoebe_star_ready())
            try:
                after_count = int(self.state.get('starflash_combo', 0))
            except Exception:
                after_count = before_count
            count_advanced = after_count > before_count
            stable_not_ready = 0 if ready else stable_not_ready + 1
            if count_advanced and stable_not_ready >= 2:
                self.logger.info(
                    f'ZFG V3.0 Phoebe {tag}: Z VERIFIED counter={before_count}->{after_count} '
                    f'not-ready={stable_not_ready}'
                )
                return True
            if stable_not_ready >= self.P2_STAR_NOT_READY_CONFIRM_FRAMES:
                self.logger.info(
                    f'ZFG V3.0 Phoebe {tag}: Z VERIFIED by READY->stable NOT READY '
                    f'counter={before_count}->{after_count}'
                )
                return True
            self.sleep(0.04)
        self.logger.warning(f'ZFG V3.0 Phoebe {tag}: special Z still/again ready -> retry same phase')
        return False

    def _cast_p2_star_with_energy_guard(self, tag, target_max=None):
        """P2单发Z：READY->稳定NOT READY为主证据，原版计数为辅助。"""
        if not self._phoebe_star_ready():
            self._charge_starflash_without_recover_e()
        if not self._phoebe_star_ready():
            self.logger.warning(f'ZFG V3.0 Phoebe {tag}: Starflash not ready -> keep same phase')
            return False
        try:
            before_count = int(self.state.get('starflash_combo', 0))
        except Exception:
            before_count = 0
        self.logger.info(f'ZFG V3.0 Phoebe {tag}: special Z READY counter={before_count}')
        self.starflash_combo()
        return self._confirm_p2_star_not_ready(before_count, tag)


    def _confirm_p2_blue_forte_empty(self, tag='P2 double-star final'):
        start = time.time()
        stable = 0
        last = None
        while time.time() - start < self.P2_FINAL_EMPTY_TIMEOUT:
            self.task.next_frame()
            last = self._read_p2_blue_forte_cells()
            if last == 0:
                stable += 1
                if stable >= self.P2_FINAL_EMPTY_CONFIRM_FRAMES:
                    self.logger.info(
                        f'ZFG V3.0 Phoebe {tag}: FINAL BLUE-FORTE EMPTY stable={stable}'
                    )
                    return True
            else:
                stable = 0
            self.sleep(0.04)
        self.logger.warning(
            f'ZFG V3.0 Phoebe {tag}: blue forte not empty last={last}/2 -> need another Z'
        )
        return False

    def _fill_concerto_and_intro_zani(
        self,
        state,
        next_step,
        require_saved_star,
        tag,
    ):
        phase = state.get('phase')

        if phase == 'fill_con':
            ready = self._attack_until_con(
                self.CONCERTO_FILL_TIMEOUT,
                check_liber=False,
                require_forte=require_saved_star,
            )

            if ready is None:
                return False

            if not ready:
                self.logger.warning(
                    f'ZFG V3.0 Phoebe {tag}: concerto fill timeout'
                )
                return False

            if require_saved_star and not self.is_forte_full():
                self.logger.warning(
                    f'ZFG V3.0 Phoebe {tag}: saved Starflash lost'
                )
                state['phase'] = 'save_star'
                return False

            if not self._raw_con_full():
                return False

            state['phase'] = 'full_tail'
            phase = 'full_tail'

        if phase == 'full_tail':
            self.continues_normal_attack(self.FULL_CON_TAIL)
            self.task.next_frame()

            if not self._raw_con_full():
                state['phase'] = 'fill_con'
                return False

            self.logger.info(
                f'ZFG V3.0 Phoebe {tag}: '
                'FULL concerto + 0.20s tail confirmed'
            )
            state['phase'] = 'switch_zani'
            phase = 'switch_zani'

        if phase == 'switch_zani':
            if not self._raw_con_full():
                state['phase'] = 'fill_con'
                return False

            switched = self._switch_route(
                state,
                'Zani',
                next_step,
                force_intro=True,
            )
            if switched:
                self.first_rotation_done = True
            return switched

        return False


    def _p1_confession_r_eq_to_rover(self, state):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P1 confession entry')
            state['phase'] = 'confession'
            phase = 'confession'

        if phase == 'confession':
            if (
                not state.get(self.PHOEBE_PREHOLD_E_KEY)
                and not self.resonance_available()
            ):
                self.sleep(self.POLL)
                self.task.next_frame()
                return

            if not self._hold_e_until_confession_state():
                return

            state['phase'] = 'r_cancel'
            phase = 'r_cancel'

        if phase == 'r_cancel':
            if not self._cast_confession_r_required(
                'P1 confession-cancel',
            ):
                return

            state['phase'] = 'control_e'
            phase = 'control_e'

        if phase == 'control_e':
            if not self._cast_control_e_required('P1 after-R'):
                return
            state['phase'] = 'q'
            phase = 'q'

        if phase == 'q':
            if not self._cast_echo_required('P1 after-R'):
                return
            state['phase'] = 'switch_rover'
            phase = 'switch_rover'

        if phase == 'switch_rover':
            self._switch_route(
                state,
                'Rover',
                self.STEP_P1_ROVER_EQR_TO_PHOEBE,
            )


    def _p1_3a_star_save_fill_to_zani(self, state):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P1 3A entry')
            state['phase'] = 'aaa_star'
            phase = 'aaa_star'

        if phase == 'aaa_star':
            self._three_a('P1 first')
            state['phase'] = 'star1'
            phase = 'star1'

        if phase == 'star1':
            if not self._cast_star_required('P1 first'):
                return
            state['phase'] = 'aaa_save'
            phase = 'aaa_save'

        if phase == 'aaa_save':
            self._three_a('P1 save')
            state['phase'] = 'save_star'
            phase = 'save_star'

        if phase == 'save_star':
            if not self.is_forte_full():
                self._charge_starflash_until_full(
                    finish_with_right_click=False,
                )

            if not self.is_forte_full():
                return

            self.logger.info(
                'ZFG V3.0 Phoebe P1 saved Starflash READY; DO NOT CAST'
            )
            state['phase'] = 'fill_con'
            phase = 'fill_con'

        if phase in ('fill_con', 'full_tail', 'switch_zani'):
            self._fill_concerto_and_intro_zani(
                state,
                self.STEP_P1_ZANI_EFORTE_PREP,
                require_saved_star=True,
                tag='P1 setup',
            )


    def _single_star_to_target(
        self,
        state,
        target,
        next_step,
        tag,
    ):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded(tag)
            state['phase'] = 'star'
            phase = 'star'

        if phase == 'star':
            if not self._cast_star_required(tag):
                return

            if tag == 'P1-N1-insert':
                state[self.P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY] = True
                self.logger.info(
                    'ZFG V3.0 Phoebe P1-N1-insert: forte expected EMPTY armed '
                    'for legacy compatibility; V3.0 current-state confession check no longer needs transition history'
                )

            state['phase'] = 'switch'
            phase = 'switch'

        if phase == 'switch':
            self._switch_route(
                state,
                target,
                next_step,
            )


    def _p2_confession_remaining(self, state):
        """Prayer理论24s剩余；只用于调度，不直接宣告告解成功。"""
        last = state.get(self.PHOEBE_LAST_CONFESSION_TIME_KEY)
        if not isinstance(last, (int, float)) or last <= 0:
            return None, None
        elapsed = max(0.0, time.time() - last)
        remaining = max(0.0, self.P2_CONFESSION_PRAYER_REFILL - elapsed)
        return elapsed, remaining

    def _p2_phoebe_r_remaining(self, state):
        """按上一次真实R输入时刻，以freeze-aware计时估算25s RCD。"""
        last = state.get(self.PHOEBE_LAST_R_CAST_TIME_KEY)
        if not isinstance(last, (int, float)) or last <= 0:
            return 0.0 if self.liberation_available() else None
        elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(last)))
        return max(0.0, self.PHOEBE_R_COOLDOWN - elapsed)

    def _p2_r2_fill_room(self, state):
        """还能拿多少秒去光主填轴，同时保证赞妮R2尾端留6s保护。"""
        start = float(state.get('zani_r1_timer_start', 0) or 0)
        if start <= 0:
            return None, None
        elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(start)))
        r2_left = max(0.0, self.ZANI_R2_HARD_DEADLINE_SHARED - elapsed)
        fill_room = max(0.0, r2_left - self.P2_CONFESSION_R2_RESERVE)
        return r2_left, fill_room

    def _p2_confession_e_stably_available(self):
        ready_frames = 0
        for _ in range(3):
            self.task.next_frame()
            if self.resonance_available():
                ready_frames += 1
            else:
                ready_frames = 0
            if ready_frames >= self.P2_CONFESSION_E_READY_FRAMES:
                return True
            self.sleep(0.03)
        return False

    def _p2_wait_budget(self, state):
        elapsed, prayer = self._p2_confession_remaining(state)
        r_rem = self._p2_phoebe_r_remaining(state)
        retry_after = float(state.get(self.P2_CONFESSION_RETRY_AFTER_KEY, 0.0) or 0.0)
        retry_wait = max(0.0, retry_after - time.time())
        known = [x for x in (prayer, r_rem) if isinstance(x, (int, float))]
        if retry_wait > 0:
            known.append(retry_wait)
        need = max(known) if known else None
        r2_left, fill_room = self._p2_r2_fill_room(state)
        return elapsed, prayer, r_rem, retry_wait, need, r2_left, fill_room

    def _p2_plan_rover_az(self, state, reason, force_one=False):
        """按剩余等待与R2截止计算本次光主最多AZ数量；Rover每发后还会再次重算。"""
        _, prayer, r_rem, retry_wait, need, r2_left, fill_room = self._p2_wait_budget(state)
        total_done = int(state.get(self.P2_CONFESSION_AZ_COUNT_KEY, 0) or 0)
        remaining_total = max(0, self.P2_CONFESSION_MAX_AZ - total_done)
        if remaining_total <= 0:
            return False

        if need is None:
            n = 1 if force_one else 0
        else:
            effective = need
            if fill_room is not None:
                effective = min(effective, fill_room)
            usable = effective - self.P2_CONFESSION_SWITCH_TOTAL - self.P2_CONFESSION_PLAN_SAFETY
            n = int(max(0.0, usable) // self.P2_CONFESSION_AZ_COST)
            if force_one and n <= 0 and (fill_room is None or fill_room >= self.P2_CONFESSION_AZ_COST):
                n = 1
        n = max(0, min(n, remaining_total))
        if n <= 0:
            return False

        state[self.P2_CONFESSION_AZ_USED_KEY] = True
        state[self.P2_CONFESSION_AZ_TARGET_KEY] = total_done + n
        self._release_phoebe_prehold(state, reason='p2-confession-dynamic-rover')
        self.logger.info(
            f'ZFG V3.0 P2 confession -> Rover dynamic fill reason={reason} '
            f'Prayer={prayer} Rrem={r_rem} retry={retry_wait:.2f}s '
            f'R2left={r2_left} fill_room={fill_room} AZ_plan={n} '
            f'total_target={total_done + n}'
        )
        self._switch_route(state, 'Rover', self.STEP_P2_ROVER_AZ_WAIT_CONFESSION)
        return True

    def _p2_confession_check(self, state):
        """P2三终夜：Prayer/RCD长就光主动态AZ填轴，短就菲比A；E/R真正就绪后再告解/R。"""
        phase = state.get('phase', 'entry')
        if phase == 'entry':
            self._release_phoebe_prehold(state, reason='p2-confession-check-entry')
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P2 confession check')
            state['phase'] = 'decide'
            phase = 'decide'

        if phase == 'decide':
            elapsed, prayer, r_rem, retry_wait, need, r2_left, fill_room = self._p2_wait_budget(state)
            e_ready = self._p2_confession_e_stably_available()
            az_done = int(state.get(self.P2_CONFESSION_AZ_COUNT_KEY, 0) or 0)
            self.logger.info(
                f'ZFG V3.0 P2 confession CHECK Prayer_elapsed={elapsed} '
                f'Prayer_rem={prayer} R_rem={r_rem} E={e_ready} '
                f'retry={retry_wait:.2f}s R2_left={r2_left} fill_room={fill_room} AZ_done={az_done}'
            )

            if need is None:
                if not e_ready and self._p2_plan_rover_az(state, 'timer-unknown-E-cooldown', force_one=True):
                    return
            elif need > self.P2_CONFESSION_AZ_THRESHOLD:
                if self._p2_plan_rover_az(state, f'wait-budget-{need:.2f}s'):
                    return

            if (need is not None and need > 0) or retry_wait > 0:
                self.logger.info(
                    f'ZFG V3.0 P2 confession A-WAIT need≈{0.0 if need is None else need:.2f}s'
                )
                self.task.click()
                self.sleep(self.P2_CONFESSION_A_WAIT_GAP)
                self.task.next_frame()
                return

            if not e_ready:
                if self._p2_plan_rover_az(state, 'Prayer/R-ready-but-E-cooldown', force_one=True):
                    return
                self.task.click()
                self.sleep(self.P2_CONFESSION_A_WAIT_GAP)
                self.task.next_frame()
                return

            self.logger.info(
                'ZFG V3.0 P2 confession CHECK -> hold E and confirm CURRENT confession state'
            )
            self._advance_step(state, self.STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI)
            return

    def _p2_confession_r_to_zani(self, state):
        """P2双硬门：先确认真正进入告解，R输入前再确认当前仍处于告解。"""
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            self._release_phoebe_prehold(state, reason='p2-confession-attempt-entry')
            self._clear_p2_confession_proof(state)
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P2-before-N3')
            state['phase'] = 'confession'
            phase = 'confession'

        if phase == 'confession':
            if not self._p2_confession_e_stably_available():
                self._clear_p2_confession_proof(state)
                self.logger.info(
                    'ZFG V3.0 P2 confession attempt blocked: E unavailable -> CHECK'
                )
                self._advance_step(state, self.STEP_P2_PHOEBE_CONFESSION_CHECK)
                return

            if not self._hold_e_until_p2_confession_strict():
                state[self.P2_CONFESSION_RETRY_AFTER_KEY] = (
                    time.time() + self.P2_CONFESSION_FAILED_PROBE_BACKOFF
                )
                self.logger.warning(
                    'ZFG V3.0 P2 confession STRICT entry proof missing '
                    '-> recalc dynamic Rover/A wait'
                )
                if self._p2_plan_rover_az(
                    state, reason='confession-probe-failed', force_one=True
                ):
                    return
                self._advance_step(state, self.STEP_P2_PHOEBE_CONFESSION_CHECK)
                return

            state.pop(self.P2_CONFESSION_RETRY_AFTER_KEY, None)
            state['phase'] = 'r_cancel'
            phase = 'r_cancel'

        if phase == 'r_cancel':
            if not self._wait_p1_confession_r_ready('P2-before-N3'):
                return

            # R READY只是按键前置条件，绝不能作为告解证据。
            if not self._confirm_p2_confession_current_before_r(
                state, 'P2-before-N3'
            ):
                failed = int(
                    state.get('p2_confession_pre_r_failed_slices', 0) or 0
                ) + 1
                state['p2_confession_pre_r_failed_slices'] = failed

                if failed >= self.P2_CONFESSION_PRE_R_MAX_FAILED_SLICES:
                    self.logger.warning(
                        f'ZFG V3.0 P2 confession pre-R gate failed {failed} slices '
                        '-> restart confession proof'
                    )
                    self._clear_p2_confession_proof(state)
                    state['phase'] = 'confession'
                else:
                    self.logger.info(
                        f'ZFG V3.0 P2 confession pre-R gate failed '
                        f'{failed}/{self.P2_CONFESSION_PRE_R_MAX_FAILED_SLICES} '
                        '-> keep r_cancel and recheck; R remains blocked'
                    )
                return

            state['p2_confession_pre_r_failed_slices'] = 0
            if not self._cast_confession_r_required('P2-before-N3'):
                return

            self._cast_echo_soft('P2-before-N3-after-R')
            self._clear_p2_confession_proof(state)
            state.pop(self.P2_CONFESSION_AZ_USED_KEY, None)
            state.pop(self.P2_CONFESSION_AZ_COUNT_KEY, None)
            state.pop(self.P2_CONFESSION_AZ_TARGET_KEY, None)
            state.pop(self.P2_CONFESSION_RETRY_AFTER_KEY, None)
            state['phase'] = 'switch'
            phase = 'switch'

        if phase == 'switch':
            self._switch_route(
                state,
                'Zani',
                self.STEP_P2_ZANI_N3_R2_E_TO_PHOEBE,
            )


    def _confession_r_to_target(
        self,
        state,
        target,
        next_step,
        tag,
    ):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded(tag)
            state['phase'] = 'confession'
            phase = 'confession'

        if phase == 'confession':
            if not state.get(self.PHOEBE_PREHOLD_E_KEY):
                ready_frames = 0
                for _ in range(3):
                    self.task.next_frame()
                    if self.resonance_available():
                        ready_frames += 1
                    else:
                        ready_frames = 0
                    self.sleep(0.03)
                if ready_frames < 2:
                    self.sleep(self.POLL)
                    return

            if not self._hold_e_until_confession_state():
                self.sleep(0.20)
                return

            state['phase'] = 'r_cancel'
            phase = 'r_cancel'

        if phase == 'r_cancel':
            if not self._wait_p1_confession_r_ready(tag):
                return
            if not self._cast_p1_confession_r_fast_required(tag):
                return
            self._cast_echo_soft(f'{tag}-after-R')
            state['phase'] = 'switch'
            phase = 'switch'

        if phase == 'switch':
            self._switch_route(
                state,
                target,
                next_step,
            )


    def _p2_double_star_fill_to_zani(self, state):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            state['p2_double_star_done'] = False
            if state.pop('new_cycle_pending', False):
                state['cycle'] = int(state.get('cycle', 1)) + 1
                self.logger.info(f'ZFG V3.0 enter P2 cycle {state["cycle"]}')
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P2 double-star entry')
            state['phase'] = 'star1'
            phase = 'star1'

        if phase == 'star1':
            if not self._cast_p2_star_with_energy_guard('P2 star1'):
                return
            state['phase'] = 'star2'
            phase = 'star2'

        if phase == 'star2':
            if not self._cast_p2_star_with_energy_guard('P2 star2'):
                return
            state['phase'] = 'verify_empty'
            phase = 'verify_empty'

        if phase == 'verify_empty':
            if not self._confirm_p2_blue_forte_empty():
                state['phase'] = 'star2'
                return
            state['p2_double_star_done'] = True
            self.logger.info(
                'ZFG V3.0 Phoebe P2 DOUBLE-STAR HARD GUARD satisfied: '
                'two Z ready-transitions + final blue forte 0/2'
            )
            state['phase'] = 'fill_con'
            phase = 'fill_con'

        if phase in ('fill_con', 'full_tail', 'switch_zani'):
            if not state.get('p2_double_star_done'):
                state['phase'] = 'star2'
                return
            self._fill_concerto_and_intro_zani(
                state,
                self.STEP_P2_ZANI_EFORTE_PREP,
                require_saved_star=False,
                tag='P2 double-star',
            )
