import time
from src.char.BaseChar import BaseChar, SwitchPriority, forte_white_color


class Cantarella(BaseChar):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_heavy = -1
        self.started = False
        self._fkj_round = 0
        self._force_switch_me = False
        self._entry_mode = None

    def f_break(self, check_f_on_switch=False, force=False):
        # 覆写基类：彻底关死自动处决，任何路径均静默返回 False
        return False

    def reset_state(self):
        # 每场战斗重新走启动轴
        super().reset_state()
        self.started = False
        self._fkj_round = 0
        self._entry_mode = None

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        # 强切标记协议（工坊三人特化专用）
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        # 工坊 zip 加载的是独立 class，不能用 isinstance(src.char.X)
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode=None):
        # mode：指定目标入场的循环函数（f1/f2/f3），由目标的 _entry_mode 消费
        if target is None:
            return super().switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            return super().switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    def _trace(self, msg):
        # 链路诊断埋点（用户裁定：全链节点 INFO + 闭环轮次计数）；只读，异常不外溢
        try:
            self.logger.info(f'[FKJ][R{self._fkj_round}] Cantarella {msg}')
        except Exception:
            pass

    def do_perform(self):
        if not self.started:
            self._trace('startup enter build=r19-clickf')
            self.perform_startup()
            return
        mode = self._entry_mode or 'f1'
        self._entry_mode = None
        self._trace(f'enter {mode}')
        if mode == 'f2':
            self.perform_f2()
        else:
            self.perform_f1()

    def perform_startup(self):
        """启动轴（全队首发）：变奏入场等待 → 开大招 → 开声骸 → 强切嘉贝莉娜"""
        self.started = True
        if self.has_intro:
            self.wait_intro()
        self._trace(f'startup liberation {self.click_liberation(click_f=False)}')
        self.send_echo_key()
        self.record_echo_use()
        self._trace('startup echo sent directly')
        self.task.next_frame()
        self._trace('startup exit -> Galbrena startup')
        self._force_switch_to(self._find_teammate('Galbrena'))

    def perform_f1(self):
        """循环函数1：重击一次 → E → 普攻到强化 E 真正释放 → 声骸 → 强切嘉贝莉娜 f3"""
        if self.has_intro:
            self.wait_intro()
        heavy = self.heavy_click_forte(check_fun=self.is_mouse_forte_full)  # 重击一次（环满才释放，同 baseline 写法）
        self._trace(f'f1 heavy {heavy} mouse_forte_full {bool(self.is_mouse_forte_full())}')
        self.last_heavy = time.time()  # 重击成功与否都刷蓄力锚点，防 last_heavy=-1 短路蓄力循环
        self._trace(f'f1 E {self.click_resonance()[0]}')
        forte_delay = time.time()
        charge_exit = 'timeout_8s'
        stagnation_logged = False
        attack_count = 0
        e_attempts = 0
        enhanced_e = False
        while self.time_elapsed_accounting_for_freeze(self.last_heavy) < 8:
            self.task.click()
            attack_count += 1
            self.sleep(0.2)
            if self.resonance_available():
                e_attempts += 1
                enhanced_e = self.click_resonance(send_click=False)[0]
                if enhanced_e:
                    charge_exit = 'enhancedE'
                    break
            now = time.time()
            if self.is_forte_full():
                forte_delay = now
            elif now - forte_delay > 0.5 and not stagnation_logged:
                stagnation_logged = True
                self._trace('f1 charge stagnation 0.5s; continue until enhancedE/timeout')
            self.check_combat()
            self.task.next_frame()
        self.task.mouse_up()
        self._trace(
            f'f1 charge exit={charge_exit} '
            f'elapsed {self.time_elapsed_accounting_for_freeze(self.last_heavy):.1f}s '
            f'attacks={attack_count} E_attempts={e_attempts}'
        )
        self._trace(f'f1 enhancedE {bool(enhanced_e)}')
        self.sleep(1)  # 用户裁定：保留强化E与Q之间的1s停顿
        self.send_echo_key()
        self.record_echo_use()
        self._trace('f1 echo sent directly')
        self.task.next_frame()
        self._trace('f1 exit -> Galbrena f3')
        self._force_switch_to(self._find_teammate('Galbrena'), 'f3')

    def perform_f2(self):
        """循环函数2（用户裁定：先开大、再判协奏、后切人）：大招未就绪则持续普攻充能 → 开大 → 声骸 → 协奏未满补满 → 强切弗洛洛"""
        if self.has_intro:
            self.wait_intro()
        t0 = time.time()
        if not self.liberation_available():
            # 能量未满时 click_liberation 会 110ms 快速失败根本没按键；先边打边等 R 就绪（普攻同时回能和涨协奏）
            ok = self.task.wait_until(self.liberation_available, time_out=12, post_action=self.task.click)
            self._trace(f'f2 wait R {bool(ok)} {time.time() - t0:.1f}s')
        self._trace(f'f2 liberation {self.click_liberation(click_f=False)}')
        self.send_echo_key()
        self.record_echo_use()
        self._trace('f2 echo sent directly')
        self.task.next_frame()
        if not self.is_con_full():
            self.continues_normal_attack(15, until_con_full=True)
            self._trace(f'f2 con_fill -> {self.get_current_con():.2f} (1.00=满)')
        else:
            self._trace('f2 con already full')
        # 闭环计轮：一圈以 C f2 → P 收尾；计数同步到全队，各角色日志共享 [Rn]
        self._fkj_round += 1
        for name in ('Cantarella', 'Galbrena', 'Phrolova'):
            teammate = self._find_teammate(name)
            if teammate is not None:
                teammate._fkj_round = self._fkj_round
        self._trace(f'round {self._fkj_round} complete -> Phrolova f1')
        self._force_switch_to(self._find_teammate('Phrolova'))
            
    def resonance_available(self, current=None, check_ready=False, check_cd=False):
        if not self.is_mouse_forte_full() and self.is_forte_full():
            return not self.has_cd('resonance')
        return super().resonance_available()
        
    def on_combat_end(self, chars):
        next_char = str((self.index + 1) % len(chars) + 1)
        self.logger.debug(f'Cantarella on_combat_end {self.index} switch next char: {next_char}')
        self.task.send_key(next_char)

    def is_forte_full(self):
        box = self.task.box_of_screen_scaled(5120, 2880, 3034, 2640, 3090, 2700, name='forte_full', hcenter=True)
        white_percent = self.task.calculate_color_percentage(forte_white_color, box)
        self.logger.debug(f'forte_color_percent {white_percent}')
        return white_percent > 0.06
