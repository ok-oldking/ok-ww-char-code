import time

from src.char.BaseChar import BaseChar, SwitchPriority



class Phrolova(BaseChar):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.check_f_on_switch = False  # 取消自动处决
        self.last_liberation = -1
        self.sp = False
        self.started = False
        self._fkj_round = 0
        self._force_switch_me = False
        self._entry_mode = None

    def f_break(self, check_f_on_switch=False, force=False):
        # 覆写基类：彻底关死自动处决，任何路径均静默返回 False
        return False

    def reset_state(self):
        # 每场战斗重新走启动轴
        super().reset_state()
        self.started = False
        self._fkj_round = 0
        self._entry_mode = None

    def skip_combat_check(self):
        # 用户裁定：弗洛洛站场期间完全不接收 target-lost 脱战判定（恒定豁免，取代上轮 6s 窗口）。
        # 演出锁输入期锁定图标不渲染+中键重锁定无效，限时窗口仍会耽误链路重联节奏。
        # 代价（用户已知晓）：若 boss 真死/退战，需等下一次强切的 in_team 失败兑底才收尾；
        # 开放世界灭团后可能空转，刷图场景慎用
        return True

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        # 强切标记协议（工坊三人特化专用）
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        self.logger.debug(f'Phrolova last_liberation {self.time_elapsed_accounting_for_freeze(self.last_liberation)}')
        if self._cantarella_outro_ready(current_char, has_intro):
            return SwitchPriority.MUST
        if self.time_elapsed_accounting_for_freeze(self.last_liberation) < 24:
            return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        # 工坊 zip 加载的是独立 class，不能用 isinstance(src.char.X)
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode=None):
        # mode：指定目标入场的循环函数（f1/f2/f3），由目标的 _entry_mode 消费
        if target is None:
            return super().switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            return super().switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    def _trace(self, msg):
        # 链路诊断埋点（与另两文件同构；R n=闭环轮次，由 Cantarella f2 同步）
        try:
            self.logger.info(f'[FKJ][R{getattr(self, "_fkj_round", 0)}] Phrolova {msg}')
        except Exception:
            pass

    def do_perform(self):
        self.last_liberation = -1
        self.sp = False
        if not self.started:
            self._trace('startup enter build=r21-intro-na17')
            self.perform_startup()
            return
        self._entry_mode = None
        self._trace('f1 enter')
        self.perform_f1()

    def perform_startup(self):
        """弗洛洛固定动作体：有变奏先普攻1.7秒，最多站场16秒后固定切嘉贝莉娜 f1"""
        self.started = True
        self.sp = True
        if self.has_intro:
            self.continues_normal_attack(1.7)
        if self.flying():
            self.wait_down()
        start = time.time()
        exit_reason = 'timeout_16s'
        while self.time_elapsed_accounting_for_freeze(self.last_perform) < 16:
            if self.liberation_available() and self.click_liberation(wait_if_cd_ready=0, click_f=False):
                exit_reason = 'liberation'
                break
            if self.flying():
                self.wait_down()
            if self.heavy_and_liber():
                exit_reason = 'heavy+liber'
                break
            if self.resonance_available() and 1 < time.time() - start:
                self.continues_normal_attack(0.3)
                if self.click_resonance()[0]:
                    self.continues_normal_attack(0.1)
                    self.task.wait_until(lambda: not self.resonance_available(), post_action=self.task.click,
                                         time_out=0.3)
                    if not self.click_echo():
                        self.continues_right_click(0.1)
            self.task.click()
            self.check_combat()
            self.task.next_frame()
        self.sp = False
        self._trace(f'fixed16s exit={exit_reason} after {time.time() - start:.1f}s -> Galbrena f1')
        self._force_switch_to(self._find_teammate('Galbrena'), 'f1')

    def perform_f1(self):
        """循环阶段复用固定16秒动作体；动作结束后由动作体切到嘉贝莉娜 f1"""
        self.perform_startup()

    def _cantarella_outro_ready(self, current_char, has_intro):
        return self.time_elapsed_accounting_for_freeze(
            self.last_liberation) > 14 and has_intro and current_char and current_char.char_name in {'char_cantarella'}

    def resonance_available(self):
        if self.sp:
            return not (self.flying() or self.has_cd('resonance'))
        return super().resonance_available()

    def heavy_and_liber(self):
        if self.heavy_click_forte(check_fun=self.is_mouse_forte_full):
            self.logger.debug('Phrolova heavy_click_forte')
            self.task.wait_until(lambda: self.click_liberation(wait_if_cd_ready=0, click_f=False), time_out=3)
            return True
