import time

from src.char.BaseChar import BaseChar, SwitchPriority


class Galbrena(BaseChar):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.check_f_on_switch = False  # 取消自动处决
        self.started = False
        self._fkj_round = 0
        self._force_switch_me = False
        self._entry_mode = None

    def f_break(self, check_f_on_switch=False, force=False):
        # 覆写基类：默认拦截所有被动处决；仅由 perform_f3 显式 force=True 放行
        if force:
            return self.task.f_break()
        return False


    def reset_state(self):
        # 每场战斗重新走启动轴
        super().reset_state()
        self.started = False
        self._fkj_round = 0
        self._entry_mode = None

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        # 强切标记协议（工坊三人特化专用）
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        # 工坊 zip 加载的是独立 class，不能用 isinstance(src.char.X)
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode=None):
        # mode：指定目标入场的循环函数（f1/f2/f3），由目标的 _entry_mode 消费
        if target is None:
            return super().switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            return super().switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    def _trace(self, msg):
        # 链路诊断埋点（与 Cantarella/Phrolova 同构；R n=闭环轮次，由 Cantarella f2 同步）
        try:
            self.logger.info(f'[FKJ][R{getattr(self, "_fkj_round", 0)}] Galbrena {msg}')
        except Exception:
            pass

    def do_perform(self):
        if not self.started:
            self._trace('startup enter build=r19-clickf')
            self.perform_startup()
            return
        mode = self._entry_mode or 'f1'
        self._entry_mode = None
        self._trace(f'enter {mode}')
        if mode == 'f3':
            self.perform_f3()
        else:
            self.perform_f1()

    def _echo_then_hold(self, trace_tag):
        # 声骸不会处于 CD：直接发送后让出一帧，再开始长按
        self.send_echo_key()
        self.record_echo_use()
        self._trace(f'{trace_tag} echo sent directly')
        self.task.next_frame()
        self.task.mouse_down()
        self.sleep(2)
        self.task.mouse_up()
        self._trace(f'{trace_tag} hold 2s done')

    def perform_startup(self):
        """启动轴（第二手）：变奏入场等待 → 开声骸 → 左键长按2秒 → 强切弗洛洛"""
        self.started = True
        if self.has_intro:
            self.wait_intro()
        self._echo_then_hold('startup')
        self._trace('startup exit -> Phrolova startup')
        self._force_switch_to(self._find_teammate('Phrolova'))

    def _resonance_once(self):
        """单次释放 E（用户实测：click_resonance 循环会连按多次 E，第二次 E 角色起飞）。
        click_resonance 的退出条件只看 has_cd（图标冷却遮罩），嘉贝莉娜位格技 CD 显示滞后被误判可用。
        这里改为：垫刀 → 判定图标就绪（≤1s）→ 只按一次，绝不补按。"""
        self.task.click()
        ok = self.resonance_available() or self.task.wait_until(
            lambda: self.resonance_available(), time_out=1, post_action=self.task.click)
        if ok and self.resonance_available():
            self.send_resonance_key()
            self.record_resonance_use()
            return True
        return False

    def perform_f1(self):
        """循环函数1（进入恶魔位格）：稳定确认能量满且大招可放后，单次 E→R→函数2"""
        if self.has_intro:
            self.wait_intro()
        self.task.mouse_down()
        charge_t0 = time.time()
        try:
            charged = self.task.wait_until(
                lambda: self.is_forte_full() and self.liberation_available(),
                time_out=10,
                settle_time=0.15,
            )
        finally:
            self.task.mouse_up()
        post_release_forte = bool(self.is_forte_full())
        post_release_liberation = bool(self.liberation_available())
        self._trace(
            f'f1 gate charged={bool(charged)} '
            f'post-release forte={post_release_forte} R={post_release_liberation} '
            f'(wait_until {"hit" if charged else "timeout"} {time.time() - charge_t0:.1f}s)'
        )
        if not charged:
            self._trace('f1 gate timeout skip E-R -> f2')
            self.perform_f2()
            return
        if not (post_release_forte and post_release_liberation):
            self._trace('f1 post-release sample dropped; trust stable gate')
        e_result = self._resonance_once()
        r_ready = self.task.wait_until(
            lambda: self.liberation_available(),
            time_out=1,
            settle_time=0.1,
        )
        post_e_liberation = bool(self.liberation_available())
        self._trace(f'f1 post-E R={post_e_liberation} (E result={bool(e_result)} window={bool(r_ready)})')
        if not r_ready or not post_e_liberation:
            self._trace('f1 R window failed skip R -> f2')
            self.perform_f2()
            return
        r_result = self.click_liberation(click_f=False)
        self._trace(f'f1 R result={bool(r_result)}')
        self.perform_f2()

    def perform_f2(self):
        """爆发函数（用户裁定）：持续左键4s → 右键闪避 → 持续左键3s → 右键闪避 → 持续左键0.5s → 强切坎特蕾拉 f1"""
        t0 = time.time()
        self._trace('f2 enter')
        self.continues_normal_attack(4)
        self._trace(f'f2 burst1 4s t={time.time() - t0:.1f}s forte_full {bool(self.is_forte_full())} con {self.get_current_con():.2f}')
        self.continues_right_click(0.05)
        self.sleep(0.2)  # 用户裁定：闪避后停 0.2s
        self.continues_normal_attack(3)
        self._trace(f'f2 burst2 3s t={time.time() - t0:.1f}s forte_full {bool(self.is_forte_full())} con {self.get_current_con():.2f}')
        self.continues_right_click(0.05)
        self.sleep(0.2)  # 同上
        self.continues_normal_attack(0.5)
        self._trace(f'f2 burst3 0.5s done t={time.time() - t0:.1f}s -> Cantarella f1')
        self._force_switch_to(self._find_teammate('Cantarella'), 'f1')

    def perform_f3(self):
        """循环函数3：主动尝试处决 → 变奏入场等待 → 声骸 → 左键长按2秒（同启动轴）→ 强切坎特蕾拉 f2"""
        fired = False
        try:
            if hasattr(self.task, 'check_f_break') and self.task.check_f_break():
                self.f_break(force=True)
                fired = True
            elif getattr(self.task, 'can_break', False):
                self.f_break(force=True)
                fired = True
        except Exception:
            pass
        if fired:
            self._trace('f3 f_break fired')
        if self.has_intro:
            self.wait_intro()
        self._echo_then_hold('f3')
        self._trace('f3 exit -> Cantarella f2')
        self._force_switch_to(self._find_teammate('Cantarella'), 'f2')
