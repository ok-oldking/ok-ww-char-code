"""忌炎红绿灯合轴 V3.1。

职责：执行忌炎开场、P1/P2/P3共鸣解放爆发、P2/P3补R插入段，
并管理青龙状态下的普攻、闪避、E与特殊变奏切莫特斐。

按键缩写：A=普通攻击，E=共鸣技能，Q=声骸技能，R=共鸣解放，Z=重击。
流程缩写：P1/P2/P3=第一套/第二套/第三套，FSM=三角色共享的流程状态机。
代码词速查：STEP=大阶段，phase=阶段内的小步骤，fill=补协奏，raw=当前画面的原始识别结果，guard=保护判断。
"""

import time  # 计时、动作间隔和超时保护。
import math  # 计算忌炎R能量圆弧的角度与距离。

import cv2  # 处理技能图标颜色、遮罩和形态学识别。
import numpy as np  # 处理截图像素矩阵和圆环采样坐标。

from ok import color_range_to_bound  # 把OK-WW颜色范围转换为OpenCV可用的上下界。
from src.char.BaseChar import BaseChar, SwitchPriority  # 使用OK-WW角色基类和角色切换优先级。
from src.char.Jiyan import Jiyan as BuiltinJiyan  # 继承本角色内置逻辑，包含初始化、辅助动作和切人优先级。


# 仅“忌炎+莫特斐+维里奈”启用红绿灯轴；其他队伍调用OK-WW内置角色逻辑。
# 请通过OK-WW自定义代码加载本文件，保留src/char中的内置角色文件供继承。
class Jiyan(BuiltinJiyan):
    """红绿灯轴V3.1：固定轴优先；补R阶段必须完成R双门+Q后回莫，R爆发结束不再强制补满协奏。"""

    # =========================================================
    # 红绿灯轴V3.1 FSM：STEP 名直接描述当前真实动作；角色归属由 STEP_ACTOR 显式映射。
    # 以后流程改名/插入新阶段，不再依赖字符串里是否包含 JIYAN/MORT/VERINA。
    # =========================================================
    STEP_P1_JIYAN_OPEN_E = 'P1_JIYAN_OPEN_E'  # 第一套开场：忌炎释放E后普通切莫特斐
    STEP_P1_MORT_AUTO_TO_VERINA = 'P1_MORT_AUTO_TO_VERINA'  # 第一套：莫特斐利用角色自动普攻衔接并普通切维里奈
    STEP_P1_VERINA_E_Q_R = 'P1_VERINA_E_Q_R'  # 第一套：维里奈依次执行E、Q、R后切莫特斐
    STEP_P1_MORT_R_E_Q_TO_VERINA = 'P1_MORT_R_E_Q_TO_VERINA'  # 第一套：莫特斐依次执行R、E、Q后切维里奈
    STEP_P1_VERINA_FAST_FILL_TO_MORT = 'P1_VERINA_FAST_FILL_TO_MORT'  # 第一套：维里奈快速补满协奏后特殊变奏莫特斐
    STEP_P1_MORT_INTRO_E_DODGE_FILL = 'P1_MORT_INTRO_E_DODGE_FILL'  # 第一套：莫特斐变奏入场后E、闪避并把协奏补到忌Q插入门
    STEP_P1_JIYAN_A_WAIT_Q_TO_MORT = 'P1_JIYAN_A_WAIT_Q_TO_MORT'  # 第一套：忌炎用A覆盖换人CD，随后Q并等飞廉二段出手后回莫
    STEP_P1_MORT_RETURN_FAST_FILL_TO_JIYAN = 'P1_MORT_RETURN_FAST_FILL_TO_JIYAN'  # 第一套：莫特斐回场快速补满协奏并特殊变奏忌炎
    STEP_P1_JIYAN_BURST_R = 'P1_JIYAN_BURST_R'  # 第一套：忌炎变奏入场后执行完整R爆发循环

    STEP_P2_MORT_INTRO_E_TO_JIYAN = 'P2_MORT_INTRO_E_TO_JIYAN'  # 第二套开头：莫特斐变奏入场执行E模块后普通切忌炎
    STEP_P2_JIYAN_QUICK_E_TO_MORT = 'P2_JIYAN_QUICK_E_TO_MORT'  # 第二套：忌炎快速尝试E后普通切莫特斐
    STEP_P2_MORT_AUTO_TO_VERINA = 'P2_MORT_AUTO_TO_VERINA'  # 第二套：莫特斐不额外补动作，普通切维里奈
    STEP_P2_VERINA_E_R_PHOTO_TO_MORT = 'P2_VERINA_E_R_PHOTO_TO_MORT'  # 第二套：维里奈E、可用则R、按光合格数空中A后切莫
    STEP_P2_MORT_E_Q_R_FAST_FILL = 'P2_MORT_E_Q_R_FAST_FILL'  # 第二套主体：莫特斐E→Q→R并快速补协奏，期间带忌R插入门
    STEP_P2_JIYAN_R_PREP_Q_TO_MORT = 'P2_JIYAN_R_PREP_Q_TO_MORT'  # 第二套插入：忌炎补R能量、满足门后Q，等飞廉二段出手再回莫
    STEP_P2_JIYAN_BURST_R = 'P2_JIYAN_BURST_R'  # 第二套结尾：忌炎特殊变奏后执行完整R爆发循环

    STEP_P3_MORT_INTRO_E_TO_JIYAN = 'P3_MORT_INTRO_E_TO_JIYAN'  # 第三套循环开头：莫特斐自然切入（满协奏则变奏）后立即执行E模块并切忌炎
    STEP_P3_JIYAN_E_A_HEAVY_TO_MORT = 'P3_JIYAN_E_A_HEAVY_TO_MORT'  # 第三套：忌炎E→A→重击后普通切莫特斐，不释放Q
    STEP_P3_MORT_AUTO_TO_VERINA = 'P3_MORT_AUTO_TO_VERINA'  # 第三套：莫特斐普通切维里奈
    STEP_P3_VERINA_E_R_PHOTO_TO_MORT = 'P3_VERINA_E_R_PHOTO_TO_MORT'  # 第三套前半：维里奈E、可用则R、按光合格数空中A后切莫
    STEP_P3_MORT_ENTRY_E_TO_VERINA = 'P3_MORT_ENTRY_E_TO_VERINA'  # 第三套中段：莫特斐执行入场E模块后切维里奈
    STEP_P3_VERINA_Q_R_TO_MORT = 'P3_VERINA_Q_R_TO_MORT'  # 第三套中段：维里奈Q后R若可用则放，再切莫特斐
    STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL = 'P3_MORT_ENTRY_E_R_Q_FAST_FILL'  # 第三套后半：莫特斐可选入场E→R→Q并快速补协奏
    STEP_P3_JIYAN_R_PREP_Q_TO_MORT = 'P3_JIYAN_R_PREP_Q_TO_MORT'  # 第三套插入：忌炎补R能量、满足门后Q，等飞廉二段出手再回莫
    STEP_P3_JIYAN_BURST_R = 'P3_JIYAN_BURST_R'  # 第三套结尾：忌炎特殊变奏后执行完整R爆发，然后回到第三套开头

    STEP_ACTOR = {  # 阶段执行角色表：每个流程阶段只能由表中指定的角色执行。
        STEP_P1_JIYAN_OPEN_E: 'Jiyan', STEP_P1_MORT_AUTO_TO_VERINA: 'Mortefi',
        STEP_P1_VERINA_E_Q_R: 'Verina', STEP_P1_MORT_R_E_Q_TO_VERINA: 'Mortefi',
        STEP_P1_VERINA_FAST_FILL_TO_MORT: 'Verina', STEP_P1_MORT_INTRO_E_DODGE_FILL: 'Mortefi',
        STEP_P1_JIYAN_A_WAIT_Q_TO_MORT: 'Jiyan', STEP_P1_MORT_RETURN_FAST_FILL_TO_JIYAN: 'Mortefi',
        STEP_P1_JIYAN_BURST_R: 'Jiyan', STEP_P2_MORT_INTRO_E_TO_JIYAN: 'Mortefi',
        STEP_P2_JIYAN_QUICK_E_TO_MORT: 'Jiyan', STEP_P2_MORT_AUTO_TO_VERINA: 'Mortefi',
        STEP_P2_VERINA_E_R_PHOTO_TO_MORT: 'Verina', STEP_P2_MORT_E_Q_R_FAST_FILL: 'Mortefi',
        STEP_P2_JIYAN_R_PREP_Q_TO_MORT: 'Jiyan', STEP_P2_JIYAN_BURST_R: 'Jiyan',
        STEP_P3_MORT_INTRO_E_TO_JIYAN: 'Mortefi', STEP_P3_JIYAN_E_A_HEAVY_TO_MORT: 'Jiyan',
        STEP_P3_MORT_AUTO_TO_VERINA: 'Mortefi', STEP_P3_VERINA_E_R_PHOTO_TO_MORT: 'Verina',
        STEP_P3_MORT_ENTRY_E_TO_VERINA: 'Mortefi', STEP_P3_VERINA_Q_R_TO_MORT: 'Verina',
        STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL: 'Mortefi', STEP_P3_JIYAN_R_PREP_Q_TO_MORT: 'Jiyan',
        STEP_P3_JIYAN_BURST_R: 'Jiyan',
    }

    TARGET_MORTEFI = 'Mortefi'  # 忌炎离场时要寻找的莫特斐角色名称；必须与OK-WW识别到的英文名一致。

    INTRO_WAIT_TIMEOUT = 1.5  # 变奏入场最长等待时间（秒）：超过后不再继续等入场动作。
    INTRO_CONFIRM_TIME = 0.12  # 满协奏最短确认时间（秒）：保留给特殊变奏稳定检查。
    INTRO_CONFIRM_TIMEOUT = 1.4  # 特殊变奏确认上限（秒）：在这段时间内寻找连续满协奏画面。
    INTRO_CONFIRM_POLL = 0.04  # 特殊变奏确认采样间隔（秒）：每隔多久读取一次满协奏状态。
    INTRO_CONFIRM_FRAMES = 3  # 特殊变奏所需连续满协奏帧数：任意一帧不满就重新计数。
    NORMAL_SWITCH_FULL_CONFIRM_TIME = 0.18  # 普通切人前满协奏复核时间（秒）：若持续为满则阻止普通切，避免意外触发变奏。
    # 普通切入后稍等角色真正可操作，避免在换人过渡帧把 E 作为预输入提前塞进去。
    NORMAL_SWITCH_ACTION_SETTLE_TIME = 0.12  # 普通切入后的稳定等待（秒）：防止E在换人过渡帧被提前吞掉。


    # P1 忌Q插入前先用平A覆盖莫特斐换人CD；CD一好就停止等待，最多约1s。
    PRE_ECHO_SWITCH_READY_ATTACK_TIME = 0.7  # P1忌炎放Q前最多用A等待莫特斐换人冷却的时间（秒）。
    PRE_ECHO_SWITCH_READY_ATTACK_INTERVAL = 0.12  # P1等待莫特斐换人冷却期间，两次A之间的最短间隔（秒）。
    ECHO_INPUT_CONFIRM_TIMEOUT = 0.8  # 忌炎Q缓冲与消耗确认上限（秒）：Q未进入CD就不结束当前Q阶段。
    OLD_FEILIAN_SECOND_STAGE_WAIT_TIME = 0.30  # 老版飞廉Q确认进入CD后，等待二段开始出手的保护时间（秒）；不等待二段命中或动画结束。
    RESONANCE_INPUT_CONFIRM_TIMEOUT = 0.7  # 忌炎E缓冲与消耗确认上限（秒）：只发出E键但图标未进入CD时不算成功。
    F_POST_ACTION_SETTLE_TIME = 0.15  # F处决结束后的动作恢复保护（秒）：防止恢复瞬间发送的E/Q/A被动作锁吞掉。

    # task.is_con_full() 实机偶发在视觉已满时仍返回False并把进度压到0.99。
    # V3.1：P2/P3补R阶段不再被协奏满抢占；有效满协奏只用于最终自然切莫时决定是否触发变奏。
    CONCERTO_EFFECTIVE_FULL_THRESHOLD = 0.99  # 有效满协奏阈值：画面读数达到该比例时，可兼容raw满判定偶发失败。
    CONCERTO_BRANCH_CONFIRM_TIME = 0.08  # 有效满协奏分支最短确认时间（秒）：用于过滤单帧误识别。
    CONCERTO_BRANCH_CONFIRM_FRAMES = 2  # 有效满协奏连续确认帧数：连续达到该帧数才允许抢占或切换分支。

    # 变奏后 R 有时第一下输入会被入场/后摇吞掉；持续缓冲，但必须有界。
    LIBERATION_READY_TIMEOUT = 6.0  # 忌炎R启动等待上限（秒）：快速缓冲R仍未成功时退出本轮，避免卡死。
    LIBERATION_INPUT_BUFFER_INTERVAL = 0.08  # 特殊变奏忌炎后R的连按间隔（秒）：越小越容易抢到首个可操作帧，过小会增加无效输入。
    # R 动画结束、队伍 UI 重新出现的时刻作为强化输出 T0。
    LIBERATION_ACTIVE_TIME = 10.8  # 忌炎R动画结束、队伍界面恢复后，青龙强化输出持续时间（秒）。

    # =========================================================
    # 忌炎 R 模块手动 / 自动闪避开关
    # =========================================================
    # True：青龙期间循环执行连续点击A -> 短按一次闪避 -> 按住W并连续点击A。
    # False：只执行第一段连续点击A，重复至青龙窗口结束；方向键和闪避交给玩家。
    QINGLONG_AUTO_DODGE_ENABLED = True  # 青龙期自动闪避开关：True启用单闪接W平A，False只自动连续点击A。

    # True：忌炎 R 强化站场期间只要检测到 E 可用，就立即穿插一次 E，
    # 用于额外积攒下一轮共鸣解放能量；调试纯 A 轴时可改为 False。
    # False：R 强化期完全不主动穿插 E，仅保留原本 A / 闪避节奏。
    LIBERATION_ACTIVE_E_ENABLED = False  # 青龙期自动穿插E开关：True时E一亮就释放，False时强化期不主动用E。

    # True：10.7 秒结束时若 E 不可用，脚本自动轻闪一次再 A。
    # False：结束时 E 不可用就直接 A，不发送 Dodge。
    LIBERATION_END_AUTO_DODGE_ENABLED = False  # 青龙期结束后的自动闪避开关：E不可用时，True先轻闪再A，False直接A。

    # =========================================================
    # 忌炎 R 能量识别（红绿灯轴V2.8沿用V2.5标定）
    # =========================================================
    # V2.4实机截图确认：
    # 1) box_liberation中心与R技能图标中心基本一致；
    # 2) box_liberation短边/2并不是完整技能图标半径；
    # 3) 真实R能量环稳定落在当前base_r约1.30~1.40倍处。
    # 因此V2.5不再做0.30~2.00r径向扫描，直接采用实机标定尺度。
    LIBERATION_RING_COLOR = {  # 忌炎R能量环的RGB取色范围；只有实机UI颜色发生明显变化时才需要调整。
        'r': (70, 110),
        'g': (215, 250),
        'b': (155, 190),
    }

    # 当前BaseChar box半径 -> 真实技能图标半径的实机标定比例。
    LIBERATION_ICON_RADIUS_SCALE = 1.35  # R图标真实半径换算比例：用OK-WW基础框半径乘以该值定位完整图标。
    # 用户确认R能量环位于完整技能图标最大半径最外沿。
    # 所以正式采样 = 真实图标半径的0.95~1.05；
    # 换算到当前box base_r约等于1.2825~1.4175倍。
    LIBERATION_ENERGY_RING_INNER_RATIO = 0.95  # R能量环采样内半径比例：相对于换算后的真实图标半径。
    LIBERATION_ENERGY_RING_OUTER_RATIO = 1.05  # R能量环采样外半径比例：相对于换算后的真实图标半径。
    # 只需覆盖正式外环并留少量边界，不再扩到2.20r做诊断。
    LIBERATION_ENERGY_ROI_SCALE = 1.55  # R能量识别截图范围比例：过小会裁掉外环，过大会引入更多背景颜色。

    # V2.4 raw截图显示：严格con_colors只能抓到能量弧中的零散像素。
    # V2.5保留官方RGB范围，同时增加更宽容的HSV青绿色mask并取并集。
    # OpenCV Hue范围0~179；实机R环主色约落在H=77附近。
    LIBERATION_HSV_LOWER = (65, 70, 120)  # R能量青绿色的HSV下限；用于补充严格RGB取色漏掉的像素。
    LIBERATION_HSV_UPPER = (90, 255, 255)  # R能量青绿色的HSV上限；范围过宽可能把背景颜色误当成能量。

    # 从12点方向作为第0份，沿屏幕逆时针递增，共72份，每份5度。
    LIBERATION_ENERGY_ANGLE_BINS = 72  # R能量环角度分格数：72表示每格5度，用于估算圆弧填充比例。
    # 90% * 72 = 64.8，因此>=65份视为达到90%。
    LIBERATION_ENERGY_READY_BINS = 65  # R能量达标所需连续亮格数：数值越大，要求的R能量越高。

    # 每个扇区颜色覆盖率门。HSV连续mask下，峰值通常明显高于旧严格RGB。
    LIBERATION_BIN_MIN_COLOR_COVERAGE = 0.10  # 单个角度格判亮的最低颜色覆盖率：过低易误判，过高易漏判。
    LIBERATION_BIN_RELATIVE_COVERAGE = 0.35  # 单格相对亮度门槛：以本帧最亮格为基准，过滤零散噪点。
    # UI发光圆头/抗锯齿可能让12点第0格或中途1~2格短暂缺色。
    # 允许起点最多缺2格；中间最多桥接2格，但必须被真实亮格夹住。
    LIBERATION_START_GAP_TOLERANCE = 2  # R能量环12点起始位置允许缺失的格数，用于兼容圆头和抗锯齿。
    LIBERATION_INTERNAL_GAP_TOLERANCE = 2  # R能量弧内部允许桥接的连续缺口格数，用于兼容短暂漏色。

    LIBERATION_ENERGY_PREP_SAMPLE_INTERVAL = 0.10  # 忌炎补R阶段重新读取能量环的间隔（秒）。
    LIBERATION_ENERGY_READY_CONFIRM_FRAMES = 2  # R能量与冷却条件需要连续成立的帧数，防止单帧误判完成。
    LIBERATION_ENERGY_MID_THRESHOLD = 0.80  # R能量中段参考比例：用于日志和阶段显示，不是最终放行门。
    LIBERATION_ENERGY_FINAL_THRESHOLD =0.85  # R准备完成目标比例：达到该能量且冷却满足要求后，才进入后续Q与回莫。
    LIBERATION_CD_NEAR_READY = 2.00  # 允许通过最终R准备门的最大剩余冷却（秒）。
    LIBERATION_ENERGY_PREP_SLICE = 3.0  # 每次进入补R阶段最多连续工作多久（秒），到时让出控制权以保持框架响应。
    LIBERATION_ENERGY_ATTACK_INTERVAL = 0.08  # 忌炎补R期间两次A的最短间隔（秒）。

    # 青龙调试节奏：第一段连续点击A -> 短按一次无方向闪避 -> W+第二段连续点击A。
    # 下列时间单位均为秒；A表示点击鼠标普攻，不是按键盘字母a，也不是长按鼠标。
    # 1.20仅沿用为第一段的初始时长；连续点击后的取消时机需要重新实机调试。
    QINGLONG_ATTACK_TO_DODGE_TIME = 0.70  # 第一段平A总时长：从开始输入算起，期间按下方间隔重复点击A。
    QINGLONG_ATTACK_INTERVAL = 0.08  # 第一段平A点击间隔：0.20表示约每0.2秒点击一次，可改为0.30。
    QINGLONG_DODGE_PRESS_TIME = 0.01  # 单次闪避短按时长：只按一次并松开，不连续补发闪避。
    QINGLONG_DODGE_TO_FORWARD_ATTACK_TIME = 0  # 闪避键松开后，到开始W+第二段平A的等待时间。
    QINGLONG_FORWARD_KEY = 'w'  # 第二段使用的前进键：按住它的同时点击普攻，不再发送第二次闪避。
    QINGLONG_FORWARD_HOLD_TIME = 0.15  # 第二段W按住时长：从第二段开始独立计时，到时松开。
    QINGLONG_FORWARD_ATTACK_TIME = 0.70  # 第二段平A总时长：从第二段开始独立计时，到时停止本段点击。
    QINGLONG_FORWARD_ATTACK_INTERVAL = 0.08  # 第二段平A点击间隔：可单独改为0.30等数值。
    # W和平A同时开始、分别到时结束：W短则松W后继续A，W长则停A后继续W。
    # 第二段总耗时取W时长和平A时长中的较大值；强化窗口结束或异常时会松开W。

    # R 强化期从 UI 恢复第一帧开始检查 F；视觉检测不跟每次 A 同频。
    F_CHECK_INTERVAL = 0.20  # 忌炎在场时检测F处决提示的最短间隔（秒）。

    RESONANCE_READY_TIMEOUT = 2.0  # 等待忌炎E可用并确认释放的最长时间（秒）；等待期间会用A填充。
    CONCERTO_FILL_TIMEOUT = 6.0  # 补协奏最长时间（秒）：超过仍未满就停止本轮尝试，防止无限攻击。
    STATE_POLL_INTERVAL = 0.05  # 状态刷新间隔（秒）：每隔多久更新画面并重新判断；调小反应更快，但会增加识别频率。
    ACTION_RETRY_INTERVAL = 0.05  # 动作重试间隔（秒）：E/Q/R等输入失败后，至少隔多久再发一次。
    DODGE_BUFFER_TIME = 0.12  # 闪避输入缓冲总时长（秒）：短时间重复输入，降低单次闪避被动作后摇吞掉的概率。
    DODGE_RETRY_INTERVAL = 0.05  # 闪避键重发间隔（秒）：仅在闪避缓冲窗口内使用。

    SWITCH_TIMEOUT = 6.0  # 精确切人最长等待时间（秒）：包括等待换人冷却和确认目标角色上场。
    SWITCH_RETRY_INTERVAL = 0.04  # 切人键重发间隔（秒）：目标角色尚未上场时按此频率重试。

    def _clear_red_light_rotation_state(self):
        """退出指定队伍或结束战斗时，清理红绿灯轴的共享阶段与独占切人标记。"""
        for key in ('red_light_rotation_state', 'red_light_fsm_exclusive_switch_logged'):
            if hasattr(self.task, key):
                delattr(self.task, key)

    def _red_light_team_matches(self):
        """只在框架已识别出忌炎、莫特斐、维里奈三人时启用合轴；队伍顺序不限。"""
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            chars = ()
        # 使用框架识别的角色身份，不依赖中文显示名或当前谁在场；未知身份不放行。
        # 兼容带labels.前缀的新身份名称与旧名称；只去掉开头的已知前缀，不修改角色对象。
        signature = tuple(
            (str(getattr(char, 'char_name', '') or '').casefold().removeprefix('labels.'), getattr(char, 'index', None))
            for char in chars
        )
        required = {'char_jiyan', 'char_mortefi', 'char_verina'}
        matched = (
            len(chars) == 3
            and {name for name, _ in signature} == required
            and any(char is self for char in chars)
        )
        previous = getattr(self.task, 'red_light_team_signature', None)
        if signature != previous:
            # 换队/调整位置后重新开始，不能继承另一队或旧位置留下的P2/P3进度。
            self._clear_red_light_rotation_state()
            self.task.red_light_team_signature = signature
            mode = 'red-light rotation' if matched else 'builtin character rotation'
            self.logger.info(f'team changed -> {mode}; members={signature}')
        elif not matched:
            # 即使队伍没变，也不让历史FSM状态干涉内置角色的正常切人。
            self._clear_red_light_rotation_state()
        return matched

    def do_perform(self):
        """读取共享流程状态，只执行当前轮到忌炎负责的阶段。"""
        if not self._red_light_team_matches():
            return super().do_perform()  # 非指定队伍：执行对应角色的内置动作，而非BaseChar通用动作。

        state = self._get_rotation_state()  # 取得三角色共享FSM状态，必要时初始化为第一套开场步骤
        if not self._restore_f_resume_phase(state):
            # F结束后队伍UI/当前角色尚未稳定时，保留恢复阶段，下轮再继续原动作。
            return
        step = state['step']

        # 三个特殊变奏爆发仅在phase=burst时优先立即缓冲R；R完成后若正处于
        # switch_mort重试阶段，仍要恢复通用F检测，不能因为STEP名称没变而漏掉F。
        burst_phase_keys = {
            self.STEP_P1_JIYAN_BURST_R: 'p1_jiyan_burst_phase',
            self.STEP_P2_JIYAN_BURST_R: 'p2_jiyan_burst_phase',
            self.STEP_P3_JIYAN_BURST_R: 'p3_jiyan_burst_phase',
        }
        skip_f_for_first_r = (
            step in burst_phase_keys
            and state.get(burst_phase_keys[step], 'burst') == 'burst'
        )
        # 老版飞廉第一段命中后还要继续生成二段。这个约0.30秒的保护阶段内，
        # F不能抢占，否则可能在二段真正出手前取消声骸；二段出手后立即恢复F检测。
        skip_f_for_feilian_second = (
            step == self.STEP_P1_JIYAN_A_WAIT_Q_TO_MORT
            and state.get('pre_jiyan_echo_phase') == 'wait_feilian_second'
        ) or (
            step in {
                self.STEP_P2_JIYAN_R_PREP_Q_TO_MORT,
                self.STEP_P3_JIYAN_R_PREP_Q_TO_MORT,
            }
            and state.get('jiyan_energy_phase') == 'wait_feilian_second'
        )
        if not skip_f_for_first_r and not skip_f_for_feilian_second:
            if self._field_f_check(
                force=True,
                resume_label=f'before-step:{step}',
            ):
                # F作为独立插入阶段执行。本轮到此为止；下一次perform读取同一STEP/phase继续。
                return

        self.logger.info(
            f'jiyan FSM step={step} intro={self.has_intro}'
        )

        if step == self.STEP_P1_JIYAN_OPEN_E:
            return self._p1_opening_e(state)
        if step == self.STEP_P1_JIYAN_BURST_R:
            return self._p1_burst_r(state)
        if step == self.STEP_P2_JIYAN_QUICK_E_TO_MORT:
            return self._p2_quick_e_to_mort(state)
        if step == self.STEP_P2_JIYAN_R_PREP_Q_TO_MORT:
            return self._jiyan_energy_prep(state)
        if step == self.STEP_P2_JIYAN_BURST_R:
            return self._p2_burst_r(state)
        if step == self.STEP_P3_JIYAN_E_A_HEAVY_TO_MORT:
            return self._p3_e_a_heavy_to_mort(state)
        if step == self.STEP_P3_JIYAN_R_PREP_Q_TO_MORT:
            return self._jiyan_energy_prep(state)
        if step == self.STEP_P3_JIYAN_BURST_R:
            return self._p3_burst_r(state)
        if step == self.STEP_P1_JIYAN_A_WAIT_Q_TO_MORT:
            return self._p1_jiyan_a_wait_q_to_mort(state)

        return self._recover_wrong_actor(state)

    # =========================================================
    # 第一套
    # =========================================================

    def _p1_opening_e(self, state):
        # 忌 E -> 普通轮切莫 -> 莫 A
        """第一套开场：忌炎确认E释放后普通切莫特斐。"""
        phase_key = 'p1_jiyan_open_phase'
        phase = state.get(phase_key, 'cast_e')

        if phase == 'cast_e':
            resonance_result = self._cast_resonance_when_ready(
                timeout=self.RESONANCE_READY_TIMEOUT
            )
            if resonance_result is None:
                # F插入已保存当前STEP/phase；下一轮仍从cast_e恢复。
                return
            if not resonance_result:
                self.logger.warning('jiyan P1 opening E failed; keep phase=cast_e')
                return
            state[phase_key] = 'switch_mort'
            phase = 'switch_mort'
            self.logger.info(
                'jiyan P1 opening E confirmed -> phase=switch_mort; '
                'switch retries will not repeat E'
            )

        if phase != 'switch_mort':
            self.logger.warning(
                f'jiyan P1 opening unknown phase={phase}; reset to cast_e'
            )
            state[phase_key] = 'cast_e'
            return

        if self._switch_to(
            self.TARGET_MORTEFI,
            expect_intro=False,
        ):
            state.pop(phase_key, None)
            state['step'] = self.STEP_P1_MORT_AUTO_TO_VERINA

    def _p1_burst_r(self, state):
        # 第一套：变奏忌 -> R -> UI恢复T0 -> F/E -> 10.7s强化A -> E或闪避取消结束后摇
        # -> E可用即E，否则A补协奏 -> 满协奏稳定确认 -> 变奏莫。
        """第一套爆发：R循环只执行一次；完成后只重试自然切莫。"""
        phase_key = 'p1_jiyan_burst_phase'
        phase = state.get(phase_key, 'burst')

        if phase == 'burst':
            if not self._run_liberation_cycle():
                self.logger.warning(
                    'jiyan P1 liberation cycle could not start; keep phase=burst'
                )
                return
            state[phase_key] = 'switch_mort'
            phase = 'switch_mort'
            self.logger.info(
                'jiyan P1 burst complete -> phase=switch_mort; '
                'switch retries will not replay R'
            )

        if phase != 'switch_mort':
            self.logger.warning(
                f'jiyan P1 burst unknown phase={phase}; reset to burst'
            )
            state[phase_key] = 'burst'
            return

        if self._switch_to(
            self.TARGET_MORTEFI,
            expect_intro=None,
        ):
            state.pop(phase_key, None)
            state['step'] = self.STEP_P2_MORT_INTRO_E_TO_JIYAN

    # =========================================================
    # 第二套
    # =========================================================

    def _p2_quick_e_to_mort(self, state):
        """
        第二套：莫普通切忌 -> 切入稳定后尝试一次 E -> 无论 E 是否成功都普通切莫。

        这里不为了 E 等 CD，也不因为 E 失败阻塞 FSM。
        额外给一个很短的切入稳定窗，避免鸣潮预输入把 E 提前压进换人过渡。
        """
        phase_key = 'p2_jiyan_quick_phase'
        phase = state.get(phase_key, 'action')

        if phase == 'action':
            self.sleep(self.NORMAL_SWITCH_ACTION_SETTLE_TIME)
            self.task.next_frame()

            e_casted = self._cast_resonance_if_ready_once('P2 quick E')
            replay_after_f = False
            if not e_casted:
                # 实机若 E/Q 同时在 CD，原流程会短暂原地无动作。
                # 此时补一次 A + Z，再切莫；若 Q 已亮则不浪费时间做这个兜底。
                if not self.echo_available():
                    self.logger.info('jiyan P2 E/Q unavailable -> fallback A + heavy before Mortefi')
                    self.normal_attack()
                    self.heavy_attack()  # 发送一次重击输入
                    replay_after_f = True
                else:
                    self.logger.info('jiyan P2 E unavailable but Q ready -> skip idle fallback and switch')

            # E已经视觉确认时无需重放；未确认的A+重击若被F打断，则下一轮重做action。
            state[phase_key] = 'action' if replay_after_f else 'snapshot'
            if self._field_f_check(
                force=True,
                resume_label='P2-quick-action-exit',
            ):
                return
            state[phase_key] = 'snapshot'
            phase = 'snapshot'

        if phase == 'snapshot':
            self.get_red_light_skill_snapshot(
                refresh_energy=True,
                log=True,
                label='P2-quick-E-exit',
            )
            state[phase_key] = 'switch_mort'
            phase = 'switch_mort'

        if phase == 'switch_mort':
            if self._switch_to(
                self.TARGET_MORTEFI,
                expect_intro=False,
            ):
                state.pop(phase_key, None)
                state['step'] = self.STEP_P2_MORT_AUTO_TO_VERINA
            return

        self.logger.warning(
            f'jiyan P2 quick unknown phase={phase}; reset to action'
        )
        state[phase_key] = 'action'

    def _p2_burst_r(self, state):
        """第二套爆发：R循环只执行一次；结束后无论协奏是否满都自然切莫。"""
        phase_key = 'p2_jiyan_burst_phase'
        phase = state.get(phase_key, 'burst')

        if phase == 'burst':
            if not self._run_liberation_cycle():
                self.logger.warning(
                    'jiyan V3.1 P2 liberation cycle could not start; keep phase=burst'
                )
                return
            state[phase_key] = 'switch_mort'
            phase = 'switch_mort'
            self.logger.info(
                'jiyan V3.1 P2 burst complete -> phase=switch_mort; '
                'do not refill concerto and never replay R on switch retry'
            )

        if phase == 'switch_mort':
            if self._switch_to(self.TARGET_MORTEFI, expect_intro=None):
                state.pop(phase_key, None)
                state['step'] = self.STEP_P3_MORT_INTRO_E_TO_JIYAN
                return
            self.logger.warning(
                'jiyan V3.1 P2 natural switch Mortefi pending; retry switch only'
            )
            return

        self.logger.warning(
            f'jiyan V3.1 P2 burst unknown phase={phase}; reset to burst'
        )
        state[phase_key] = 'burst'

    # =========================================================
    # 第三套 / 无限循环
    # =========================================================

    def _p3_e_a_heavy_to_mort(self, state):
        """
        第三套：E -> A 一次 -> 重击 Z -> 普通切莫。
        这里明确不再检测/释放 Q；Q 留给后续轴。
        """
        phase_key = 'p3_jiyan_combo_phase'
        phase = state.get(phase_key, 'cast_e')

        if phase == 'cast_e':
            resonance_result = self._cast_resonance_when_ready(
                timeout=self.RESONANCE_READY_TIMEOUT
            )
            if resonance_result is None:
                return
            if not resonance_result:
                self.logger.warning(
                    'jiyan P3 resonance failed; continue phase=attack_heavy'
                )
            state[phase_key] = 'attack_heavy'
            phase = 'attack_heavy'

        if phase == 'attack_heavy':
            # A+重击没有可靠的UI消耗确认。若随后检测到F，就保留本phase并在F后重做，
            # 宁可重复一次，也不让被F取消的动作直接跨到切人。
            self.normal_attack()
            self.heavy_attack()  # 发送一次重击输入
            if self._field_f_check(
                force=True,
                resume_label='P3-A-heavy-exit',
            ):
                return
            state[phase_key] = 'snapshot'
            phase = 'snapshot'

        if phase == 'snapshot':
            self.get_red_light_skill_snapshot(
                refresh_energy=True,
                log=True,
                label='P3-E-A-heavy-exit',
            )
            state[phase_key] = 'switch_mort'
            phase = 'switch_mort'

        if phase == 'switch_mort':
            if self._switch_to(
                self.TARGET_MORTEFI,
                expect_intro=None,  # 自然切莫：协奏满则允许变奏，不满则普通切；不以R能量作为切人条件。
            ):
                state.pop(phase_key, None)
                state['step'] = self.STEP_P3_MORT_AUTO_TO_VERINA
            return

        self.logger.warning(
            f'jiyan P3 combo unknown phase={phase}; reset to cast_e'
        )
        state[phase_key] = 'cast_e'

    def _p3_burst_r(self, state):
        """第三套循环爆发：R循环只执行一次；结束后无论协奏是否满都自然切莫。"""
        phase_key = 'p3_jiyan_burst_phase'
        phase = state.get(phase_key, 'burst')

        if phase == 'burst':
            if not self._run_liberation_cycle():
                self.logger.warning(
                    'jiyan V3.1 P3 liberation cycle could not start; keep phase=burst'
                )
                return
            state[phase_key] = 'switch_mort'
            phase = 'switch_mort'
            self.logger.info(
                'jiyan V3.1 P3 burst complete -> phase=switch_mort; '
                'do not refill concerto and never replay R on switch retry'
            )

        if phase == 'switch_mort':
            if self._switch_to(self.TARGET_MORTEFI, expect_intro=None):
                state.pop(phase_key, None)
                state['step'] = self.STEP_P3_MORT_INTRO_E_TO_JIYAN
                return
            self.logger.warning(
                'jiyan V3.1 P3 natural switch Mortefi pending; retry switch only'
            )
            return

        self.logger.warning(
            f'jiyan V3.1 P3 burst unknown phase={phase}; reset to burst'
        )
        state[phase_key] = 'burst'

    # =========================================================
    # 动作辅助
    # =========================================================

    def _p1_jiyan_a_wait_q_to_mort(self, state):
        """P1忌Q插入：A覆盖换人CD，确认Q并等老版飞廉二段出手后自然切莫。"""
        self._wait_intro_if_needed()  # 如果本次是变奏入场，则等待入场动作结束

        return_step = state.get('pre_jiyan_echo_return_step')
        if not return_step:
            self.logger.error('jiyan pre-intro Q missing return step')
            state['step'] = self.STEP_P1_JIYAN_OPEN_E
            state.pop('pre_jiyan_echo_phase', None)
            state.pop('pre_jiyan_echo_cast_attempted', None)
            state.pop('pre_jiyan_echo_switch_wait_done', None)
            state.pop('pre_jiyan_echo_second_started_at', None)
            return

        phase_key = 'pre_jiyan_echo_phase'
        phase = state.get(phase_key, 'wait_switch')

        if phase == 'wait_switch':
            # 先用平A覆盖莫的换人CD；F若在这里插入，本轮立即退出，
            # 下一轮仍从wait_switch恢复，绝不会越过Q阶段直接切人。
            switch_ready = self._attack_until_mortefi_switch_ready(
                max_wait=self.PRE_ECHO_SWITCH_READY_ATTACK_TIME
            )
            if switch_ready is None:
                return
            state['pre_jiyan_echo_switch_wait_done'] = True
            state[phase_key] = 'cast_q'
            phase = 'cast_q'

        if phase == 'cast_q':
            if self._field_f_check(
                force=True,
                resume_label='P1-pre-Q-cast',
            ):
                # phase已经是cast_q；F后会从这里重新确认并发送Q。
                return
            if self.echo_available():
                # time_out=0只代表“发出了Q键”，不能证明游戏接受了输入。
                # 这里持续缓冲到Q图标进入CD；未确认时保留cast_q，下轮继续。
                if not self._click_echo_confirmed('pre-intro Q'):
                    self.logger.warning(
                        'jiyan pre-intro Q input sent but consumption was not confirmed; '
                        'keep phase=cast_q'
                    )
                    self.sleep(self.STATE_POLL_INTERVAL)
                    self.task.next_frame()
                    return
                self.logger.info(
                    'jiyan pre-intro Q consumption confirmed '
                    '-> phase=wait_feilian_second'
                )
                state['pre_jiyan_echo_second_started_at'] = time.time()
                state[phase_key] = 'wait_feilian_second'
                phase = 'wait_feilian_second'
            else:
                self.logger.info('jiyan pre-intro Q unavailable -> skip')
                state[phase_key] = 'switch_mort'
                phase = 'switch_mort'
            state['pre_jiyan_echo_cast_attempted'] = True

        if phase == 'wait_feilian_second':
            self._wait_old_feilian_second_stage(
                state,
                start_key='pre_jiyan_echo_second_started_at',
                label='P1-pre-intro-Q',
            )
            state[phase_key] = 'switch_mort'
            phase = 'switch_mort'

        if phase != 'switch_mort':
            self.logger.warning(
                f'jiyan pre-intro Q unknown phase={phase}; reset to wait_switch'
            )
            state[phase_key] = 'wait_switch'
            state.pop('pre_jiyan_echo_second_started_at', None)
            return

        # expect_intro=None：若忌在这1秒里意外把协奏补满，也必须照样切莫，
        # 由有效满协奏判定自然决定普通切/特殊变奏，不再死锁在普通切保护上。
        if self._switch_to(self.TARGET_MORTEFI, expect_intro=None):
            state['step'] = return_step
            state.pop('pre_jiyan_echo_return_step', None)
            state.pop('pre_jiyan_echo_cast_attempted', None)
            state.pop('pre_jiyan_echo_switch_wait_done', None)
            state.pop('pre_jiyan_echo_second_started_at', None)
            state.pop(phase_key, None)

    def _attack_until_mortefi_switch_ready(self, max_wait):
        """P1忌Q前短A：莫的wait_switch()一结束就停止，最多约max_wait秒。"""
        target = self._find_target_char(self.TARGET_MORTEFI)
        if target is None:
            self.logger.warning('jiyan pre-Q switch-CD wait: Mortefi not found -> skip')
            return False

        start = time.time()
        last_attack = -100.0
        attacks = 0
        ready = False

        while self.time_elapsed_accounting_for_freeze(start) < max_wait:
            if self._field_f_check(resume_label='P1-pre-Q-switch-wait'):
                # None专门表示F插入中断；调用者必须保留wait_switch阶段并结束本轮。
                return None
            self.task.next_frame()
            try:
                waiting = bool(target.wait_switch())
            except Exception:
                waiting = True

            if not waiting:
                ready = True
                break  # 立即跳出当前循环，继续执行循环之后的代码

            now = time.time()
            if now - last_attack >= self.PRE_ECHO_SWITCH_READY_ATTACK_INTERVAL:
                self.normal_attack()
                last_attack = now
                attacks += 1

            self.sleep(self.STATE_POLL_INTERVAL)

        if not ready:
            try:
                ready = not bool(target.wait_switch())
            except Exception:
                ready = False

        elapsed = self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
        self.logger.info(
            f'jiyan pre-Q Mortefi switch-CD cover ended: ready={ready} '
            f'attacks={attacks} elapsed={elapsed:.2f}s'
        )
        return ready

    def _sample_liberation_ring_progress(self):
        """V2.8沿用V2.5实机标定：读取R最外圈青绿色连续充能弧。

        几何：
        - box_liberation中心作为R中心；
        - true_radius = base_r * 1.35；
        - 正式环 = true_radius * 0.95~1.05。

        颜色：
        - 官方风属性RGB mask；
        - 实机标定HSV青绿色mask；
        - 二者取并集后做3x3 close。

        进度：
        - 12点=bin0；
        - 屏幕逆时针；
        - 72格；
        - 允许起点最多2格缺口和中间最多2格短洞。
        """
        if not self.is_current_char:
            return None

        try:
            box = self.task.get_box_by_name('box_liberation')
            frame = self.task.frame
        except Exception:
            return None

        if frame is None or getattr(frame, 'ndim', 0) < 3:
            return None

        roi_mode = 'expanded-frame'
        try:
            bx = float(box.x)
            by = float(box.y)
            bw = float(box.width)
            bh = float(box.height)
            base_radius = min(bw, bh) / 2.0
            center_x = bx + bw / 2.0
            center_y = by + bh / 2.0
            half = base_radius * float(self.LIBERATION_ENERGY_ROI_SCALE)

            fh, fw = frame.shape[:2]
            x0 = max(0, int(math.floor(center_x - half)))
            x1 = min(fw, int(math.ceil(center_x + half)))
            y0 = max(0, int(math.floor(center_y - half)))
            y1 = min(fh, int(math.ceil(center_y + half)))
            if x1 - x0 < 8 or y1 - y0 < 8:
                return None
            image = frame[y0:y1, x0:x1, :3]
            cx = center_x - x0
            cy = center_y - y0
        except Exception:
            roi_mode = 'fallback-box-crop'
            try:
                image = box.crop_frame(frame)
            except Exception:
                return None
            if image is None or getattr(image, 'ndim', 0) < 3:
                return None
            image = image[..., :3]
            h0, w0 = image.shape[:2]
            base_radius = min(float(w0), float(h0)) / 2.0
            cx = (w0 - 1) / 2.0
            cy = (h0 - 1) / 2.0

        if base_radius < 4:
            return None

        # 官方风属性色mask。
        lower, upper = color_range_to_bound(self.LIBERATION_RING_COLOR)
        official_mask = cv2.inRange(image, lower, upper)

        # V2.4实机raw表明真正R能量弧是连续青绿色，严格RGB只命中零散像素。
        # 直接在当前OK-WW frame上按OpenCV BGR->HSV读取该发光轨迹。
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        hsv_lower = np.array(self.LIBERATION_HSV_LOWER, dtype=np.uint8)
        hsv_upper = np.array(self.LIBERATION_HSV_UPPER, dtype=np.uint8)
        hsv_mask = cv2.inRange(hsv, hsv_lower, hsv_upper)

        raw_mask = cv2.bitwise_or(official_mask, hsv_mask)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        color_mask = cv2.morphologyEx(raw_mask, cv2.MORPH_CLOSE, kernel)

        h, w = image.shape[:2]
        yy, xx = np.ogrid[:h, :w]  # 执行图像/数值计算，为视觉识别生成坐标、颜色掩码或统计结果
        dx = xx - float(cx)
        dy = yy - float(cy)
        radius_px = np.sqrt(dx ** 2 + dy ** 2)

        true_icon_radius = float(base_radius) * float(self.LIBERATION_ICON_RADIUS_SCALE)
        inner_radius = true_icon_radius * float(self.LIBERATION_ENERGY_RING_INNER_RATIO)
        outer_radius = true_icon_radius * float(self.LIBERATION_ENERGY_RING_OUTER_RATIO)
        annulus = (radius_px >= inner_radius) & (radius_px <= outer_radius)

        # 图像坐标y向下。alpha: 3点=0, 6点=pi/2, 9点=pi, 12点=3pi/2。
        alpha = (np.arctan2(dy, dx) + 2 * np.pi) % (2 * np.pi)
        # 12点=0，沿屏幕逆时针递增。
        progress_angle = (1.5 * np.pi - alpha) % (2 * np.pi)
        colored = color_mask > 0

        bin_count = int(self.LIBERATION_ENERGY_ANGLE_BINS)
        coverages = []
        for i in range(bin_count):
            lo = 2 * np.pi * i / bin_count
            hi = 2 * np.pi * (i + 1) / bin_count
            sector = annulus & (progress_angle >= lo) & (progress_angle < hi)
            total = int(np.count_nonzero(sector))
            if total <= 0:
                coverages.append(0.0)
                continue
            hit = int(np.count_nonzero(colored & sector))
            coverages.append(hit / total)

        if not coverages:
            return None

        peak = max(coverages)
        threshold = max(
            float(self.LIBERATION_BIN_MIN_COLOR_COVERAGE),
            peak * float(self.LIBERATION_BIN_RELATIVE_COVERAGE),
        )
        active = [value >= threshold for value in coverages]
        smooth = active[:]

        # 起点容错：真实发光弧从12点开始，但圆头/抗锯齿可能使bin0~bin1覆盖不足。
        start_tol = max(0, int(self.LIBERATION_START_GAP_TOLERANCE))
        first_active = None
        for i in range(min(bin_count, start_tol + 1)):
            if active[i]:
                first_active = i
                break  # 立即跳出当前循环，继续执行循环之后的代码
        if first_active is not None:
            for i in range(first_active):
                smooth[i] = True

        # 中间短洞容错：只补被亮格夹住的1~2格空洞，不跨越真实终点。
        gap_tol = max(0, int(self.LIBERATION_INTERNAL_GAP_TOLERANCE))
        i = 1
        while i < bin_count - 1:
            if smooth[i]:
                i += 1
                continue
            gap_start = i
            while i < bin_count and not smooth[i]:
                i += 1
            gap_len = i - gap_start
            if (
                gap_len <= gap_tol
                and gap_start > 0
                and i < bin_count
                and smooth[gap_start - 1]
                and smooth[i]
            ):
                # 要求空洞之后至少还有一个真实亮格，避免把圆弧真正终点误桥接到孤立噪声。
                next_confirm = (i + 1 < bin_count and active[i + 1])
                if next_confirm or gap_len == 1:
                    for j in range(gap_start, i):
                        smooth[j] = True

        filled_bins = 0
        if first_active is not None:
            for value in smooth:
                if not value:
                    break  # 立即跳出当前循环，继续执行循环之后的代码
                filled_bins += 1

        energy = max(0.0, min(1.0, filled_bins / float(bin_count)))
        return {
            'energy': energy,
            'filled_bins': filled_bins,
            'threshold': threshold,
            'peak': peak,
            'coverages': coverages,
            'roi_mode': roi_mode,
            'base_radius': float(base_radius),
            'true_icon_radius': true_icon_radius,
            'inner_radius': inner_radius,
            'outer_radius': outer_radius,
        }

    def _reset_liberation_energy_tracking(self):
        """每次R成功消耗后清空上一轮R圆弧识别状态。"""
        self._lib_energy_estimate = 0.0
        self._lib_energy_filled_bins = 0
        self._lib_energy_last_threshold = 0.0
        self._lib_energy_last_peak = 0.0
        self._lib_energy_last_coverages = []
        self._lib_energy_last_roi_mode = 'unknown'
        self._lib_energy_base_radius = None
        self._lib_energy_true_radius = None
        self.logger.info(
            'jiyan liberation-energy tracking reset; V2.8 calibrated outer ring + RGB/HSV mask + 72-bin arc'
        )
        return True

    def read_liberation_energy_estimate(self):
        """返回0~1的R能量圆弧估算；最终门仍严格使用filled_bins。"""
        if not self.is_current_char:
            return getattr(self, '_lib_energy_estimate', None)

        result = self._sample_liberation_ring_progress()
        if result is None:
            return getattr(self, '_lib_energy_estimate', None)

        self._lib_energy_estimate = float(result['energy'])
        self._lib_energy_filled_bins = int(result['filled_bins'])
        self._lib_energy_last_threshold = float(result['threshold'])
        self._lib_energy_last_peak = float(result.get('peak', 0.0))
        self._lib_energy_last_coverages = list(result['coverages'])
        self._lib_energy_last_roi_mode = str(result.get('roi_mode', 'unknown'))
        self._lib_energy_base_radius = float(result.get('base_radius', 0.0) or 0.0)
        self._lib_energy_true_radius = float(result.get('true_icon_radius', 0.0) or 0.0)
        return self._lib_energy_estimate

    def get_red_light_skill_snapshot(self, refresh_energy=False, log=False, label='snapshot'):
        """V2.8统一E/Q/R冷却 + 实机标定R能量快照。"""
        try:
            e_cd = max(0.0, float(self.task.get_cd('resonance', self.index)))
        except Exception:
            e_cd = 0.0
        try:
            q_cd = max(0.0, float(self.task.get_cd('echo', self.index)))
        except Exception:
            q_cd = 0.0
        try:
            r_cd = max(0.0, float(self.task.get_cd('liberation', self.index)))
        except Exception:
            r_cd = 0.0

        if refresh_energy and self.is_current_char:
            energy = self.read_liberation_energy_estimate()
        else:
            energy = getattr(self, '_lib_energy_estimate', None)

        on_field_ready = bool(self.is_current_char and self.liberation_available())  # 检测R当前是否可用
        if energy is None:
            r_state = 'READY_UNKNOWN_ENERGY' if on_field_ready else 'UNKNOWN'
        elif energy < self.LIBERATION_ENERGY_MID_THRESHOLD:
            r_state = 'LOW_ENERGY'
        elif energy < self.LIBERATION_ENERGY_FINAL_THRESHOLD:
            r_state = 'MID_ENERGY'
        elif r_cd > self.LIBERATION_CD_NEAR_READY:
            r_state = 'HIGH_ENERGY_CD_WAIT'
        else:
            r_state = 'READY' if on_field_ready else 'NEAR_READY'

        filled_bins = getattr(self, '_lib_energy_filled_bins', None)
        snap = {
            'resonance_cd': e_cd,
            'echo_cd': q_cd,
            'liberation_cd': r_cd,
            'liberation_energy': energy,
            'liberation_filled_bins': filled_bins,
            'liberation_state': r_state,
        }
        if log:
            energy_text = 'unknown' if energy is None else f'{energy:.3f}'
            arc_text = (
                'unknown'
                if filled_bins is None
                else f'{int(filled_bins)}/{self.LIBERATION_ENERGY_ANGLE_BINS}'
            )
            threshold = float(getattr(self, '_lib_energy_last_threshold', 0.0) or 0.0)
            peak = float(getattr(self, '_lib_energy_last_peak', 0.0) or 0.0)
            coverages = list(getattr(self, '_lib_energy_last_coverages', []) or [])
            roi_mode = str(getattr(self, '_lib_energy_last_roi_mode', 'unknown') or 'unknown')
            base_r = getattr(self, '_lib_energy_base_radius', None)
            true_r = getattr(self, '_lib_energy_true_radius', None)
            boundary = ''
            if coverages and filled_bins is not None:
                lo = max(0, int(filled_bins) - 2)
                hi = min(len(coverages), int(filled_bins) + 3)
                boundary = ' boundary=' + ','.join(
                    f'{i}:{coverages[i]:.2f}' for i in range(lo, hi)
                )
            self.logger.info(
                f'jiyan skill snapshot {label}: E_cd={e_cd:.2f} Q_cd={q_cd:.2f} '
                f'R_cd={r_cd:.2f} R_arc={arc_text} R_energy={energy_text} '
                f'R_color_peak={peak:.3f} R_bin_threshold={threshold:.3f} '
                f'R_icon_scale={self.LIBERATION_ICON_RADIUS_SCALE:.2f} '
                f'R_ring=0.95-1.05*true_r R_roi={roi_mode} '
                f'R_base_r={"unknown" if base_r is None else f"{float(base_r):.2f}"} '
                f'R_true_r={"unknown" if true_r is None else f"{float(true_r):.2f}"} '
                f'R_state={r_state}{boundary}'
            )
        return snap

    def _prepare_liberation_energy_on_field(
        self,
        target_energy,
        max_cd,
        timeout,
        label,
        confirm_frames=1,
        stop_on_concerto_full=False,
    ):
        """V3.1快速R准备：固定轴优先，协奏满不再中断R能量准备。

        只有“R圆弧达到目标 + R CD达到目标”连续confirm_frames次成立才返回True；
        在此之前持续E>A补R。stop_on_concerto_full参数仅为兼容旧调用保留，V3.1忽略它。
        """
        start = time.time()
        last_attack = -100.0
        last_energy_sample = -100.0
        last_log = -100.0
        ready_streak = 0
        confirm_frames = max(1, int(confirm_frames))
        required_bins = int(math.ceil(
            self.LIBERATION_ENERGY_ANGLE_BINS * float(target_energy)
        ))
        if abs(float(target_energy) - self.LIBERATION_ENERGY_FINAL_THRESHOLD) < 1e-6:
            required_bins = max(required_bins, int(self.LIBERATION_ENERGY_READY_BINS))

        while self.time_elapsed_accounting_for_freeze(start) < timeout:
            if self._field_f_check(resume_label=f'{label}-energy-prep'):
                # 当前jiyan_energy_phase仍是prep；下一次perform从同一阶段重新采样双条件。
                return False
            now = time.time()

            if now - last_energy_sample >= self.LIBERATION_ENERGY_PREP_SAMPLE_INTERVAL:
                snap = self.get_red_light_skill_snapshot(refresh_energy=True)
                filled_bins = snap.get('liberation_filled_bins')
                cd_ok = (
                    max_cd is None
                    or snap.get('liberation_cd', 99.0) <= max_cd
                )
                energy_ok = (
                    filled_bins is not None
                    and int(filled_bins) >= required_bins
                )

                if energy_ok and cd_ok:
                    ready_streak += 1
                else:
                    ready_streak = 0

                if ready_streak >= confirm_frames:
                    self.get_red_light_skill_snapshot(
                        refresh_energy=False,
                        log=True,
                        label=f'{label}-goal-{ready_streak}x',
                    )
                    self.logger.info(
                        f'jiyan V3.1 {label}: R dual-condition confirmed '
                        f'{ready_streak}x -> mandatory Q next; concerto does not preempt'
                    )
                    return True
                last_energy_sample = now

            if now - last_log >= 0.60:
                self.get_red_light_skill_snapshot(
                    refresh_energy=False,
                    log=True,
                    label=(
                        f'{label}-arc>={required_bins}/'
                        f'{self.LIBERATION_ENERGY_ANGLE_BINS}-streak-{ready_streak}'
                    ),
                )
                last_log = now

            if self.resonance_available():
                if self._cast_resonance_if_ready_once(f'{label} energy E'):
                    self.task.next_frame()
                    continue

            if now - last_attack >= self.LIBERATION_ENERGY_ATTACK_INTERVAL:
                self.task.click()
                last_attack = now

            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        self.logger.info(
            f'jiyan {label}: fast energy-prep slice ended; '
            f'need_arc>={required_bins}/{self.LIBERATION_ENERGY_ANGLE_BINS}; keep same step'
        )
        return False

    def _jiyan_energy_prep(self, state):
        """P2/P3共享忌R插入分支：R双门 -> mandatory Q -> 飞廉二段出手 -> 自然切莫。

        V3.1取消“协奏满提前抢占”。协奏无论满不满都不能改变当前R-prep动作链；
        只有在Q成功之后，最终自然切莫时才由协奏决定普通切还是特殊变奏。
        """
        self._wait_intro_if_needed()
        probe_label = state.get('jiyan_energy_label', 'final-R-prep')
        phase = state.get('jiyan_energy_phase', 'prep')

        if phase == 'prep':
            if not self._prepare_liberation_energy_on_field(
                target_energy=self.LIBERATION_ENERGY_FINAL_THRESHOLD,
                max_cd=self.LIBERATION_CD_NEAR_READY,
                timeout=self.LIBERATION_ENERGY_PREP_SLICE,
                label=probe_label,
                confirm_frames=self.LIBERATION_ENERGY_READY_CONFIRM_FRAMES,
                stop_on_concerto_full=False,
            ):
                return
            state['jiyan_energy_phase'] = 'wait_q'
            phase = 'wait_q'
            self.logger.info(
                f'jiyan V3.1 {probe_label}: R conditions stable -> mandatory WAIT_Q; '
                'ignore concerto until Q succeeds'
            )

        if phase == 'wait_q':
            if self._field_f_check(resume_label=f'{probe_label}-WAIT_Q'):
                # F可能吞掉同一调用栈中紧随其后的Q；必须结束本轮并保留WAIT_Q。
                return
            if not self.echo_available():
                now = time.time()
                last_log = float(state.get('jiyan_energy_q_wait_last_log', 0.0) or 0.0)
                if now - last_log >= 0.50:
                    snap = self.get_red_light_skill_snapshot(
                        refresh_energy=False,
                        log=True,
                        label=f'{probe_label}-WAIT_Q',
                    )
                    self.logger.info(
                        f"jiyan V3.1 {probe_label}: mandatory Q not ready; stay on field, "
                        f"Q_cd={snap.get('echo_cd', 99.0):.2f}; concerto ignored"
                    )
                    state['jiyan_energy_q_wait_last_log'] = now
                self.sleep(self.STATE_POLL_INTERVAL)
                self.task.next_frame()
                return

            if not self._click_echo_confirmed(f'{probe_label} mandatory Q'):
                self.logger.warning(
                    f'jiyan V3.1 {probe_label}: mandatory Q input sent but consumption '
                    'was not confirmed; keep WAIT_Q'
                )
                self.sleep(self.STATE_POLL_INTERVAL)
                self.task.next_frame()
                return

            self.logger.info(
                f'jiyan V3.1 {probe_label}: mandatory Q consumption confirmed '
                '-> WAIT_FEILIAN_SECOND'
            )
            state['jiyan_energy_phase'] = 'wait_feilian_second'
            state['jiyan_energy_echo_second_started_at'] = time.time()
            state['jiyan_energy_goal_done'] = True
            state.pop('jiyan_energy_q_wait_last_log', None)
            phase = 'wait_feilian_second'

        if phase == 'wait_feilian_second':
            self._wait_old_feilian_second_stage(
                state,
                start_key='jiyan_energy_echo_second_started_at',
                label=f'{probe_label}-mandatory-Q',
            )
            state['jiyan_energy_phase'] = 'return_mort'
            phase = 'return_mort'

        if phase == 'return_mort':
            self._return_mortefi_from_energy_prep(
                state,
                goal_done=True,
                reason='R-goal-and-Q-complete',
            )

    def _return_mortefi_from_energy_prep(self, state, goal_done, reason):
        """补R分支统一回莫：有效满则自然特殊变奏，未满则普通切；不再硬编码普通切。"""
        return_step = state.get('jiyan_energy_return_step')
        if not return_step:
            self.logger.error('jiyan energy prep missing return step; reset opening')
            state['step'] = self.STEP_P1_JIYAN_OPEN_E
            state.pop('jiyan_energy_phase', None)
            state.pop('jiyan_energy_echo_second_started_at', None)
            return False

        gate_key = state.get('jiyan_energy_gate_key')
        if not self._switch_to(self.TARGET_MORTEFI, expect_intro=None):
            self.logger.info(
                f'jiyan energy-prep return Mortefi pending reason={reason} goal_done={goal_done}'
            )
            return False

        state['step'] = return_step
        # 无论普通切还是自然特殊变奏，莫回场都先走一次统一恢复门再续保存phase。
        state['mortefi_post_jiyan_ground_pending'] = True

        if goal_done and gate_key:
            # 只有R双条件稳定通过、Q成功、并真正回莫后才锁gate。
            state[gate_key] = True
        elif gate_key:
            self.logger.warning(
                f'jiyan V3.1 energy-prep returned without completed R+Q goal; '
                f'keep {gate_key} open for recovery'
            )

        self.logger.info(
            f'jiyan energy-prep returned Mortefi reason={reason} goal_done={goal_done} '
            f'natural_intro={bool(getattr(self._find_target_char(self.TARGET_MORTEFI), "has_intro", False))}'
        )

        state.pop('jiyan_energy_return_step', None)
        state.pop('jiyan_energy_label', None)
        state.pop('jiyan_energy_gate_key', None)
        state.pop('jiyan_energy_phase', None)
        state.pop('jiyan_energy_goal_done', None)
        state.pop('jiyan_energy_q_wait_last_log', None)
        state.pop('jiyan_energy_echo_second_started_at', None)
        return True

    def _wait_old_feilian_second_stage(self, state, start_key, label):
        """Q进入CD后只等到老版飞廉二段开始出手；保护窗内不插F、不追加其他输入。"""
        started_at = state.get(start_key)
        if not isinstance(started_at, (int, float)):
            started_at = time.time()
            state[start_key] = started_at
            self.logger.warning(
                f'jiyan {label}: missing Feilian second-stage timestamp; '
                'restart protection window'
            )

        wait_time = max(0.0, float(self.OLD_FEILIAN_SECOND_STAGE_WAIT_TIME))
        while self.time_elapsed_accounting_for_freeze(started_at) < wait_time:
            remaining = wait_time - self.time_elapsed_accounting_for_freeze(started_at)
            self.sleep(min(self.STATE_POLL_INTERVAL, max(0.001, remaining)))
            self.task.next_frame()

        elapsed = self.time_elapsed_accounting_for_freeze(started_at)
        state.pop(start_key, None)
        self.logger.info(
            f'jiyan {label}: old Feilian second-stage release protected '
            f'elapsed={elapsed:.2f}s -> allow Mortefi switch'
        )

    def _wait_intro_if_needed(self):
        """仅在确实带变奏入场时等待角色可操作；普通切入不会额外等待。"""
        if self.has_intro:
            self.wait_intro(
                time_out=self.INTRO_WAIT_TIMEOUT,
                click=False,
            )

    def _click_echo_confirmed(self, label):
        """缓冲Q并以图标进入CD为准；同时补查超时边界最后一帧是否已生效。"""
        click_result = self.click_echo(time_out=self.ECHO_INPUT_CONFIRM_TIMEOUT)
        # BaseChar会先判断超时、再读取图标；Q若恰好在超时边界生效，返回值可能是False。
        # 所以返回后刷新一帧，以当前图标是否已不可用作为最终判据。
        self.task.next_frame()
        consumed = not self.echo_available()
        if consumed:
            self.logger.info(
                f'jiyan {label}: Q consumption confirmed '
                f'(base_click_result={bool(click_result)})'
            )
            return True
        return False

    def _click_resonance_confirmed(self, label):
        """缓冲E并复核图标已进入CD；仅“发过E键”不视为动作完成。"""
        clicked, _, _ = self.click_resonance(
            send_click=False,
            time_out=self.RESONANCE_INPUT_CONFIRM_TIMEOUT,
        )
        self.task.next_frame()
        consumed = bool(clicked and not self.resonance_available())
        if consumed:
            self.logger.info(f'jiyan {label}: E consumption confirmed')
            return True
        if clicked:
            self.logger.warning(
                f'jiyan {label}: E input sent but icon still available; '
                'treat as swallowed input'
            )
        return False

    def _cast_resonance_when_ready(self, timeout):
        """
        E 可用就立即尝试；未亮时用 A 填充。距离控制由玩家手动完成。
        """
        start = time.time()
        saw_ready = False

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < timeout
        ):
            if self._field_f_check(resume_label='resonance-wait'):
                # None表示F作为独立阶段插入；调用者要保留当前E阶段并结束本轮。
                return None
            if self.resonance_available():
                saw_ready = True
                if self._click_resonance_confirmed('resonance-wait'):
                    return True

            self.normal_attack()
            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        if saw_ready:
            self.logger.warning(
                'jiyan E was ready but not consumed -> dodge recovery'
            )
            self._dodge_buffered()
            self.task.next_frame()
            if self.resonance_available():
                if self._click_resonance_confirmed('resonance-dodge-recovery'):
                    return True

        self.logger.warning(
            f'jiyan resonance wait timed out after {timeout}s'
        )
        return False

    def _cast_liberation_when_ready(self, timeout):
        """特殊变奏入场后立即快速缓冲R，并确认真正进入、结束R动画。"""
        start = time.time()
        last_buffer = -100.0
        buffer_attempts = 0

        if self.has_intro:
            self.logger.info(
                'jiyan special intro -> start immediate rapid R buffering '
                f'interval={self.LIBERATION_INPUT_BUFFER_INTERVAL:.2f}s'
            )

        # 第一发不等待截图或技能图标；若仍在入场动作中，后续0.08s重发会覆盖可操作帧。
        self.task.send_key(self.get_liberation_key())
        last_buffer = time.time()
        buffer_attempts = 1

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < timeout
        ):
            self.task.next_frame()
            in_team, _, _ = self.task.in_team()

            # 原始R缓冲可能早于技能图标识别一帧生效。队伍UI消失说明R动画已经开始，
            # 交回BaseChar等待动画结束并记录时停，不重复误判为释放失败。
            if buffer_attempts and not in_team:
                self.task.in_liberation = True
                self.logger.info(
                    f'jiyan buffered R accepted before ready-icon confirmation attempts={buffer_attempts}'
                )
                if self.click_liberation(wait_if_cd_ready=0, click_f=False):
                    return True
                self.task.in_liberation = False

            if self.liberation_available():
                if self.click_liberation(
                    wait_if_cd_ready=0,  # 图标已亮时无需再添加固定等待
                    click_f=False,
                ):
                    # click_liberation 成功返回时，队伍 UI 已重新出现。
                    return True

            now = time.time()
            if now - last_buffer >= self.LIBERATION_INPUT_BUFFER_INTERVAL:
                # 直接发原始R键，不提前清空liberation_available缓存；下一帧仍可正常视觉确认。
                self.task.send_key(self.get_liberation_key())
                last_buffer = now
                buffer_attempts += 1

            self.sleep(self.STATE_POLL_INTERVAL)

        self.logger.warning(
            f'jiyan liberation wait timed out after {timeout}s'
        )
        return False

    def _run_f_break_with_freeze(self, label):
        """同步执行F，并把处决与动作解锁保护时间一起从轴计时中扣除。"""
        f_start = time.time()
        if not self.f_break():
            return False

        f_duration = max(0.0, time.time() - f_start)
        settle_time = max(0.0, float(self.F_POST_ACTION_SETTLE_TIME))
        if settle_time > 0:
            # f_break()结束只说明F提示已经消耗，不等于角色动作锁已解除。
            # 给输入系统一个很短的恢复窗，避免下一发E/Q/A紧贴F而被游戏吞掉。
            self.sleep(settle_time)
            self.task.next_frame()

        blocked_duration = max(0.0, time.time() - f_start)
        # F处决带全局时停。连同恢复保护一起登记后，青龙窗口、补R时间片和
        # 其他冻结感知计时都不会把这段不可操作时间算进原动作预算。
        self.add_freeze_duration(f_start, blocked_duration)
        self.logger.info(
            f'jiyan F break triggered during {label}; '
            f'F={f_duration:.2f}s settle={settle_time:.2f}s '
            f'freeze_duration={blocked_duration:.2f}s'
        )
        return True

    def _capture_f_resume_phase(self, label):
        """只读保存F打断前的STEP和子phase，供下一次perform校验恢复。"""
        state = getattr(self.task, 'red_light_rotation_state', None)
        if not isinstance(state, dict):
            return None
        phases = {
            key: value
            for key, value in state.items()
            if key.endswith('_phase') and key != 'jiyan_f_phase'
        }
        return {
            'step': state.get('step'),
            'phases': phases,
            'label': label,
            'captured_at': time.time(),
        }

    def _store_f_resume_phase(self, resume):
        """把F标记为独立插入阶段；原STEP/phase本身保持不变。"""
        if not isinstance(resume, dict):
            return
        state = getattr(self.task, 'red_light_rotation_state', None)
        if not isinstance(state, dict):
            return
        state['jiyan_f_phase'] = 'resume_pending'
        state['jiyan_f_resume'] = resume
        self.logger.info(
            f'jiyan F phase saved: step={resume.get("step")} '
            f'action_phases={resume.get("phases") or {"default": "step-entry"}} '
            f'label={resume.get("label")}'
        )

    def _restore_f_resume_phase(self, state):
        """在下一次perform恢复F前的动作阶段；仅校验，不把旧快照反写覆盖新进度。"""
        if state.get('jiyan_f_phase') != 'resume_pending':
            return True

        resume = state.get('jiyan_f_resume')
        if not isinstance(resume, dict):
            self.logger.warning('jiyan F resume marker damaged -> discard marker')
            state.pop('jiyan_f_phase', None)
            state.pop('jiyan_f_resume', None)
            return True

        saved_step = resume.get('step')
        current_step = state.get('step')
        if saved_step != current_step:
            # F调用点按约定会立即return，因此正常情况下STEP不会变化。
            # 若外部恢复已推进STEP，以当前新STEP为准，绝不能用旧快照倒退流程。
            self.logger.warning(
                f'jiyan F resume step changed {saved_step} -> {current_step}; '
                'discard stale resume marker without rolling FSM back'
            )
            state.pop('jiyan_f_phase', None)
            state.pop('jiyan_f_resume', None)
            return True

        try:
            in_team, current_index, _ = self.task.in_team()
            actor_stable = bool(in_team and current_index == self.index)
        except Exception:
            actor_stable = bool(self.is_current_char)

        if not actor_stable:
            now = time.time()
            last_log = float(resume.get('wait_log_at', 0.0) or 0.0)
            if now - last_log >= 0.50:
                self.logger.info(
                    f'jiyan F phase waiting for on-field UI before resume: step={current_step}'
                )
                resume['wait_log_at'] = now
            return False

        current_phases = {
            key: value
            for key, value in state.items()
            if key.endswith('_phase') and key != 'jiyan_f_phase'
        }
        saved_phases = resume.get('phases') or {}
        if current_phases != saved_phases:
            self.logger.warning(
                f'jiyan F resume phase snapshot changed saved={saved_phases} '
                f'current={current_phases}; keep current state and never roll back'
            )

        self.task.next_frame()
        state.pop('jiyan_f_phase', None)
        state.pop('jiyan_f_resume', None)
        self.logger.info(
            f'jiyan F phase restored: step={current_step} '
            f'action_phases={current_phases or {"default": "step-entry"}} '
            '-> continue unfinished action'
        )
        return True

    def _field_f_check(self, force=False, resume_label='on-field coverage'):
        """R外统一F检测；命中后保存当前阶段并要求调用者立即结束本轮。"""
        if not self.is_current_char:
            return False
        now = time.time()
        last = getattr(self, '_last_field_f_check', -100.0)
        if not force and now - last < self.F_CHECK_INTERVAL:
            return False
        self._last_field_f_check = now
        self.task.next_frame()
        resume = self._capture_f_resume_phase(resume_label)
        if not self._run_f_break_with_freeze(resume_label):
            return False
        self._store_f_resume_phase(resume)
        return True

    def _perform_liberation_attacks(self, start):
        """青龙窗口内循环：连续点击A -> 单次短闪 -> W与第二段连续A独立计时。"""
        last_f_check = self.time_elapsed_accounting_for_freeze(start)
        cycle = 0

        while self.time_elapsed_accounting_for_freeze(start) < self.LIBERATION_ACTIVE_TIME:
            cycle += 1
            # 青龙循环保留在当前同步调用栈中，F结束后直接续剩余窗口；
            # 这里不能挂起perform，否则重进STEP时可能再次释放R。
            self._run_f_break_with_freeze('qinglong cycle boundary')
            if self.time_elapsed_accounting_for_freeze(start) >= self.LIBERATION_ACTIVE_TIME:
                break
            if self.LIBERATION_ACTIVE_E_ENABLED and self.resonance_available():
                if self._cast_resonance_if_ready_once('liberation-active energy E'):
                    self.logger.info('jiyan liberation active E cast for next-R energy')
                    self.task.next_frame()
                    continue

            active, last_f_check = self._qinglong_attack_window(
                start=start,
                # 第一段至少保留一个状态刷新周期，避免误填0时形成无等待循环。
                duration=max(self.QINGLONG_ATTACK_TO_DODGE_TIME, self.STATE_POLL_INTERVAL),
                interval=self.QINGLONG_ATTACK_INTERVAL,
                last_f_check=last_f_check,
            )
            if not active:
                break
            if not self.QINGLONG_AUTO_DODGE_ENABLED:
                continue

            # 窗口尾端不足以完成短闪和衔接等待时，不再发出闪避。
            press_time = max(self.QINGLONG_DODGE_PRESS_TIME, 0.01)
            gap_time = max(self.QINGLONG_DODGE_TO_FORWARD_ATTACK_TIME, 0.0)
            remaining = self.LIBERATION_ACTIVE_TIME - self.time_elapsed_accounting_for_freeze(start)
            if remaining <= press_time + gap_time:
                break
            dodge_key = self.task.key_config.get('Dodge Key', 'lshift')
            self.task.send_key(dodge_key, down_time=press_time)
            active, last_f_check = self._wait_liberation_rhythm(
                start=start,
                duration=gap_time,
                last_f_check=last_f_check,
            )
            if not active:
                break

            active, last_f_check = self._qinglong_attack_window(
                start=start,
                duration=self.QINGLONG_FORWARD_ATTACK_TIME,
                interval=self.QINGLONG_FORWARD_ATTACK_INTERVAL,
                last_f_check=last_f_check,
                forward_hold_time=self.QINGLONG_FORWARD_HOLD_TIME,
            )
            if not active:
                break

        self.logger.info(
            f'jiyan qinglong loop finished cycles={cycle} auto_dodge={self.QINGLONG_AUTO_DODGE_ENABLED}'
        )

    def _qinglong_attack_window(self, start, duration, interval, last_f_check, forward_hold_time=0.0):
        """在指定时段重复点击A；可同时按住W，两个时长独立，保留F检测与强化结束检查。"""
        attack_time = max(duration, 0.0)
        hold_time = max(forward_hold_time, 0.0)
        total_time = max(attack_time, hold_time)
        attack_interval = max(interval, 0.01)  # 点击间隔至少0.01秒，避免零间隔连续发键。
        phase_start = time.time()
        next_attack = 0.0
        forward_key = self.QINGLONG_FORWARD_KEY
        forward_held = False

        try:
            if self.time_elapsed_accounting_for_freeze(start) >= self.LIBERATION_ACTIVE_TIME:
                return False, last_f_check
            if hold_time > 0:
                # 先标记再发键，保证发送或后续识别异常时也尝试松开W。
                forward_held = True
                self.task.send_key_down(forward_key)

            while True:
                if self.time_elapsed_accounting_for_freeze(start) >= self.LIBERATION_ACTIVE_TIME:
                    return False, last_f_check
                elapsed = self.time_elapsed_accounting_for_freeze(phase_start)
                if forward_held and elapsed >= hold_time:
                    self.task.send_key_up(forward_key)
                    forward_held = False
                if elapsed >= total_time:
                    return True, last_f_check

                if elapsed < attack_time and elapsed >= next_attack:
                    self.normal_attack()
                    # 不补发因识别、输入耗时错过的点击，避免短时间挤出多次A。
                    next_attack = self.time_elapsed_accounting_for_freeze(phase_start) + attack_interval

                # 在下一次点击、松W、段落结束中选最近的时刻，期间仍刷新画面并检测F。
                deadline = total_time
                if next_attack < attack_time:
                    deadline = min(deadline, next_attack)
                if forward_held:
                    deadline = min(deadline, hold_time)
                wait_time = max(0.001, min(
                    self.STATE_POLL_INTERVAL,
                    deadline - self.time_elapsed_accounting_for_freeze(phase_start),
                ))
                active, last_f_check = self._wait_liberation_rhythm(
                    start=start,
                    duration=wait_time,
                    last_f_check=last_f_check,
                )
                if not active:
                    return False, last_f_check
        finally:
            if forward_held:
                self.task.send_key_up(forward_key)

    def _wait_liberation_rhythm(self, start, duration, last_f_check):
        """
        A闪A专用短等待。

        返回：
            (active_window_still_open, last_f_check)

        等待时间也扣除框架记录的冻结时间，避免 F 处决/全局时停
        把 A -> Dodge 或 Dodge -> A 的节奏窗口直接吃掉。
        """
        wait_start = time.time()

        while (
            self.time_elapsed_accounting_for_freeze(wait_start)  # 计算扣除框架冻结/时停后的有效经过时间
            < duration
        ):
            elapsed = self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            if elapsed >= self.LIBERATION_ACTIVE_TIME:
                return False, last_f_check

            if elapsed - last_f_check >= self.F_CHECK_INTERVAL:
                self.task.next_frame()
                self._run_f_break_with_freeze('qinglong A-dodge loop')
                last_f_check = self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间

            remaining_wait = (
                duration
                - self.time_elapsed_accounting_for_freeze(wait_start)  # 计算扣除框架冻结/时停后的有效经过时间
            )
            if remaining_wait <= 0:
                break  # 立即跳出当前循环，继续执行循环之后的代码

            self.sleep(
                min(
                    self.STATE_POLL_INTERVAL,
                    remaining_wait,
                )
            )
            self.task.next_frame()

        return True, last_f_check

    def _cast_resonance_if_ready_once(self, label):
        """只检查当前这一刻；E 不亮就立即跳过，不等待 CD。"""
        self.task.next_frame()
        if not self.resonance_available():
            self.logger.debug(f'jiyan {label}: E unavailable -> skip')  # 写入DEBUG日志，记录高频诊断数据，正常使用时通常不会重点查看
            return False

        return self._click_resonance_confirmed(label)

    def _dodge_buffered(self):
        """Dodge = 游戏闪避动作；用于需要短时间覆盖可取消窗口的场景。"""
        dodge_key = self.task.key_config.get('Dodge Key', 'lshift')
        start = time.time()
        last_send = 0.0

        while time.time() - start < self.DODGE_BUFFER_TIME:
            now = time.time()
            if now - last_send >= self.DODGE_RETRY_INTERVAL:
                self.task.send_key(dodge_key)
                last_send = now
            self.sleep(self.DODGE_RETRY_INTERVAL)
            self.task.next_frame()

    def _dodge_once(self):
        """只发送一次轻闪；用于忌炎强化窗口结束后的快速后摇取消。"""
        dodge_key = self.task.key_config.get('Dodge Key', 'lshift')
        self.task.send_key(dodge_key)
        self.task.next_frame()

    def _fill_concerto_after_liberation(self, timeout):
        """大招结束后：协奏未满时，E 一亮立即 E；否则持续 A。距离控制由玩家手动完成。"""
        if self.is_con_full():
            return True

        start = time.time()

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < timeout
        ):
            if self.is_con_full():
                return True

            if self.resonance_available():
                clicked, _, _ = self.click_resonance(  # 发送并确认共鸣技能E
                    send_click=False,
                    time_out=0.7,
                )
                if clicked:
                    self.logger.info('jiyan post-liberation fill: E cast')
                    self.task.next_frame()
                    continue

            self.task.click()
            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        return self.is_con_full()

    def _run_liberation_cycle(self):
        """统一忌炎R段：R -> 10.8s青龙输出 -> 一次结束取消 -> 立即交给自然切莫。

        V3.1不再为了特殊变奏额外E/A补满协奏。窗口结束时满协奏当然可以自然变奏莫；
        未满也直接普通切莫。这样R窗口结束时间就是固定轴的离场时间。
        """
        if not self._cast_liberation_when_ready(
            timeout=self.LIBERATION_READY_TIMEOUT
        ):
            return False

        self._reset_liberation_energy_tracking()

        ui_ready_time = time.time()
        self.logger.info(
            f'jiyan liberation UI restored; start '
            f'{self.LIBERATION_ACTIVE_TIME:.1f}s active window'
        )

        self.task.next_frame()
        self._run_f_break_with_freeze('liberation start')
        self._cast_resonance_if_ready_once('liberation-start cancel')

        self._perform_liberation_attacks(ui_ready_time)

        if self._raw_con_full():
            self.logger.info(
                'jiyan V3.1 liberation window ended with full concerto -> '
                'no extra fill; caller will natural-switch Mortefi with intro'
            )
            return True

        if not self._cast_resonance_if_ready_once('liberation-end cancel'):
            if self.LIBERATION_END_AUTO_DODGE_ENABLED:
                self.logger.info('jiyan liberation-end E unavailable -> auto light dodge + quick A')
                self._dodge_once()
            else:
                self.logger.info('jiyan liberation-end E unavailable -> auto dodge disabled; quick A only')
            self.normal_attack()
            self.task.next_frame()

        self.logger.info(
            'jiyan V3.1 liberation window ended without full concerto -> '
            'skip concerto refill and natural-switch Mortefi immediately'
        )
        return True

    def _fill_concerto(self, timeout):
        """用A持续补充忌炎协奏，满协奏或超时后返回。"""
        if self.is_con_full():
            return True

        start = time.time()

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < timeout
        ):
            if self.is_con_full():
                return True

            self.normal_attack()
            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        return self.is_con_full()


    def _read_concerto_progress(self):
        """读取当前协奏百分比，供接近满协奏的兼容判断使用。"""
        if self._raw_con_full():
            return 1.0

        try:
            value = float(self.task.get_current_con())  # 读取当前协奏百分比
        except Exception:
            try:
                value = float(self.get_current_con())  # 读取当前协奏百分比
            except Exception:
                return 0.0

        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        """兼容raw满协奏偶发False但环形进度已被压成0.99的实机情况。"""
        if self._raw_con_full():
            return True
        return self._read_concerto_progress() >= self.CONCERTO_EFFECTIVE_FULL_THRESHOLD

    def _confirm_concerto_effective_full(self):
        """补R抢占用轻量稳定确认，避免单帧0.99噪声直接打断R准备。"""
        if not self._concerto_effectively_full():
            return False

        start = time.time()
        frames = 0
        while (
            self.time_elapsed_accounting_for_freeze(start) < self.CONCERTO_BRANCH_CONFIRM_TIME  # 计算扣除框架冻结/时停后的有效经过时间
            or frames < self.CONCERTO_BRANCH_CONFIRM_FRAMES
        ):
            self.task.next_frame()
            if not self._concerto_effectively_full():
                return False
            frames += 1
            self.sleep(self.INTRO_CONFIRM_POLL)
        return True

    # =========================================================
    # 共享状态 + 精确切人
    # =========================================================

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """FSM 独占切人决策：当前 step 指定忌炎才允许框架选忌；否则彻底屏蔽 BaseChar 自动轮切。

        说明：
        - MUST 只承担“当前场上演员错误时，把 FSM 指定演员拉回场”的恢复职责；
        - NO 表示本角色绝不因 BaseChar 的通用协奏/角色优先级策略主动上场；
        - 真正的正常轮轴切人仍全部由各 step 内的 _switch_to(...) 显式执行。
        """
        if not self._red_light_team_matches():
            return super().get_switch_priority(current_char, has_intro, target_low_con)

        state = getattr(self.task, 'red_light_rotation_state', None)
        if not isinstance(state, dict) or 'step' not in state:
            state = {'step': self.STEP_P1_JIYAN_OPEN_E}
            self.task.red_light_rotation_state = state
            self.logger.info('initialize red-light FSM early from Jiyan switch-priority')

        step = state.get('step')
        expected_actor = self._expected_actor(step)
        if expected_actor is None:
            self.logger.error(
                f'jiyan switch-priority got unknown step={step}; reset to opening'
            )
            state['step'] = self.STEP_P1_JIYAN_OPEN_E
            expected_actor = 'Jiyan'

        if not getattr(self.task, 'red_light_fsm_exclusive_switch_logged', False):
            self.logger.info(
                f'FSM-exclusive switching enabled: step={state.get("step")} '
                f'expected={expected_actor}; BaseChar strategy switching disabled'
            )
            self.task.red_light_fsm_exclusive_switch_logged = True

        if expected_actor == 'Jiyan':
            return SwitchPriority.MUST

        return SwitchPriority.NO

    def _get_rotation_state(self):
        """取得三角色共享流程状态；首次运行或状态损坏时重建为P1开场。"""
        state = getattr(
            self.task,
            'red_light_rotation_state',
            None,
        )

        if not isinstance(state, dict) or 'step' not in state:
            state = {'step': self.STEP_P1_JIYAN_OPEN_E}
            self.task.red_light_rotation_state = state
            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, 'unknown'
            self.logger.info(
                f'initialize red-light FSM at P1_JIYAN_OPEN_E caller={self.name} '
                f'in_team={in_team} current_index={current_index} self_index={self.index}'
            )

        return state

    def on_combat_end(self, chars):
        """清理本轮合轴状态，并保留内置角色自己的战斗结束处理。"""
        self._clear_red_light_rotation_state()
        if hasattr(self.task, 'red_light_team_signature'):
            delattr(self.task, 'red_light_team_signature')
        return super().on_combat_end(chars)

    def _recover_wrong_actor(self, state):
        """当前角色与流程要求不一致时，精确切回该阶段指定的角色。"""
        step = state.get('step', '')
        actor = self._expected_actor(step)

        if actor and actor != self.name:
            self.logger.warning(
                f'jiyan got step={step}, expected actor={actor}; '
                f'switch to expected actor'
            )
            return self._switch_to(
                actor,
                expect_intro=None,
            )

        self.logger.error(
            f'jiyan unknown FSM step={step}; reset to opening'
        )
        state['step'] = self.STEP_P1_JIYAN_OPEN_E

    @classmethod  # 把下一函数声明为类方法，使其可直接通过类读取STEP映射
    def _expected_actor(cls, step):
        """根据阶段名称查询当前应该在场的角色。"""
        return cls.STEP_ACTOR.get(step)

    def _find_target_char(self, target_name):
        """按英文角色名在当前队伍中查找目标角色对象。"""
        target_name = target_name.lower()
        for char in getattr(self.task, 'chars', []):
            if char is None or char is self:
                continue
            names = (
                getattr(char, 'name', None),
                char.__class__.__name__,
                getattr(char, 'display_name', None),
            )
            for name in names:
                if name and str(name).lower() == target_name:
                    return char
        return None

    def _raw_con_full(self):
        """绕开 BaseChar.current_con==1 的缓存，只看当前帧真实协奏视觉。"""
        return bool(self.task.is_con_full())

    def _confirm_intro_ready(self, target_name=None):
        """
        V2.8 选择性特殊变奏保护：仅用于 expect_intro=True 的忌炎 -> 莫特斐。
        必须连续 3 个不同画面帧 raw 满协奏；任意一帧不满即清零重计。
        普通切人和 expect_intro=None 不调用本保护。
        """
        if not self._raw_con_full():
            self._fill_concerto(self.CONCERTO_FILL_TIMEOUT)  # 持续补协奏直到满或超时

        start = time.time()
        full_frames = 0
        label = target_name or self.TARGET_MORTEFI

        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            if self._raw_con_full():
                full_frames += 1
                self.logger.info(
                    f'jiyan special-intro guard -> {label}: raw full {full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                )
                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'jiyan special-intro guard -> {label}: strict 3-frame raw-full passed'
                    )
                    return True
            else:
                if full_frames:
                    self.logger.warning(
                        f'jiyan special-intro guard -> {label}: raw full lost; reset {full_frames}/3 -> 0/3'
                    )
                full_frames = 0

            self.sleep(self.INTRO_CONFIRM_POLL)
            self.task.next_frame()

        self.logger.warning(
            f'jiyan special-intro guard -> {label}: strict 3-frame raw-full timed out'
        )
        return False

    def _normal_switch_has_stable_full_con(self):
        """普通切人前短暂复核协奏；持续为满时阻止普通切。"""
        if not self._concerto_effectively_full():
            return False

        start = time.time()
        while time.time() - start < self.NORMAL_SWITCH_FULL_CONFIRM_TIME:
            self.sleep(self.INTRO_CONFIRM_POLL)
            self.task.next_frame()
            if not self._concerto_effectively_full():
                return False
        return True

    def _switch_to(self, target_name, expect_intro=None):
        # 通用不变量：忌炎的特殊变奏只交给莫特斐。
        """按流程要求精确切人，并区分强制特殊变奏、强制普通切和自然判断。"""
        if expect_intro is True and target_name != self.TARGET_MORTEFI:
            self.logger.error(
                f'jiyan blocked invalid special intro target -> {target_name}'
            )
            return False

        target = self._find_target_char(target_name)
        if target is None:
            self.logger.error(
                f'jiyan cannot find target char {target_name}'
            )
            return False

        if expect_intro is True:
            if not self._confirm_intro_ready(target_name):
                return False
            has_intro = True
        elif expect_intro is False:
            if self._normal_switch_has_stable_full_con():
                self.logger.error(
                    f'jiyan blocked normal switch -> {target_name}: '
                    'concerto is stably full; keep current FSM step'
                )
                self.current_con = 0
                return False
            has_intro = False
        else:
            # 自然切换统一使用有效满协奏；解决raw=False/0.99时P2/P3行为不一致。
            has_intro = self._concerto_effectively_full()  # 用raw满或接近1.0的视觉进度判断“有效满协奏”

        target.has_intro = has_intro
        target.has_sub_dps_intro = (
            has_intro and self.is_sub_dps
        )
        start = time.time()
        last_send = 0.0

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.check_combat()
            in_team, current_index, _ = self.task.in_team()

            if in_team and current_index == target.index:
                self.task.in_liberation = False
                target.is_current_char = True

                if has_intro:
                    self.logger.info(
                        f'jiyan special intro switch accepted -> {target_name}; '
                        'stable full concerto confirmed before switch and target index is active'
                    )

                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(
                        now,
                        target.intro_motion_freeze_duration,
                        -100,
                    )
                    self.last_outro_time = now

                return True

            if (
                in_team
                and current_index == self.index
                and self._field_f_check(
                    resume_label=f'switch-wait-to-{target_name}',
                )
            ):
                # 切人等待最长可持续数秒；期间出现F时先保存当前switch phase，
                # 结束本轮，下一次perform只重试切人而不重放前面的E/Q/R。
                return False

            if (
                in_team
                and current_index == self.index
                and not target.wait_switch()
            ):
                now = time.time()
                if now - last_send >= self.SWITCH_RETRY_INTERVAL:
                    if expect_intro is True and not self._raw_con_full():
                        self.logger.warning(
                            f'jiyan special-intro send blocked -> {target_name}: raw concerto lost after 3-frame guard'
                        )
                        return False
                    self.task.send_key(target.index + 1)
                    last_send = now

            self.sleep(self.SWITCH_RETRY_INTERVAL)
            self.task.next_frame()

        self.logger.error(
            f'jiyan exact switch timed out -> {target_name}'
        )
        return False
