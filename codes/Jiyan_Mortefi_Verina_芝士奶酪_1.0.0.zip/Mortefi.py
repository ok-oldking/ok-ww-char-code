"""莫特斐红绿灯合轴 V3.1。

职责：执行莫特斐的E/Q/R资源动作、协奏填充、忌炎补R插入门，
以及P1/P2/P3最终“莫特斐特殊变奏忌炎”的落地与防假满保护。

按键缩写：A=普通攻击，E=共鸣技能，Q=声骸技能，R=共鸣解放，Z=重击。
流程缩写：P1/P2/P3=第一套/第二套/第三套，FSM=三角色共享的流程状态机。
代码词速查：STEP=大阶段，phase=阶段内的小步骤，fill=补协奏，raw=当前画面的原始识别结果，guard=保护判断。
"""

import time  # 计时、动作间隔和超时保护。

from src.char.BaseChar import BaseChar, SwitchPriority  # 使用OK-WW角色基类和角色切换优先级。
from src.char.Mortefi import Mortefi as BuiltinMortefi  # 继承本角色内置逻辑，包含初始化、辅助动作和切人优先级。


# 仅“忌炎+莫特斐+维里奈”启用红绿灯轴；其他队伍调用OK-WW内置角色逻辑。
# 请通过OK-WW自定义代码加载本文件，保留src/char中的内置角色文件供继承。
class Mortefi(BuiltinMortefi):
    """红绿灯轴V3.1：固定轴优先；P2最终补协奏A常驻、P3入场强E立即响应，并保留V3.0切人恢复诊断。"""

    # BaseChar.flying() 在 task.has_lavitator=False 时固定返回False，不能作为落地证据。
    # 因此无控物工具时先完全不输入，给角色自然下落；随后再用可用的UI信号做辅助确认。
    POST_SWITCH_PASSIVE_FALL_TIME = 0.1  # 莫特斐从忌炎插入段切回后，固定资源阶段先停止输入并自然下落的时间（秒）。
    POST_SWITCH_GROUND_CONFIRM_TIMEOUT = 0.1  # 自然下落结束后，继续寻找稳定落地信号的最长时间（秒）。
    POST_SWITCH_GROUND_STABLE_FRAMES = 2  # 判定莫特斐已经落地所需的连续画面帧数；帧数越多越稳，但会稍慢。

    # P1/P2/P3最终“莫特殊变奏忌”统一先自然落地，再用地面动作补协奏。
    # 首次识别满协奏后仍持续地面A 0.30s，抵抗回场/UI过渡造成的假满识别。
    SPECIAL_INTRO_GROUND_PASSIVE_FALL_TIME = 0.1  # P1/P2/P3最终莫→忌特殊变奏前，莫特斐优先自然落地的快速保护时间（秒）。
    SPECIAL_INTRO_FULL_ATTACK_GUARD_TIME = 0.05  # 首次识别满协奏后仍继续地面A的时间（秒），用于防止UI假满导致普通切忌。

    # =========================================================
    # 红绿灯轴V3.1 FSM：STEP 名直接描述当前真实动作；角色归属由 STEP_ACTOR 显式映射。
    # 以后流程改名/插入新阶段，不再依赖字符串里是否包含 JIYAN/MORT/VERINA。
    # =========================================================
    STEP_P1_JIYAN_OPEN_E = 'P1_JIYAN_OPEN_E'  # 第一套开场：忌炎释放E后普通切莫特斐
    STEP_P1_MORT_AUTO_TO_VERINA = 'P1_MORT_AUTO_TO_VERINA'  # 第一套：莫特斐利用角色自动普攻衔接并普通切维里奈
    STEP_P1_VERINA_E_Q_R = 'P1_VERINA_E_Q_R'  # 第一套：维里奈依次执行E、Q、R后切莫特斐
    STEP_P1_MORT_R_E_Q_TO_VERINA = 'P1_MORT_R_E_Q_TO_VERINA'  # 第一套：莫特斐依次执行R、E、Q后切维里奈
    STEP_P1_VERINA_FAST_FILL_TO_MORT = 'P1_VERINA_FAST_FILL_TO_MORT'  # 第一套：维里奈快速补满协奏后特殊变奏莫特斐
    STEP_P1_MORT_INTRO_E_DODGE_FILL = 'P1_MORT_INTRO_E_DODGE_FILL'  # 第一套：莫特斐变奏入场后E、闪避并把协奏补到忌Q插入门
    STEP_P1_JIYAN_A_WAIT_Q_TO_MORT = 'P1_JIYAN_A_WAIT_Q_TO_MORT'  # 第一套：忌炎用A覆盖换人CD，随后Q并立即回莫特斐
    STEP_P1_MORT_RETURN_FAST_FILL_TO_JIYAN = 'P1_MORT_RETURN_FAST_FILL_TO_JIYAN'  # 第一套：莫特斐回场快速补满协奏并特殊变奏忌炎
    STEP_P1_JIYAN_BURST_R = 'P1_JIYAN_BURST_R'  # 第一套：忌炎变奏入场后执行完整R爆发循环

    STEP_P2_MORT_INTRO_E_TO_JIYAN = 'P2_MORT_INTRO_E_TO_JIYAN'  # 第二套开头：莫特斐变奏入场执行E模块后普通切忌炎
    STEP_P2_JIYAN_QUICK_E_TO_MORT = 'P2_JIYAN_QUICK_E_TO_MORT'  # 第二套：忌炎快速尝试E后普通切莫特斐
    STEP_P2_MORT_AUTO_TO_VERINA = 'P2_MORT_AUTO_TO_VERINA'  # 第二套：莫特斐不额外补动作，普通切维里奈
    STEP_P2_VERINA_E_R_PHOTO_TO_MORT = 'P2_VERINA_E_R_PHOTO_TO_MORT'  # 第二套：维里奈E、可用则R、按光合格数空中A后切莫
    STEP_P2_MORT_E_Q_R_FAST_FILL = 'P2_MORT_E_Q_R_FAST_FILL'  # 第二套主体：莫特斐E→Q→R并快速补协奏，期间带忌R插入门
    STEP_P2_JIYAN_R_PREP_Q_TO_MORT = 'P2_JIYAN_R_PREP_Q_TO_MORT'  # 第二套插入：忌炎补R能量、满足门后Q，再回莫特斐
    STEP_P2_JIYAN_BURST_R = 'P2_JIYAN_BURST_R'  # 第二套结尾：忌炎特殊变奏后执行完整R爆发循环

    STEP_P3_MORT_INTRO_E_TO_JIYAN = 'P3_MORT_INTRO_E_TO_JIYAN'  # 第三套循环开头：莫特斐自然切入（满协奏则变奏）后立即执行E模块并切忌炎
    STEP_P3_JIYAN_E_A_HEAVY_TO_MORT = 'P3_JIYAN_E_A_HEAVY_TO_MORT'  # 第三套：忌炎E→A→重击后普通切莫特斐，不释放Q
    STEP_P3_MORT_AUTO_TO_VERINA = 'P3_MORT_AUTO_TO_VERINA'  # 第三套：莫特斐普通切维里奈
    STEP_P3_VERINA_E_R_PHOTO_TO_MORT = 'P3_VERINA_E_R_PHOTO_TO_MORT'  # 第三套前半：维里奈E、可用则R、按光合格数空中A后切莫
    STEP_P3_MORT_ENTRY_E_TO_VERINA = 'P3_MORT_ENTRY_E_TO_VERINA'  # 第三套中段：莫特斐执行入场E模块后切维里奈
    STEP_P3_VERINA_Q_R_TO_MORT = 'P3_VERINA_Q_R_TO_MORT'  # 第三套中段：维里奈Q后R若可用则放，再切莫特斐
    STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL = 'P3_MORT_ENTRY_E_R_Q_FAST_FILL'  # 第三套后半：莫特斐可选入场E→R→Q并快速补协奏
    STEP_P3_JIYAN_R_PREP_Q_TO_MORT = 'P3_JIYAN_R_PREP_Q_TO_MORT'  # 第三套插入：忌炎补R能量、满足门后Q，再回莫特斐
    STEP_P3_JIYAN_BURST_R = 'P3_JIYAN_BURST_R'  # 第三套结尾：忌炎特殊变奏后执行完整R爆发，然后回到第三套开头

    STEP_ACTOR = {  # 阶段执行角色表：每个流程阶段只能由表中指定的角色执行。
        STEP_P1_JIYAN_OPEN_E: 'Jiyan', STEP_P1_MORT_AUTO_TO_VERINA: 'Mortefi',
        STEP_P1_VERINA_E_Q_R: 'Verina', STEP_P1_MORT_R_E_Q_TO_VERINA: 'Mortefi',
        STEP_P1_VERINA_FAST_FILL_TO_MORT: 'Verina', STEP_P1_MORT_INTRO_E_DODGE_FILL: 'Mortefi',
        STEP_P1_JIYAN_A_WAIT_Q_TO_MORT: 'Jiyan', STEP_P1_MORT_RETURN_FAST_FILL_TO_JIYAN: 'Mortefi',
        STEP_P1_JIYAN_BURST_R: 'Jiyan', STEP_P2_MORT_INTRO_E_TO_JIYAN: 'Mortefi',
        STEP_P2_JIYAN_QUICK_E_TO_MORT: 'Jiyan', STEP_P2_MORT_AUTO_TO_VERINA: 'Mortefi',
        STEP_P2_VERINA_E_R_PHOTO_TO_MORT: 'Verina', STEP_P2_MORT_E_Q_R_FAST_FILL: 'Mortefi',
        STEP_P2_JIYAN_R_PREP_Q_TO_MORT: 'Jiyan', STEP_P2_JIYAN_BURST_R: 'Jiyan',
        STEP_P3_MORT_INTRO_E_TO_JIYAN: 'Mortefi', STEP_P3_JIYAN_E_A_HEAVY_TO_MORT: 'Jiyan',
        STEP_P3_MORT_AUTO_TO_VERINA: 'Mortefi', STEP_P3_VERINA_E_R_PHOTO_TO_MORT: 'Verina',
        STEP_P3_MORT_ENTRY_E_TO_VERINA: 'Mortefi', STEP_P3_VERINA_Q_R_TO_MORT: 'Verina',
        STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL: 'Mortefi', STEP_P3_JIYAN_R_PREP_Q_TO_MORT: 'Jiyan',
        STEP_P3_JIYAN_BURST_R: 'Jiyan',
    }

    TARGET_JIYAN = 'Jiyan'  # 莫特斐最终要切入的忌炎角色名称；必须与OK-WW识别到的英文名一致。
    TARGET_VERINA = 'Verina'  # 莫特斐流程中要切入的维里奈角色名称；必须与OK-WW识别到的英文名一致。

    STATE_POLL_INTERVAL = 0.05  # 状态刷新间隔（秒）：每隔多久更新画面并重新判断；调小反应更快，但会增加识别频率。
    ACTION_RETRY_INTERVAL = 0.05  # 动作重试间隔（秒）：E/Q/R等输入失败后，至少隔多久再发一次。
    EXPECTED_SKILL_TIMEOUT = 0.80  # 预期技能等待上限（秒）：超过后仍未确认成功，就保留当前阶段等待下次重试。
    WAIT_E_WITH_ATTACK_TIMEOUT = 4.0  # 等待莫特斐E可用的最长时间（秒）；等待期间用A继续打协奏。
    CONCERTO_FILL_TIMEOUT = 7.0  # 补协奏最长时间（秒）：超过仍未满就停止本轮尝试，防止无限攻击。
    # 快速协奏的“状态检测频率”和“A输入频率”分离：
    # 每 0.05s 仍检查满协奏/强E/普E/R，但 A 最快每 0.12s 才发一次，减少无意义点击 spam。
    FAST_FILL_ATTACK_INTERVAL = 0.1  # 快速补协奏时A的最短间隔（秒）：调小会更密集，过小可能产生无效输入。

    # 强化 E（Fury Fugue）使用 is_e_forte_full() 单独识别。
    FORTE_E_BUFFER_TIME = 0.8  # 强化E连续缓冲的最长时间（秒）：直到确认强化图标消失或超时。
    FORTE_E_SEEN_FRAMES = 3  # 强化E图标需要连续出现的帧数，达到后才认为强化E真的可用。
    FORTE_E_CLEAR_FRAMES = 2  # V3.1：实机修正为真正2帧；V3.0测试文件实际值误为4，导致强化E成功后仍易被判失败。
    INTRO_E_WAIT_TIMEOUT = 4.0  # 莫特斐变奏入场后等待E模块完成的最长时间（秒）。
    ENTRY_SECOND_E_CHECK_FRAMES = 2  # 入场E模块检查第二次强化E时要求的连续确认帧数。
    # 第一个 E 命令确认后，不立刻闪；先进入技能后摇再 Dodge，避免把脱手 E 本体吞掉。
    # 这是实机调轴参数；若仍吞 E 可提高到 0.26~0.30，若明显拖轴可降到 0.18~0.20。
    ENTRY_E_DODGE_DELAY = 0.18  # 莫特斐E确认后到闪避的等待（秒）：过短可能吞E，过长会拖慢流程。

    # P1维满协奏变奏莫后，莫协奏到90%再普通切忌Q；90%是V3.1当前门值。
    PRE_JIYAN_ECHO_CON = 0.85  # P1莫特斐协奏达到该比例后，普通切忌炎插入一次Q，再切回莫继续补满。
    # P2/P3 忌R插入门：莫一进入对应主体阶段、变得可操作后就开始监控协奏。
    # 协奏 >=50% 时，在下一个资源动作前优先普通切忌做一次R准备；回莫后恢复原phase继续。
    # 该值是实机调轴参数：若单个莫技能仍能从阈值下方直接冲满，可继续下调。
    JIYAN_R_CHECK_CON_THRESHOLD = 0.65  # P2/P3莫特斐协奏达到该比例后，优先普通切忌炎检查并补充R资源。

    # 与维里奈一致：raw is_con_full偶发False但进度被压到0.99时，按有效满协奏处理。
    CONCERTO_EFFECTIVE_FULL_THRESHOLD = 0.99  # 有效满协奏阈值：画面读数达到该比例时，可兼容raw满判定偶发失败。

    # 闪避没有可靠的 BaseChar 成功视觉，因此只做非常短的输入缓冲。
    DODGE_BUFFER_TIME = 0.12  # 闪避输入缓冲总时长（秒）：短时间重复输入，降低单次闪避被动作后摇吞掉的概率。
    DODGE_RETRY_INTERVAL = 0.05  # 闪避键重发间隔（秒）：仅在闪避缓冲窗口内使用。

    INTRO_WAIT_TIMEOUT = 0.8  # 变奏入场最长等待时间（秒）：超过后不再继续等入场动作。
    INTRO_CONFIRM_TIME = 0.12  # 满协奏最短确认时间（秒）：保留给特殊变奏稳定检查。
    INTRO_CONFIRM_TIMEOUT = 1.4  # 特殊变奏确认上限（秒）：在这段时间内寻找连续满协奏画面。
    INTRO_CONFIRM_POLL = 0.04  # 特殊变奏确认采样间隔（秒）：每隔多久读取一次满协奏状态。
    INTRO_CONFIRM_FRAMES = 3  # 特殊变奏所需连续满协奏帧数：任意一帧不满就重新计数。
    NORMAL_SWITCH_FULL_CONFIRM_TIME = 0.18  # 普通切人前满协奏复核时间（秒）：若持续为满则阻止普通切，避免意外触发变奏。

    SWITCH_TIMEOUT = 6.0  # 精确切人最长等待时间（秒）：包括等待换人冷却和确认目标角色上场。
    SWITCH_RETRY_INTERVAL = 0.04  # 切人键重发间隔（秒）：目标角色尚未上场时按此频率重试。
    SWITCH_DIAGNOSTIC_INTERVAL = 0.50  # V3.0：精确切人等待期间每0.5s记录一次识别/冷却/发键状态，便于实机定位超时原因。

    def _clear_red_light_rotation_state(self):
        """退出指定队伍或结束战斗时，清理红绿灯轴的共享阶段与独占切人标记。"""
        for key in ('red_light_rotation_state', 'red_light_fsm_exclusive_switch_logged'):
            if hasattr(self.task, key):
                delattr(self.task, key)

    def _red_light_team_matches(self):
        """只在框架已识别出忌炎、莫特斐、维里奈三人时启用合轴；队伍顺序不限。"""
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            chars = ()
        # 使用框架识别的角色身份，不依赖中文显示名或当前谁在场；未知身份不放行。
        # 兼容带labels.前缀的新身份名称与旧名称；只去掉开头的已知前缀，不修改角色对象。
        signature = tuple(
            (str(getattr(char, 'char_name', '') or '').casefold().removeprefix('labels.'), getattr(char, 'index', None))
            for char in chars
        )
        required = {'char_jiyan', 'char_mortefi', 'char_verina'}
        matched = (
            len(chars) == 3
            and {name for name, _ in signature} == required
            and any(char is self for char in chars)
        )
        previous = getattr(self.task, 'red_light_team_signature', None)
        if signature != previous:
            # 换队/调整位置后重新开始，不能继承另一队或旧位置留下的P2/P3进度。
            self._clear_red_light_rotation_state()
            self.task.red_light_team_signature = signature
            mode = 'red-light rotation' if matched else 'builtin character rotation'
            self.logger.info(f'team changed -> {mode}; members={signature}')
        elif not matched:
            # 即使队伍没变，也不让历史FSM状态干涉内置角色的正常切人。
            self._clear_red_light_rotation_state()
        return matched

    def do_perform(self):
        """读取共享流程状态，只执行当前轮到莫特斐负责的阶段。"""
        if not self._red_light_team_matches():
            return super().do_perform()  # 非指定队伍：执行对应角色的内置动作，而非BaseChar通用动作。

        state = self._get_rotation_state()  # 取得三角色共享FSM状态，必要时初始化为第一套开场步骤
        step = state['step']

        self.logger.info(
            f'mortefi FSM step={step} intro={self.has_intro}'
        )

        if step == self.STEP_P1_MORT_AUTO_TO_VERINA:
            return self._p1_auto_to_verina(state)
        if step == self.STEP_P1_MORT_R_E_Q_TO_VERINA:
            return self._p1_r_e_q_to_verina(state)
        if step == self.STEP_P1_MORT_INTRO_E_DODGE_FILL:
            return self._p1_intro_e_dodge_fill(state)
        if step == self.STEP_P2_MORT_INTRO_E_TO_JIYAN:
            return self._p2_intro_e_module_to_jiyan(state)
        if step == self.STEP_P2_MORT_AUTO_TO_VERINA:
            return self._p2_auto_to_verina(state)
        if step == self.STEP_P2_MORT_E_Q_R_FAST_FILL:
            return self._p2_e_q_r_fast_fill(state)
        if step == self.STEP_P3_MORT_INTRO_E_TO_JIYAN:
            return self._p3_intro_e_module_to_jiyan(state)
        if step == self.STEP_P3_MORT_AUTO_TO_VERINA:
            return self._p3_auto_to_verina(state)
        if step == self.STEP_P3_MORT_ENTRY_E_TO_VERINA:
            return self._p3_entry_e_to_verina(state)
        if step == self.STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL:
            return self._p3_entry_e_r_q_fast_fill(state)
        if step == self.STEP_P1_MORT_RETURN_FAST_FILL_TO_JIYAN:
            return self._p1_return_fast_fill_to_jiyan(state, self.STEP_P1_JIYAN_BURST_R)

        return self._recover_wrong_actor(state)

    # =========================================================
    # 第一套
    # =========================================================

    def _p1_auto_to_verina(self, state):
        """第一套：忌普通切莫后依赖角色内置自动A，不再人工补A；直接普通切维。"""
        if self._switch_to(self.TARGET_VERINA, expect_intro=False):
            state['step'] = self.STEP_P1_VERINA_E_Q_R

    def _p1_r_e_q_to_verina(self, state):
        """第一套：维 EQR -> 莫 R -> E -> Q -> 立即普通切维；切维取消 Q 后摇。"""
        if not self._cast_liberation_required():
            self.logger.warning('mortefi P1 liberation failed; keep same step and retry')
            return
        self._cast_resonance_required()  # 等待并确认E成功释放
        self._cast_echo_required()  # 等待并缓冲Q直到确认进入CD
        if self._switch_to(self.TARGET_VERINA, expect_intro=False):
            state['step'] = self.STEP_P1_VERINA_FAST_FILL_TO_MORT

    def _p1_intro_e_dodge_fill(self, state):
        # 维满协奏变奏莫 -> A等待强化/普通E出现 -> E -> 闪避 -> 攒到约90%插忌Q -> 回莫 -> 满 -> 变奏忌
        """P1莫特斐变奏入场：完成E与闪避，再把协奏推进到忌炎Q插入门。"""
        self._wait_intro_if_needed()  # 如果本次是变奏入场，则等待入场动作结束

        if not self._wait_and_cast_resonance_with_attacks(
            timeout=self.INTRO_E_WAIT_TIMEOUT
        ):
            self.logger.warning(
                'mortefi P1 intro E did not become usable; keep same step'
            )
            return

        # E 成功后先让技能本体完成出手，再在后摇阶段单次闪避取消。
        # 与入场双 E 模块共用同一安全窗，避免紧贴 E 的闪避吞掉技能。
        self._wait_entry_e_dodge_window()
        self._dodge_once()
        self._fill_to_pre_jiyan_echo_or_full(
            state,
            return_step=self.STEP_P1_MORT_RETURN_FAST_FILL_TO_JIYAN,
            jiyan_step=self.STEP_P1_JIYAN_BURST_R,
        )

    # =========================================================
    # 第二套
    # =========================================================

    def _p2_intro_e_module_to_jiyan(self, state):
        """第二套开头：特殊变奏莫 -> 入场 E 状态模块 -> 普通切忌；不强制第二 E。"""
        if not self._run_entry_e_module(wait_intro=True):
            self.logger.warning('mortefi P2 entry E module timed out; keep step')
            return
        if self._switch_to(self.TARGET_JIYAN, expect_intro=False):
            state['step'] = self.STEP_P2_JIYAN_QUICK_E_TO_MORT

    def _p2_auto_to_verina(self, state):
        """第二套：忌 E 普通切莫后依赖莫内置自动A，不人工补A；直接普通切维。"""
        if self._switch_to(self.TARGET_VERINA, expect_intro=False):
            state['step'] = self.STEP_P2_VERINA_E_R_PHOTO_TO_MORT

    def _p2_e_q_r_fast_fill(self, state):
        """P2莫主体：固定资源顺序 E -> Q -> R -> 快速补协奏；50%门可在动作前后插入一次忌R准备。"""
        phase = state.get('p2_mort_phase', 'entry')
        gate_key = 'p2_jiyan_r_gate_done'

        # 忌R插入分支回莫后先完成入场/落地恢复，再从保存phase续轴。
        if not self._resume_after_jiyan_ground_if_needed(state, label='P2', phase=phase):
            return

        if phase == 'entry':
            need_entry_e = bool(self.has_intro)
            if need_entry_e:
                self._wait_intro_if_needed()  # 如果本次是变奏入场，则等待入场动作结束
            state['p2_mort_need_entry_e'] = need_entry_e
            state['p2_mort_phase'] = 'entry_e'
            phase = 'entry_e'

        if phase == 'entry_e':
            # 仍保留“刚可操作第一时间”50%检查；达到门就先插忌R准备。
            if self._check_and_enter_jiyan_r_prep_now(
                state,
                energy_step=self.STEP_P2_JIYAN_R_PREP_Q_TO_MORT,
                return_step=self.STEP_P2_MORT_E_Q_R_FAST_FILL,
                gate_key=gate_key,
                label='P2-entry-live-R-check',
            ):
                return

            if state.get('p2_mort_need_entry_e'):
                # 特殊变奏入场时，这个模块本身就是E动作，因此完成后直接进入Q。
                if not self._run_entry_e_module(wait_intro=False):
                    self.logger.warning('mortefi P2 special-intro entry E module timed out; keep step')
                    return
                state['p2_mort_need_entry_e'] = False
                state['p2_mort_phase'] = 'q'
                if self._check_and_enter_jiyan_r_prep_now(
                    state,
                    energy_step=self.STEP_P2_JIYAN_R_PREP_Q_TO_MORT,
                    return_step=self.STEP_P2_MORT_E_Q_R_FAST_FILL,
                    gate_key=gate_key,
                    label='P2-after-entry-E-live-check',
                ):
                    return
                phase = 'q'
            else:
                # 普通进场没有入场E模块，显式执行一次当前可用的强E/普E。
                state['p2_mort_phase'] = 'e'
                phase = 'e'

        if phase == 'e':
            if self._check_and_enter_jiyan_r_prep_now(
                state,
                energy_step=self.STEP_P2_JIYAN_R_PREP_Q_TO_MORT,
                return_step=self.STEP_P2_MORT_E_Q_R_FAST_FILL,
                gate_key=gate_key,
                label='P2-before-E-live-check',
            ):
                return

            self._cast_any_resonance_if_available_once()  # 当前帧按强化E优先于普通E尝试一次E
            state['p2_mort_phase'] = 'q'

            if self._check_and_enter_jiyan_r_prep_now(
                state,
                energy_step=self.STEP_P2_JIYAN_R_PREP_Q_TO_MORT,
                return_step=self.STEP_P2_MORT_E_Q_R_FAST_FILL,
                gate_key=gate_key,
                label='P2-after-E-live-check',
            ):
                return
            phase = 'q'

        if phase == 'q':
            if self._check_and_enter_jiyan_r_prep_now(
                state,
                energy_step=self.STEP_P2_JIYAN_R_PREP_Q_TO_MORT,
                return_step=self.STEP_P2_MORT_E_Q_R_FAST_FILL,
                gate_key=gate_key,
                label='P2-before-Q-live-check',
            ):
                return

            self._cast_echo_required()  # 等待并缓冲Q直到确认进入CD
            state['p2_mort_phase'] = 'r'

            if self._check_and_enter_jiyan_r_prep_now(
                state,
                energy_step=self.STEP_P2_JIYAN_R_PREP_Q_TO_MORT,
                return_step=self.STEP_P2_MORT_E_Q_R_FAST_FILL,
                gate_key=gate_key,
                label='P2-after-Q-live-check',
            ):
                return
            phase = 'r'

        if phase == 'r':
            if self._check_and_enter_jiyan_r_prep_now(
                state,
                energy_step=self.STEP_P2_JIYAN_R_PREP_Q_TO_MORT,
                return_step=self.STEP_P2_MORT_E_Q_R_FAST_FILL,
                gate_key=gate_key,
                label='P2-before-R-live-check',
            ):
                return

            if not self._cast_liberation_required():
                self.logger.warning('mortefi P2 liberation failed; keep same step and retry')
                return

            state['p2_mort_phase'] = 'pre_fill_gate'
            if self._check_and_enter_jiyan_r_prep_now(
                state,
                energy_step=self.STEP_P2_JIYAN_R_PREP_Q_TO_MORT,
                return_step=self.STEP_P2_MORT_E_Q_R_FAST_FILL,
                gate_key=gate_key,
                label='P2-after-R-live-check',
            ):
                return
            phase = 'pre_fill_gate'

        if phase == 'pre_fill_gate':
            # E/Q/R都走完仍未触发50%门，就用强E > 普E > A快速推进到门，再进入最终fill。
            if not state.get(gate_key):
                if self._wait_and_enter_jiyan_r_prep(
                    state,
                    energy_step=self.STEP_P2_JIYAN_R_PREP_Q_TO_MORT,
                    return_step=self.STEP_P2_MORT_E_Q_R_FAST_FILL,
                    gate_key=gate_key,
                    label='P2-post-EQR-R-check',
                ):
                    return
                if not state.get(gate_key):
                    return
            state['p2_mort_phase'] = 'fill'
            phase = 'fill'

        if phase == 'fill':
            if self._fill_fastest_and_intro_jiyan(
                state,
                jiyan_step=self.STEP_P2_JIYAN_BURST_R,
                allow_liberation=False,
                label='P2-fastest-fill',
                attack_first=True,
            ):
                state.pop('p2_mort_phase', None)
                state.pop('p2_mort_need_entry_e', None)
                state.pop(gate_key, None)
                state.pop(f'{gate_key}_missed', None)

    def _p3_intro_e_module_to_jiyan(self, state):
        """第三套开头：自然切莫后立刻响应E；若是特殊变奏且强化E已亮，不再先等intro/落地。"""
        phase_key = 'p3_intro_mort_phase'
        phase = state.get(phase_key, 'entry_e')

        if phase == 'entry_e':
            fast_intro = bool(self.has_intro)
            if fast_intro:
                self.logger.info(
                    'mortefi V3.1 P3 intro: special intro detected -> E has priority; '
                    'skip pre-wait and allow airborne forte buffer'
                )

            if not self._run_entry_e_module(
                wait_intro=False,
                allow_airborne_forte=fast_intro,
            ):
                self.logger.warning(
                    'mortefi V3.1 P3 intro E module timed out; keep phase=entry_e'
                )
                return

            state[phase_key] = 'switch_jiyan'
            phase = 'switch_jiyan'
            self.logger.info(
                'mortefi V3.1 P3 intro E complete -> phase=switch_jiyan; '
                'switch retries will not repeat E'
            )

        if phase == 'switch_jiyan':
            if self._switch_to(self.TARGET_JIYAN, expect_intro=False):
                state.pop(phase_key, None)
                state['step'] = self.STEP_P3_JIYAN_E_A_HEAVY_TO_MORT
                return
            self.logger.warning(
                'mortefi V3.1 P3 intro switch Jiyan pending; retry switch only'
            )
            return

        self.logger.warning(
            f'mortefi V3.1 P3 intro unknown phase={phase}; reset to entry_e'
        )
        state[phase_key] = 'entry_e'

    def _p3_auto_to_verina(self, state):
        """第三套：忌 E+A+重击 后普通切莫；莫不额外补A，直接普通切维。"""
        if self._switch_to(self.TARGET_VERINA, expect_intro=False):
            state['step'] = self.STEP_P3_VERINA_E_R_PHOTO_TO_MORT

    def _p3_entry_e_to_verina(self, state):
        """第三套中段：E模块与切维拆成可恢复phase；E一旦完成，切人失败只重试切维，绝不重复E。"""
        phase_key = 'p3_mid_mort_phase'
        phase = state.get(phase_key, 'entry_e')

        # V3.0关键修复：E模块只允许成功执行一次。
        # 旧版在 _switch_to(Verina) 超时后仍停留在同一STEP，下一轮会重新跑整套E模块，导致双E/轴错位。
        if phase == 'entry_e':
            if not self._run_entry_e_module(wait_intro=True):
                self.logger.warning(
                    'mortefi P3 mid entry E module timed out; keep phase=entry_e and retry E module'
                )
                return

            state[phase_key] = 'switch_verina'
            phase = 'switch_verina'
            self.logger.info(
                'mortefi P3 mid entry E module complete -> phase=switch_verina; '
                'future retries will not repeat E'
            )

        if phase == 'switch_verina':
            if self._switch_to(self.TARGET_VERINA, expect_intro=False):
                state.pop(phase_key, None)
                state['step'] = self.STEP_P3_VERINA_Q_R_TO_MORT
                return

            self.logger.warning(
                'mortefi P3 mid switch Verina failed; keep phase=switch_verina and retry switch only'
            )
            return

        # 理论上不会进入；若旧状态/异常写入了未知phase，安全回到E模块。
        self.logger.warning(
            f'mortefi P3 mid unknown phase={phase}; reset to entry_e for safe recovery'
        )
        state[phase_key] = 'entry_e'

    def _p3_entry_e_r_q_fast_fill(self, state):
        """P3后半：可选入场E -> R -> Q -> 快速补协奏；期间50%门可插入一次忌R准备。"""
        phase = state.get('p3_mort_phase', 'entry')
        gate_key = 'p3_jiyan_r_gate_done'

        # 忌R插入分支Q成功回莫后，只在这里做一次落地恢复；
        # 落地完成前不允许继续R/Q或后续补协奏。
        if not self._resume_after_jiyan_ground_if_needed(state, label='P3', phase=phase):
            return

        if phase == 'entry':
            need_entry_e = bool(self.has_intro)
            if need_entry_e:
                self._wait_intro_if_needed()  # 如果本次是变奏入场，则等待入场动作结束
            state['p3_mort_need_entry_e'] = need_entry_e
            state['p3_mort_phase'] = 'entry_e'
            phase = 'entry_e'

        if phase == 'entry_e':
            if self._check_and_enter_jiyan_r_prep_now(
                state,
                energy_step=self.STEP_P3_JIYAN_R_PREP_Q_TO_MORT,
                return_step=self.STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL,
                gate_key=gate_key,
                label='P3-entry-live-R-check',
            ):
                return

            if state.get('p3_mort_need_entry_e'):
                if not self._run_entry_e_module(wait_intro=False):
                    self.logger.warning('mortefi P3 Q-intro entry E module timed out; keep step')
                    return
                state['p3_mort_need_entry_e'] = False

                # 入场E已经完成：先保存下一phase=r，再做动作后50%检测。
                state['p3_mort_phase'] = 'r'
                if self._check_and_enter_jiyan_r_prep_now(
                    state,
                    energy_step=self.STEP_P3_JIYAN_R_PREP_Q_TO_MORT,
                    return_step=self.STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL,
                    gate_key=gate_key,
                    label='P3-after-entry-E-R-check',
                ):
                    return

            state['p3_mort_phase'] = 'r'
            phase = 'r'

        if phase == 'r':
            if self._check_and_enter_jiyan_r_prep_now(
                state,
                energy_step=self.STEP_P3_JIYAN_R_PREP_Q_TO_MORT,
                return_step=self.STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL,
                gate_key=gate_key,
                label='P3-before-R-live-check',
            ):
                return

            if self.liberation_available():
                self.logger.info('mortefi P3 initial R ready -> cast')
                self.click_liberation(wait_if_cd_ready=0)  # 发送并确认共鸣解放R
            else:
                self.logger.info('mortefi P3 initial R unavailable -> skip immediately')

            # R动作已经完成/确认跳过：先保存下一phase=pre_q_gate，再做动作后50%检测。
            # 若这里插入忌R，回莫落地后继续Q门，不会再次尝试R。
            state['p3_mort_phase'] = 'pre_q_gate'
            if self._check_and_enter_jiyan_r_prep_now(
                state,
                energy_step=self.STEP_P3_JIYAN_R_PREP_Q_TO_MORT,
                return_step=self.STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL,
                gate_key=gate_key,
                label='P3-after-R-live-check',
            ):
                return

            phase = 'pre_q_gate'

        if phase == 'pre_q_gate':
            if not state.get(gate_key):
                if self._wait_and_enter_jiyan_r_prep(
                    state,
                    energy_step=self.STEP_P3_JIYAN_R_PREP_Q_TO_MORT,
                    return_step=self.STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL,
                    gate_key=gate_key,
                    label='P3-pre-Q-R-check',
                ):
                    return
                if not state.get(gate_key):
                    return
            state['p3_mort_phase'] = 'q'
            phase = 'q'

        if phase == 'q':
            self._cast_echo_required()  # 等待并缓冲Q直到确认进入CD
            state['p3_mort_phase'] = 'fill'
            phase = 'fill'

        if phase == 'fill':
            if self._fill_fastest_and_intro_jiyan(
                state,
                jiyan_step=self.STEP_P3_JIYAN_BURST_R,
                allow_liberation=True,
                label='P3-fastest-fill',
            ):
                state.pop('p3_mort_phase', None)
                state.pop('p3_mort_need_entry_e', None)
                state.pop(gate_key, None)
                state.pop(f'{gate_key}_missed', None)

    def _switch_to_jiyan_energy_prep(self, state, energy_step, return_step, label, gate_key=None):
        """莫协奏未满时普通切忌进入共享R准备；忌现场确认能量/CD/Q后切回当前莫step。"""
        if self._concerto_effectively_full():
            self.logger.warning(f'mortefi {label}: concerto effectively full; cannot ordinary-switch Jiyan for energy prep')
            return False
        state['jiyan_energy_return_step'] = return_step
        state['jiyan_energy_label'] = label
        # 每次真正进入该插入分支都从prep开始；防止异常中断遗留WAIT_Q/return_mort状态。
        state['jiyan_energy_phase'] = 'prep'
        state.pop('jiyan_energy_q_wait_last_log', None)
        if gate_key:
            state['jiyan_energy_gate_key'] = gate_key
        if self._switch_to(self.TARGET_JIYAN, expect_intro=False):
            state['step'] = energy_step
            return True
        state.pop('jiyan_energy_return_step', None)
        state.pop('jiyan_energy_label', None)
        state.pop('jiyan_energy_gate_key', None)
        state.pop('jiyan_energy_phase', None)
        state.pop('jiyan_energy_q_wait_last_log', None)
        return False

    def _check_and_enter_jiyan_r_prep_now(self, state, energy_step, return_step, gate_key, label):
        """V3.0 非阻塞R-gate：每个莫资源动作前/后调用；协奏>=50%就立即插入一次忌R准备。"""
        if state.get(gate_key):
            return False
        if self._concerto_effectively_full():
            # 已满/有效满时普通切会变成特殊变奏，无法再执行“普通切忌检查R”。
            # 为避免FSM永久卡在pre_q_gate，记录一次missed并放行原莫流程；
            # 正常实机应依靠50%提前门和动作前后检查避免走到这里。
            self.logger.error(
                f'mortefi {label}: concerto already full before Jiyan R gate; '
                'ordinary probe impossible -> emergency bypass to avoid deadlock'
            )
            state[gate_key] = True
            state[f'{gate_key}_missed'] = True
            return False
        try:
            con = float(self.get_current_con())  # 读取当前协奏百分比
        except Exception:
            con = 0.0
        if con < self.JIYAN_R_CHECK_CON_THRESHOLD:
            return False
        self.logger.info(
            f'mortefi {label}: concerto={con:.3f} >= Jiyan R-check threshold '
            f'{self.JIYAN_R_CHECK_CON_THRESHOLD:.2f} -> insert one ordinary Jiyan R-prep branch'
        )
        switched = self._switch_to_jiyan_energy_prep(  # 执行P2/P3共享的忌炎R准备、Q和回莫分支
            state,
            energy_step=energy_step,
            return_step=return_step,
            label=label,
            gate_key=gate_key,
        )
        if not switched:
            # 阈值已经满足时，即使本帧因切人CD/输入失败没切出去，也不能继续R/E等资源动作；
            # 返回True让当前phase停住，下次perform继续优先尝试普通切忌。
            self.logger.info(
                f'mortefi {label}: 50% gate reached but ordinary switch not completed; hold phase and retry'
            )
        return True

    def _wait_and_enter_jiyan_r_prep(self, state, energy_step, return_step, gate_key, label):
        """低于50%时快速推进莫协奏，并在每轮动作前检查；达到50%立即插入忌R分支。"""
        if state.get(gate_key):
            return False
        start = time.time()
        last_attack = -100.0
        while self.time_elapsed_accounting_for_freeze(start) < self.CONCERTO_FILL_TIMEOUT:
            if self._check_and_enter_jiyan_r_prep_now(
                state, energy_step, return_step, gate_key, label
            ):
                return True
            # raw-full兜底会在上面的即时检查里把gate标记为missed并放行，避免双重日志/死循环。
            if state.get(gate_key):
                return False

            if self.is_e_forte_full() and self._cast_forte_resonance():
                self.task.next_frame()
                # 强E后下一轮首先重新检查50% gate。
                continue
            if self.resonance_available() and self._cast_normal_resonance_once():
                self.task.next_frame()
                # 普E后下一轮首先重新检查50% gate。
                continue

            now = time.time()
            if now - last_attack >= self.FAST_FILL_ATTACK_INTERVAL:
                self.task.click()
                last_attack = now
            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        self.logger.warning(
            f'mortefi {label}: did not reach {self.JIYAN_R_CHECK_CON_THRESHOLD:.0%} concerto within gate window'
        )
        return False

    def _wait_intro_if_needed(self):
        """仅在确实带变奏入场时等待角色可操作；普通切入不会额外等待。"""
        if self.has_intro:
            self.wait_intro(
                time_out=self.INTRO_WAIT_TIMEOUT,
                click=False,
            )

    def _dodge_buffered(self):
        """闪避缺少可靠成功视觉，用很短的重复输入覆盖可取消后摇窗口。"""
        dodge_key = self.task.key_config.get('Dodge Key', 'lshift')
        start = time.time()
        last_send = 0.0
        while time.time() - start < self.DODGE_BUFFER_TIME:
            now = time.time()
            if now - last_send >= self.DODGE_RETRY_INTERVAL:
                self.task.send_key(dodge_key)
                last_send = now
            self.sleep(self.DODGE_RETRY_INTERVAL)
            self.task.next_frame()

    def _dodge_once(self):
        """入场 E 状态模块只发送一次闪避，用于取消第一个 E 的后摇。"""
        dodge_key = self.task.key_config.get('Dodge Key', 'lshift')
        self.task.send_key(dodge_key)
        self.task.next_frame()

    def _cast_normal_resonance_once(self):
        """普通 E 当前可用时只尝试一次，不等待未来 CD。"""
        if not self.resonance_available():
            return False
        clicked, _, _ = self.click_resonance(send_click=False, time_out=0.7)  # 发送并确认共鸣技能E
        return bool(clicked)

    def _cast_any_resonance_if_available_once(self):
        """资源优先：当前帧强化 E > 普通 E；都没有则立即返回。"""
        self.task.next_frame()
        if self.is_e_forte_full():
            return self._cast_forte_resonance()
        if self.resonance_available():
            return self._cast_normal_resonance_once()
        return False

    def _second_entry_e_ready(self, kind):
        """第一个 E 后紧接着刷新两帧，只观察另一种 E 是否出现。"""
        for _ in range(self.ENTRY_SECOND_E_CHECK_FRAMES):
            self.task.next_frame()
            if kind == 'normal' and self.resonance_available():
                return True
            if kind == 'forte' and self.is_e_forte_full():
                return True
        return False

    def _wait_entry_e_dodge_window(self):
        """等到第一个 E 的本体已经发出、进入后摇，再用 Dodge 取消；避免过早闪避吞技能。"""
        start = time.time()
        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < self.ENTRY_E_DODGE_DELAY
        ):
            remaining = (
                self.ENTRY_E_DODGE_DELAY
                - self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            )
            if remaining <= 0:
                break  # 立即跳出当前循环，继续执行循环之后的代码
            self.sleep(min(self.STATE_POLL_INTERVAL, remaining))
            self.task.next_frame()

    def _run_entry_e_module(self, wait_intro=True, allow_airborne_forte=False):
        """
        莫入场 E 状态模块：
          强E先出 -> 强E -> 立即两帧看普E -> 等到E后摇 -> Dodge -> 普E(若出现) -> 后续
          普E先出 -> 普E -> 立即两帧看强E -> 等到E后摇 -> Dodge -> 强E(若出现) -> 后续
          都没有  -> A等待；同时出现时强E优先。

        V3.1：P3爆发后自然切莫时，特殊变奏若已经显示强化E，允许直接在空中缓冲E，
        不再先走wait_intro + wait_down双重等待。其他调用保持原落地保护。
        """
        if wait_intro:
            self._wait_intro_if_needed()

        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.INTRO_E_WAIT_TIMEOUT:
            forte_ready = bool(self.is_e_forte_full())
            normal_ready = bool(self.resonance_available())

            if forte_ready:
                if not self._cast_forte_resonance(
                    allow_airborne=allow_airborne_forte
                ):
                    self.sleep(self.STATE_POLL_INTERVAL)
                    self.task.next_frame()
                    continue
                normal_after = self._second_entry_e_ready('normal')
                self._wait_entry_e_dodge_window()
                self._dodge_once()
                if normal_after:
                    if self._cast_normal_resonance_once():
                        self.logger.info('mortefi entry module: forte E -> dodge -> normal E')
                    else:
                        self.logger.warning('mortefi entry module: normal E appeared but cast not confirmed')
                else:
                    self.logger.info('mortefi entry module: forte E -> dodge; no normal E in two frames')
                return True

            if normal_ready:
                if not self._cast_normal_resonance_once():
                    self.sleep(self.STATE_POLL_INTERVAL)
                    self.task.next_frame()
                    continue
                forte_after = self._second_entry_e_ready('forte')
                self._wait_entry_e_dodge_window()
                self._dodge_once()
                if forte_after:
                    if self._cast_forte_resonance(
                        allow_airborne=allow_airborne_forte
                    ):
                        self.logger.info('mortefi entry module: normal E -> dodge -> forte E')
                    else:
                        self.logger.warning('mortefi entry module: forte E appeared but cast not confirmed')
                else:
                    self.logger.info('mortefi entry module: normal E -> dodge; no forte E in two frames')
                return True

            self.task.click()
            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        self.logger.warning('mortefi entry E module timed out before either E became usable')
        return False

    def _cast_forte_resonance(self, allow_airborne=False):
        """
        V3.1 强化 E 实机容错确认。

        默认仍保留落地保护；P3特殊变奏开头可传allow_airborne=True，
        只要强化E视觉已经成立就直接缓冲E，避免亮E状态下罚站。
        成功确认使用：连续2帧强化图标消失，或“至少消失1帧 + 普通E出现”的交叉证据。
        """
        if self.flying() and not allow_airborne:
            self.logger.info('mortefi forte E detected while airborne -> wait down')
            self.wait_down(click=False)
            self.task.next_frame()
        elif self.flying() and allow_airborne:
            self.logger.info(
                'mortefi V3.1 forte E visible during intro airborne -> buffer immediately; skip wait_down'
            )

        start = time.time()
        last_send = 0.0
        seen_frames = 0
        clear_frames = 0
        sent = False

        while (
            self.time_elapsed_accounting_for_freeze(start)
            < self.FORTE_E_BUFFER_TIME
        ):
            forte_now = bool(self.is_e_forte_full())

            if not sent:
                if forte_now:
                    seen_frames += 1
                else:
                    seen_frames = 0

                if seen_frames >= self.FORTE_E_SEEN_FRAMES:
                    now = time.time()
                    if now - last_send >= self.ACTION_RETRY_INTERVAL:
                        self.send_resonance_key()
                        sent = True
                        last_send = now
                        self.logger.info(
                            'mortefi forte E visually confirmed -> start buffered E'
                        )
            else:
                if forte_now:
                    clear_frames = 0
                    now = time.time()
                    if now - last_send >= self.ACTION_RETRY_INTERVAL:
                        self.send_resonance_key()
                        last_send = now
                else:
                    clear_frames += 1
                    normal_ready_after = bool(self.resonance_available())

                    if clear_frames >= self.FORTE_E_CLEAR_FRAMES:
                        self.record_resonance_use()
                        self.logger.info(
                            'mortefi forte E consumed after V3.1 2-frame clear confirmation'
                        )
                        return True

                    if clear_frames >= 1 and normal_ready_after:
                        self.record_resonance_use()
                        self.logger.info(
                            'mortefi forte E consumed by fallback confirmation: '
                            'forte cleared and normal E is visible'
                        )
                        return True

            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        if sent:
            self.logger.warning(
                'mortefi forte E buffered but V3.1 consume confirmation was not reached'
            )
        else:
            self.logger.warning(
                'mortefi forte E did not stay visible long enough to confirm'
            )
        return False

    def _blind_buffer_resonance(self):
        """V3.0 不把纯盲发E当成功；只接受普通E确认或强化E主/交叉视觉确认。"""
        if self.is_e_forte_full():
            return self._cast_forte_resonance()
        if self.resonance_available():
            clicked, _, _ = self.click_resonance(  # 发送并确认共鸣技能E
                send_click=False,
                time_out=0.7,
            )
            return clicked
        return False

    def _cast_resonance_required(self, prefer_forte=False):
        """
        普通/强化 E 统一入口。
        强化 E 一旦出现就停止平 A，直到确认消费或超时。
        """
        start = time.time()
        saw_ready = False

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < self.EXPECTED_SKILL_TIMEOUT
        ):
            if self.is_e_forte_full():
                saw_ready = True
                if self._cast_forte_resonance():
                    return True
                self.sleep(self.STATE_POLL_INTERVAL)
                self.task.next_frame()
                continue

            if self.resonance_available():
                saw_ready = True
                clicked, _, _ = self.click_resonance(  # 发送并确认共鸣技能E
                    send_click=False,
                    time_out=0.7,
                )
                if clicked:
                    return True

            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        if saw_ready:
            self.logger.warning(
                'mortefi resonance was visually ready but not consumed -> dodge recovery'
            )
            self._dodge_buffered()
        else:
            self.logger.warning('mortefi required resonance unavailable')
        return False

    def _wait_and_cast_resonance_with_attacks(self, timeout=None):
        """
        E 不可用就 A；强化 E 或普通 E 任一真正可用时立即释放。
        距离控制由玩家手动完成。
        """
        if timeout is None:
            timeout = self.WAIT_E_WITH_ATTACK_TIMEOUT

        start = time.time()
        saw_ready = False

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < timeout
        ):
            if self.is_e_forte_full():
                saw_ready = True
                if self._cast_forte_resonance():
                    return True
                self.sleep(self.STATE_POLL_INTERVAL)
                self.task.next_frame()
                continue

            if self.resonance_available():
                saw_ready = True
                clicked, _, _ = self.click_resonance(  # 发送并确认共鸣技能E
                    send_click=False,
                    time_out=0.7,
                )
                if clicked:
                    return True

            self.task.click()
            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        if saw_ready:
            self.logger.warning(
                f'mortefi E was ready but not consumed within {timeout}s -> dodge recovery'
            )
            self._dodge_buffered()
        else:
            self.logger.warning(
                f'mortefi resonance wait with attacks timed out after {timeout}s'
            )
        return False

    def _cast_liberation_required(self):
        """等待并重复尝试莫特斐R，只有确认释放成功才返回成功。"""
        start = time.time()

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < self.EXPECTED_SKILL_TIMEOUT
        ):
            if self.liberation_available():
                return self.click_liberation(
                    wait_if_cd_ready=0,
                )

            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        return self.click_liberation(
            wait_if_cd_ready=0.2,
        )

    def _cast_echo_required(self):
        """Q 可用后持续缓冲，直到 Q 进入CD/不可用；用于取消前一动作后摇。"""
        start = time.time()
        last_send = 0.0
        sent = False

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < self.EXPECTED_SKILL_TIMEOUT
        ):
            available = self.echo_available()  # 检测Q当前是否可用

            if sent and (not available or self.has_cd('echo')):
                return True

            if available:
                now = time.time()
                if now - last_send >= self.ACTION_RETRY_INTERVAL:
                    self.send_echo_key()
                    if not sent:
                        self.record_echo_use()
                        sent = True
                    last_send = now

            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        if sent:
            self.logger.warning(
                'mortefi echo state did not change before timeout; '
                'continue after buffered Q inputs'
            )
            return True

        self.logger.warning('mortefi required echo unavailable')
        return False

    def _fill_concerto(self, monitor_forte=True):
        """
        A 到协奏满。
        强化 E 优先；持续 A 期间的距离与锁敌由玩家手动处理。
        """
        if self._raw_con_full():
            return True

        start = time.time()

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < self.CONCERTO_FILL_TIMEOUT
        ):
            if monitor_forte and self.is_e_forte_full():
                if self._cast_forte_resonance():
                    self.task.next_frame()
                    continue
                self.sleep(self.STATE_POLL_INTERVAL)
                self.task.next_frame()
                continue

            if self._raw_con_full():
                return True

            self.task.click()
            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        return self._raw_con_full()

    def _fill_to_pre_jiyan_echo_or_full(self, state, return_step, jiyan_step):
        """
        莫攒协奏：约 90% 插一次忌炎 Q。
        强化 E 的优先级高于继续 A、90% 插 Q 和最终变奏；距离与锁敌由玩家手动处理。
        """
        start = time.time()
        last_attack = -100.0

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < self.CONCERTO_FILL_TIMEOUT
        ):
            if self.is_e_forte_full():
                if self._cast_forte_resonance():
                    self.task.next_frame()
                    continue
                self.sleep(self.STATE_POLL_INTERVAL)
                self.task.next_frame()
                continue

            if self._raw_con_full():
                if self._switch_to(self.TARGET_JIYAN, expect_intro=True):
                    state['step'] = jiyan_step
                    return True
                return False

            con = self.get_current_con()  # 读取当前协奏百分比
            if con >= self.PRE_JIYAN_ECHO_CON and not self._raw_con_full():
                self.logger.info(
                    f'mortefi concerto {con:.3f} reached pre-Jiyan-echo threshold'
                )
                if self._switch_to(self.TARGET_JIYAN, expect_intro=False):
                    state['pre_jiyan_echo_return_step'] = return_step
                    state['pre_jiyan_echo_cast_attempted'] = False
                    state['step'] = self.STEP_P1_JIYAN_A_WAIT_Q_TO_MORT
                    return True
                return False

            now = time.time()
            if now - last_attack >= self.FAST_FILL_ATTACK_INTERVAL:
                self.task.click()
                last_attack = now
            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        self.logger.warning(
            'mortefi concerto fill timed out before pre-Jiyan echo/full'
        )
        return False

    def _resume_after_jiyan_ground_if_needed(self, state, label, phase):
        """P2/P3忌R插入分支回莫后的单次恢复门。

        V3.1固定轴规则：R门完成+Q后才回莫，因此不再需要处理“协奏满提前抢占”的异常往返。
        若P3恰好以特殊变奏回到entry_e且强化E已亮，直接把控制权交给E模块，
        不再先wait_intro/落地，从而避免亮E罚站；其他资源phase继续保留落地保护。
        """
        key = 'mortefi_post_jiyan_ground_pending'
        if not state.get(key):
            return True

        self.task.next_frame()

        if (
            label == 'P3'
            and phase == 'entry_e'
            and self.has_intro
            and self.is_e_forte_full()
        ):
            self.logger.info(
                'mortefi V3.1 P3 post-Jiyan entry_e: intro + forte E visible -> '
                'bypass landing guard and let E module act immediately'
            )
            state.pop(key, None)
            return True

        if self.has_intro:
            self.logger.info(
                f'mortefi {label} post-Jiyan return has intro -> finish intro before phase={phase} recovery'
            )
            self._wait_intro_if_needed()
            self.task.next_frame()

        self.logger.info(
            f'mortefi {label} post-Jiyan return phase={phase} -> '
            'land before resuming saved phase'
        )
        passive_fall_time = (
            self.SPECIAL_INTRO_GROUND_PASSIVE_FALL_TIME
            if phase == 'fill'
            else self.POST_SWITCH_PASSIVE_FALL_TIME
        )
        if not self._wait_until_ground_stable(passive_fall_time=passive_fall_time):
            self.logger.warning(
                f'mortefi {label} post-Jiyan landing not confirmed; '
                'keep phase and do not use R/E/Q/A'
            )
            return False

        state.pop(key, None)
        return True

    def _wait_until_ground_stable(
        self,
        timeout=None,
        ground_frames=None,
        passive_fall_time=None,
    ):
        """停止攻击后等待稳定落地。

        固定资源阶段恢复默认保留0.85s自然下落硬保护；
        P1/P2/P3最终特殊变奏门使用0.45s快速落地保护，落地后才允许继续补协奏。
        """
        if timeout is None:
            timeout = self.POST_SWITCH_GROUND_CONFIRM_TIMEOUT
        if ground_frames is None:
            ground_frames = self.POST_SWITCH_GROUND_STABLE_FRAMES
        if passive_fall_time is None:
            passive_fall_time = self.POST_SWITCH_PASSIVE_FALL_TIME

        start = time.time()
        has_lavitator = bool(getattr(self.task, 'has_lavitator', False))

        # 先做一个极短的“已经落地”稳定探测。P1忌Q前新增约1s换人CD覆盖后，
        # 莫回场有机会已经在地面；这时不再无条件先白等0.45/0.85s。
        pre_stable = 0
        for _ in range(max(1, int(ground_frames))):
            self.task.next_frame()
            if has_lavitator:
                grounded = not self.flying()  # 检测角色是否在空中
                signal = 'levitator-precheck'
            else:
                try:
                    grounded = bool(self.down())  # 用技能UI辅助判断是否落地
                except Exception:
                    grounded = False
                signal = 'skill-ui-precheck'
            if not grounded:
                break  # 立即跳出当前循环，继续执行循环之后的代码
            pre_stable += 1
            self.sleep(self.STATE_POLL_INTERVAL)

        if pre_stable >= ground_frames:
            self.logger.info(
                f'mortefi landing guard: already grounded -> skip passive fall frames={pre_stable} signal={signal}'
            )
            return True

        self.logger.info(
            f'mortefi landing guard: passive no-input fall {passive_fall_time:.2f}s '
            f'has_lavitator={has_lavitator}'
        )
        while self.time_elapsed_accounting_for_freeze(start) < passive_fall_time:
            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        stable = 0
        confirm_start = time.time()
        while self.time_elapsed_accounting_for_freeze(confirm_start) < timeout:
            self.task.next_frame()

            if has_lavitator:
                grounded = not self.flying()  # 检测角色是否在空中
                signal = 'levitator'
            else:
                try:
                    grounded = bool(self.down())  # 用技能UI辅助判断是否落地
                except Exception:
                    grounded = False
                signal = 'skill-ui'

            if grounded:
                stable += 1
                if stable >= ground_frames:
                    self.logger.info(
                        f'mortefi ground stable confirmed frames={stable} signal={signal}'
                    )
                    return True
            else:
                stable = 0

            self.sleep(self.STATE_POLL_INTERVAL)

        if not has_lavitator:
            self.logger.warning(
                'mortefi landing guard: no levitator and no positive skill-ui ground signal; '
                f'resume only after passive/time fallback passive={passive_fall_time:.2f}s'
            )
            return True

        return False

    def _p1_return_fast_fill_to_jiyan(self, state, jiyan_step):
        """P1忌Q回莫：先落地，再统一执行地面补协奏和满后0.3秒A保护。"""
        self.task.next_frame()
        self.logger.info(
            'mortefi P1 post-echo return -> land first, then ground-fill concerto'
        )

        self._fill_fastest_and_intro_jiyan(
            state,
            jiyan_step=jiyan_step,
            allow_liberation=False,
            label='P1-post-echo-fill',
        )

    def _fill_fastest_and_intro_jiyan(
        self,
        state,
        jiyan_step,
        allow_liberation,
        label,
        attack_first=False,
    ):
        """
        P1/P2/P3最终特殊变奏门。

        默认(P1/P3)保持技能优先的旧策略；V3.1的P2传attack_first=True：
        A始终按FAST_FILL_ATTACK_INTERVAL持续发送，E仅作为非阻塞插入，绝不因为技能视觉确认
        或错误R可用识别而停止平A等待。P2同时传allow_liberation=False，禁止已放R后再次尝试R。
        """
        if not self._wait_until_ground_stable(
            passive_fall_time=self.SPECIAL_INTRO_GROUND_PASSIVE_FALL_TIME
        ):
            self.logger.warning(
                f'mortefi {label}: landing not confirmed; keep current step and do not start final fill'
            )
            return False

        start = time.time()
        last_attack = -100.0
        last_e_buffer = -100.0
        last_e_log = -100.0

        if attack_first:
            self.logger.info(
                f'mortefi V3.1 {label}: attack-first fill active -> '
                'continuous A + nonblocking E; liberation disabled after fixed R'
            )

        while self.time_elapsed_accounting_for_freeze(start) < self.CONCERTO_FILL_TIMEOUT:
            if self._raw_con_full():
                guard_start = time.time()
                guard_attacks = 0
                self.logger.info(
                    f'mortefi {label}: first raw-full seen -> keep ground A for '
                    f'{self.SPECIAL_INTRO_FULL_ATTACK_GUARD_TIME:.2f}s before switch'
                )
                while (
                    self.time_elapsed_accounting_for_freeze(guard_start)
                    < self.SPECIAL_INTRO_FULL_ATTACK_GUARD_TIME
                ):
                    now = time.time()
                    if now - last_attack >= self.FAST_FILL_ATTACK_INTERVAL:
                        self.task.click()
                        last_attack = now
                        guard_attacks += 1
                    self.sleep(self.STATE_POLL_INTERVAL)
                    self.task.next_frame()

                if not self._raw_con_full():
                    self.logger.warning(
                        f'mortefi {label}: raw-full lost after ground-A guard '
                        f'attacks={guard_attacks}; resume ground fill'
                    )
                    continue

                self.logger.info(
                    f'mortefi {label}: ground-A guard completed '
                    f'attacks={guard_attacks}; begin strict intro confirmation'
                )
                if self._switch_to(self.TARGET_JIYAN, expect_intro=True):
                    state['step'] = jiyan_step
                    return True
                return False

            if attack_first:
                # P2: A是底层时钟，不让任何E识别/确认阻塞持续输出。
                now = time.time()
                if now - last_attack >= self.FAST_FILL_ATTACK_INTERVAL:
                    self.task.click()
                    last_attack = now

                forte_ready = bool(self.is_e_forte_full())
                normal_ready = bool(self.resonance_available())
                if (forte_ready or normal_ready) and now - last_e_buffer >= self.FAST_FILL_ATTACK_INTERVAL:
                    self.send_resonance_key()
                    last_e_buffer = now
                    if now - last_e_log >= 0.50:
                        self.logger.info(
                            f'mortefi V3.1 {label}: nonblocking E buffer '
                            f'forte={forte_ready} normal={normal_ready}; A stream continues'
                        )
                        last_e_log = now

                self.sleep(self.STATE_POLL_INTERVAL)
                self.task.next_frame()
                continue

            if self.is_e_forte_full():
                if self._cast_forte_resonance():
                    self.task.next_frame()
                    continue
            if self.resonance_available():
                if self._cast_normal_resonance_once():
                    self.logger.info(f'mortefi {label}: normal E cast')
                    self.task.next_frame()
                    continue
            if allow_liberation and self.liberation_available():
                self.logger.info(f'mortefi {label}: R became available -> cast')
                if self.click_liberation(wait_if_cd_ready=0):
                    self.task.next_frame()
                    continue
            now = time.time()
            if now - last_attack >= self.FAST_FILL_ATTACK_INTERVAL:
                self.task.click()
                last_attack = now
            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        self.logger.warning(f'mortefi {label}: concerto fill timed out before special intro')
        return False

    def _read_concerto_progress(self):
        """读取当前协奏百分比，供接近满协奏和阶段门判断使用。"""
        if self._raw_con_full():
            return 1.0

        try:
            value = float(self.task.get_current_con())  # 读取当前协奏百分比
        except Exception:
            try:
                value = float(self.get_current_con())  # 读取当前协奏百分比
            except Exception:
                return 0.0

        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        """把raw满或接近100%的视觉进度统一视为有效满协奏。"""
        if self._raw_con_full():
            return True
        return self._read_concerto_progress() >= self.CONCERTO_EFFECTIVE_FULL_THRESHOLD

    # =========================================================
    # 共享状态 + 精确切人
    # =========================================================

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """FSM 独占切人决策：当前 step 指定莫特斐才返回 MUST，否则返回 NO。

        不再调用 super().get_switch_priority()，因此 BaseChar 的 NORMAL 自动轮切
        无法在固定轴中插入额外的莫特斐切入。显式 _switch_to(...) 与 wrong-actor
        恢复仍然保留。
        """
        if not self._red_light_team_matches():
            return super().get_switch_priority(current_char, has_intro, target_low_con)

        state = getattr(self.task, 'red_light_rotation_state', None)
        if not isinstance(state, dict) or 'step' not in state:
            state = {'step': self.STEP_P1_JIYAN_OPEN_E}
            self.task.red_light_rotation_state = state
            self.logger.info('initialize red-light FSM early from Mortefi switch-priority')

        step = state.get('step')
        expected_actor = self._expected_actor(step)
        if expected_actor is None:
            self.logger.error(
                f'mortefi switch-priority got unknown step={step}; reset to opening'
            )
            state['step'] = self.STEP_P1_JIYAN_OPEN_E
            expected_actor = 'Jiyan'

        if not getattr(self.task, 'red_light_fsm_exclusive_switch_logged', False):
            self.logger.info(
                f'FSM-exclusive switching enabled: step={state.get("step")} '
                f'expected={expected_actor}; BaseChar strategy switching disabled'
            )
            self.task.red_light_fsm_exclusive_switch_logged = True

        if expected_actor == 'Mortefi':
            return SwitchPriority.MUST

        return SwitchPriority.NO

    def _get_rotation_state(self):
        """取得三角色共享流程状态；首次运行或状态损坏时重建为P1开场。"""
        state = getattr(
            self.task,
            'red_light_rotation_state',
            None,
        )

        if not isinstance(state, dict) or 'step' not in state:
            state = {'step': self.STEP_P1_JIYAN_OPEN_E}
            self.task.red_light_rotation_state = state
            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, 'unknown'
            self.logger.info(
                f'initialize red-light FSM at P1_JIYAN_OPEN_E caller={self.name} '
                f'in_team={in_team} current_index={current_index} self_index={self.index}'
            )

        return state

    def on_combat_end(self, chars):
        """清理本轮合轴状态，并保留内置角色自己的战斗结束处理。"""
        self._clear_red_light_rotation_state()
        if hasattr(self.task, 'red_light_team_signature'):
            delattr(self.task, 'red_light_team_signature')
        return super().on_combat_end(chars)

    def _recover_wrong_actor(self, state):
        """当前角色与流程要求不一致时，精确切回该阶段指定的角色。"""
        step = state.get('step', '')
        actor = self._expected_actor(step)

        if actor and actor != self.name:
            self.logger.warning(
                f'mortefi got step={step}, expected actor={actor}; '
                f'switch to expected actor'
            )
            return self._switch_to(
                actor,
                expect_intro=None,
            )

        self.logger.error(
            f'mortefi unknown FSM step={step}; reset to opening'
        )
        state['step'] = self.STEP_P1_JIYAN_OPEN_E
    @classmethod  # 把下一函数声明为类方法，使其可直接通过类读取STEP映射
    def _expected_actor(cls, step):
        """根据阶段名称查询当前应该在场的角色。"""
        return cls.STEP_ACTOR.get(step)

    def _find_target_char(self, target_name):
        """按英文角色名在当前队伍中查找目标角色对象。"""
        target_name = target_name.lower()
        for char in getattr(self.task, 'chars', []):
            if char is None or char is self:
                continue
            names = (
                getattr(char, 'name', None),
                char.__class__.__name__,
                getattr(char, 'display_name', None),
            )
            for name in names:
                if name and str(name).lower() == target_name:
                    return char
        return None

    def _raw_con_full(self):
        """只读取当前画面的原始满协奏结果，不使用角色对象里的旧缓存。"""
        return bool(self.task.is_con_full())

    def _confirm_intro_ready(self, target_name=None):
        """
        V3.0 选择性特殊变奏保护：仅用于 expect_intro=True 的莫特斐 -> 忌炎。
        必须连续 3 个不同画面帧 raw 满协奏；任意一帧不满即清零重计。
        普通切人和 expect_intro=None 不调用本保护。
        """
        if not self._raw_con_full():
            self._fill_concerto(monitor_forte=True)  # 持续补协奏直到满或超时

        start = time.time()
        full_frames = 0
        label = target_name or self.TARGET_JIYAN

        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            if self._raw_con_full():
                full_frames += 1
                self.logger.info(
                    f'mortefi special-intro guard -> {label}: raw full {full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                )
                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'mortefi special-intro guard -> {label}: strict 3-frame raw-full passed'
                    )
                    return True
            else:
                if full_frames:
                    self.logger.warning(
                        f'mortefi special-intro guard -> {label}: raw full lost; reset {full_frames}/3 -> 0/3'
                    )
                full_frames = 0

            self.sleep(self.INTRO_CONFIRM_POLL)
            self.task.next_frame()

        self.logger.warning(
            f'mortefi special-intro guard -> {label}: strict 3-frame raw-full timed out'
        )
        return False

    def _normal_switch_has_stable_full_con(self):
        """普通轮切前确认有效满协奏，兼容raw=False但视觉进度0.99。"""
        if not self._concerto_effectively_full():
            return False

        start = time.time()
        while time.time() - start < self.NORMAL_SWITCH_FULL_CONFIRM_TIME:
            self.sleep(self.INTRO_CONFIRM_POLL)
            self.task.next_frame()
            if not self._concerto_effectively_full():
                return False
        return True

    def _switch_to(self, target_name, expect_intro=None):
        # 通用不变量：莫特斐的特殊变奏只交给忌炎。
        """按流程要求精确切人，并区分强制特殊变奏、强制普通切和自然判断。"""
        if expect_intro is True and target_name != self.TARGET_JIYAN:
            self.logger.error(
                f'mortefi blocked invalid special intro target -> {target_name}'
            )
            return False

        target = self._find_target_char(target_name)
        if target is None:
            self.logger.error(
                f'mortefi cannot find target char {target_name}'
            )
            return False

        if expect_intro is True:
            if not self._confirm_intro_ready(target_name):
                return False
            has_intro = True
        elif expect_intro is False:
            if self._normal_switch_has_stable_full_con():
                self.logger.error(
                    f'mortefi blocked normal switch -> {target_name}: '
                    'concerto is stably full; keep current FSM step for recovery'
                )
                self.current_con = 0
                return False
            has_intro = False
        else:
            has_intro = self._concerto_effectively_full()  # 用raw满或接近1.0的视觉进度判断“有效满协奏”

        target.has_intro = has_intro
        target.has_sub_dps_intro = (
            has_intro and self.is_sub_dps
        )

        start = time.time()
        last_send = 0.0
        last_diag = 0.0
        send_count = 0
        last_in_team = None
        last_current_index = None
        last_wait_switch = None

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.check_combat()
            in_team, current_index, _ = self.task.in_team()
            last_in_team = in_team
            last_current_index = current_index

            if in_team and current_index == target.index:
                self.task.in_liberation = False
                target.is_current_char = True

                self.logger.info(
                    f'mortefi exact switch accepted -> {target_name}: '
                    f'intro={has_intro} send_count={send_count} target_index={target.index}'
                )
                if has_intro:
                    self.logger.info(
                        f'mortefi special intro switch accepted -> {target_name}; '
                        'stable full concerto confirmed before switch and target index is active'
                    )

                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(
                        now,
                        target.intro_motion_freeze_duration,
                        -100,
                    )
                    self.last_outro_time = now

                return True

            wait_switch_blocked = None
            if in_team and current_index == self.index:
                wait_switch_blocked = bool(target.wait_switch())
                last_wait_switch = wait_switch_blocked

                if not wait_switch_blocked:
                    now = time.time()
                    if now - last_send >= self.SWITCH_RETRY_INTERVAL:
                        if expect_intro is True and not self._raw_con_full():
                            self.logger.warning(
                                f'mortefi special-intro send blocked -> {target_name}: raw concerto lost after 3-frame guard'
                            )
                            return False
                        self.task.send_key(target.index + 1)
                        last_send = now
                        send_count += 1

            # V3.0诊断：不要等到6秒超时才知道发生了什么。
            now = time.time()
            if now - last_diag >= self.SWITCH_DIAGNOSTIC_INTERVAL:
                self.logger.info(
                    f'mortefi switch diag -> {target_name}: '
                    f'elapsed={now - start:.2f}s in_team={in_team} '
                    f'current_index={current_index} self_index={self.index} '
                    f'target_index={target.index} wait_switch={wait_switch_blocked} '
                    f'send_count={send_count} intro={has_intro}'
                )
                last_diag = now

            self.sleep(self.SWITCH_RETRY_INTERVAL)
            self.task.next_frame()

        self.logger.error(
            f'mortefi exact switch timed out -> {target_name}: '
            f'in_team={last_in_team} current_index={last_current_index} '
            f'self_index={self.index} target_index={target.index} '
            f'wait_switch={last_wait_switch} send_count={send_count} intro={has_intro}'
        )
        return False
