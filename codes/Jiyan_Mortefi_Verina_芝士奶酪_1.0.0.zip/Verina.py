"""维里奈红绿灯合轴 V3.1。

职责：执行维里奈的E/Q/R、读取光合能量、按当前格数安排空中A，
并在协奏满足要求后按固定流程切入莫特斐。

按键缩写：A=普通攻击，E=共鸣技能，Q=声骸技能，R=共鸣解放，Z=重击。
流程缩写：P1/P2/P3=第一套/第二套/第三套，FSM=三角色共享的流程状态机。
代码词速查：STEP=大阶段，phase=阶段内的小步骤，fill=补协奏，raw=当前画面的原始识别结果，guard=保护判断。
"""

import time  # 计时、动作间隔和超时保护。

from src.char.BaseChar import BaseChar, SwitchPriority, forte_white_color
from src.char.Verina import Verina as BuiltinVerina  # 继承本角色内置逻辑，包含初始化、辅助动作和切人优先级。


# 仅“忌炎+莫特斐+维里奈”启用红绿灯轴；其他队伍调用OK-WW内置角色逻辑。
# 请通过OK-WW自定义代码加载本文件，保留src/char中的内置角色文件供继承。
class Verina(BuiltinVerina):
    """红绿灯轴V3.1：维里奈动作逻辑沿用V2.8；同步V3.1共享FSM语义与版本标识。"""

    # =========================================================
    # 红绿灯轴V3.1 FSM：step 只描述真实动作；角色归属由 STEP_ACTOR 显式映射。
    # 以后流程改名/插入新阶段，不再依赖字符串里是否包含 JIYAN/MORT/VERINA。
    # =========================================================
    STEP_P1_JIYAN_OPEN_E = 'P1_JIYAN_OPEN_E'  # 第一套开场：忌炎释放E后普通切莫特斐
    STEP_P1_MORT_AUTO_TO_VERINA = 'P1_MORT_AUTO_TO_VERINA'  # 第一套：莫特斐利用角色自动普攻衔接并普通切维里奈
    STEP_P1_VERINA_E_Q_R = 'P1_VERINA_E_Q_R'  # 第一套：维里奈依次执行E、Q、R后切莫特斐
    STEP_P1_MORT_R_E_Q_TO_VERINA = 'P1_MORT_R_E_Q_TO_VERINA'  # 第一套：莫特斐依次执行R、E、Q后切维里奈
    STEP_P1_VERINA_FAST_FILL_TO_MORT = 'P1_VERINA_FAST_FILL_TO_MORT'  # 第一套：维里奈快速补满协奏后特殊变奏莫特斐
    STEP_P1_MORT_INTRO_E_DODGE_FILL = 'P1_MORT_INTRO_E_DODGE_FILL'  # 第一套：莫特斐变奏入场后E、闪避并把协奏补到忌Q插入门
    STEP_P1_JIYAN_A_WAIT_Q_TO_MORT = 'P1_JIYAN_A_WAIT_Q_TO_MORT'  # 第一套：忌炎用A覆盖换人CD，随后Q并立即回莫特斐
    STEP_P1_MORT_RETURN_FAST_FILL_TO_JIYAN = 'P1_MORT_RETURN_FAST_FILL_TO_JIYAN'  # 第一套：莫特斐回场快速补满协奏并特殊变奏忌炎
    STEP_P1_JIYAN_BURST_R = 'P1_JIYAN_BURST_R'  # 第一套：忌炎变奏入场后执行完整R爆发循环

    STEP_P2_MORT_INTRO_E_TO_JIYAN = 'P2_MORT_INTRO_E_TO_JIYAN'  # 第二套开头：莫特斐变奏入场执行E模块后普通切忌炎
    STEP_P2_JIYAN_QUICK_E_TO_MORT = 'P2_JIYAN_QUICK_E_TO_MORT'  # 第二套：忌炎快速尝试E后普通切莫特斐
    STEP_P2_MORT_AUTO_TO_VERINA = 'P2_MORT_AUTO_TO_VERINA'  # 第二套：莫特斐不额外补动作，普通切维里奈
    STEP_P2_VERINA_E_R_PHOTO_TO_MORT = 'P2_VERINA_E_R_PHOTO_TO_MORT'  # 第二套：维里奈E、可用则R、按光合格数空中A后切莫
    STEP_P2_MORT_E_Q_R_FAST_FILL = 'P2_MORT_E_Q_R_FAST_FILL'  # 第二套主体：莫特斐E→Q→R并快速补协奏，期间带忌R插入门
    STEP_P2_JIYAN_R_PREP_Q_TO_MORT = 'P2_JIYAN_R_PREP_Q_TO_MORT'  # 第二套插入：忌炎补R能量、满足门后Q，再回莫特斐
    STEP_P2_JIYAN_BURST_R = 'P2_JIYAN_BURST_R'  # 第二套结尾：忌炎特殊变奏后执行完整R爆发循环

    STEP_P3_MORT_INTRO_E_TO_JIYAN = 'P3_MORT_INTRO_E_TO_JIYAN'  # 第三套循环开头：莫特斐自然切入（满协奏则变奏）后立即执行E模块并切忌炎
    STEP_P3_JIYAN_E_A_HEAVY_TO_MORT = 'P3_JIYAN_E_A_HEAVY_TO_MORT'  # 第三套：忌炎E→A→重击后普通切莫特斐，不释放Q
    STEP_P3_MORT_AUTO_TO_VERINA = 'P3_MORT_AUTO_TO_VERINA'  # 第三套：莫特斐普通切维里奈
    STEP_P3_VERINA_E_R_PHOTO_TO_MORT = 'P3_VERINA_E_R_PHOTO_TO_MORT'  # 第三套前半：维里奈E、可用则R、按光合格数空中A后切莫
    STEP_P3_MORT_ENTRY_E_TO_VERINA = 'P3_MORT_ENTRY_E_TO_VERINA'  # 第三套中段：莫特斐执行入场E模块后切维里奈
    STEP_P3_VERINA_Q_R_TO_MORT = 'P3_VERINA_Q_R_TO_MORT'  # 第三套中段：维里奈Q后R若可用则放，再切莫特斐
    STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL = 'P3_MORT_ENTRY_E_R_Q_FAST_FILL'  # 第三套后半：莫特斐可选入场E→R→Q并快速补协奏
    STEP_P3_JIYAN_R_PREP_Q_TO_MORT = 'P3_JIYAN_R_PREP_Q_TO_MORT'  # 第三套插入：忌炎补R能量、满足门后Q，再回莫特斐
    STEP_P3_JIYAN_BURST_R = 'P3_JIYAN_BURST_R'  # 第三套结尾：忌炎特殊变奏后执行完整R爆发，然后回到第三套开头

    STEP_ACTOR = {  # 阶段执行角色表：每个流程阶段只能由表中指定的角色执行。
        STEP_P1_JIYAN_OPEN_E: 'Jiyan', STEP_P1_MORT_AUTO_TO_VERINA: 'Mortefi',
        STEP_P1_VERINA_E_Q_R: 'Verina', STEP_P1_MORT_R_E_Q_TO_VERINA: 'Mortefi',
        STEP_P1_VERINA_FAST_FILL_TO_MORT: 'Verina', STEP_P1_MORT_INTRO_E_DODGE_FILL: 'Mortefi',
        STEP_P1_JIYAN_A_WAIT_Q_TO_MORT: 'Jiyan', STEP_P1_MORT_RETURN_FAST_FILL_TO_JIYAN: 'Mortefi',
        STEP_P1_JIYAN_BURST_R: 'Jiyan', STEP_P2_MORT_INTRO_E_TO_JIYAN: 'Mortefi',
        STEP_P2_JIYAN_QUICK_E_TO_MORT: 'Jiyan', STEP_P2_MORT_AUTO_TO_VERINA: 'Mortefi',
        STEP_P2_VERINA_E_R_PHOTO_TO_MORT: 'Verina', STEP_P2_MORT_E_Q_R_FAST_FILL: 'Mortefi',
        STEP_P2_JIYAN_R_PREP_Q_TO_MORT: 'Jiyan', STEP_P2_JIYAN_BURST_R: 'Jiyan',
        STEP_P3_MORT_INTRO_E_TO_JIYAN: 'Mortefi', STEP_P3_JIYAN_E_A_HEAVY_TO_MORT: 'Jiyan',
        STEP_P3_MORT_AUTO_TO_VERINA: 'Mortefi', STEP_P3_VERINA_E_R_PHOTO_TO_MORT: 'Verina',
        STEP_P3_MORT_ENTRY_E_TO_VERINA: 'Mortefi', STEP_P3_VERINA_Q_R_TO_MORT: 'Verina',
        STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL: 'Mortefi', STEP_P3_JIYAN_R_PREP_Q_TO_MORT: 'Jiyan',
        STEP_P3_JIYAN_BURST_R: 'Jiyan',
    }

    TARGET_MORTEFI = 'Mortefi'  # 维里奈流程中要切入的莫特斐角色名称；必须与OK-WW识别到的英文名一致。
    TARGET_JIYAN = 'Jiyan'  # 错误角色恢复时可能寻找的忌炎角色名称；必须与OK-WW识别到的英文名一致。

    STATE_POLL_INTERVAL = 0.05  # 状态刷新间隔（秒）：每隔多久更新画面并重新判断；调小反应更快，但会增加识别频率。
    ACTION_RETRY_INTERVAL = 0.05  # 动作重试间隔（秒）：E/Q/R等输入失败后，至少隔多久再发一次。
    EXPECTED_SKILL_TIMEOUT = 1.2  # 预期技能等待上限（秒）：超过后仍未确认成功，就保留当前阶段等待下次重试。
    CONCERTO_FILL_TIMEOUT = 7.0  # 补协奏最长时间（秒）：超过仍未满就停止本轮尝试，防止无限攻击。
    # 日志里 task.is_con_full() 会在环形百分比>1时仍返回False并把进度压成0.99；
    # 因此分支/变奏确认同时接受接近满值的稳定进度，避免维明明满了却走普通切忌。
    CONCERTO_EFFECTIVE_FULL_THRESHOLD = 0.99  # 有效满协奏阈值：画面读数达到该比例时，可兼容raw满判定偶发失败。
    CONCERTO_BRANCH_CONFIRM_TIME = 0.08  # 有效满协奏分支最短确认时间（秒）：用于过滤单帧误识别。
    CONCERTO_BRANCH_CONFIRM_FRAMES = 2  # 有效满协奏连续确认帧数：连续达到该帧数才允许抢占或切换分支。

    # V2.8 快速协奏参数：技能状态仍按 0.05s 高频检查，并限制平A输入频率，
    # 旧版“若干A后再Z”的策略已不作为P1主流程；当前P1快速补协奏优先直接检查E/Q/R与光合能量。
    FAST_FILL_ATTACK_INTERVAL = 0.12  # 快速补协奏时A的最短间隔（秒）：调小会更密集，过小可能产生无效输入。
    FAST_FILL_A_PULSES_BEFORE_HEAVY = 3  # 旧版快速填充保留参数：曾用于重击前发送几次A，当前主流程不依赖它。

    # 维里奈快速协奏：先跳起，用空中A消耗光合能量；再用地面A兜底。
    AERIAL_ATTACK_INTERVAL = 0.045  # 维里奈空中A的最短输入间隔（秒）：过小可能产生无效点击。
    AERIAL_BURST_TIME = 0.65  # 通用空中A单轮持续时间（秒）：仅供保留的辅助填充逻辑使用。
    AERIAL_MAX_BURSTS = 3  # 通用空中A最多执行轮数：限制滞空时间，避免一直无法落地。
    AERIAL_JUMP_SLEEP = 0.01  # 发送跳跃后等待动作登记的时间（秒）。

    # P1维光合能量：游戏内最多4格。BaseChar只提供forte满/可用布尔判断，
    # V2.8沿用“把BaseChar同一forte ROI横向切成4格”的识别方式，分别统计forte_white_color。
    PHOTOSYNTHESIS_STACKS = 4  # 维里奈光合能量最大格数；当前游戏角色机制为4格。
    PHOTOSYNTHESIS_STACK_WHITE_THRESHOLD = 0.06  # 单格光合能量判亮所需的白色像素比例；过低易误判，过高易漏格。

    # 地面 A 兜底时使用一个短攻击段，然后重新检查协奏。
    GROUND_PROGRESS_BURST_TIME = 0.32  # 维里奈地面A单轮持续时间（秒）：用于协奏未满时的地面补充。
    GROUND_ATTACK_INTERVAL = 0.05  # 维里奈地面补协奏时两次A的最短间隔（秒）。

    INTRO_WAIT_TIMEOUT = 1.5  # 变奏入场最长等待时间（秒）：超过后不再继续等入场动作。
    INTRO_CONFIRM_TIME = 0.12  # 满协奏最短确认时间（秒）：保留给特殊变奏稳定检查。
    INTRO_CONFIRM_TIMEOUT = 1.4  # 特殊变奏确认上限（秒）：在这段时间内寻找连续满协奏画面。
    INTRO_CONFIRM_POLL = 0.04  # 特殊变奏确认采样间隔（秒）：每隔多久读取一次满协奏状态。
    INTRO_CONFIRM_FRAMES = 3  # 特殊变奏所需连续满协奏帧数：任意一帧不满就重新计数。
    NORMAL_SWITCH_FULL_CONFIRM_TIME = 0.18  # 普通切人前满协奏复核时间（秒）：若持续为满则阻止普通切，避免意外触发变奏。

    SWITCH_TIMEOUT = 6.0  # 精确切人最长等待时间（秒）：包括等待换人冷却和确认目标角色上场。
    SWITCH_RETRY_INTERVAL = 0.04  # 切人键重发间隔（秒）：目标角色尚未上场时按此频率重试。

    def _clear_red_light_rotation_state(self):
        """退出指定队伍或结束战斗时，清理红绿灯轴的共享阶段与独占切人标记。"""
        for key in ('red_light_rotation_state', 'red_light_fsm_exclusive_switch_logged'):
            if hasattr(self.task, key):
                delattr(self.task, key)

    def _red_light_team_matches(self):
        """只在框架已识别出忌炎、莫特斐、维里奈三人时启用合轴；队伍顺序不限。"""
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            chars = ()
        # 使用框架识别的角色身份，不依赖中文显示名或当前谁在场；未知身份不放行。
        # 兼容带labels.前缀的新身份名称与旧名称；只去掉开头的已知前缀，不修改角色对象。
        signature = tuple(
            (str(getattr(char, 'char_name', '') or '').casefold().removeprefix('labels.'), getattr(char, 'index', None))
            for char in chars
        )
        required = {'char_jiyan', 'char_mortefi', 'char_verina'}
        matched = (
            len(chars) == 3
            and {name for name, _ in signature} == required
            and any(char is self for char in chars)
        )
        previous = getattr(self.task, 'red_light_team_signature', None)
        if signature != previous:
            # 换队/调整位置后重新开始，不能继承另一队或旧位置留下的P2/P3进度。
            self._clear_red_light_rotation_state()
            self.task.red_light_team_signature = signature
            mode = 'red-light rotation' if matched else 'builtin character rotation'
            self.logger.info(f'team changed -> {mode}; members={signature}')
        elif not matched:
            # 即使队伍没变，也不让历史FSM状态干涉内置角色的正常切人。
            self._clear_red_light_rotation_state()
        return matched

    def do_perform(self):
        """读取共享流程状态，只执行当前轮到维里奈负责的阶段。"""
        if not self._red_light_team_matches():
            return super().do_perform()  # 非指定队伍：执行对应角色的内置动作，而非BaseChar通用动作。

        state = self._get_rotation_state()  # 取得三角色共享FSM状态，必要时初始化为第一套开场步骤
        step = state['step']

        self.logger.info(
            f'verina FSM step={step} intro={self.has_intro}'
        )

        if step == self.STEP_P1_VERINA_E_Q_R:
            return self._p1_e_q_r(state)
        if step == self.STEP_P1_VERINA_FAST_FILL_TO_MORT:
            return self._p1_fill_to_mortefi(state)
        if step == self.STEP_P2_VERINA_E_R_PHOTO_TO_MORT:
            return self._p2_e_r_photo_to_mort(state)
        if step == self.STEP_P3_VERINA_E_R_PHOTO_TO_MORT:
            return self._p3_e_r_photo_to_mort(state)
        if step == self.STEP_P3_VERINA_Q_R_TO_MORT:
            return self._p3_q_r_to_mortefi(state)

        return self._recover_wrong_actor(state)

    # =========================================================
    # 第一套
    # =========================================================

    def _p1_e_q_r(self, state):
        # 莫 A -> 维 E -> Q -> R -> 普通轮切莫
        """P1维里奈依次确认E、Q、R，然后普通切莫特斐。"""
        self._wait_intro_if_needed()  # 如果本次是变奏入场，则等待入场动作结束

        self._cast_resonance_required()  # 等待并确认E成功释放
        self._cast_echo_required()  # 等待并缓冲Q直到确认进入CD
        self._cast_liberation_required()  # 等待并确认R成功释放

        if self._switch_to_mortefi(
            expect_intro=False,
        ):
            state['step'] = self.STEP_P1_MORT_R_E_Q_TO_VERINA

    def _p1_fill_to_mortefi(self, state):
        """
        P1：莫 R/E/Q 后切维。
        不再只靠空中A补满；改为循环检测 满 > E > Q > R > 重击Z，
        以最快协奏为目标，满后特殊变奏莫。
        """
        self._wait_intro_if_needed()  # 如果本次是变奏入场，则等待入场动作结束
        self._fill_concerto_p1_no_heavy()  # 维里奈P1按E/Q/R/光合A优先级补协奏

        if self._switch_to_mortefi(
            expect_intro=True,
        ):
            state['step'] = self.STEP_P1_MORT_INTRO_E_DODGE_FILL


    def _get_photosynthesis_stack_count(self, log=False):
        """估算维里奈当前光合能量格数（0~4）。

        BaseChar.is_forte_full()使用的ROI是：
        3840x2160基准下 x=2251~2311, y=1993~2016。
        V2.8将这60px宽区域横向等分为4格，逐格统计BaseChar同款
        forte_white_color，把原来的True/False细化为0~4格。
        """
        x0, x1 = 2251, 2311
        y0, y1 = 1993, 2016
        width = x1 - x0
        percentages = []
        active = []

        for i in range(self.PHOTOSYNTHESIS_STACKS):
            left = x0 + round(width * i / self.PHOTOSYNTHESIS_STACKS)
            right = x0 + round(width * (i + 1) / self.PHOTOSYNTHESIS_STACKS)
            if right - left >= 4:
                left += 1
                right -= 1
            try:
                box = self.task.box_of_screen_scaled(  # 按基准分辨率生成缩放后的识别区域
                    3840, 2160,
                    left, y0, right, y1,
                    name=f'verina_photo_stack_{i + 1}',
                    hcenter=True,
                )
                pct = float(
                    self.task.calculate_color_percentage(  # 计算指定颜色在视觉区域中的占比
                        forte_white_color, box
                    )
                )
            except Exception:
                pct = 0.0

            percentages.append(pct)
            active.append(
                pct >= self.PHOTOSYNTHESIS_STACK_WHITE_THRESHOLD
            )

        count = int(sum(active))

        # 分格首版若没识别出来，但BaseChar整体forte视觉明确可用，
        # 至少保守按1格处理，避免完全错过P1跳A提速。
        if count == 0 and self._forte_energy_visible():
            count = 1

        if log:
            values = ','.join(
                f'{i + 1}:{pct:.3f}'
                for i, pct in enumerate(percentages)
            )
            self.logger.info(
                f'verina photosynthesis stacks={count}/4 '
                f'cells=[{values}] threshold='
                f'{self.PHOTOSYNTHESIS_STACK_WHITE_THRESHOLD:.3f}'
            )

        return max(0, min(self.PHOTOSYNTHESIS_STACKS, count))

    def _consume_p1_photosynthesis_aerial(self, stack_count):
        """P1一次跳跃后，最多按识别格数逐次空中A。

        每次A后立即检查协奏、技能和剩余光合能量；
        满协奏就马上停止，交给P1特殊变奏莫。
        """
        remaining = max(0, min(self.PHOTOSYNTHESIS_STACKS, int(stack_count)))
        if remaining <= 0:
            return False

        self.logger.info(
            f'verina P1 photosynthesis detected {remaining}/4 -> jump + aerial A consume'
        )
        self.task.jump(after_sleep=self.AERIAL_JUMP_SLEEP)  # 发送跳跃输入

        for attack_no in range(1, remaining + 1):
            if self._raw_con_full():
                return True

            self.normal_attack()
            self.sleep(self.AERIAL_ATTACK_INTERVAL)
            self.task.next_frame()

            self.logger.info(
                f'verina P1 photosynthesis aerial A {attack_no}/{remaining}'
            )

            if self._raw_con_full():
                self.logger.info(
                    'verina P1 concerto full during photosynthesis aerial A -> stop immediately'
                )
                return True

            if (
                self.resonance_available()  # 检测E当前是否可用
                or self.echo_available()  # 检测Q当前是否可用
                or self.liberation_available()  # 检测R当前是否可用
            ):
                return False

            current_stacks = self._get_photosynthesis_stack_count(log=False)  # 视觉估算维里奈当前0~4格光合能量
            if current_stacks <= 0:
                return False

        return self._raw_con_full()

    def _consume_current_photosynthesis_aerial_once(self, label):
        """读取当前0~4格光合能量，只跳一次并按识别格数精确空中A；0格立即返回。"""
        stacks = self._get_photosynthesis_stack_count(log=True)  # 视觉估算维里奈当前0~4格光合能量
        stacks = max(0, min(self.PHOTOSYNTHESIS_STACKS, int(stacks)))
        if stacks <= 0:
            self.logger.info(f'verina {label}: photosynthesis=0 -> skip aerial A')
            return 0

        self.logger.info(
            f'verina {label}: photosynthesis={stacks}/4 -> jump + aerial A x{stacks}'
        )
        self.task.jump(after_sleep=self.AERIAL_JUMP_SLEEP)  # 发送跳跃输入
        for attack_no in range(1, stacks + 1):
            self.normal_attack()
            self.sleep(self.AERIAL_ATTACK_INTERVAL)
            self.task.next_frame()
            self.logger.info(
                f'verina {label}: photosynthesis aerial A {attack_no}/{stacks}'
            )
        return stacks

    def _fill_concerto_p1_no_heavy(self):
        """P1专用快速协奏：满 > E > Q > R > 光合能量跳A > 地面A。

        仍禁止Z/跳重击；新增跳跃只在识别到至少1格光合能量时触发。
        """
        start = time.time()
        last_attack = -100.0
        last_stack_log = -100.0

        while self.time_elapsed_accounting_for_freeze(start) < self.CONCERTO_FILL_TIMEOUT:
            if self._raw_con_full():
                return True

            if self.resonance_available() and self._cast_resonance_required():
                self.task.next_frame()
                continue
            if self.echo_available() and self._cast_echo_required():
                self.task.next_frame()
                continue
            if self.liberation_available() and self._cast_liberation_required():
                self.task.next_frame()
                continue

            now = time.time()
            stacks = self._get_photosynthesis_stack_count(  # 视觉估算维里奈当前0~4格光合能量
                log=(now - last_stack_log >= 0.60)
            )
            if now - last_stack_log >= 0.60:
                last_stack_log = now

            if stacks > 0:
                if self._consume_p1_photosynthesis_aerial(stacks):
                    return True
                self.task.next_frame()
                continue

            if now - last_attack >= self.FAST_FILL_ATTACK_INTERVAL:
                self.task.click()
                last_attack = now

            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        return self._raw_con_full()

    # =========================================================
    # 第二套
    # =========================================================

    def _p2_e_r_photo_to_mort(self, state):
        """P2：E -> R(当前可用才放) -> 按当前光合格数跳A；都没有就直接进入莫阶段。"""
        self._wait_intro_if_needed()  # 如果本次是变奏入场，则等待入场动作结束
        self._cast_resonance_required()  # 等待并确认E成功释放

        if self._cast_liberation_if_available_once():
            self.logger.info('verina P2 after-E R ready -> cast')
            self.task.next_frame()
        else:
            self.logger.info('verina P2 after-E R unavailable -> skip')

        self._consume_current_photosynthesis_aerial_once('P2-after-E')  # 按当前光合格数执行一次跳跃空中A

        if self._switch_to_mortefi(expect_intro=None):
            state.pop('pre_jiyan_echo_return_step', None)
            state.pop('pre_jiyan_echo_cast_attempted', None)
            state['step'] = self.STEP_P2_MORT_E_Q_R_FAST_FILL

    def _p3_e_r_photo_to_mort(self, state):
        """P3前半：E -> R(当前可用才放) -> 按当前光合格数跳A -> 自然切莫。"""
        self._wait_intro_if_needed()  # 如果本次是变奏入场，则等待入场动作结束
        self._cast_resonance_required()  # 等待并确认E成功释放

        if self._cast_liberation_if_available_once():
            self.logger.info('verina P3 after-E R ready -> cast')
            self.task.next_frame()
        else:
            self.logger.info('verina P3 after-E R unavailable -> skip')

        self._consume_current_photosynthesis_aerial_once('P3-after-E')  # 按当前光合格数执行一次跳跃空中A

        if self._switch_to_mortefi(expect_intro=None):
            state['step'] = self.STEP_P3_MORT_ENTRY_E_TO_VERINA

    def _p3_q_r_to_mortefi(self, state):
        """P3中段：Q -> R(当前可用才放) -> 立即自然切莫。"""
        self._wait_intro_if_needed()  # 如果本次是变奏入场，则等待入场动作结束
        self._cast_echo_required()  # 等待并缓冲Q直到确认进入CD

        if self._cast_liberation_if_available_once():
            self.logger.info('verina P3 after-Q R ready -> cast')
            self.task.next_frame()
        else:
            self.logger.info('verina P3 after-Q R unavailable -> skip')

        if self._switch_to_mortefi(
            expect_intro=None,
        ):
            state['step'] = self.STEP_P3_MORT_ENTRY_E_R_Q_FAST_FILL

    # =========================================================
    # 动作辅助
    # =========================================================

    def _wait_intro_if_needed(self):
        """仅在确实带变奏入场时等待角色可操作；普通切入不会额外等待。"""
        if self.has_intro:
            self.logger.warning(
                'verina got unexpected intro; wait before continuing'
            )
            self.wait_intro(
                time_out=self.INTRO_WAIT_TIMEOUT,
                click=False,
            )

    def _cast_resonance_required(self):
        """
        E 使用 BaseChar 可用识别。
        如果 E 曾经亮起却没有消费，短闪避恢复硬直后再做一次尝试。
        """
        start = time.time()
        saw_ready = False

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < self.EXPECTED_SKILL_TIMEOUT
        ):
            if self.resonance_available():
                saw_ready = True
                clicked, _, _ = self.click_resonance(  # 发送并确认共鸣技能E
                    send_click=False,
                    time_out=0.7,
                )
                if clicked:
                    return True

            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        if saw_ready:
            self.logger.warning(
                'verina E was ready but not consumed -> dodge recovery'
            )
            self._dodge_buffered()
            self.task.next_frame()
            if self.resonance_available():
                clicked, _, _ = self.click_resonance(  # 发送并确认共鸣技能E
                    send_click=False,
                    time_out=0.7,
                )
                if clicked:
                    return True

        self.logger.warning(
            'verina required resonance unavailable'
        )
        return False

    def _dodge_buffered(self):
        """只在技能已亮但未消费时使用的轻量硬直恢复。"""
        dodge_key = self.task.key_config.get('Dodge Key', 'lshift')
        start = time.time()
        last_send = 0.0

        while time.time() - start < 0.12:
            now = time.time()
            if now - last_send >= 0.05:
                self.task.send_key(dodge_key)
                last_send = now
            self.sleep(0.05)
            self.task.next_frame()

    def _cast_echo_required(self):
        """Q 持续缓冲，成功后立即进入下一指令，不等待自然后摇。"""
        start = time.time()
        last_send = 0.0
        sent = False

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < self.EXPECTED_SKILL_TIMEOUT
        ):
            available = self.echo_available()  # 检测Q当前是否可用

            if sent and (not available or self.has_cd('echo')):
                return True

            if available:
                now = time.time()
                if now - last_send >= self.ACTION_RETRY_INTERVAL:
                    self.send_echo_key()
                    if not sent:
                        self.record_echo_use()
                        sent = True
                    last_send = now

            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        if sent:
            self.logger.warning(
                'verina echo state did not change before timeout; '
                'continue after buffered Q inputs'
            )
            return True

        self.logger.warning(
            'verina required echo unavailable'
        )
        return False

    def _cast_liberation_required(self):
        """等待并重复尝试维里奈R，只有确认释放成功才返回成功。"""
        start = time.time()

        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < self.EXPECTED_SKILL_TIMEOUT
        ):
            if self.liberation_available():
                return self.click_liberation(
                    wait_if_cd_ready=0,
                )

            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        self.logger.warning(
            'verina required liberation unavailable'
        )
        return False

    def _forte_energy_visible(self):
        """优先使用 BaseChar 已有回路视觉；它不保证能识别所有“部分能量”情况。"""
        try:
            if self.is_mouse_forte_full():
                return True
        except Exception:
            pass  # 明确什么也不做，用作异常或兼容分支的空操作

        try:
            return bool(self.is_forte_full())
        except Exception:
            return False

    def _read_concerto_progress(self):
        """
        读取当前帧协奏进度，供接近满协奏的兼容判断使用。

        这里优先直接读取 task.get_current_con()，避免 BaseChar.current_con
        的满协奏缓存影响判断。返回值限制在 0~1。
        """
        if self._raw_con_full():
            return 1.0

        try:
            value = float(self.task.get_current_con())  # 读取当前协奏百分比
        except Exception:
            try:
                value = float(self.get_current_con())  # 读取当前协奏百分比
            except Exception:
                return 0.0

        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        """兼容 is_con_full() 偶发False但环形进度被压成0.99的情况。"""
        if self._raw_con_full():
            return True
        return (
            self._read_concerto_progress()  # 读取0~1范围的当前协奏进度
            >= self.CONCERTO_EFFECTIVE_FULL_THRESHOLD
        )

    def _confirm_concerto_branch_full(self):
        """P2分支用的轻量稳定确认：连续多帧接近满值才按“满协奏”处理。"""
        start = time.time()
        frames = 0
        while (
            self.time_elapsed_accounting_for_freeze(start)  # 计算扣除框架冻结/时停后的有效经过时间
            < self.CONCERTO_BRANCH_CONFIRM_TIME
            or frames < self.CONCERTO_BRANCH_CONFIRM_FRAMES
        ):
            self.task.next_frame()
            if not self._concerto_effectively_full():
                return False
            frames += 1
            self.sleep(self.INTRO_CONFIRM_POLL)
        return True

    def _aerial_attack_burst(self):
        """跳起后快速平 A；只负责补协奏，不判断命中或自动追怪。"""
        if self.is_con_full():
            return True

        self.task.jump(after_sleep=self.AERIAL_JUMP_SLEEP)
        start = time.time()

        while time.time() - start < self.AERIAL_BURST_TIME:
            if self._raw_con_full():
                return True
            self.task.click(interval=self.AERIAL_ATTACK_INTERVAL)
            self.sleep(self.AERIAL_ATTACK_INTERVAL)
            self.task.next_frame()

        return self._raw_con_full()

    def _aerial_attack_exact(self, count=2):
        """固定“跳跃 + 空中A×count”；不等待协奏满，也不进入地面A兜底。"""
        if count <= 0:
            return
        self.task.jump(after_sleep=self.AERIAL_JUMP_SLEEP)
        for _ in range(count):
            self.normal_attack()
            self.sleep(self.AERIAL_ATTACK_INTERVAL)
            self.task.next_frame()

    def _ground_attack_burst(self):
        """短时间持续地面 A；只负责补协奏，不判断命中或自动追怪。"""
        start = time.time()

        while (
            self.time_elapsed_accounting_for_freeze(start)
            < self.GROUND_PROGRESS_BURST_TIME
        ):
            if self._raw_con_full():
                return True
            self.normal_attack()
            self.sleep(self.GROUND_ATTACK_INTERVAL)
            self.task.next_frame()

        return self._raw_con_full()

    def _cast_resonance_if_available_once(self):
        """当前帧E可用时只尝试一次；不可用就立即跳过。"""
        if not self.resonance_available():
            return False
        clicked, _, _ = self.click_resonance(  # 发送并确认共鸣技能E
            send_click=False,
            time_out=0.7,
        )
        return bool(clicked)

    def _cast_echo_if_available_once(self):
        """当前帧Q可用时只尝试一次；不可用就立即跳过。"""
        if not self.echo_available():
            return False
        return bool(self.click_echo(time_out=0))

    def _cast_liberation_if_available_once(self):
        """当前帧R可用时只尝试一次；不可用就立即跳过。"""
        if not self.liberation_available():
            return False
        return bool(self.click_liberation(wait_if_cd_ready=0))

    def _fill_concerto_fastest(self):
        """
        P1 快速协奏：严格循环 满 > E > Q > R > 重击 Z。
        不再检测攻击是否命中，也不会自动锁敌或追怪。
        """
        if self._raw_con_full():
            return True

        start = time.time()
        while (
            self.time_elapsed_accounting_for_freeze(start)
            < self.CONCERTO_FILL_TIMEOUT
        ):
            if self._raw_con_full():
                return True

            if self._cast_resonance_if_available_once():
                self.logger.info('verina fastest fill: E cast')
                self.task.next_frame()
                continue
            if self._cast_echo_if_available_once():
                self.logger.info('verina fastest fill: Q cast')
                self.task.next_frame()
                continue
            if self._cast_liberation_if_available_once():
                self.logger.info('verina fastest fill: R cast')
                self.task.next_frame()
                continue

            self.heavy_attack()
            self.sleep(self.STATE_POLL_INTERVAL)
            self.task.next_frame()

        return self._raw_con_full()

    def _fill_concerto_fast(self, prefer_aerial=True):
        """
        维里奈补协奏：有回路视觉时优先跳跃空中 A，
        否则使用短地面 A。距离与锁敌由玩家手动处理。
        """
        if self.is_con_full():
            return True

        start = time.time()
        aerial_bursts = 0
        probe_used = False

        while (
            self.time_elapsed_accounting_for_freeze(start)
            < self.CONCERTO_FILL_TIMEOUT
        ):
            if self.is_con_full():
                return True

            forte_visible = self._forte_energy_visible()
            should_aerial = (
                prefer_aerial
                and aerial_bursts < self.AERIAL_MAX_BURSTS
                and (forte_visible or not probe_used)
            )

            if should_aerial:
                if not forte_visible:
                    probe_used = True
                    self.logger.debug(
                        'verina partial forte not visually confirmed; '
                        'use one aerial probe burst'
                    )
                aerial_bursts += 1
                if self._aerial_attack_burst():
                    return True
                continue

            if self._ground_attack_burst():
                return True

        return self.is_con_full()

    # =========================================================
    # 共享状态
    # =========================================================

    def _get_rotation_state(self):
        """取得三角色共享流程状态；首次运行或状态损坏时重建为P1开场。"""
        state = getattr(
            self.task,
            'red_light_rotation_state',
            None,
        )

        if not isinstance(state, dict) or 'step' not in state:
            state = {'step': self.STEP_P1_JIYAN_OPEN_E}
            self.task.red_light_rotation_state = state
            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, 'unknown'
            self.logger.info(
                f'initialize red-light FSM at P1_JIYAN_OPEN_E caller={self.name} '
                f'in_team={in_team} current_index={current_index} self_index={self.index}'
            )

        return state

    def on_combat_end(self, chars):
        """清理本轮合轴状态，并保留内置角色自己的战斗结束处理。"""
        self._clear_red_light_rotation_state()
        if hasattr(self.task, 'red_light_team_signature'):
            delattr(self.task, 'red_light_team_signature')
        return super().on_combat_end(chars)

    def _recover_wrong_actor(self, state):
        """当前角色与流程要求不一致时，精确切回该阶段指定的角色。"""
        step = state.get('step', '')
        actor = self._expected_actor(step)

        if actor and actor != self.name:
            self.logger.warning(
                f'verina got step={step}, expected actor={actor}; '
                f'switch to expected actor'
            )
            return self._switch_to(
                actor,
                expect_intro=None,
            )

        self.logger.error(
            f'verina unknown FSM step={step}; reset to opening'
        )
        state['step'] = self.STEP_P1_JIYAN_OPEN_E

    @classmethod  # 把下一函数声明为类方法，使其可直接通过类读取STEP映射
    def _expected_actor(cls, step):
        """根据阶段名称查询当前应该在场的角色。"""
        return cls.STEP_ACTOR.get(step)

    def _find_target_char(self, target_name):
        """按英文角色名在当前队伍中查找目标角色对象。"""
        target_name = target_name.lower()
        for char in getattr(self.task, 'chars', []):
            if char is None or char is self:
                continue
            names = (
                getattr(char, 'name', None),
                char.__class__.__name__,
                getattr(char, 'display_name', None),
            )
            for name in names:
                if name and str(name).lower() == target_name:
                    return char
        return None

    def _switch_to_mortefi(self, expect_intro):
        """按当前协奏状态自然切莫特斐，并把流程推进到指定阶段。"""
        return self._switch_to(
            self.TARGET_MORTEFI,
            expect_intro=expect_intro,
        )

    def _raw_con_full(self):
        """只读取当前画面的原始满协奏结果，不使用角色对象里的旧缓存。"""
        return bool(self.task.is_con_full())

    def _confirm_intro_ready(self, target_name=None):
        """
        V2.8 选择性特殊变奏保护：只服务 P1 维里奈 -> 莫特斐的 expect_intro=True。
        P2/P3 的 expect_intro=None 在V2.8继续采用自然切换，不增加特殊变奏的3帧强制保护。
        特殊变奏必须连续 3 个不同画面帧 raw 满协奏。
        """
        if not self._raw_con_full():
            self._fill_concerto_fastest()  # 按技能优先级快速补协奏

        start = time.time()
        full_frames = 0
        label = target_name or self.TARGET_MORTEFI

        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            if self._raw_con_full():
                full_frames += 1
                self.logger.info(
                    f'verina P1 special-intro guard -> {label}: raw full {full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                )
                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'verina P1 special-intro guard -> {label}: strict 3-frame raw-full passed'
                    )
                    return True
            else:
                if full_frames:
                    self.logger.warning(
                        f'verina P1 special-intro guard -> {label}: raw full lost; reset {full_frames}/3 -> 0/3'
                    )
                full_frames = 0

            self.sleep(self.INTRO_CONFIRM_POLL)
            self.task.next_frame()

        self.logger.warning(
            f'verina P1 special-intro guard -> {label}: strict 3-frame raw-full timed out'
        )
        return False

    def _normal_switch_has_stable_full_con(self):
        """普通切人前短暂复核协奏；持续为满时阻止普通切。"""
        if not self._concerto_effectively_full():
            return False

        start = time.time()
        while time.time() - start < self.NORMAL_SWITCH_FULL_CONFIRM_TIME:
            self.sleep(self.INTRO_CONFIRM_POLL)
            self.task.next_frame()
            if not self._concerto_effectively_full():
                return False
        return True

    def _switch_to(self, target_name, expect_intro=None):
        # 通用不变量：维里奈的特殊变奏只交给莫特斐。
        """按流程要求精确切人，并区分强制特殊变奏、强制普通切和自然判断。"""
        if expect_intro is True and target_name != self.TARGET_MORTEFI:
            self.logger.error(
                f'verina blocked invalid special intro target -> {target_name}'
            )
            return False

        target = self._find_target_char(target_name)
        if target is None:
            self.logger.error(
                f'verina cannot find target char {target_name}'
            )
            return False

        if expect_intro is True:
            if not self._confirm_intro_ready(target_name):
                return False
            has_intro = True
        elif expect_intro is False:
            if self._normal_switch_has_stable_full_con():
                self.logger.error(
                    f'verina blocked normal switch -> {target_name}: '
                    'concerto is stably full; keep current FSM step'
                )
                self.current_con = 0
                return False
            has_intro = False
        else:
            has_intro = self._concerto_effectively_full()  # 用raw满或接近1.0的视觉进度判断“有效满协奏”

        target.has_intro = has_intro
        target.has_sub_dps_intro = (
            has_intro and self.is_sub_dps
        )

        start = time.time()
        last_send = 0.0

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.check_combat()
            in_team, current_index, _ = self.task.in_team()

            if in_team and current_index == target.index:
                self.task.in_liberation = False
                target.is_current_char = True

                if has_intro:
                    self.logger.info(
                        f'verina special intro switch accepted -> {target_name}; '
                        'stable full concerto confirmed before switch and target index is active'
                    )

                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(
                        now,
                        target.intro_motion_freeze_duration,
                        -100,
                    )
                    self.last_outro_time = now

                return True

            if (
                in_team
                and current_index == self.index
                and not target.wait_switch()
            ):
                now = time.time()
                if now - last_send >= self.SWITCH_RETRY_INTERVAL:
                    if expect_intro is True and not self._raw_con_full():
                        self.logger.warning(
                            f'verina P1 special-intro send blocked -> {target_name}: raw concerto lost after 3-frame guard'
                        )
                        return False
                    self.task.send_key(target.index + 1)
                    last_send = now

            self.sleep(self.SWITCH_RETRY_INTERVAL)
            self.task.next_frame()

        self.logger.error(
            f'verina exact switch timed out -> {target_name}'
        )
        return False
    def get_switch_priority(
        self,
        current_char=None,
        has_intro=False,
        target_low_con=False,
    ):
        """FSM 独占切人决策：当前 step 指定维里奈才返回 MUST，否则返回 NO。

        旧版通用/兼容优先级分支会让 BaseChar 仍参与固定轴切人；
        V2.8保持该分支关闭；本队伍所有正常换人只由 FSM 的显式 _switch_to(...) 触发。
        """
        if not self._red_light_team_matches():
            return super().get_switch_priority(current_char, has_intro, target_low_con)

        state = getattr(self.task, 'red_light_rotation_state', None)
        if not isinstance(state, dict) or 'step' not in state:
            state = {'step': self.STEP_P1_JIYAN_OPEN_E}
            self.task.red_light_rotation_state = state
            self.logger.info('initialize red-light FSM early from Verina switch-priority')

        step = state.get('step')
        expected_actor = self._expected_actor(step)
        if expected_actor is None:
            self.logger.error(
                f'verina switch-priority got unknown step={step}; reset to opening'
            )
            state['step'] = self.STEP_P1_JIYAN_OPEN_E
            expected_actor = 'Jiyan'

        if not getattr(self.task, 'red_light_fsm_exclusive_switch_logged', False):
            self.logger.info(
                f'FSM-exclusive switching enabled: step={state.get("step")} '
                f'expected={expected_actor}; BaseChar strategy switching disabled'
            )
            self.task.red_light_fsm_exclusive_switch_logged = True

        if expected_actor == 'Verina':
            return SwitchPriority.MUST

        return SwitchPriority.NO
