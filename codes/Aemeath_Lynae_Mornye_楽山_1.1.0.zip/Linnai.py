import time

from src.char.BaseChar import BaseChar, SwitchPriority, forte_white_color

class Linnai(BaseChar):
    CON_FULL_TIME_OUT = 5

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_heavy = 0

        self.is_sending_e = False


    @property
    def is_in_25s_cycle(self) -> bool:
        team_members = 0
        for char in self.task.chars:
            if char and char.name in {'Aemeath', 'Mornye'}:
                team_members += 1
        return team_members == 2
    

    def do_perform(self):
        if self.is_in_25s_cycle:
            self.check_f_on_switch = False
            self.perform_25s_cycle()
        else:
            if self.has_intro:
                if self.check_res():
                    self.continues_normal_attack(1.33)
                else:
                    self.continues_normal_attack(1)
                    self.click_echo(time_out=0)
                    if not self.is_con_full():
                        self.click_liberation()
                    if not self.is_mouse_forte_full():
                        self.click_resonance()   
                    self.task.wait_until(self.is_mouse_forte_full, post_action=self.click, time_out=2)
                    self.task.mouse_down() 
                    if self.task.wait_until(lambda: not self.is_mouse_forte_full(), time_out=5):
                        self.task.mouse_up()
                        self.sleep(0.4)                 
                        self.perform_under_intro()
                    else:
                        self.task.mouse_up()
                    
            else: 
                self.click_echo(time_out=0)
                if self.perform_under_intro():
                    pass
                elif self.flying():
                    self.continues_normal_attack(0.1)
                elif not self.is_con_full() and self.click_liberation():
                    self.continues_normal_attack(0.5)
                self.click_resonance()
            return self.switch_next_char()
    
    def perform_25s_cycle(self):
        if self.check_outro() in {'char_moning', 'char_moning_new'}:
            # 变奏入场
            self.click_liberation()
            self.sleep(0.3)
            for i in range(3):
                self.send_resonance_key()
                self.sleep(0.01)
            self.is_sending_e = True
            def post_action(switch_to: BaseChar, has_intro: bool):
                switch_to.continues_normal_attack(1.4)
                switch_to.switch_next_char()
            self.switch_next_char(post_action=post_action)
        else:
            # e回切
            self.is_sending_e = False
            if self.resonance_available():
                self.click_resonance()
                self.sleep(1)
            self.click_echo(time_out=0)
            send_lib = self.click_liberation()
            self.task.mouse_down()
            if self.task.wait_until(lambda: not self.is_mouse_forte_full(), time_out=5):
                self.task.mouse_up()
                self.sleep(0.4)
                if not send_lib:
                    send_lib = self.click_liberation()
                self.perform_under_intro()
                if not send_lib:
                    send_lib = self.click_liberation()
            else:
                self.task.mouse_up()
            self.ensure_con_full()
            self.switch_next_char()
            

            
    def ensure_con_full(self):
        """切爱弥斯前的保底: 协奏没满就接着打, 满了才走。

        这一次切人必须带变奏入场, 否则爱弥斯 check_outro 拿不到 char_linnai,
        只会打一套普攻就切走, 本轮大招循环全废。
        超时仍然切人, 免得卡在这里脱战。
        """
        if self.is_con_full():
            return True
        self.logger.info('con not full before switching to Aemeath, keep attacking')
        self.click_echo(time_out=0)
        if self.resonance_available():
            self.click_resonance(time_out=1)
        if self.task.wait_until(self.is_con_full, post_action=self.click,
                                time_out=self.CON_FULL_TIME_OUT):
            return True
        self.logger.warning(f'con still not full after {self.CON_FULL_TIME_OUT}s, switch to Aemeath anyway')
        return False

    def perform_under_intro(self):
        if not self.check_res():
            self.logger.debug(f'Linnai fails entering accelerate mode!')
            return False
        self.task.wait_until(lambda: self.is_color_full() or self.is_con_full(), post_action=self.click,
                                     time_out=1)
        if self.task.wait_until(lambda: not self.is_forte_full(),
             post_action=self.task.jump, time_out=3):
            self.continues_normal_attack(1.6)
            self.click_liberation()
            if not self.is_con_full():
                self.click_resonance()
                self.task.wait_until(lambda: self.is_con_full(), post_action=self.click)
            # if self.task.wait_until(lambda: self.click_resonance()[0],
            #  post_action=self.click, time_out=2):
                # self.wait_after_resonance_kick()
                # second_kick = False

                # def click_second_resonance():
                #     nonlocal second_kick
                #     if self.is_con_full():
                #         return True
                #     second_kick = self.click_resonance()[0]
                #     return second_kick

                # self.task.wait_until(click_second_resonance, post_action=self.click, time_out=3)
                # if second_kick:
                #     self.wait_after_resonance_kick()
        # if not self.is_con_full() and self.click_liberation():
        #     self.task.wait_until(self.is_con_full, post_action=self.click_with_interval, time_out=1.2) 
        return True

    def wait_after_resonance_kick(self):
        self.sleep(0.3)
        self.wait_down()

    def check_res(self):
        if not self.task.in_team_and_world():
            return False
        best = self.task.find_best_match_in_box(self.task.get_box_by_name('target_box_long2'),
                                               ['has_target', 'no_target'],
                                               threshold=0.6)
        self.logger.debug(f'check res {best}')
        return best

    def is_color_full(self):
        box = self.task.box_of_screen_scaled(5120, 2880, 2846, 2602, 2889, 2690, name='color_full', hcenter=True)
        white_percent = self.task.calculate_color_percentage(forte_white_color, box)
        self.logger.debug(f'forte_color_percent {white_percent}')
        return white_percent > 0.06

    def on_combat_end(self, chars):
        self.switch_other_char()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self.is_in_25s_cycle:
            if self.is_sending_e or (has_intro and current_char and current_char.char_name in {'char_moning', 'char_moning_new'}):
                return SwitchPriority.MUST
            else:
                return SwitchPriority.NO
        elif has_intro and current_char and current_char.char_name in {'char_moning'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
