"""
赞菲光固定轴 V2.0 - Phoebe（菲比）

定位：
- 告解：支持赞妮跨角色“预按住E”；V2.0以血条上方两格蓝色forte为主确认，E旁蓝圈下降沿为辅助确认。
- P1：告解R/E/Q；3A->Starflash；再3A存下一发Starflash；N1插入交一个重击；N3后告解R。
- P2：两个Starflash硬保护后才允许变奏赞妮；N2后告解R补焰光。
- 菲比不抢F，Q在中段多为软动作：有就放，没有不阻塞主轴。

V2.0 稳定版的 3A->Z：
- 第一组采用完整3A后，再进入原版Starflash安全释放流程。
- 不使用A3尾段长按预输入，避免UI瞬时漏识别造成“Z假成功”。
- 第二组仍然只负责3A造出并保存下一发Starflash，不能提前消费。

学习建议：
- _enter_confession_on_ring_fall()：学习“两格蓝色forte主判据 + 蓝圈下降沿辅判据”的双视觉告解确认。
- _three_a() + _cast_star_required()：学习稳定的3A->Starflash硬门流程。
- _fill_concerto_and_intro_zani()：学习满协奏硬门与特殊变奏交通。
"""


import time

from src.char.BaseChar import SwitchPriority, Elements
from src.char.Phoebe import Phoebe as BuiltinPhoebe


# =============================================================================
# V2.0 学习 / 调试总览
# -----------------------------------------------------------------------------
# 这组三个角色脚本不是“各打各的优先级AI”，而是一条共享 STEP 状态机：
#
# 1) task.zanfei_rotation_state
#    三个角色共用同一份字典，核心字段是 step / phase / cycle / nightfall_count。
#    step = 大阶段；phase = 大阶段内部的小阶段。某个动作一旦确认成功，就先推进 phase，
#    这样后续切人失败、F处决、UI识别抖动都不会让已经完成的动作重放。
#
# 2) STEP_ACTOR
#    每个 STEP 都指定唯一应该站场的角色。当前角色不对时，先精确切回目标角色，
#    而不是继续执行错误角色自己的输出逻辑。
#
# 3) SPECIAL_INTRO_TARGET
#    特殊变奏交通固定为 Phoebe -> Zani -> Rover -> Phoebe。
#    如果满协奏时“想切的人”不是正确特殊变奏接收者，就先走 detour，
#    再自然切到最终目标，避免满协奏把固定轴交通撞乱。
#
# 4) 成功确认原则
#    重要技能尽量不以“按键已经发出”当作成功，而以图标消耗、状态变化、
#    角色切换结果等可观测条件确认。软动作（Q/F机会槽）则允许失败直接放行。
#
# 5) 调试方法
#    先看日志中的 "ZFG V2.0 <Actor> step=... phase=..."，再找该 STEP 的方法。
#    调时间时优先改类顶部的常量；不要先改主流程中的 sleep，避免破坏其它阶段。
# =============================================================================


class _ZFGFSM:
    ACTOR = None

    # --- 共享状态键：三个角色必须完全一致，不能只改其中一份。 ---
    STATE_KEY = 'zanfei_rotation_state'  # 共享FSM主体：step/phase/cycle等都放这里
    TEAM_SIGNATURE_KEY = 'zanfei_rotation_team_signature'  # 队伍变化检测；换队后重置固定轴
    SWITCH_LOG_KEY = 'zanfei_rotation_switch_logged'  # 避免重复刷同一条切人日志
    PHOEBE_PREHOLD_E_KEY = 'phoebe_prehold_e_active'  # 跨角色按住E：是否仍应保持按键
    PHOEBE_PREHOLD_SOURCE_KEY = 'phoebe_prehold_e_source'  # 记录是谁发起的预输入，便于查日志
    # P1-N1插入的Starflash已确认消费后，菲比蓝色forte理论上应为空。
    # 后续P1-N3跨detour预按E时，如果菲比入场首帧已经>=1/2，
    # 可用这个上下文判定“告解已在切人途中提交”，避免漏掉0->1的跃迁。
    P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY = 'p1_phoebe_forte_expected_empty'

    # P2告解动态等待：三个角色都要知道这些状态键，才能在菲比/光主之间安全往返。
    PHOEBE_LAST_CONFESSION_TIME_KEY = 'phoebe_last_confession_time'
    PHOEBE_LAST_R_CAST_TIME_KEY = 'phoebe_last_r_cast_time'
    P2_CONFESSION_AZ_USED_KEY = 'p2_confession_az_detour_used'  # 兼容旧日志：本轮是否至少走过一次光主等待槽
    P2_CONFESSION_AZ_COUNT_KEY = 'p2_confession_az_count'
    P2_CONFESSION_AZ_TARGET_KEY = 'p2_confession_az_target'
    P2_CONFESSION_RETRY_AFTER_KEY = 'p2_confession_retry_after'

    # P2 告解/R 等待调度的共享参数。Phoebe负责算初始计划，Rover每发AZ后重算。
    PHOEBE_R_COOLDOWN = 25.0
    ZANI_R2_HARD_DEADLINE_SHARED = 19.50
    P2_CONFESSION_R2_RESERVE = 6.00  # 给告解+R动画+切赞妮+N3/R2留出的尾端保护
    P2_CONFESSION_AZ_COST = 0.85
    P2_CONFESSION_SWITCH_TOTAL = 0.35
    P2_CONFESSION_PLAN_SAFETY = 0.25
    P2_CONFESSION_MAX_AZ = 6

    # =========================
    # V2.0 共享 STEP
    # P1 = 四终夜启动轴；P2 = 三终夜稳态循环
    # =========================

    STEP_P1_ZANI_OPEN_AE_TO_PHOEBE = 'P1_ZANI_OPEN_AE_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER = 'P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER'
    STEP_P1_ROVER_EQR_TO_PHOEBE = 'P1_ROVER_EQR_TO_PHOEBE'
    STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI = 'P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI'

    STEP_P1_ZANI_EFORTE_PREP = 'P1_ZANI_EFORTE_PREP'
    STEP_P1_ZANI_R1_N1_TO_ROVER = 'P1_ZANI_R1_N1_TO_ROVER'
    STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE = 'P1_ROVER_OPPORTUNITY_E_TO_PHOEBE'
    STEP_P1_PHOEBE_STAR_TO_ZANI = 'P1_PHOEBE_STAR_TO_ZANI'
    STEP_P1_ZANI_N2_TO_ROVER_R = 'P1_ZANI_N2_TO_ROVER_R'
    STEP_P1_ROVER_R_TO_ZANI = 'P1_ROVER_R_TO_ZANI'
    STEP_P1_ZANI_N3_TO_PHOEBE = 'P1_ZANI_N3_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI = 'P1_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P1_ZANI_N4_R2_E_TO_PHOEBE = 'P1_ZANI_N4_R2_E_TO_PHOEBE'

    STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI = 'P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI'
    STEP_P2_ZANI_EFORTE_PREP = 'P2_ZANI_EFORTE_PREP'
    STEP_P2_ZANI_R1_N1_TO_ROVER = 'P2_ZANI_R1_N1_TO_ROVER'
    STEP_P2_ROVER_SLOT_TO_ZANI = 'P2_ROVER_SLOT_TO_ZANI'
    STEP_P2_ZANI_N2_TO_PHOEBE = 'P2_ZANI_N2_TO_PHOEBE'

    # P2告解不再“切到菲比就盲长E”。
    # CHECK先判断还要等多久；时间长则让光主AZ一次，时间短则菲比A等待；
    # 只有真正进入告解后才进入原本的 R -> 赞妮N3。
    STEP_P2_PHOEBE_CONFESSION_CHECK = 'P2_PHOEBE_CONFESSION_CHECK'
    STEP_P2_ROVER_AZ_WAIT_CONFESSION = 'P2_ROVER_AZ_WAIT_CONFESSION'
    STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI = 'P2_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P2_ZANI_N3_R2_E_TO_PHOEBE = 'P2_ZANI_N3_R2_E_TO_PHOEBE'

    STEP_RECOVER_ZANI_LIBERATION = 'RECOVER_ZANI_LIBERATION'
    STEP_RECOVER_P2_PHOEBE = 'RECOVER_P2_PHOEBE'

    # STEP -> 应该站场的角色。角色不对时先纠错切人，不执行本角色其它动作。
    STEP_ACTOR = {
        STEP_P1_ZANI_OPEN_AE_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER: 'Phoebe',
        STEP_P1_ROVER_EQR_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI: 'Phoebe',

        STEP_P1_ZANI_EFORTE_PREP: 'Zani',
        STEP_P1_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_STAR_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N2_TO_ROVER_R: 'Zani',
        STEP_P1_ROVER_R_TO_ZANI: 'Rover',
        STEP_P1_ZANI_N3_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N4_R2_E_TO_PHOEBE: 'Zani',

        STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_EFORTE_PREP: 'Zani',
        STEP_P2_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P2_ROVER_SLOT_TO_ZANI: 'Rover',
        STEP_P2_ZANI_N2_TO_PHOEBE: 'Zani',
        STEP_P2_PHOEBE_CONFESSION_CHECK: 'Phoebe',
        STEP_P2_ROVER_AZ_WAIT_CONFESSION: 'Rover',
        STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_N3_R2_E_TO_PHOEBE: 'Zani',

        STEP_RECOVER_ZANI_LIBERATION: 'Zani',
        STEP_RECOVER_P2_PHOEBE: 'Phoebe',
    }

    # 满协奏时的“合法特殊变奏接收者”。detour交通完全依赖这张表。
    SPECIAL_INTRO_TARGET = {
        'Phoebe': 'Zani',
        'Zani': 'Rover',
        'Rover': 'Phoebe',
    }

    CONCERTO_EFFECTIVE_FULL = 0.99
    INTRO_CONFIRM_FRAMES = 3
    INTRO_CONFIRM_TIMEOUT = 1.0
    POLL = 0.05

    SWITCH_TIMEOUT = 6.0
    SWITCH_RETRY_INTERVAL = 0.04

    def _release_phoebe_prehold(self, state, reason='cleanup'):
        if not isinstance(state, dict) or not state.get(self.PHOEBE_PREHOLD_E_KEY):
            return False
        try:
            self.task.send_key_up(self.get_resonance_key())
        except Exception:
            pass
        source = state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)
        state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
        self.logger.info(
            f'ZFG Phoebe-E prehold RELEASE reason={reason} source={source}'
        )
        return True

    def _clear_zfg_state(self):
        state = getattr(self.task, self.STATE_KEY, None)
        self._release_phoebe_prehold(state, reason='clear-zfg-state')
        for key in (self.STATE_KEY, self.SWITCH_LOG_KEY):
            if hasattr(self.task, key):
                delattr(self.task, key)

    def _zfg_team_matches(self):
        """仅精确的“赞妮 + 菲比 + 漂泊者”三人队启用赞菲光固定轴。

        角色身份完全沿用OK-WW框架已经识别出的char_name，不依赖中文显示名、
        队伍顺序或当前站场角色。Rover形态已知时必须是Spectro；首次载入若
        ring_index仍为-1，只作为“形态待确认”的启动兼容，避免真正的赞菲光
        因光主尚未上场识别形态而误走默认代码。一旦框架明确识别为非Spectro，
        会立即清空固定轴状态并回落到对应角色的OK-WW内置逻辑。
        """
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            chars = ()

        # 与红绿灯轴一致：使用框架角色身份做精确三人签名；不按中文名猜队伍。
        # 不过滤None，这样角色尚未识别完整时绝不会误判为完整三人队。
        signature = tuple(
            (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.'),
                getattr(char, 'index', None),
            )
            for char in chars
        )
        required = {'char_zani', 'char_phoebe', 'char_rover'}
        identity_ok = (
            len(chars) == 3
            and {name for name, _ in signature} == required
            and any(char is self for char in chars)
        )

        rover = None
        if identity_ok:
            for char in chars:
                name = (
                    str(getattr(char, 'char_name', '') or '')
                    .casefold()
                    .removeprefix('labels.')
                )
                if name == 'char_rover':
                    rover = char
                    break

        rover_form = -1
        if rover is not None:
            # Rover当前在场时，先让框架尽可能完成一次形态识别，再读取缓存。
            try:
                if (
                    getattr(rover, 'is_current_char', False)
                    and hasattr(rover, 'ensure_display_form')
                ):
                    rover.ensure_display_form()
            except Exception:
                pass

            try:
                if hasattr(self.task, 'get_known_ring_index'):
                    rover_form = self.task.get_known_ring_index(rover)
                else:
                    rover_form = getattr(rover, 'ring_index', -1)
            except Exception:
                rover_form = getattr(rover, 'ring_index', -1)

        try:
            rover_form = int(rover_form)
        except (TypeError, ValueError):
            rover_form = -1

        spectro_confirmed = identity_ok and rover_form == int(Elements.SPECTRO)
        rover_form_pending = identity_ok and rover_form < 0

        # 形态pending只用于解决OK-WW首次加载时Rover尚未上场、ring_index=-1的问题。
        # 它不是“任意Rover都算光主”：一旦已知形态不是Spectro，马上退出固定轴。
        matched = spectro_confirmed or rover_form_pending

        previous_signature = getattr(self.task, self.TEAM_SIGNATURE_KEY, None)
        rover_form_key = 'zanfei_rotation_rover_form'
        previous_form = getattr(self.task, rover_form_key, None)

        if signature != previous_signature:
            # 真正换队/调整位置：清掉旧队伍的P1/P2进度，从新队伍重新判断。
            self._clear_zfg_state()
            setattr(self.task, self.TEAM_SIGNATURE_KEY, signature)
            setattr(self.task, rover_form_key, rover_form)
            if spectro_confirmed:
                mode = 'ZFG V2.0 fixed rotation (Spectro confirmed)'
            elif rover_form_pending:
                mode = 'ZFG V2.0 fixed rotation (Rover form pending)'
            else:
                mode = 'builtin character rotation'
            self.logger.info(
                f'ZFG team gate -> {mode}; '
                f'rover_form={rover_form} members={signature}'
            )
        elif rover_form != previous_form:
            # 同一队伍中，首次 -1 -> Spectro 只是“确认光主”，绝不能重置已在执行的P1。
            setattr(self.task, rover_form_key, rover_form)
            if (
                identity_ok
                and previous_form is not None
                and int(previous_form) < 0
                and spectro_confirmed
            ):
                self.logger.info(
                    'ZFG team gate Rover form pending -> Spectro confirmed; '
                    'preserve current FSM/STEP'
                )
            else:
                # 已知形态发生真实变化，或确认成非Spectro：旧固定轴不可继续继承。
                self._clear_zfg_state()
                mode = (
                    'ZFG V2.0 fixed rotation (Spectro confirmed)'
                    if spectro_confirmed
                    else 'builtin character rotation'
                )
                self.logger.info(
                    f'ZFG team gate Rover form changed -> {mode}; '
                    f'old={previous_form} new={rover_form}'
                )
        elif not matched:
            # 非指定队伍不能残留任何赞菲光FSM/独占切人状态。
            self._clear_zfg_state()

        if not matched and hasattr(self, '_zanfei_guang'):
            self._zanfei_guang = False

        return matched

    def _zfg_state(self):
        """Return shared FSM state.

        First creation starts from P1.  If an already-existing state is damaged,
        do not replay the one-time opening: route to the agreed recovery entry.
        """
        state = getattr(self.task, self.STATE_KEY, None)

        if state is None:
            state = {
                'step': self.STEP_P1_ZANI_OPEN_AE_TO_PHOEBE,
                'cycle': 1,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self.logger.info(
                'ZFG FSM initialize -> P1_ZANI_OPEN_AE_TO_PHOEBE'
            )
            return state

        if not isinstance(state, dict) or 'step' not in state:
            old_cycle = state.get('cycle', 1) if isinstance(state, dict) else 1
            state = {
                'cycle': old_cycle,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self._route_broken_state_to_recovery(
                state,
                reason='state-missing-step',
            )

        return state


    def _advance_step(self, state, next_step):
        old = state.get('step')
        state['step'] = next_step
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        self.logger.info(
            f'ZFG FSM advance {old} -> {next_step} '
            f'cycle={state.get("cycle", 1)} '
            f'nightfall={state.get("nightfall_count", 0)}'
        )

    def _expected_actor(self, state):
        if state.get('detour_active'):
            return state.get('detour_actor')
        return self.STEP_ACTOR.get(state.get('step'))

    def _route_broken_state_to_recovery(self, state, reason='unknown'):
        """Route a damaged FSM without replaying the one-time P1 opening.

        - Zani still in R state -> RECOVER_ZANI_LIBERATION.
        - Otherwise -> RECOVER_P2_PHOEBE.
        """
        if not isinstance(state, dict):
            return 'Phoebe'

        self._clear_detour(state)
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        zani = self if self.ACTOR == 'Zani' else self._find_target_char('Zani')
        if zani is not None and getattr(zani, 'in_liberation', False):
            state['step'] = self.STEP_RECOVER_ZANI_LIBERATION
            actor = 'Zani'
        else:
            state['step'] = self.STEP_RECOVER_P2_PHOEBE
            actor = 'Phoebe'

        self.logger.error(
            f'ZFG broken FSM recovery reason={reason} '
            f'-> step={state.get("step")} actor={actor}'
        )
        return actor

    def get_switch_priority(
        self,
        current_char=None,
        has_intro=False,
        target_low_con=False,
    ):
        if not self._zfg_team_matches():
            return super().get_switch_priority(
                current_char,
                has_intro,
                target_low_con,
            )

        state = self._zfg_state()
        expected = self._expected_actor(state)

        if expected is None:
            expected = self._route_broken_state_to_recovery(
                state,
                reason=f'unknown-step:{state.get("step")}',
            )

        if not getattr(self.task, self.SWITCH_LOG_KEY, False):
            self.logger.info(
                f'ZFG FSM-exclusive switching enabled '
                f'step={state.get("step")} expected={expected}'
            )
            setattr(self.task, self.SWITCH_LOG_KEY, True)

        return (
            SwitchPriority.MUST
            if expected == self.ACTOR
            else SwitchPriority.NO
        )

    def _find_target_char(self, target_name):
        target_name = target_name.casefold()

        for char in getattr(self.task, 'chars', []):
            if char is None or char is self:
                continue

            names = (
                getattr(char, 'name', None),
                char.__class__.__name__,
                getattr(char, 'display_name', None),
            )

            for name in names:
                if name and str(name).casefold() == target_name:
                    return char

        return None

    def _raw_con_full(self):
        try:
            return bool(self.task.is_con_full())
        except Exception:
            return bool(self.is_con_full())

    def _read_concerto(self):
        if self._raw_con_full():
            return 1.0

        try:
            value = float(self.get_current_con())
        except Exception:
            try:
                value = float(self.task.get_current_con())
            except Exception:
                value = 0.0

        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        return (
            self._raw_con_full()
            or self._read_concerto() >= self.CONCERTO_EFFECTIVE_FULL
        )

    def _confirm_hard_intro_ready(self, target_name):
        start = time.time()
        full_frames = 0

        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            if self._raw_con_full():
                full_frames += 1

                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'ZFG hard-intro guard passed '
                        f'{self.ACTOR}->{target_name} '
                        f'{full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                    )
                    return True
            else:
                full_frames = 0

            self.sleep(self.POLL)
            self.task.next_frame()

        self.logger.warning(
            f'ZFG hard-intro guard failed '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _switch_to(self, target_name, expect_intro=None):
        target = self._find_target_char(target_name)

        if target is None:
            self.logger.error(
                f'ZFG {self.ACTOR}: target not found -> {target_name}'
            )
            return False

        if expect_intro is True:
            allowed = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

            if target_name != allowed:
                self.logger.error(
                    f'ZFG invalid special intro '
                    f'{self.ACTOR}->{target_name}; '
                    f'allowed={allowed}'
                )
                return False

            if not self._confirm_hard_intro_ready(target_name):
                return False

            has_intro = True

        elif expect_intro is False:
            if self._concerto_effectively_full():
                self.logger.warning(
                    f'ZFG block forced-normal switch '
                    f'{self.ACTOR}->{target_name}: concerto full'
                )
                return False
            has_intro = False

        else:
            has_intro = self._concerto_effectively_full()

        target.has_intro = has_intro
        target.has_sub_dps_intro = (
            has_intro and getattr(self, 'is_sub_dps', False)
        )

        start = time.time()
        last_send = 0.0

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.check_combat()

            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, -1

            if in_team and current_index == target.index:
                self.task.in_liberation = False
                target.is_current_char = True

                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(
                        now,
                        target.intro_motion_freeze_duration,
                        -100,
                    )
                    self.last_outro_time = now

                self.logger.info(
                    f'ZFG exact switch success '
                    f'{self.ACTOR}->{target_name} '
                    f'intro={has_intro}'
                )
                return True

            if (
                in_team
                and current_index == self.index
                and not target.wait_switch()
            ):
                now = time.time()

                if now - last_send >= self.SWITCH_RETRY_INTERVAL:
                    self.task.send_key(target.index + 1)
                    last_send = now

            self.sleep(self.SWITCH_RETRY_INTERVAL)
            self.task.next_frame()

        self.logger.error(
            f'ZFG exact switch timeout '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _clear_detour(self, state):
        for key in (
            'detour_active',
            'detour_actor',
            'detour_final_target',
            'detour_next_step',
            'detour_resume_step',
            'detour_resume_phase',
        ):
            state.pop(key, None)

    def _switch_route(
        self,
        state,
        planned_target,
        next_step,
        force_intro=False,
    ):
        """
        正常切人入口。

        若协奏满，但planned_target不是当前角色正确的特殊变奏目标：
        保存主轴step/phase -> 先让正确角色吃特殊变奏
        -> 再自然切planned_target -> 进入next_step。
        """

        if force_intro:
            if self._switch_to(planned_target, expect_intro=True):
                self._advance_step(state, next_step)
                return True
            return False

        full = self._concerto_effectively_full()
        special_target = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

        if (
            full
            and special_target
            and planned_target != special_target
        ):
            # V2.0：P1赞妮N3后的Phoebe-E预按即使遇到特殊变奏detour也继续保持。
            # 代价是中转光主可能额外吃到一次E输入，但实机优先保证菲比到场时
            # 长按E链不断，避免“已经进入告解但蓝圈漏识别”后脚本反复重试。
            if planned_target == 'Phoebe' and state.get(self.PHOEBE_PREHOLD_E_KEY):
                self.logger.info(
                    f'ZFG Phoebe-E prehold PRESERVE across detour '
                    f'{self.ACTOR}->{special_target}->Phoebe'
                )
            resume_step = state.get('step')
            resume_phase = state.get('phase')

            self.logger.warning(
                f'ZFG intro detour required: '
                f'source={self.ACTOR} '
                f'planned={planned_target} '
                f'correct_intro={special_target} '
                f'resume={resume_step}/{resume_phase}'
            )

            if not self._switch_to(
                special_target,
                expect_intro=None,
            ):
                return False

            state['detour_active'] = True
            state['detour_actor'] = special_target
            state['detour_final_target'] = planned_target
            state['detour_next_step'] = next_step
            state['detour_resume_step'] = resume_step
            state['detour_resume_phase'] = resume_phase
            return True

        if self._switch_to(planned_target, expect_intro=None):
            self._advance_step(state, next_step)
            return True

        return False

    def _run_detour_if_needed(self, state):
        if not state.get('detour_active'):
            return False

        expected = state.get('detour_actor')

        if expected != self.ACTOR:
            self._recover_wrong_actor(state)
            return True

        final_target = state.get('detour_final_target')
        next_step = state.get('detour_next_step')
        resume_step = state.get('detour_resume_step')
        resume_phase = state.get('detour_resume_phase')

        self.logger.info(
            f'ZFG detour actor={self.ACTOR} '
            f'return={final_target} '
            f'resume={resume_step}/{resume_phase}'
        )

        if self._switch_to(final_target, expect_intro=None):
            self._clear_detour(state)
            self._advance_step(state, next_step)

        return True

    def _recover_wrong_actor(self, state):
        expected = self._expected_actor(state)

        if expected and expected != self.ACTOR:
            self.logger.warning(
                f'ZFG wrong actor: current={self.ACTOR} '
                f'step={state.get("step")} expected={expected}'
            )
            return self._switch_to(
                expected,
                expect_intro=None,
            )

        # If dispatch reached here while the current actor is already the
        # expected actor, the STEP itself has no valid handler. Treat that as
        # FSM damage and use the agreed recovery entrance instead of P1.
        recovery_actor = self._route_broken_state_to_recovery(
            state,
            reason=f'unhandled-step:{state.get("step")}',
        )

        if recovery_actor != self.ACTOR:
            return self._switch_to(
                recovery_actor,
                expect_intro=None,
            )

        return False


    def on_combat_end(self, chars):
        self._clear_zfg_state()

        if hasattr(self.task, self.TEAM_SIGNATURE_KEY):
            delattr(self.task, self.TEAM_SIGNATURE_KEY)
        if hasattr(self.task, 'zanfei_rotation_rover_form'):
            delattr(self.task, 'zanfei_rotation_rover_form')

        return super().on_combat_end(chars)



# IMPORTANT - OK-WW custom loader entrypoint:
# 公开类名必须保持“Phoebe”，不要改成PhoebeV2/CustomPhoebe等名称；
# 否则框架不会把当前自定义代码热替换到该角色实例，实战会继续执行内置代码。
class Phoebe(_ZFGFSM, BuiltinPhoebe):
    ACTOR = 'Phoebe'

    # =============================================================================
    # 菲比调试索引
    # -----------------------------------------------------------------------------
    # 1. _enter_confession_on_ring_fall()
    #    负责长E告解：支持跨角色预按E；两格蓝色forte稳定2/2即可确认，蓝圈下降沿作为独立备用证据。
    #
    # 2. _three_a() + _cast_star_required()
    #    V2.0稳定版：第一组完整3A后，再用安全Starflash流程释放Z。
    #
    # 3. _cast_star_required()
    #    统一使用经过多轮实机验证的安全Starflash释放流程。
    #
    # 4. _p1_3a_star_save_fill_to_zani()
    #    第一组3A要“打Z”；第二组3A只“存Z”。这两个目的不能混。
    #
    # 5. _p2_double_star_fill_to_zani()
    #    双Z硬保护：两发Starflash都确认消费后，才允许满协奏特殊变奏赞妮。
    # =============================================================================

    # -----------------------------------------------------------------
    # 可调参数：调试时优先改这里，不要先去主流程里随意增加 sleep。
    # -----------------------------------------------------------------
    # 告解长E双视觉：两格蓝色forte是主判据；蓝圈下降沿是辅助判据。
    CONFESSION_HOLD_TIMEOUT = 1.60
    CONFESSION_FORTE_FULL_CONFIRM_FRAMES = 2
    CONFESSION_VISIBLE_CONFIRM_FRAMES = 1
    CONFESSION_CLEAR_CONFIRM_FRAMES = 2

    # P2告解等待策略。祈愿上限120、每秒自然恢复5点，理论回满时间24s。
    # 注意：24s只用于决定“去不去光主AZ”，绝不作为告解成功判据；
    # 真正成功仍必须由“两格蓝色forte稳定2/2”或“confession ring ARMED -> FALL”至少一条强视觉证据确认。
    P2_CONFESSION_PRAYER_REFILL = 24.0
    P2_CONFESSION_AZ_THRESHOLD = 1.60   # 预计还差更多时间 -> 光主AZ一次
    P2_CONFESSION_A_WAIT_GAP = 0.18     # 差得不多 -> 菲比A一下再复查
    P2_CONFESSION_FAILED_PROBE_BACKOFF = 0.80
    P2_CONFESSION_E_READY_FRAMES = 2

    # 普攻节奏。第一组3A->Z与第二组3A存Z都统一使用普通3A节奏；
    # 第一组随后交给原版Starflash安全流程释放重击。
    THREE_A_GAP = 0.12

    # 满协奏与硬动作等待。
    CONCERTO_FILL_TIMEOUT = 9.0
    FULL_CON_TAIL = 0.20
    REQUIRED_E_TIMEOUT = 1.6
    REQUIRED_Q_TIMEOUT = 1.6

    # P1告解后的R：四终夜虽然赶时间，但菲比R属于关键补焰光动作。
    # 不允许 liberation_available() 还没亮就盲按R；必须连续稳定看到READY后再输入。
    # 每次只等待一个短slice，未就绪就保留phase，下一个do_perform继续等，绝不跳过。
    P1_CONFESSION_R_READY_FRAMES = 2
    P1_CONFESSION_R_WAIT_SLICE = 0.80
    P1_CONFESSION_R_FAST_RETRY_POLL = 0.03
    P1_CONFESSION_R_FAST_RETRY_WINDOW = 0.55

    # 长E受控窗口内 baseline=0 时，只要蓝色forte稳定从0跃迁到>=1/2，
    # 就视为告解已经提交；这是对2/2分格偶发漏掉一格的容错。
    CONFESSION_FORTE_RISE_CONFIRM_FRAMES = 2

    def f_break(
        self,
        check_f_on_switch=False,
        force=False,
    ):
        if self._zfg_team_matches():
            return False
        return super().f_break(
            check_f_on_switch=check_f_on_switch,
            force=force,
        )

    def do_perform(self):
        if not self._zfg_team_matches():
            return super().do_perform()

        if (
            getattr(self, 'team', 0) != 1
            or getattr(self, 'attribute', 0) != 2
        ):
            self.decide_teammate()

        state = self._zfg_state()

        if self._run_detour_if_needed(state):
            return

        step = state.get('step')
        self.logger.info(
            f'ZFG V2.0 Phoebe step={step} phase={state.get("phase")} '
            f'intro={self.has_intro} forte={self.is_forte_full()} '
            f'con={self._read_concerto():.3f}'
        )

        if step == self.STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER:
            return self._p1_confession_r_eq_to_rover(state)

        if step == self.STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI:
            return self._p1_3a_star_save_fill_to_zani(state)

        if step == self.STEP_P1_PHOEBE_STAR_TO_ZANI:
            return self._single_star_to_target(
                state,
                target='Zani',
                next_step=self.STEP_P1_ZANI_N2_TO_ROVER_R,
                tag='P1-N1-insert',
            )

        if step == self.STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI:
            return self._confession_r_to_target(
                state,
                target='Zani',
                next_step=self.STEP_P1_ZANI_N4_R2_E_TO_PHOEBE,
                tag='P1-before-N4',
            )

        if step == self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI:
            return self._p2_double_star_fill_to_zani(state)

        if step == self.STEP_P2_PHOEBE_CONFESSION_CHECK:
            return self._p2_confession_check(state)

        if step == self.STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI:
            return self._p2_confession_r_to_zani(state)

        if step == self.STEP_RECOVER_P2_PHOEBE:
            self.logger.warning(
                'ZFG V2.0 RECOVER_P2_PHOEBE '
                '-> P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI'
            )
            self._advance_step(
                state,
                self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI,
            )
            return

        return self._recover_wrong_actor(state)

    # =========================================================
    # 告解：蓝圈出现 -> 消失下降沿 -> 松E
    # =========================================================

    def _read_confession_forte_segments(self):
        """读取菲比告解形态的两格蓝色特殊能量。

        直接复用OK-WW原版Phoebe.judge_forte()：attribute=2时，
        它会在血条上方forte区域用phoebe_forte_blue_color按2格统计。
        固定轴只接受0/1/2，识别异常时保守返回0。
        """
        if self.attribute != 2:
            self.attribute = 2
        try:
            segments = int(self.judge_forte())
        except Exception as exc:
            self.logger.debug(
                f'ZFG V2.0 Phoebe confession forte read failed: {exc}'
            )
            return 0
        return max(0, min(2, segments))

    def _finalize_confession_visual_success(
        self,
        state,
        key,
        via,
        ring_seen=False,
        forte_baseline=None,
    ):
        """统一收口：任一强视觉证据确认告解后，松E并同步本地状态。"""
        self.task.send_key_up(key)
        state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
        state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)
        # 无论由哪条强证据确认，只要告解完成，就消费掉P1“此前应为空”的上下文。
        state.pop(self.P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY, None)

        # P2用这个时间估算Prayer自然恢复；真正放行仍由视觉证据完成。
        state[self.PHOEBE_LAST_CONFESSION_TIME_KEY] = time.time()
        self.logger.info(
            f'ZFG V2.0 Phoebe confession CONFIRMED via={via} '
            f'ring_seen={ring_seen} forte_baseline={forte_baseline}/2'
        )
        self.logger.info(
            'ZFG V2.0 Phoebe confession timestamp recorded for P2 Prayer estimate'
        )

        self.star_available = True
        self.reset_action(new_rotation=False)
        self._refill_form_charges()
        self.state['enter_status'] += 1
        return True

    def _enter_confession_on_ring_fall(self):
        """V2.0告解双视觉确认 + 分格漏识别容错。

        强判据A：两格蓝色forte稳定2/2。
        强判据B：若长E前baseline=0/2，则受控长E窗口里稳定跃迁到>=1/2也认可告解提交。
        强判据C：旧版E旁蓝圈 ARMED -> FALL。
        强判据D（仅P1）：P1-N1插入Z已确认把forte清空，且P1-N3跨detour保持预按E；
        若菲比入场首帧已经>=1/2并稳定2帧，则认为0->1跃迁发生在切人途中，告解已提交。

        B只在baseline=0且本窗口没有A/Z等其它补forte动作时成立。
        D还要求expected-empty上下文 + inherited_prehold + 精确P1 STEP，避免把P2或残留1/2误判。
        """
        if self.attribute != 2:
            self.attribute = 2

        state = self._zfg_state()
        key = self.get_resonance_key()
        start = time.time()
        ring_seen = False
        visible_frames = 0
        clear_frames = 0
        forte_full_frames = 0
        forte_rise_frames = 0
        prehold_arrival_frames = 0

        self.task.next_frame()
        forte_baseline = self._read_confession_forte_segments()
        self.logger.info(
            f'ZFG V2.0 Phoebe confession forte baseline={forte_baseline}/2'
        )

        inherited_prehold = bool(state.get(self.PHOEBE_PREHOLD_E_KEY))
        if inherited_prehold:
            self.task.send_key_down(key)
            self.logger.info(
                'ZFG V2.0 Phoebe confession inherited PREHOLD E; '
                'reassert key-down, NO-A guard active'
            )
        else:
            self.task.send_key_down(key)
            self.logger.info(
                'ZFG V2.0 Phoebe confession hold START; NO-A guard active'
            )

        # 只为P1后半告解开放的窄上下文门。
        # 如果P1-N1插入Z已把forte明确消费为空，而N3后预按E又跨detour保持，
        # 那么菲比入场首帧直接读到1/2，很可能就是告解在切人过程中已经生效，
        # 而分格识别只看到了2格中的1格。这里仍要求后续稳定2帧，不单帧放行。
        p1_prehold_arrival_guard = bool(
            state.get('step') == self.STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI
            and state.get(self.P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY)
            and inherited_prehold
            and forte_baseline >= 1
        )
        if p1_prehold_arrival_guard:
            self.logger.info(
                f'ZFG V2.0 Phoebe P1 confession PREHOLD-ARRIVAL candidate '
                f'baseline={forte_baseline}/2 expected_empty=True'
            )

        try:
            while time.time() - start < self.CONFESSION_HOLD_TIMEOUT:
                forte_segments = self._read_confession_forte_segments()

                # V2.0仅P1窄门：入场时已经>=1/2，连续稳定2帧即可确认。
                if p1_prehold_arrival_guard and forte_segments >= 1:
                    prehold_arrival_frames += 1
                    if prehold_arrival_frames == 1:
                        self.logger.info(
                            f'ZFG V2.0 Phoebe P1 confession PREHOLD-ARRIVAL '
                            f'forte={forte_segments}/2 frame=1/2'
                        )
                    if prehold_arrival_frames >= self.CONFESSION_FORTE_RISE_CONFIRM_FRAMES:
                        self.logger.info(
                            f'ZFG V2.0 Phoebe P1 confession PREHOLD-ARRIVAL stable '
                            f'{prehold_arrival_frames}/{self.CONFESSION_FORTE_RISE_CONFIRM_FRAMES} '
                            '-> release E NOW'
                        )
                        return self._finalize_confession_visual_success(
                            state, key, via='PREHOLD_ARRIVAL_1PLUS',
                            ring_seen=ring_seen, forte_baseline=forte_baseline,
                        )
                elif p1_prehold_arrival_guard:
                    prehold_arrival_frames = 0

                # 最强分格证据：稳定2/2。
                if forte_segments >= 2:
                    forte_full_frames += 1
                    if forte_full_frames == 1:
                        self.logger.info(
                            'ZFG V2.0 Phoebe confession forte=2/2 frame=1/2'
                        )
                    if forte_full_frames >= self.CONFESSION_FORTE_FULL_CONFIRM_FRAMES:
                        self.logger.info(
                            f'ZFG V2.0 Phoebe confession FORTE 2/2 stable '
                            f'{forte_full_frames}/{self.CONFESSION_FORTE_FULL_CONFIRM_FRAMES} '
                            f'-> release E NOW'
                        )
                        return self._finalize_confession_visual_success(
                            state, key, via='FORTE_2OF2', ring_seen=ring_seen,
                            forte_baseline=forte_baseline,
                        )
                else:
                    forte_full_frames = 0

                # V2.0容错：受控长E期间0/2 -> >=1/2稳定跃迁。
                # 只允许baseline=0，避免“本来就剩1格”被当成新告解。
                if forte_baseline == 0 and forte_segments >= 1:
                    forte_rise_frames += 1
                    if forte_rise_frames == 1:
                        self.logger.info(
                            f'ZFG V2.0 Phoebe confession FORTE rise 0/2->{forte_segments}/2 '
                            'frame=1/2'
                        )
                    if forte_rise_frames >= self.CONFESSION_FORTE_RISE_CONFIRM_FRAMES:
                        self.logger.info(
                            f'ZFG V2.0 Phoebe confession FORTE positive transition stable '
                            f'{forte_rise_frames}/{self.CONFESSION_FORTE_RISE_CONFIRM_FRAMES} '
                            '-> release E NOW'
                        )
                        return self._finalize_confession_visual_success(
                            state, key, via='FORTE_RISE_0_TO_1PLUS',
                            ring_seen=ring_seen, forte_baseline=forte_baseline,
                        )
                else:
                    forte_rise_frames = 0

                # 独立辅助强证据：蓝圈下降沿。
                visible = bool(self.confession_ready())
                if not ring_seen:
                    if visible:
                        visible_frames += 1
                        if visible_frames >= self.CONFESSION_VISIBLE_CONFIRM_FRAMES:
                            ring_seen = True
                            clear_frames = 0
                            self.logger.info(
                                'ZFG V2.0 Phoebe confession ring ARMED'
                            )
                    else:
                        visible_frames = 0
                else:
                    if visible:
                        clear_frames = 0
                    else:
                        clear_frames += 1
                        if clear_frames >= self.CONFESSION_CLEAR_CONFIRM_FRAMES:
                            self.logger.info(
                                'ZFG V2.0 Phoebe confession ring FALL -> release E NOW'
                            )
                            return self._finalize_confession_visual_success(
                                state, key, via='RING_FALL', ring_seen=True,
                                forte_baseline=forte_baseline,
                            )

                self.task.next_frame()
                self.sleep(0.01)
        finally:
            self.task.send_key_up(key)
            state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
            state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)

        last_forte = self._read_confession_forte_segments()
        self.logger.warning(
            f'ZFG V2.0 Phoebe confession timeout ring_seen={ring_seen} '
            f'forte_baseline={forte_baseline}/2 forte_last={last_forte}/2 '
            f'inherited_prehold={inherited_prehold} '
            f'p1_prehold_arrival_guard={p1_prehold_arrival_guard}'
        )
        return False

    def _three_a(self, tag):
        """普通3A：只负责把A1/A2/A3完整打出，不主动把下一发重击消费掉。

        这个版本专门用于“3A后要存Z”的阶段。因为第二组3A的目的就是让
        Starflash进入可用状态并保留下来，所以这里绝不能偷偷长按A。
        """
        self.logger.info(f'ZFG V2.0 Phoebe {tag}: AAA start')
        for index in range(3):
            self.task.click()
            self.logger.debug(f'ZFG V2.0 Phoebe {tag}: A{index + 1} sent')
            self.sleep(self.THREE_A_GAP)
            self.task.next_frame()
        self.logger.info(f'ZFG V2.0 Phoebe {tag}: AAA end')

    # =========================================================
    # 通用动作硬门
    # =========================================================

    def _cast_control_e_required(self, tag):
        start = time.time()

        while time.time() - start < self.REQUIRED_E_TIMEOUT:
            self.task.next_frame()

            if self.resonance_available():
                clicked, duration, animated = self.click_resonance(
                    send_click=False,
                    time_out=0.8,
                    click_f=False,
                )
                if clicked:
                    self.logger.info(
                        f'ZFG V2.0 Phoebe {tag}: control E confirmed '
                        f'duration={duration:.2f} animated={animated}'
                    )
                    return True

            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V2.0 Phoebe {tag}: control E not confirmed'
        )
        return False

    def _cast_echo_required(self, tag):
        start = time.time()

        while time.time() - start < self.REQUIRED_Q_TIMEOUT:
            self.task.next_frame()

            if self.echo_available():
                base_result = self.click_echo(time_out=0.8)
                self.task.next_frame()
                consumed = not self.echo_available()

                if base_result or consumed:
                    self.logger.info(
                        f'ZFG V2.0 Phoebe {tag}: Q confirmed '
                        f'base_result={bool(base_result)} consumed={consumed}'
                    )
                    return True

            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V2.0 Phoebe {tag}: Q not confirmed'
        )
        return False

    def _wait_p1_confession_r_ready(self, tag):
        """等待P1告解后的菲比R真正READY。

        设计目的：
        - 旧版会在R图标尚未亮时直接调用可靠R输入，产生 no-effect + 长确认等待；
        - V2.0改为“READY是输入前置条件”，不再拿失败输入试CD；
        - 连续2帧READY才通过，过滤单帧UI抖动；
        - 一个slice没等到就返回False并保留r_cancel phase，下轮继续等，不推进STEP。
        """
        start = time.time()
        stable = 0
        first_log = True

        while time.time() - start < self.P1_CONFESSION_R_WAIT_SLICE:
            self.task.next_frame()
            ready = bool(self.liberation_available())

            if ready:
                stable += 1
                if stable >= self.P1_CONFESSION_R_READY_FRAMES:
                    self.logger.info(
                        f'ZFG V2.0 Phoebe {tag}: R READY stable '
                        f'{stable}/{self.P1_CONFESSION_R_READY_FRAMES} -> allow input'
                    )
                    return True
            else:
                stable = 0
                if first_log:
                    self.logger.info(
                        f'ZFG V2.0 Phoebe {tag}: R not ready -> WAIT, no blind input'
                    )
                    first_log = False

            self.sleep(self.POLL)

        self.logger.info(
            f'ZFG V2.0 Phoebe {tag}: R still cooling -> keep r_cancel phase'
        )
        return False

    def _record_phoebe_r_shared_time(self, input_time, tag):
        state = self._zfg_state()
        state[self.PHOEBE_LAST_R_CAST_TIME_KEY] = float(input_time)
        self.logger.info(
            f'ZFG V2.0 Phoebe {tag}: R cooldown timestamp armed at input'
        )

    def _cast_confession_r_required(self, tag):
        """通用可靠R：保留原版扩展确认；成功后记录共享R起始时刻供P2算25s CD。"""
        input_time = time.time()
        if not self._click_liberation_reliable(
            send_click=False,
            tag=f' {tag}',
        ):
            self.logger.warning(
                f'ZFG V2.0 Phoebe {tag}: R failed -> keep phase'
            )
            return False

        self._record_phoebe_r_shared_time(input_time, tag)
        self._record_liberation_cast()
        self.logger.info(
            f'ZFG V2.0 Phoebe {tag}: confession R confirmed (NO-A R input)'
        )
        return True

    def _cast_p1_confession_r_fast_required(self, tag):
        """P1四终夜专用：R第一次no-effect后不再固定等1s，图标重新READY就立刻retry。"""
        for attempt in (1, 2):
            if attempt > 1:
                start = time.time()
                stable = 0
                while time.time() - start < self.P1_CONFESSION_R_FAST_RETRY_WINDOW:
                    self.task.next_frame()
                    if self.liberation_available():
                        stable += 1
                        if stable >= 1:
                            self.logger.info(
                                f'ZFG V2.0 Phoebe {tag}: R re-READY -> FAST retry now'
                            )
                            break
                    else:
                        stable = 0
                    self.sleep(self.P1_CONFESSION_R_FAST_RETRY_POLL)
                else:
                    self.logger.warning(
                        f'ZFG V2.0 Phoebe {tag}: R fast-retry window expired -> keep phase'
                    )
                    return False

            if not self.liberation_available():
                self.logger.info(
                    f'ZFG V2.0 Phoebe {tag}: R not READY at attempt={attempt} -> keep phase'
                )
                return False

            input_time = time.time()
            self.logger.info(
                f'ZFG V2.0 Phoebe {tag}: R FAST input attempt={attempt}'
            )
            if self.click_liberation(
                send_click=False, wait_if_cd_ready=0, click_f=False
            ):
                self.state['liber_no_effect_at'] = 0
                self._record_phoebe_r_shared_time(input_time, tag)
                self._record_liberation_cast()
                self.logger.info(
                    f'ZFG V2.0 Phoebe {tag}: confession R FAST confirmed attempt={attempt}'
                )
                return True

            self.logger.warning(
                f'ZFG V2.0 Phoebe {tag}: R FAST no-effect attempt={attempt}; '
                'NO fixed 1.0s extended wait'
            )

        self._mark_liber_no_effect()
        return False

    def _cast_echo_soft(self, tag):
        """脱手Q机会动作：有就放，没有直接通过。"""
        if not self.echo_available():
            self.logger.info(f'ZFG V2.0 Phoebe {tag}: soft Q skip cooldown')
            return False
        result = self.click_echo(time_out=0)
        self.logger.info(f'ZFG V2.0 Phoebe {tag}: soft Q result={result}')
        return bool(result)

    def _charge_starflash_without_recover_e(self, timeout=5.0):
        """P2双Z保护：只用A充重击，不允许自动长E恢复，保留E给后续告解。"""
        start = time.time()
        attacks = 0
        while not self.is_forte_full() and time.time() - start < timeout:
            self.task.click()
            attacks += 1
            self.sleep(0.05)
            self.task.next_frame()
        self.logger.info(
            f'ZFG V2.0 Phoebe no-recover star charge end '
            f'ready={bool(self.is_forte_full())} attacks={attacks}'
        )
        return bool(self.is_forte_full())

    def _cast_star_required(self, tag, allow_recover_e=True):
        if not self.is_forte_full():
            if allow_recover_e:
                self._charge_starflash_until_full(
                    finish_with_right_click=False,
                )
            else:
                self._charge_starflash_without_recover_e()

        if not self.is_forte_full():
            self.logger.warning(
                f'ZFG V2.0 Phoebe {tag}: Starflash not ready'
            )
            return False

        self.starflash_combo()
        self.task.next_frame()

        if self.is_forte_full():
            self.logger.warning(
                f'ZFG V2.0 Phoebe {tag}: Starflash not consumed'
            )
            return False

        self.logger.info(
            f'ZFG V2.0 Phoebe {tag}: Starflash consumed'
        )
        return True

    def _fill_concerto_and_intro_zani(
        self,
        state,
        next_step,
        require_saved_star,
        tag,
    ):
        phase = state.get('phase')

        if phase == 'fill_con':
            ready = self._attack_until_con(
                self.CONCERTO_FILL_TIMEOUT,
                check_liber=False,
                require_forte=require_saved_star,
            )

            if ready is None:
                return False

            if not ready:
                self.logger.warning(
                    f'ZFG V2.0 Phoebe {tag}: concerto fill timeout'
                )
                return False

            if require_saved_star and not self.is_forte_full():
                self.logger.warning(
                    f'ZFG V2.0 Phoebe {tag}: saved Starflash lost'
                )
                state['phase'] = 'save_star'
                return False

            if not self._raw_con_full():
                return False

            state['phase'] = 'full_tail'
            phase = 'full_tail'

        if phase == 'full_tail':
            self.continues_normal_attack(self.FULL_CON_TAIL)
            self.task.next_frame()

            if not self._raw_con_full():
                state['phase'] = 'fill_con'
                return False

            self.logger.info(
                f'ZFG V2.0 Phoebe {tag}: '
                'FULL concerto + 0.20s tail confirmed'
            )
            state['phase'] = 'switch_zani'
            phase = 'switch_zani'

        if phase == 'switch_zani':
            if not self._raw_con_full():
                state['phase'] = 'fill_con'
                return False

            switched = self._switch_route(
                state,
                'Zani',
                next_step,
                force_intro=True,
            )
            if switched:
                self.first_rotation_done = True
            return switched

        return False

    # =========================================================
    # P1 前半：告解R -> E -> Q -> 光主
    # =========================================================

    def _p1_confession_r_eq_to_rover(self, state):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P1 confession entry')
            state['phase'] = 'confession'
            phase = 'confession'

        if phase == 'confession':
            if (
                not state.get(self.PHOEBE_PREHOLD_E_KEY)
                and not self.resonance_available()
            ):
                self.sleep(self.POLL)
                self.task.next_frame()
                return

            if not self._enter_confession_on_ring_fall():
                return

            state['phase'] = 'r_cancel'
            phase = 'r_cancel'

        if phase == 'r_cancel':
            if not self._cast_confession_r_required(
                'P1 confession-cancel',
            ):
                return

            # R返回UI可用后，下一phase立刻尝试短E。
            state['phase'] = 'control_e'
            phase = 'control_e'

        if phase == 'control_e':
            if not self._cast_control_e_required('P1 after-R'):
                return
            state['phase'] = 'q'
            phase = 'q'

        if phase == 'q':
            if not self._cast_echo_required('P1 after-R'):
                return
            state['phase'] = 'switch_rover'
            phase = 'switch_rover'

        if phase == 'switch_rover':
            self._switch_route(
                state,
                'Rover',
                self.STEP_P1_ROVER_EQR_TO_PHOEBE,
            )

    # =========================================================
    # P1 后半：光主EQR回来 -> AAA Z -> AAA存Z -> 补协奏 -> 赞妮
    # =========================================================

    def _p1_3a_star_save_fill_to_zani(self, state):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P1 3A entry')
            state['phase'] = 'aaa_star'
            phase = 'aaa_star'

        if phase == 'aaa_star':
            # V2.0稳定版：回退A3尾段预输入。
            # 先完整打完3A，再进入经过多轮实机验证的Starflash安全释放流程。
            # 这样会牺牲一点点衔接速度，但能避免A3尾段UI瞬时消失造成Z假成功。
            self._three_a('P1 first')
            state['phase'] = 'star1'
            phase = 'star1'

        if phase == 'star1':
            if not self._cast_star_required('P1 first'):
                return
            state['phase'] = 'aaa_save'
            phase = 'aaa_save'

        if phase == 'aaa_save':
            # 这一组3A只“造出”下一发Starflash，不允许用预输入消费。
            # 该重击要一直保存到赞妮N1插入时再交。
            self._three_a('P1 save')
            state['phase'] = 'save_star'
            phase = 'save_star'

        if phase == 'save_star':
            if not self.is_forte_full():
                self._charge_starflash_until_full(
                    finish_with_right_click=False,
                )

            if not self.is_forte_full():
                return

            self.logger.info(
                'ZFG V2.0 Phoebe P1 saved Starflash READY; DO NOT CAST'
            )
            state['phase'] = 'fill_con'
            phase = 'fill_con'

        if phase in ('fill_con', 'full_tail', 'switch_zani'):
            self._fill_concerto_and_intro_zani(
                state,
                self.STEP_P1_ZANI_EFORTE_PREP,
                require_saved_star=True,
                tag='P1 setup',
            )

    # =========================================================
    # P1 N1插入：菲比只交一个重击 -> 赞妮
    # =========================================================

    def _single_star_to_target(
        self,
        state,
        target,
        next_step,
        tag,
    ):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded(tag)
            state['phase'] = 'star'
            phase = 'star'

        if phase == 'star':
            if not self._cast_star_required(tag):
                return

            # V2.0：P1-N1插入Z已经真实消费后，记录“菲比告解蓝条理论应为空”。
            # 这个标记只服务于后面的P1-N3告解入场判定；P2不使用。
            if tag == 'P1-N1-insert':
                state[self.P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY] = True
                self.logger.info(
                    'ZFG V2.0 Phoebe P1-N1-insert: forte expected EMPTY armed '
                    'for later prehold-arrival confession guard'
                )

            state['phase'] = 'switch'
            phase = 'switch'

        if phase == 'switch':
            self._switch_route(
                state,
                target,
                next_step,
            )

    # =========================================================
    # V2.0 P2告解动态等待：菲比检查 -> 光主AZ(最多一次) / 菲比A等待 -> 告解
    # =========================================================

    def _p2_confession_remaining(self, state):
        """Prayer理论24s剩余；只用于调度，不直接宣告告解成功。"""
        last = state.get(self.PHOEBE_LAST_CONFESSION_TIME_KEY)
        if not isinstance(last, (int, float)) or last <= 0:
            return None, None
        elapsed = max(0.0, time.time() - last)
        remaining = max(0.0, self.P2_CONFESSION_PRAYER_REFILL - elapsed)
        return elapsed, remaining

    def _p2_phoebe_r_remaining(self, state):
        """按上一次真实R输入时刻，以freeze-aware计时估算25s RCD。"""
        last = state.get(self.PHOEBE_LAST_R_CAST_TIME_KEY)
        if not isinstance(last, (int, float)) or last <= 0:
            return 0.0 if self.liberation_available() else None
        elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(last)))
        return max(0.0, self.PHOEBE_R_COOLDOWN - elapsed)

    def _p2_r2_fill_room(self, state):
        """还能拿多少秒去光主填轴，同时保证赞妮R2尾端留6s保护。"""
        start = float(state.get('zani_r1_timer_start', 0) or 0)
        if start <= 0:
            return None, None
        elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(start)))
        r2_left = max(0.0, self.ZANI_R2_HARD_DEADLINE_SHARED - elapsed)
        fill_room = max(0.0, r2_left - self.P2_CONFESSION_R2_RESERVE)
        return r2_left, fill_room

    def _p2_confession_e_stably_available(self):
        ready_frames = 0
        for _ in range(3):
            self.task.next_frame()
            if self.resonance_available():
                ready_frames += 1
            else:
                ready_frames = 0
            if ready_frames >= self.P2_CONFESSION_E_READY_FRAMES:
                return True
            self.sleep(0.03)
        return False

    def _p2_wait_budget(self, state):
        elapsed, prayer = self._p2_confession_remaining(state)
        r_rem = self._p2_phoebe_r_remaining(state)
        retry_after = float(state.get(self.P2_CONFESSION_RETRY_AFTER_KEY, 0.0) or 0.0)
        retry_wait = max(0.0, retry_after - time.time())
        known = [x for x in (prayer, r_rem) if isinstance(x, (int, float))]
        if retry_wait > 0:
            known.append(retry_wait)
        need = max(known) if known else None
        r2_left, fill_room = self._p2_r2_fill_room(state)
        return elapsed, prayer, r_rem, retry_wait, need, r2_left, fill_room

    def _p2_plan_rover_az(self, state, reason, force_one=False):
        """按剩余等待与R2截止计算本次光主最多AZ数量；Rover每发后还会再次重算。"""
        _, prayer, r_rem, retry_wait, need, r2_left, fill_room = self._p2_wait_budget(state)
        total_done = int(state.get(self.P2_CONFESSION_AZ_COUNT_KEY, 0) or 0)
        remaining_total = max(0, self.P2_CONFESSION_MAX_AZ - total_done)
        if remaining_total <= 0:
            return False

        if need is None:
            n = 1 if force_one else 0
        else:
            effective = need
            if fill_room is not None:
                effective = min(effective, fill_room)
            usable = effective - self.P2_CONFESSION_SWITCH_TOTAL - self.P2_CONFESSION_PLAN_SAFETY
            n = int(max(0.0, usable) // self.P2_CONFESSION_AZ_COST)
            if force_one and n <= 0 and (fill_room is None or fill_room >= self.P2_CONFESSION_AZ_COST):
                n = 1
        n = max(0, min(n, remaining_total))
        if n <= 0:
            return False

        state[self.P2_CONFESSION_AZ_USED_KEY] = True
        state[self.P2_CONFESSION_AZ_TARGET_KEY] = total_done + n
        self._release_phoebe_prehold(state, reason='p2-confession-dynamic-rover')
        self.logger.info(
            f'ZFG V2.0 P2 confession -> Rover dynamic fill reason={reason} '
            f'Prayer={prayer} Rrem={r_rem} retry={retry_wait:.2f}s '
            f'R2left={r2_left} fill_room={fill_room} AZ_plan={n} '
            f'total_target={total_done + n}'
        )
        self._switch_route(state, 'Rover', self.STEP_P2_ROVER_AZ_WAIT_CONFESSION)
        return True

    def _p2_confession_check(self, state):
        """P2三终夜：Prayer/RCD长就光主动态AZ填轴，短就菲比A；E/R真正就绪后再告解/R。"""
        phase = state.get('phase', 'entry')
        if phase == 'entry':
            self._release_phoebe_prehold(state, reason='p2-confession-check-entry')
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P2 confession check')
            state['phase'] = 'decide'
            phase = 'decide'

        if phase == 'decide':
            elapsed, prayer, r_rem, retry_wait, need, r2_left, fill_room = self._p2_wait_budget(state)
            e_ready = self._p2_confession_e_stably_available()
            az_done = int(state.get(self.P2_CONFESSION_AZ_COUNT_KEY, 0) or 0)
            self.logger.info(
                f'ZFG V2.0 P2 confession CHECK Prayer_elapsed={elapsed} '
                f'Prayer_rem={prayer} R_rem={r_rem} E={e_ready} '
                f'retry={retry_wait:.2f}s R2_left={r2_left} fill_room={fill_room} AZ_done={az_done}'
            )

            # 以Prayer/R/retry里最慢的一项作为“可拿来填输出”的等待。
            if need is None:
                if not e_ready and self._p2_plan_rover_az(state, 'timer-unknown-E-cooldown', force_one=True):
                    return
            elif need > self.P2_CONFESSION_AZ_THRESHOLD:
                if self._p2_plan_rover_az(state, f'wait-budget-{need:.2f}s'):
                    return

            # 时间已不足以值得再切光主：菲比A一发后重算，避免罚站。
            if (need is not None and need > 0) or retry_wait > 0:
                self.logger.info(
                    f'ZFG V2.0 P2 confession A-WAIT need≈{0.0 if need is None else need:.2f}s'
                )
                self.task.click()
                self.sleep(self.P2_CONFESSION_A_WAIT_GAP)
                self.task.next_frame()
                return

            if not e_ready:
                if self._p2_plan_rover_az(state, 'Prayer/R-ready-but-E-cooldown', force_one=True):
                    return
                self.task.click()
                self.sleep(self.P2_CONFESSION_A_WAIT_GAP)
                self.task.next_frame()
                return

            self.logger.info(
                'ZFG V2.0 P2 confession CHECK -> attempt confession; forte/ring remains final gate'
            )
            self._advance_step(state, self.STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI)
            return

    def _p2_confession_r_to_zani(self, state):
        """P2专用告解硬门：告解没真正成功时绝不进入R/N3。"""
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            self._release_phoebe_prehold(state, reason='p2-confession-attempt-entry')
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P2-before-N3')
            state['phase'] = 'confession'
            phase = 'confession'

        if phase == 'confession':
            # 再做一次E可用确认；若此时仍在普通E CD，回CHECK而不是硬按。
            if not self._p2_confession_e_stably_available():
                self.logger.info(
                    'ZFG V2.0 P2 confession attempt blocked: E unavailable -> CHECK'
                )
                self._advance_step(state, self.STEP_P2_PHOEBE_CONFESSION_CHECK)
                return

            if not self._enter_confession_on_ring_fall():
                # 失败通常意味着：祈愿/福音仍未满足，或误触普通E进入12s CD。
                # 第一次失败优先把等待时间交给光主AZ；AZ已用则菲比A等待。
                state[self.P2_CONFESSION_RETRY_AFTER_KEY] = (
                    time.time() + self.P2_CONFESSION_FAILED_PROBE_BACKOFF
                )
                self.logger.warning(
                    'ZFG V2.0 P2 confession visual confirmation missing -> recalc dynamic Rover/A wait'
                )
                if self._p2_plan_rover_az(
                    state, reason='confession-probe-failed', force_one=True
                ):
                    return
                self._advance_step(state, self.STEP_P2_PHOEBE_CONFESSION_CHECK)
                return

            # 两格蓝色forte或蓝圈下降沿任一强确认成功，才允许进入R。
            state.pop(self.P2_CONFESSION_RETRY_AFTER_KEY, None)
            state['phase'] = 'r_cancel'
            phase = 'r_cancel'

        if phase == 'r_cancel':
            # 告解已经确认后禁止再A；只等R真正READY，READY立刻放R。
            if not self._wait_p1_confession_r_ready('P2-before-N3'):
                return
            if not self._cast_confession_r_required('P2-before-N3'):
                return
            self._cast_echo_soft('P2-before-N3-after-R')
            state.pop(self.P2_CONFESSION_AZ_USED_KEY, None)
            state.pop(self.P2_CONFESSION_AZ_COUNT_KEY, None)
            state.pop(self.P2_CONFESSION_AZ_TARGET_KEY, None)
            state.pop(self.P2_CONFESSION_RETRY_AFTER_KEY, None)
            state['phase'] = 'switch'
            phase = 'switch'

        if phase == 'switch':
            self._switch_route(
                state,
                'Zani',
                self.STEP_P2_ZANI_N3_R2_E_TO_PHOEBE,
            )

    # =========================================================
    # P1中段通用：长E告解 -> R取消 -> 立即回赞妮
    # =========================================================

    def _confession_r_to_target(
        self,
        state,
        target,
        next_step,
        tag,
    ):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded(tag)
            state['phase'] = 'confession'
            phase = 'confession'

        if phase == 'confession':
            if not state.get(self.PHOEBE_PREHOLD_E_KEY):
                ready_frames = 0
                for _ in range(3):
                    self.task.next_frame()
                    if self.resonance_available():
                        ready_frames += 1
                    else:
                        ready_frames = 0
                    self.sleep(0.03)
                if ready_frames < 2:
                    self.sleep(self.POLL)
                    return

            if not self._enter_confession_on_ring_fall():
                # 不连续狂长按；让UI/CD推进后再重试。
                self.sleep(0.20)
                return

            state['phase'] = 'r_cancel'
            phase = 'r_cancel'

        if phase == 'r_cancel':
            # V2.0：P1菲比告解后的R是关键补焰光动作。
            # 先等R图标真正READY，再进行纯R输入；R未好时绝不盲按、绝不推进STEP。
            if not self._wait_p1_confession_r_ready(tag):
                return
            if not self._cast_p1_confession_r_fast_required(tag):
                return
            self._cast_echo_soft(f'{tag}-after-R')
            state['phase'] = 'switch'
            phase = 'switch'

        if phase == 'switch':
            self._switch_route(
                state,
                target,
                next_step,
            )

    # =========================================================
    # P2 起点：两个重击 -> 补满协奏 -> 特殊变奏赞妮
    # =========================================================

    def _p2_double_star_fill_to_zani(self, state):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            state['p2_double_star_done'] = False
            if state.pop('new_cycle_pending', False):
                state['cycle'] = int(state.get('cycle', 1)) + 1
                self.logger.info(
                    f'ZFG V2.0 enter P2 cycle {state["cycle"]}'
                )

            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)

            self._ensure_grounded('P2 double-star entry')
            state['phase'] = 'star1'
            phase = 'star1'

        if phase == 'star1':
            if not self._cast_star_required('P2 star1', allow_recover_e=False):
                return
            state['phase'] = 'star2'
            phase = 'star2'

        if phase == 'star2':
            if not self._cast_star_required('P2 star2', allow_recover_e=False):
                return
            state['p2_double_star_done'] = True
            self.logger.info('ZFG V2.0 Phoebe P2 DOUBLE-STAR HARD GUARD satisfied 2/2')
            state['phase'] = 'fill_con'
            phase = 'fill_con'

        if phase in ('fill_con', 'full_tail', 'switch_zani'):
            if not state.get('p2_double_star_done'):
                self.logger.warning('ZFG V2.0 Phoebe block intro: P2 double-star guard not satisfied')
                state['phase'] = 'star2'
                return
            self._fill_concerto_and_intro_zani(
                state,
                self.STEP_P2_ZANI_EFORTE_PREP,
                require_saved_star=False,
                tag='P2 double-star',
            )
