"""
赞菲光固定轴 V2.0 - Zani（赞妮）

定位：
- P1：负责四终夜启动轴的 A-E 开场、强化E准备、R1计时、N1~N4、R2与收尾E。
- P2：负责三终夜循环轴的强化E准备、R1、N1~N3、R2与收尾E。
- 赞妮在 R 持续期内禁止主动 F；R 外站场允许机会型 F 检测，F 后原 phase 续轴。
- 手动闪避不会直接修改 STEP/phase，但可能取消当前技能动画；V2.0 的强化E提交锁可在被打断后续接，
  仍建议不要在强化E/R/终夜的关键提交瞬间手动闪避。

P1 主链：
赞妮 A-E -> 菲比告解R/E/Q -> 光主E/Q/R -> 菲比3A重击、3A存重击、满协奏
-> 特殊变奏赞妮 -> 强化E准备 -> R1+Q+N1保护切出
-> 光主机会E -> 菲比重击 -> 赞妮N2 -> 光主快照技能
-> 赞妮N3(菲比E预输入) -> 菲比告解R -> 赞妮N4 -> R2 -> E -> 菲比

P2 主链：
菲比双重击+满协奏 -> 特殊变奏赞妮 -> 强化E准备 -> R1+Q+N1
-> 光主资源短轴 -> 赞妮N2 -> 菲比告解R -> 赞妮N3 -> R2 -> E -> 菲比。

学习建议：
- 先看类顶部“可调参数”；这些值控制E确认、N1保护、R2截止、F检测频率。
- 再看 do_perform() 的 STEP 分发；它相当于赞妮的总路由表。
- 最后看每个 STEP 方法内部的 phase 推进，这里决定“动作成功后从哪里续轴”。
"""


import time

from src.char.BaseChar import SwitchPriority, Elements
from src.char.Zani import Zani as BuiltinZani


# =============================================================================
# V2.0 学习 / 调试总览
# -----------------------------------------------------------------------------
# 这组三个角色脚本不是“各打各的优先级AI”，而是一条共享 STEP 状态机：
#
# 1) task.zanfei_rotation_state
#    三个角色共用同一份字典，核心字段是 step / phase / cycle / nightfall_count。
#    step = 大阶段；phase = 大阶段内部的小阶段。某个动作一旦确认成功，就先推进 phase，
#    这样后续切人失败、F处决、UI识别抖动都不会让已经完成的动作重放。
#
# 2) STEP_ACTOR
#    每个 STEP 都指定唯一应该站场的角色。当前角色不对时，先精确切回目标角色，
#    而不是继续执行错误角色自己的输出逻辑。
#
# 3) SPECIAL_INTRO_TARGET
#    特殊变奏交通固定为 Phoebe -> Zani -> Rover -> Phoebe。
#    如果满协奏时“想切的人”不是正确特殊变奏接收者，就先走 detour，
#    再自然切到最终目标，避免满协奏把固定轴交通撞乱。
#
# 4) 成功确认原则
#    重要技能尽量不以“按键已经发出”当作成功，而以图标消耗、状态变化、
#    角色切换结果等可观测条件确认。软动作（Q/F机会槽）则允许失败直接放行。
#
# 5) 调试方法
#    先看日志中的 "ZFG V2.0 <Actor> step=... phase=..."，再找该 STEP 的方法。
#    调时间时优先改类顶部的常量；不要先改主流程中的 sleep，避免破坏其它阶段。
# =============================================================================


class _ZFGFSM:
    ACTOR = None

    # --- 共享状态键：三个角色必须完全一致，不能只改其中一份。 ---
    STATE_KEY = 'zanfei_rotation_state'  # 共享FSM主体：step/phase/cycle等都放这里
    TEAM_SIGNATURE_KEY = 'zanfei_rotation_team_signature'  # 队伍变化检测；换队后重置固定轴
    SWITCH_LOG_KEY = 'zanfei_rotation_switch_logged'  # 避免重复刷同一条切人日志
    PHOEBE_PREHOLD_E_KEY = 'phoebe_prehold_e_active'  # 跨角色按住E：是否仍应保持按键
    PHOEBE_PREHOLD_SOURCE_KEY = 'phoebe_prehold_e_source'  # 记录是谁发起的预输入，便于查日志
    # P1-N1插入的Starflash已确认消费后，菲比蓝色forte理论上应为空。
    # 后续P1-N3跨detour预按E时，如果菲比入场首帧已经>=1/2，
    # 可用这个上下文判定“告解已在切人途中提交”，避免漏掉0->1的跃迁。
    P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY = 'p1_phoebe_forte_expected_empty'

    # P2告解动态等待：三个角色都要知道这些状态键，才能在菲比/光主之间安全往返。
    PHOEBE_LAST_CONFESSION_TIME_KEY = 'phoebe_last_confession_time'
    PHOEBE_LAST_R_CAST_TIME_KEY = 'phoebe_last_r_cast_time'
    P2_CONFESSION_AZ_USED_KEY = 'p2_confession_az_detour_used'  # 兼容旧日志：本轮是否至少走过一次光主等待槽
    P2_CONFESSION_AZ_COUNT_KEY = 'p2_confession_az_count'
    P2_CONFESSION_AZ_TARGET_KEY = 'p2_confession_az_target'
    P2_CONFESSION_RETRY_AFTER_KEY = 'p2_confession_retry_after'

    # P2 告解/R 等待调度的共享参数。Phoebe负责算初始计划，Rover每发AZ后重算。
    PHOEBE_R_COOLDOWN = 25.0
    ZANI_R2_HARD_DEADLINE_SHARED = 19.50
    P2_CONFESSION_R2_RESERVE = 6.00  # 给告解+R动画+切赞妮+N3/R2留出的尾端保护
    P2_CONFESSION_AZ_COST = 0.85
    P2_CONFESSION_SWITCH_TOTAL = 0.35
    P2_CONFESSION_PLAN_SAFETY = 0.25
    P2_CONFESSION_MAX_AZ = 6

    # =========================
    # V2.0 共享 STEP
    # P1 = 四终夜启动轴；P2 = 三终夜稳态循环
    # =========================

    STEP_P1_ZANI_OPEN_AE_TO_PHOEBE = 'P1_ZANI_OPEN_AE_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER = 'P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER'
    STEP_P1_ROVER_EQR_TO_PHOEBE = 'P1_ROVER_EQR_TO_PHOEBE'
    STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI = 'P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI'

    STEP_P1_ZANI_EFORTE_PREP = 'P1_ZANI_EFORTE_PREP'
    STEP_P1_ZANI_R1_N1_TO_ROVER = 'P1_ZANI_R1_N1_TO_ROVER'
    STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE = 'P1_ROVER_OPPORTUNITY_E_TO_PHOEBE'
    STEP_P1_PHOEBE_STAR_TO_ZANI = 'P1_PHOEBE_STAR_TO_ZANI'
    STEP_P1_ZANI_N2_TO_ROVER_R = 'P1_ZANI_N2_TO_ROVER_R'
    STEP_P1_ROVER_R_TO_ZANI = 'P1_ROVER_R_TO_ZANI'
    STEP_P1_ZANI_N3_TO_PHOEBE = 'P1_ZANI_N3_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI = 'P1_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P1_ZANI_N4_R2_E_TO_PHOEBE = 'P1_ZANI_N4_R2_E_TO_PHOEBE'

    STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI = 'P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI'
    STEP_P2_ZANI_EFORTE_PREP = 'P2_ZANI_EFORTE_PREP'
    STEP_P2_ZANI_R1_N1_TO_ROVER = 'P2_ZANI_R1_N1_TO_ROVER'
    STEP_P2_ROVER_SLOT_TO_ZANI = 'P2_ROVER_SLOT_TO_ZANI'
    STEP_P2_ZANI_N2_TO_PHOEBE = 'P2_ZANI_N2_TO_PHOEBE'

    # P2告解不再“切到菲比就盲长E”。
    # CHECK先判断还要等多久；时间长则让光主AZ一次，时间短则菲比A等待；
    # 只有真正进入告解后才进入原本的 R -> 赞妮N3。
    STEP_P2_PHOEBE_CONFESSION_CHECK = 'P2_PHOEBE_CONFESSION_CHECK'
    STEP_P2_ROVER_AZ_WAIT_CONFESSION = 'P2_ROVER_AZ_WAIT_CONFESSION'
    STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI = 'P2_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P2_ZANI_N3_R2_E_TO_PHOEBE = 'P2_ZANI_N3_R2_E_TO_PHOEBE'

    STEP_RECOVER_ZANI_LIBERATION = 'RECOVER_ZANI_LIBERATION'
    STEP_RECOVER_P2_PHOEBE = 'RECOVER_P2_PHOEBE'

    # STEP -> 应该站场的角色。角色不对时先纠错切人，不执行本角色其它动作。
    STEP_ACTOR = {
        STEP_P1_ZANI_OPEN_AE_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER: 'Phoebe',
        STEP_P1_ROVER_EQR_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI: 'Phoebe',

        STEP_P1_ZANI_EFORTE_PREP: 'Zani',
        STEP_P1_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_STAR_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N2_TO_ROVER_R: 'Zani',
        STEP_P1_ROVER_R_TO_ZANI: 'Rover',
        STEP_P1_ZANI_N3_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N4_R2_E_TO_PHOEBE: 'Zani',

        STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_EFORTE_PREP: 'Zani',
        STEP_P2_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P2_ROVER_SLOT_TO_ZANI: 'Rover',
        STEP_P2_ZANI_N2_TO_PHOEBE: 'Zani',
        STEP_P2_PHOEBE_CONFESSION_CHECK: 'Phoebe',
        STEP_P2_ROVER_AZ_WAIT_CONFESSION: 'Rover',
        STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_N3_R2_E_TO_PHOEBE: 'Zani',

        STEP_RECOVER_ZANI_LIBERATION: 'Zani',
        STEP_RECOVER_P2_PHOEBE: 'Phoebe',
    }

    # 满协奏时的“合法特殊变奏接收者”。detour交通完全依赖这张表。
    SPECIAL_INTRO_TARGET = {
        'Phoebe': 'Zani',
        'Zani': 'Rover',
        'Rover': 'Phoebe',
    }

    CONCERTO_EFFECTIVE_FULL = 0.99
    INTRO_CONFIRM_FRAMES = 3
    INTRO_CONFIRM_TIMEOUT = 1.0
    POLL = 0.05

    SWITCH_TIMEOUT = 6.0
    SWITCH_RETRY_INTERVAL = 0.04

    def _release_phoebe_prehold(self, state, reason='cleanup'):
        if not isinstance(state, dict) or not state.get(self.PHOEBE_PREHOLD_E_KEY):
            return False
        try:
            self.task.send_key_up(self.get_resonance_key())
        except Exception:
            pass
        source = state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)
        state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
        self.logger.info(
            f'ZFG Phoebe-E prehold RELEASE reason={reason} source={source}'
        )
        return True

    def _clear_zfg_state(self):
        state = getattr(self.task, self.STATE_KEY, None)
        self._release_phoebe_prehold(state, reason='clear-zfg-state')
        for key in (self.STATE_KEY, self.SWITCH_LOG_KEY):
            if hasattr(self.task, key):
                delattr(self.task, key)

    def _zfg_team_matches(self):
        """仅精确的“赞妮 + 菲比 + 漂泊者”三人队启用赞菲光固定轴。

        角色身份完全沿用OK-WW框架已经识别出的char_name，不依赖中文显示名、
        队伍顺序或当前站场角色。Rover形态已知时必须是Spectro；首次载入若
        ring_index仍为-1，只作为“形态待确认”的启动兼容，避免真正的赞菲光
        因光主尚未上场识别形态而误走默认代码。一旦框架明确识别为非Spectro，
        会立即清空固定轴状态并回落到对应角色的OK-WW内置逻辑。
        """
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            chars = ()

        # 与红绿灯轴一致：使用框架角色身份做精确三人签名；不按中文名猜队伍。
        # 不过滤None，这样角色尚未识别完整时绝不会误判为完整三人队。
        signature = tuple(
            (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.'),
                getattr(char, 'index', None),
            )
            for char in chars
        )
        required = {'char_zani', 'char_phoebe', 'char_rover'}
        identity_ok = (
            len(chars) == 3
            and {name for name, _ in signature} == required
            and any(char is self for char in chars)
        )

        rover = None
        if identity_ok:
            for char in chars:
                name = (
                    str(getattr(char, 'char_name', '') or '')
                    .casefold()
                    .removeprefix('labels.')
                )
                if name == 'char_rover':
                    rover = char
                    break

        rover_form = -1
        if rover is not None:
            # Rover当前在场时，先让框架尽可能完成一次形态识别，再读取缓存。
            try:
                if (
                    getattr(rover, 'is_current_char', False)
                    and hasattr(rover, 'ensure_display_form')
                ):
                    rover.ensure_display_form()
            except Exception:
                pass

            try:
                if hasattr(self.task, 'get_known_ring_index'):
                    rover_form = self.task.get_known_ring_index(rover)
                else:
                    rover_form = getattr(rover, 'ring_index', -1)
            except Exception:
                rover_form = getattr(rover, 'ring_index', -1)

        try:
            rover_form = int(rover_form)
        except (TypeError, ValueError):
            rover_form = -1

        spectro_confirmed = identity_ok and rover_form == int(Elements.SPECTRO)
        rover_form_pending = identity_ok and rover_form < 0

        # 形态pending只用于解决OK-WW首次加载时Rover尚未上场、ring_index=-1的问题。
        # 它不是“任意Rover都算光主”：一旦已知形态不是Spectro，马上退出固定轴。
        matched = spectro_confirmed or rover_form_pending

        previous_signature = getattr(self.task, self.TEAM_SIGNATURE_KEY, None)
        rover_form_key = 'zanfei_rotation_rover_form'
        previous_form = getattr(self.task, rover_form_key, None)

        if signature != previous_signature:
            # 真正换队/调整位置：清掉旧队伍的P1/P2进度，从新队伍重新判断。
            self._clear_zfg_state()
            setattr(self.task, self.TEAM_SIGNATURE_KEY, signature)
            setattr(self.task, rover_form_key, rover_form)
            if spectro_confirmed:
                mode = 'ZFG V2.0 fixed rotation (Spectro confirmed)'
            elif rover_form_pending:
                mode = 'ZFG V2.0 fixed rotation (Rover form pending)'
            else:
                mode = 'builtin character rotation'
            self.logger.info(
                f'ZFG team gate -> {mode}; '
                f'rover_form={rover_form} members={signature}'
            )
        elif rover_form != previous_form:
            # 同一队伍中，首次 -1 -> Spectro 只是“确认光主”，绝不能重置已在执行的P1。
            setattr(self.task, rover_form_key, rover_form)
            if (
                identity_ok
                and previous_form is not None
                and int(previous_form) < 0
                and spectro_confirmed
            ):
                self.logger.info(
                    'ZFG team gate Rover form pending -> Spectro confirmed; '
                    'preserve current FSM/STEP'
                )
            else:
                # 已知形态发生真实变化，或确认成非Spectro：旧固定轴不可继续继承。
                self._clear_zfg_state()
                mode = (
                    'ZFG V2.0 fixed rotation (Spectro confirmed)'
                    if spectro_confirmed
                    else 'builtin character rotation'
                )
                self.logger.info(
                    f'ZFG team gate Rover form changed -> {mode}; '
                    f'old={previous_form} new={rover_form}'
                )
        elif not matched:
            # 非指定队伍不能残留任何赞菲光FSM/独占切人状态。
            self._clear_zfg_state()

        if not matched and hasattr(self, '_zanfei_guang'):
            self._zanfei_guang = False

        return matched

    def _zfg_state(self):
        """Return shared FSM state.

        First creation starts from P1.  If an already-existing state is damaged,
        do not replay the one-time opening: route to the agreed recovery entry.
        """
        state = getattr(self.task, self.STATE_KEY, None)

        if state is None:
            state = {
                'step': self.STEP_P1_ZANI_OPEN_AE_TO_PHOEBE,
                'cycle': 1,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self.logger.info(
                'ZFG FSM initialize -> P1_ZANI_OPEN_AE_TO_PHOEBE'
            )
            return state

        if not isinstance(state, dict) or 'step' not in state:
            old_cycle = state.get('cycle', 1) if isinstance(state, dict) else 1
            state = {
                'cycle': old_cycle,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self._route_broken_state_to_recovery(
                state,
                reason='state-missing-step',
            )

        return state


    def _advance_step(self, state, next_step):
        old = state.get('step')
        state['step'] = next_step
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        self.logger.info(
            f'ZFG FSM advance {old} -> {next_step} '
            f'cycle={state.get("cycle", 1)} '
            f'nightfall={state.get("nightfall_count", 0)}'
        )

    def _expected_actor(self, state):
        if state.get('detour_active'):
            return state.get('detour_actor')
        return self.STEP_ACTOR.get(state.get('step'))

    def _route_broken_state_to_recovery(self, state, reason='unknown'):
        """Route a damaged FSM without replaying the one-time P1 opening.

        - Zani still in R state -> RECOVER_ZANI_LIBERATION.
        - Otherwise -> RECOVER_P2_PHOEBE.
        """
        if not isinstance(state, dict):
            return 'Phoebe'

        self._clear_detour(state)
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        zani = self if self.ACTOR == 'Zani' else self._find_target_char('Zani')
        if zani is not None and getattr(zani, 'in_liberation', False):
            state['step'] = self.STEP_RECOVER_ZANI_LIBERATION
            actor = 'Zani'
        else:
            state['step'] = self.STEP_RECOVER_P2_PHOEBE
            actor = 'Phoebe'

        self.logger.error(
            f'ZFG broken FSM recovery reason={reason} '
            f'-> step={state.get("step")} actor={actor}'
        )
        return actor

    def get_switch_priority(
        self,
        current_char=None,
        has_intro=False,
        target_low_con=False,
    ):
        if not self._zfg_team_matches():
            return super().get_switch_priority(
                current_char,
                has_intro,
                target_low_con,
            )

        state = self._zfg_state()
        expected = self._expected_actor(state)

        if expected is None:
            expected = self._route_broken_state_to_recovery(
                state,
                reason=f'unknown-step:{state.get("step")}',
            )

        if not getattr(self.task, self.SWITCH_LOG_KEY, False):
            self.logger.info(
                f'ZFG FSM-exclusive switching enabled '
                f'step={state.get("step")} expected={expected}'
            )
            setattr(self.task, self.SWITCH_LOG_KEY, True)

        return (
            SwitchPriority.MUST
            if expected == self.ACTOR
            else SwitchPriority.NO
        )

    def _find_target_char(self, target_name):
        target_name = target_name.casefold()

        for char in getattr(self.task, 'chars', []):
            if char is None or char is self:
                continue

            names = (
                getattr(char, 'name', None),
                char.__class__.__name__,
                getattr(char, 'display_name', None),
            )

            for name in names:
                if name and str(name).casefold() == target_name:
                    return char

        return None

    def _raw_con_full(self):
        try:
            return bool(self.task.is_con_full())
        except Exception:
            return bool(self.is_con_full())

    def _read_concerto(self):
        if self._raw_con_full():
            return 1.0

        try:
            value = float(self.get_current_con())
        except Exception:
            try:
                value = float(self.task.get_current_con())
            except Exception:
                value = 0.0

        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        return (
            self._raw_con_full()
            or self._read_concerto() >= self.CONCERTO_EFFECTIVE_FULL
        )

    def _confirm_hard_intro_ready(self, target_name):
        start = time.time()
        full_frames = 0

        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            if self._raw_con_full():
                full_frames += 1

                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'ZFG hard-intro guard passed '
                        f'{self.ACTOR}->{target_name} '
                        f'{full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                    )
                    return True
            else:
                full_frames = 0

            self.sleep(self.POLL)
            self.task.next_frame()

        self.logger.warning(
            f'ZFG hard-intro guard failed '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _switch_to(self, target_name, expect_intro=None):
        target = self._find_target_char(target_name)

        if target is None:
            self.logger.error(
                f'ZFG {self.ACTOR}: target not found -> {target_name}'
            )
            return False

        if expect_intro is True:
            allowed = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

            if target_name != allowed:
                self.logger.error(
                    f'ZFG invalid special intro '
                    f'{self.ACTOR}->{target_name}; '
                    f'allowed={allowed}'
                )
                return False

            if not self._confirm_hard_intro_ready(target_name):
                return False

            has_intro = True

        elif expect_intro is False:
            if self._concerto_effectively_full():
                self.logger.warning(
                    f'ZFG block forced-normal switch '
                    f'{self.ACTOR}->{target_name}: concerto full'
                )
                return False
            has_intro = False

        else:
            has_intro = self._concerto_effectively_full()

        target.has_intro = has_intro
        target.has_sub_dps_intro = (
            has_intro and getattr(self, 'is_sub_dps', False)
        )

        start = time.time()
        last_send = 0.0

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.check_combat()

            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, -1

            if in_team and current_index == target.index:
                self.task.in_liberation = False
                target.is_current_char = True

                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(
                        now,
                        target.intro_motion_freeze_duration,
                        -100,
                    )
                    self.last_outro_time = now

                self.logger.info(
                    f'ZFG exact switch success '
                    f'{self.ACTOR}->{target_name} '
                    f'intro={has_intro}'
                )
                return True

            if (
                in_team
                and current_index == self.index
                and not target.wait_switch()
            ):
                now = time.time()

                if now - last_send >= self.SWITCH_RETRY_INTERVAL:
                    self.task.send_key(target.index + 1)
                    last_send = now

            self.sleep(self.SWITCH_RETRY_INTERVAL)
            self.task.next_frame()

        self.logger.error(
            f'ZFG exact switch timeout '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _clear_detour(self, state):
        for key in (
            'detour_active',
            'detour_actor',
            'detour_final_target',
            'detour_next_step',
            'detour_resume_step',
            'detour_resume_phase',
        ):
            state.pop(key, None)

    def _switch_route(
        self,
        state,
        planned_target,
        next_step,
        force_intro=False,
    ):
        """
        正常切人入口。

        若协奏满，但planned_target不是当前角色正确的特殊变奏目标：
        保存主轴step/phase -> 先让正确角色吃特殊变奏
        -> 再自然切planned_target -> 进入next_step。
        """

        if force_intro:
            if self._switch_to(planned_target, expect_intro=True):
                self._advance_step(state, next_step)
                return True
            return False

        full = self._concerto_effectively_full()
        special_target = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

        if (
            full
            and special_target
            and planned_target != special_target
        ):
            # V2.0：P1赞妮N3后的Phoebe-E预按即使遇到特殊变奏detour也继续保持。
            # 代价是中转光主可能额外吃到一次E输入，但实机优先保证菲比到场时
            # 长按E链不断，避免“已经进入告解但蓝圈漏识别”后脚本反复重试。
            if planned_target == 'Phoebe' and state.get(self.PHOEBE_PREHOLD_E_KEY):
                self.logger.info(
                    f'ZFG Phoebe-E prehold PRESERVE across detour '
                    f'{self.ACTOR}->{special_target}->Phoebe'
                )
            resume_step = state.get('step')
            resume_phase = state.get('phase')

            self.logger.warning(
                f'ZFG intro detour required: '
                f'source={self.ACTOR} '
                f'planned={planned_target} '
                f'correct_intro={special_target} '
                f'resume={resume_step}/{resume_phase}'
            )

            if not self._switch_to(
                special_target,
                expect_intro=None,
            ):
                return False

            state['detour_active'] = True
            state['detour_actor'] = special_target
            state['detour_final_target'] = planned_target
            state['detour_next_step'] = next_step
            state['detour_resume_step'] = resume_step
            state['detour_resume_phase'] = resume_phase
            return True

        if self._switch_to(planned_target, expect_intro=None):
            self._advance_step(state, next_step)
            return True

        return False

    def _run_detour_if_needed(self, state):
        if not state.get('detour_active'):
            return False

        expected = state.get('detour_actor')

        if expected != self.ACTOR:
            self._recover_wrong_actor(state)
            return True

        final_target = state.get('detour_final_target')
        next_step = state.get('detour_next_step')
        resume_step = state.get('detour_resume_step')
        resume_phase = state.get('detour_resume_phase')

        self.logger.info(
            f'ZFG detour actor={self.ACTOR} '
            f'return={final_target} '
            f'resume={resume_step}/{resume_phase}'
        )

        if self._switch_to(final_target, expect_intro=None):
            self._clear_detour(state)
            self._advance_step(state, next_step)

        return True

    def _recover_wrong_actor(self, state):
        expected = self._expected_actor(state)

        if expected and expected != self.ACTOR:
            self.logger.warning(
                f'ZFG wrong actor: current={self.ACTOR} '
                f'step={state.get("step")} expected={expected}'
            )
            return self._switch_to(
                expected,
                expect_intro=None,
            )

        # If dispatch reached here while the current actor is already the
        # expected actor, the STEP itself has no valid handler. Treat that as
        # FSM damage and use the agreed recovery entrance instead of P1.
        recovery_actor = self._route_broken_state_to_recovery(
            state,
            reason=f'unhandled-step:{state.get("step")}',
        )

        if recovery_actor != self.ACTOR:
            return self._switch_to(
                recovery_actor,
                expect_intro=None,
            )

        return False


    def on_combat_end(self, chars):
        self._clear_zfg_state()

        if hasattr(self.task, self.TEAM_SIGNATURE_KEY):
            delattr(self.task, self.TEAM_SIGNATURE_KEY)
        if hasattr(self.task, 'zanfei_rotation_rover_form'):
            delattr(self.task, 'zanfei_rotation_rover_form')

        return super().on_combat_end(chars)



# IMPORTANT - OK-WW custom loader entrypoint:
# 公开类名必须保持“Zani”，不要改成ZaniV2/CustomZani等名称；
# 否则框架不会把当前自定义代码热替换到该角色实例，实战会继续执行内置代码。
class Zani(_ZFGFSM, BuiltinZani):
    ACTOR = 'Zani'

    # =============================================================================
    # 赞妮调试索引
    # -----------------------------------------------------------------------------
    # 1. _enhanced_e_prep_step()
    #    负责“强化E > 普通E > A”的准备逻辑；普通E和强化E都必须有状态确认。
    #
    # 2. _r1_n1_early_handoff()
    #    R1确认后启动20秒计时。P1的N1使用更保守的终夜保护，宁可慢一点也不能丢N1。
    #
    # 3. _nightfall_then_switch() / _final_nightfall_r2_e()
    #    中段终夜与最终终夜分开处理。最终终夜禁止通用time guard提前抢R2。
    #
    # 4. _field_f_check()
    #    只在非R持续期触发F；F发生后不改step/phase，依靠冻结时间修正继续原轴。
    #
    # 日志定位建议：
    #    先搜 "ZFG V2.0 Zani step="，再根据phase进入对应函数。
    # =============================================================================

    # =========================
    # V2.0 可调参数
    # =========================

    OPEN_A_TO_E_GAP = 0.08  # 开场A后到E的最短间隔；太大浪费P1时间，太小可能吞E

    ENHANCED_E_PREP_TIMEOUT = 7.0
    ENHANCED_E_CONFIRM_TIMEOUT = 1.50
    # 强化E图标“黑一下”可能来自受击/瞬时UI抖动；只有持续消失一段时间才算真正释放。
    ENHANCED_E_CLEAR_STABLE_SECONDS = 0.35
    # 强化E提交失败后额外观察一小段时间：如果图标随后持续消失，
    # 视为“输入被F/闪避/动作锁延迟，但最终已经成功释放”，不回退普通E。
    ENHANCED_E_AMBIGUOUS_SETTLE_TIMEOUT = 0.70

    # EFORTE准备状态必须跨 do_perform() 持久化。
    # 这是 V2.0 修复“普通E -> 强化E确认失败 -> 下一轮又从普通E开始”的核心。
    EFORTE_NORMAL_E_LAST_CAST_KEY = 'zani_eforte_normal_e_last_cast'
    EFORTE_NORMAL_E_CASTS_KEY = 'zani_eforte_normal_e_casts'
    EFORTE_ENHANCED_READY_SEEN_KEY = 'zani_eforte_enhanced_ready_seen'
    EFORTE_COMMIT_LOCK_KEY = 'zani_eforte_commit_lock'
    EFORTE_FIRST_INPUT_TIME_KEY = 'zani_eforte_first_input_time'
    EFORTE_COMMIT_ATTEMPTS_KEY = 'zani_eforte_commit_attempts'

    # 普通E真实CD为5s。UI在刚释放后可能仍被resonance_available判为亮，
    # 因此允许“未来再次普通E”，但至少经过真实CD附近才重试，避免0.5s假重复。
    NORMAL_E_REAL_CD = 5.0
    NORMAL_E_RECAST_MIN_ELAPSED = 4.80
    NORMAL_E_ATTACK_INTERVAL = 0.08
    NORMAL_E_POST_CAST_SETTLE = 0.08
    NORMAL_E_CONFIRM_TIMEOUT = 0.45
    NORMAL_E_CLEAR_CONFIRM_FRAMES = 2

    LIBERATION_READY_TIMEOUT = 2.5  # R1等待上限；失败不推进phase
    POST_R2_E_TIMEOUT = 2.5         # R2后E的硬等待上限；E成功后才允许切菲比

    # N1：
    # P1四终夜优先保证“终夜真的提交”，不再把E锁定当成功证据。
    # 必须看到终夜图标真正消失的 falling-edge，并保留最短提交保护窗后才切光主。
    # P2三终夜时间宽裕度更高，但暂时保留原来的极限早切策略。
    N1_ICON_ACQUIRE_TIMEOUT = 3.5
    N1_COMMIT_CONFIRM_TIMEOUT = 0.22
    N1_COMMIT_CLEAR_FRAMES = 1
    P1_N1_PROTECT_MIN_AFTER_TRIGGER = 0.35
    P1_N1_PROTECT_TIMEOUT = 2.50
    P1_N1_PROTECT_CLEAR_FRAMES = 2

    # 赞妮R外F检测；R持续期内明确禁止赞妮主动F。
    F_CHECK_INTERVAL = 0.20
    F_POST_ACTION_SETTLE_TIME = 0.12

    # 最终终夜(N4/P2-N3)绝不允许通用time guard提前抢R2。
    # R1确认时启动20s计时；T+19.50s作为R2硬截止门。
    FINAL_N_ICON_TIMEOUT = 3.0
    FINAL_N_COMMIT_TIMEOUT = 0.60
    R2_HARD_DEADLINE = 19.50  # 从R1确认时刻计时；给20s形态尾端留0.5s输入安全余量
    FINAL_N_SMASH_DONE_LEFT = 0.08

    NIGHTFALL_DONE = 'DONE'
    NIGHTFALL_FAILED = 'FAILED'
    NIGHTFALL_LIBERATION_ENDED = 'LIBERATION_ENDED'
    NIGHTFALL_R2_TRIGGERED = 'R2_TRIGGERED'
    NIGHTFALL_R2_DEADLINE = 'R2_DEADLINE'

    def _init_eforte_state(self, state, tag):
        """初始化一次新的强化E准备，不在重试时重复清零。"""
        state[self.EFORTE_NORMAL_E_LAST_CAST_KEY] = -1.0
        state[self.EFORTE_NORMAL_E_CASTS_KEY] = 0
        state[self.EFORTE_ENHANCED_READY_SEEN_KEY] = False
        state[self.EFORTE_COMMIT_LOCK_KEY] = False
        state[self.EFORTE_FIRST_INPUT_TIME_KEY] = 0.0
        state[self.EFORTE_COMMIT_ATTEMPTS_KEY] = 0
        self.logger.info(
            f'ZFG V2.0 {tag}: EFORTE state initialized; manual F/dodge recovery enabled'
        )

    def _clear_eforte_state(self, state):
        """强化E阶段完成后清理临时状态，避免污染下一轮P1/P2。"""
        for key in (
            self.EFORTE_NORMAL_E_LAST_CAST_KEY,
            self.EFORTE_NORMAL_E_CASTS_KEY,
            self.EFORTE_ENHANCED_READY_SEEN_KEY,
            self.EFORTE_COMMIT_LOCK_KEY,
            self.EFORTE_FIRST_INPUT_TIME_KEY,
            self.EFORTE_COMMIT_ATTEMPTS_KEY,
        ):
            state.pop(key, None)

    def _eforte_commit_locked(self, state):
        """仅在当前确实处于P1/P2 EFORTE阶段时启用提交锁。

        自动F在这个窗口必须让路。手动闪避/F无法被脚本物理禁止，
        但提交锁会保证被打断后只重试强化E，不回普通E。
        """
        if state.get('step') not in (
            self.STEP_P1_ZANI_EFORTE_PREP,
            self.STEP_P2_ZANI_EFORTE_PREP,
        ):
            return False
        if state.get('phase') not in ('prepare_e', 'buff_settle'):
            return False
        return bool(state.get(self.EFORTE_COMMIT_LOCK_KEY, False))

    def f_break(
        self,
        check_f_on_switch=False,
        force=False,
    ):
        # 赞菲光轴禁止框架层自动F；仅由下面受控的R外窗口主动检查。
        if self._zfg_team_matches():
            return False
        return super().f_break(
            check_f_on_switch=check_f_on_switch,
            force=force,
        )

    def _run_f_break_with_freeze(self, label):
        f_start = time.time()
        if not super().f_break(check_f_on_switch=False, force=False):
            return False
        f_duration = max(0.0, time.time() - f_start)
        if self.F_POST_ACTION_SETTLE_TIME > 0:
            self.sleep(self.F_POST_ACTION_SETTLE_TIME)
            self.task.next_frame()
        blocked = max(0.0, time.time() - f_start)
        self.add_freeze_duration(f_start, blocked)
        self.logger.info(
            f'ZFG V2.0 Zani F execution outside liberation during {label}; '
            f'F={f_duration:.2f}s freeze={blocked:.2f}s'
        )
        return True

    def _field_f_check(self, force=False, resume_label='Zani on-field'):
        # R持续期间绝不由赞妮主动F；变奏动画期间也不抢输入。
        if self.in_liberation or self.has_intro or not self.is_current_char:
            return False
        now = time.time()
        last = getattr(self, '_zfg_last_f_check', -100.0)
        if not force and now - last < self.F_CHECK_INTERVAL:
            return False
        self._zfg_last_f_check = now
        self.task.next_frame()
        return self._run_f_break_with_freeze(resume_label)

    def do_perform(self):
        if not self._zfg_team_matches():
            return super().do_perform()

        self._zanfei_guang = True
        state = self._zfg_state()

        if self._run_detour_if_needed(state):
            return

        step = state.get('step')
        phase = state.get('phase')

        # 用户要求：赞妮除R持续期外，其余站场时间都允许一次机会型F检测。
        # 但一旦强化E READY 进入提交锁，自动F必须让路，直到强化E确认/结算完成。
        # 手动闪避/F仍可能打断动作；V2.0 会保留EFORTE进度并只重试强化E。
        if not self.in_liberation:
            if not self._eforte_commit_locked(state):
                if self._field_f_check(resume_label=f'step={step} phase={phase}'):
                    return
            else:
                self.logger.debug(
                    'ZFG V2.0 Zani E_COMMIT_LOCK active -> skip automatic F'
                )

        self.logger.info(
            f'ZFG V2.0 Zani step={step} phase={phase} '
            f'intro={self.has_intro} liber={self.in_liberation} '
            f'N={state.get("nightfall_count", 0)}'
        )

        if step == self.STEP_P1_ZANI_OPEN_AE_TO_PHOEBE:
            return self._p1_open_ae(state)

        if step == self.STEP_P1_ZANI_EFORTE_PREP:
            return self._enhanced_e_prep_step(
                state,
                self.STEP_P1_ZANI_R1_N1_TO_ROVER,
                tag='P1-EFORTE',
            )

        if step == self.STEP_P1_ZANI_R1_N1_TO_ROVER:
            return self._r1_n1_early_handoff(
                state,
                self.STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE,
                tag='P1-N1',
            )

        if step == self.STEP_P1_ZANI_N2_TO_ROVER_R:
            return self._nightfall_then_switch(
                state,
                nightfall_number=2,
                target='Rover',
                next_step=self.STEP_P1_ROVER_R_TO_ZANI,
                tag='P1-N2',
            )

        if step == self.STEP_P1_ZANI_N3_TO_PHOEBE:
            return self._nightfall_then_switch(
                state,
                nightfall_number=3,
                target='Phoebe',
                next_step=self.STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI,
                tag='P1-N3',
                prehold_phoebe=True,
            )

        if step == self.STEP_P1_ZANI_N4_R2_E_TO_PHOEBE:
            return self._final_nightfall_r2_e(
                state,
                nightfall_number=4,
                next_phoebe_step=self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI,
                tag='P1-N4',
                mark_new_cycle=True,
                r2_policy='p1_deadline',
            )

        if step == self.STEP_P2_ZANI_EFORTE_PREP:
            return self._enhanced_e_prep_step(
                state,
                self.STEP_P2_ZANI_R1_N1_TO_ROVER,
                tag='P2-EFORTE',
            )

        if step == self.STEP_P2_ZANI_R1_N1_TO_ROVER:
            return self._r1_n1_early_handoff(
                state,
                self.STEP_P2_ROVER_SLOT_TO_ZANI,
                tag='P2-N1',
            )

        if step == self.STEP_P2_ZANI_N2_TO_PHOEBE:
            # V2.0：P2三终夜时间宽裕，取消这里的跨角色E预按。
            # 第一次进入本STEP时重置“动态AZ填轴”状态；后续由菲比按Prayer/RCD和R2截止算预算。
            if state.get('phase') is None:
                state[self.P2_CONFESSION_AZ_USED_KEY] = False
                state[self.P2_CONFESSION_AZ_COUNT_KEY] = 0
                state.pop(self.P2_CONFESSION_AZ_TARGET_KEY, None)
                state.pop(self.P2_CONFESSION_RETRY_AFTER_KEY, None)
            return self._nightfall_then_switch(
                state,
                nightfall_number=2,
                target='Phoebe',
                next_step=self.STEP_P2_PHOEBE_CONFESSION_CHECK,
                tag='P2-N2',
                prehold_phoebe=False,
            )

        if step == self.STEP_P2_ZANI_N3_R2_E_TO_PHOEBE:
            return self._final_nightfall_r2_e(
                state,
                nightfall_number=3,
                next_phoebe_step=self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI,
                tag='P2-N3',
                mark_new_cycle=True,
                r2_policy='p2_after_n3_or_deadline',
            )

        if step == self.STEP_RECOVER_ZANI_LIBERATION:
            return self._recover_liberation(state)

        return self._recover_wrong_actor(state)

    # =========================================================
    # P1 开场：A -> E -> 立即预按E切菲比
    # =========================================================

    def _arm_phoebe_prehold(self, state, tag, require_zani_e_locked=True):
        if state.get(self.PHOEBE_PREHOLD_E_KEY):
            return True
        if require_zani_e_locked and self.resonance_available():
            self.logger.info(
                f'ZFG V2.0 {tag}: skip Phoebe-E prehold for now; Zani E still available'
            )
            return False
        self.task.send_key_down(self.get_resonance_key())
        state[self.PHOEBE_PREHOLD_E_KEY] = True
        state[self.PHOEBE_PREHOLD_SOURCE_KEY] = self.ACTOR
        self.logger.info(f'ZFG V2.0 {tag}: Phoebe-E PREHOLD armed')
        return True

    def _p1_open_ae(self, state):
        phase = state.get('phase', 'a')

        if phase == 'a':
            self.task.click()
            self.sleep(self.OPEN_A_TO_E_GAP, check_combat=False)
            self.logger.info('ZFG V2.0 P1 opening: A sent')
            state['phase'] = 'e'
            phase = 'e'

        if phase == 'e':
            if not self.resonance_available():
                self.task.click()
                self.sleep(0.03)
                self.task.next_frame()
                return

            clicked, _, _ = self.click_resonance(
                send_click=False,
                time_out=0.7,
            )
            if not clicked:
                return

            self.logger.info(
                'ZFG V2.0 P1 opening: E confirmed -> no chair delay; prehold E for Phoebe'
            )
            # E已经确认释放，赞妮E进入CD后再按住同一E键不会重复放技能，
            # 这个held key跨切人交给菲比，让她入场直接开始告解。
            self._arm_phoebe_prehold(
                state,
                'P1-opening',
                require_zani_e_locked=False,
            )
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            if not state.get(self.PHOEBE_PREHOLD_E_KEY):
                self._arm_phoebe_prehold(
                    state,
                    'P1-opening-retry',
                    require_zani_e_locked=False,
                )
            switched = self._switch_route(
                state,
                'Phoebe',
                self.STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER,
            )
            if not switched:
                self._release_phoebe_prehold(state, reason='P1-opening-switch-failed')

    # =========================================================
    # 强化E准备：独立STEP，可供P1/P2共用
    # =========================================================

    def _cast_normal_e_once(self):
        """普通E：发送后必须看到“普通E进入不可用”或“强化E接管图标”才算成功。"""
        if self.is_e_forte_full():
            return False
        if not self.resonance_available():
            return False

        clicked, _, _ = self.click_resonance(
            send_click=False,
            time_out=0.7,
        )
        if not clicked:
            return False

        confirm_start = time.time()
        clear_frames = 0
        while time.time() - confirm_start < self.NORMAL_E_CONFIRM_TIMEOUT:
            self.task.next_frame()

            # 普通E成功后如果立刻转成强化E，也属于最可靠的成功证据。
            if self.is_e_forte_full():
                self.logger.info(
                    'ZFG V2.0 Zani normal E RELEASE confirmed -> enhanced-E became ready'
                )
                return True

            if not self.resonance_available():
                clear_frames += 1
                if clear_frames >= self.NORMAL_E_CLEAR_CONFIRM_FRAMES:
                    self.logger.info(
                        'ZFG V2.0 Zani normal E RELEASE confirmed -> E entered cooldown'
                    )
                    return True
            else:
                clear_frames = 0

            self.sleep(self.POLL)

        self.logger.warning(
            'ZFG V2.0 Zani normal E input sent but release NOT confirmed; do not start 5s CD lock'
        )
        return False

    def _cast_enhanced_e_release(self, state=None, tag='EFORTE'):
        """强化E提交：图标持续消失才算成功，并记录跨轮次的提交进度。

        手动F/手动闪避/受击都可能让E输入被延迟或取消。这里不把“按键已发送”
        当成功；失败后由 E_COMMIT_LOCK 继续重试强化E，绝不回普通E。
        """
        if not self.is_e_forte_full():
            return False

        start = time.time()
        last_send = 0.0
        sent = False
        first_send_time = None
        clear_since = None

        if state is not None:
            state[self.EFORTE_COMMIT_LOCK_KEY] = True
            state[self.EFORTE_ENHANCED_READY_SEEN_KEY] = True
            state[self.EFORTE_COMMIT_ATTEMPTS_KEY] = int(
                state.get(self.EFORTE_COMMIT_ATTEMPTS_KEY, 0) or 0
            ) + 1
            self.logger.info(
                f'ZFG V2.0 {tag}: E_COMMIT_LOCK attempt='
                f'{state[self.EFORTE_COMMIT_ATTEMPTS_KEY]} '
                '-> NO auto-F / NO normal-E fallback'
            )

        while time.time() - start < self.ENHANCED_E_CONFIRM_TIMEOUT:
            self.task.next_frame()
            forte_now = bool(self.is_e_forte_full())

            if forte_now:
                clear_since = None
                now = time.time()
                if now - last_send >= 0.06:
                    self.send_resonance_key()
                    last_send = now
                    if not sent:
                        sent = True
                        first_send_time = now
                        if state is not None and not state.get(
                            self.EFORTE_FIRST_INPUT_TIME_KEY
                        ):
                            state[self.EFORTE_FIRST_INPUT_TIME_KEY] = now
                        self.logger.info(
                            'ZFG V2.0 Zani enhanced E input started'
                        )
            elif sent:
                if clear_since is None:
                    clear_since = time.time()
                clear_for = time.time() - clear_since
                if clear_for >= self.ENHANCED_E_CLEAR_STABLE_SECONDS:
                    try:
                        self.record_resonance_use()
                    except Exception:
                        pass

                    self.crisis_time = (
                        first_send_time
                        if first_send_time is not None
                        else time.time()
                    )
                    self.logger.info(
                        f'ZFG V2.0 Zani enhanced E RELEASE confirmed; '
                        f'icon-clear-stable={clear_for:.2f}s hit/blazes NOT required'
                    )
                    return True

            self.sleep(self.POLL)

        self.logger.warning(
            'ZFG V2.0 Zani enhanced E release not confirmed; '
            'enter ambiguous settle under E_COMMIT_LOCK'
        )
        return False

    def _confirm_ambiguous_enhanced_e_release(self, state, tag):
        """强化E确认超时后的恢复观察窗。

        - 图标重新稳定出现：说明大概率没放出去，下一轮只重试强化E。
        - 图标持续消失：说明可能被手动F/闪避/动作锁延迟后才真正释放，按成功处理。
        - 无论哪种情况，都不回普通E/A准备链。
        """
        start = time.time()
        clear_since = None

        while time.time() - start < self.ENHANCED_E_AMBIGUOUS_SETTLE_TIMEOUT:
            self.task.next_frame()
            if self.is_e_forte_full():
                self.logger.warning(
                    f'ZFG V2.0 {tag}: enhanced-E icon returned during ambiguous settle '
                    '-> keep E_COMMIT_LOCK and retry enhanced-E only'
                )
                return False

            if clear_since is None:
                clear_since = time.time()
            clear_for = time.time() - clear_since
            if clear_for >= self.ENHANCED_E_CLEAR_STABLE_SECONDS:
                try:
                    self.record_resonance_use()
                except Exception:
                    pass
                first_input = float(
                    state.get(self.EFORTE_FIRST_INPUT_TIME_KEY, 0.0) or 0.0
                )
                self.crisis_time = first_input if first_input > 0 else time.time()
                self.logger.info(
                    f'ZFG V2.0 {tag}: delayed enhanced-E RELEASE confirmed '
                    f'after interruption; icon-clear-stable={clear_for:.2f}s'
                )
                return True

            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V2.0 {tag}: enhanced-E state still ambiguous; '
            'keep E_COMMIT_LOCK, no normal-E fallback'
        )
        return False

    def _prepare_and_cast_enhanced_e(self, state, tag):
        """V2.0：EFORTE资源准备 + 持久化提交锁。

        正常优先级仍是：强化E > 真正转好的普通E > A。

        关键恢复规则：
        1) 普通E最后释放时间和次数写入共享 state，不会因 do_perform() 重进而清零；
        2) 一旦任何一帧看到强化E READY，就进入 E_COMMIT_LOCK；
        3) 提交锁期间禁止自动F、禁止普通E、禁止A补资源，只处理强化E；
        4) 手动F/闪避若打断强化E，下一轮只重试强化E；若图标延迟消失则按延迟成功处理。
        """
        start = time.time()
        last_attack = -100.0

        normal_e_cast_count = int(
            state.get(self.EFORTE_NORMAL_E_CASTS_KEY, 0) or 0
        )
        last_normal_e_cast_at = float(
            state.get(self.EFORTE_NORMAL_E_LAST_CAST_KEY, -1.0) or -1.0
        )
        ready_seen = bool(
            state.get(self.EFORTE_ENHANCED_READY_SEEN_KEY, False)
        )

        self.logger.info(
            f'ZFG V2.0 {tag}: enhanced-E prep RESUME '
            f'ready_seen={ready_seen} normal_e_casts={normal_e_cast_count} '
            f'commit_lock={bool(state.get(self.EFORTE_COMMIT_LOCK_KEY, False))}'
        )

        while time.time() - start < self.ENHANCED_E_PREP_TIMEOUT:
            self.task.next_frame()

            # 0) 一旦历史上已经看到过强化E READY，本轮永不回普通E/A。
            if state.get(self.EFORTE_ENHANCED_READY_SEEN_KEY, False):
                state[self.EFORTE_COMMIT_LOCK_KEY] = True

                if self.is_e_forte_full():
                    if self._cast_enhanced_e_release(state=state, tag=tag):
                        return True
                    # 输入确认超时后多观察一小段，处理F/闪避造成的延迟释放。
                    if self._confirm_ambiguous_enhanced_e_release(state, tag):
                        return True
                    return False

                # 图标在上一次输入后已经不见了：先按“可能延迟成功”确认，
                # 绝不因为当前看不到强化E就重新普通E。
                if self._confirm_ambiguous_enhanced_e_release(state, tag):
                    return True
                return False

            # 1) 特殊E永远最高优先。先识别再做F检查，避免READY同帧被自动F抢走。
            if self.is_e_forte_full():
                state[self.EFORTE_ENHANCED_READY_SEEN_KEY] = True
                state[self.EFORTE_COMMIT_LOCK_KEY] = True
                self.logger.info(
                    f'ZFG V2.0 {tag}: enhanced-E READY -> E_COMMIT_LOCK '
                    f'elapsed={time.time()-start:.2f}s '
                    f'normal_e_casts={normal_e_cast_count}'
                )
                if self._cast_enhanced_e_release(state=state, tag=tag):
                    return True
                if self._confirm_ambiguous_enhanced_e_release(state, tag):
                    return True
                return False

            # 2) 还没看到强化E READY 时，R1未开启，允许机会型自动F。
            # 手动闪避同样可以做，但会取消当前A/E动作；状态持久化后可继续恢复。
            if self._field_f_check(resume_label='enhanced-E prep'):
                last_attack = time.time()
                continue

            # 3) 普通E是否真的可以再次尝试，使用 state 中跨轮次保存的CD时间。
            normal_ready = bool(self.resonance_available())
            last_normal_e_cast_at = float(
                state.get(self.EFORTE_NORMAL_E_LAST_CAST_KEY, -1.0) or -1.0
            )
            normal_e_cast_count = int(
                state.get(self.EFORTE_NORMAL_E_CASTS_KEY, 0) or 0
            )

            if last_normal_e_cast_at < 0:
                normal_recast_allowed = True
                normal_elapsed = 999.0
            else:
                normal_elapsed = self.time_elapsed_accounting_for_freeze(
                    last_normal_e_cast_at
                )
                normal_recast_allowed = (
                    normal_elapsed >= self.NORMAL_E_RECAST_MIN_ELAPSED
                )

            if normal_ready and normal_recast_allowed:
                if self._cast_normal_e_once():
                    normal_e_cast_count += 1
                    last_normal_e_cast_at = time.time()
                    state[self.EFORTE_NORMAL_E_CASTS_KEY] = normal_e_cast_count
                    state[self.EFORTE_NORMAL_E_LAST_CAST_KEY] = last_normal_e_cast_at
                    self.logger.info(
                        f'ZFG V2.0 {tag}: normal-E CAST #{normal_e_cast_count}; '
                        'state persisted, immediately re-sample enhanced-E'
                    )
                    self.sleep(self.NORMAL_E_POST_CAST_SETTLE)
                    self.task.next_frame()
                    continue
            elif normal_ready and last_normal_e_cast_at >= 0:
                if int(normal_elapsed * 10) % 10 == 0:
                    self.logger.debug(
                        f'ZFG V2.0 {tag}: normal-E UI ready ignored during real CD '
                        f'elapsed={normal_elapsed:.2f}/{self.NORMAL_E_REAL_CD:.2f}s'
                    )

            # 4) 两种E当前都没能释放 -> A一小段，然后马上重采样。
            now = time.time()
            if now - last_attack >= self.NORMAL_E_ATTACK_INTERVAL:
                self.task.click()
                last_attack = now
            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V2.0 {tag}: enhanced-E prepare timeout '
            f'normal_e_casts={state.get(self.EFORTE_NORMAL_E_CASTS_KEY, 0)} '
            f'ready_seen={state.get(self.EFORTE_ENHANCED_READY_SEEN_KEY, False)}; '
            'keep EFORTE step with persistent state'
        )
        return False

    def _wait_enhanced_e_buff_window(self):
        self.logger.info(
            'ZFG V2.0 Zani wait enhanced-E action/buff window; '
            'damage hit is irrelevant'
        )
        self.wait_crisis_protocol_end()
        self.logger.info(
            'ZFG V2.0 Zani enhanced-E buff window ready -> allow R1'
        )
        return True

    def _enhanced_e_prep_step(self, state, next_step, tag):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.5, click=False)
            # 只有真正进入一轮新的P1/P2 EFORTE时初始化；后续失败重试不清零。
            self._init_eforte_state(state, tag)
            state['phase'] = 'prepare_e'
            phase = 'prepare_e'

        if phase == 'prepare_e':
            if not self._prepare_and_cast_enhanced_e(state, tag):
                return
            state['phase'] = 'buff_settle'
            phase = 'buff_settle'

        if phase == 'buff_settle':
            self._wait_enhanced_e_buff_window()
            self.logger.info(f'ZFG V2.0 {tag}: enhanced-E step complete -> R1 step')
            self._clear_eforte_state(state)
            self._advance_step(state, next_step)

    # =========================================================
    # R1 / Nightfall
    # =========================================================

    def _try_liber_echo_soft(self, tag):
        """赞妮R持续期间Q是机会动作：有就丢，没有绝不阻塞主轴。"""
        if not self.echo_available():
            self.logger.info(f'ZFG V2.0 {tag}: soft Q skip cooldown')
            return False
        result = self.click_echo(time_out=0)
        self.logger.info(f'ZFG V2.0 {tag}: soft Q result={result}')
        return bool(result)

    def _cast_r1(self):
        start = time.time()

        while time.time() - start < self.LIBERATION_READY_TIMEOUT:
            # R1尚未真正开启前仍属于R外站场，可抢一次F；F后继续等R。
            if self._field_f_check(resume_label='R1 pre-cast wait'):
                continue

            if self.liberation_available():
                if self.click_liberation(send_click=True):
                    self._start_liberation()
                    self._liber_phase = 1
                    self.logger.info(
                        'ZFG V2.0 Zani R1 confirmed -> liberation state'
                    )
                    return True

            self.task.click()
            self.sleep(self.POLL)
            self.task.next_frame()

        self.logger.warning(
            'ZFG V2.0 Zani R1 unavailable/failed; keep phase'
        )
        return False

    def _run_nightfall_step(
        self,
        state,
        tag,
        cancel_last_smash=False,
        acquire_timeout=7.0,
        cancel_with_dodge=True,
        prehold_phoebe=False,
    ):
        """完整执行一个终夜，用于N2/N3/N4和恢复。"""
        start = time.time()

        if not self.in_liberation:
            self.logger.warning(
                f'ZFG {tag}: Nightfall rejected - liberation already ended'
            )
            return self.NIGHTFALL_LIBERATION_ENDED

        if not self.is_nightfall_ready():
            while (
                not self.is_nightfall_ready()
                or time.time() - start < 1.6
            ):
                self.click()
                elapsed = time.time() - start

                if elapsed > acquire_timeout:
                    self.logger.warning(
                        f'ZFG {tag}: Nightfall acquire timeout '
                        f'elapsed={elapsed:.2f}s'
                    )
                    return self.NIGHTFALL_FAILED

                if not self.in_liberation:
                    return self.NIGHTFALL_LIBERATION_ENDED

                if self.should_end_liberation(time_only=True):
                    r2_result = self.click_liber2()
                    self.logger.warning(
                        f'ZFG {tag}: time guard triggered R2 '
                        f'result={r2_result}'
                    )
                    return self.NIGHTFALL_R2_TRIGGERED

                self.check_combat()
                self.task.next_frame()

        self.continues_normal_attack(0.5)

        if prehold_phoebe and not state.get(self.PHOEBE_PREHOLD_E_KEY):
            # Nightfall已经触发后，赞妮E通常锁定；此时按住E不会打断赞妮，
            # 但可把held key跨普通切人交给菲比。若E仍可用则不冒险预按。
            # 用户实机确认可在终夜动作中预按E跨切人；不再因赞妮E视觉仍亮而跳过。
            self._arm_phoebe_prehold(
                state,
                tag,
                require_zani_e_locked=False,
            )

        if cancel_last_smash:
            cancel_start = time.time()
            while self.is_nightfall_ready(threshold=0.035):
                if time.time() - cancel_start > 2.5:
                    break
                self.click()
                self.task.next_frame()

            self.sleep(0.25, check_combat=False)
            if cancel_with_dodge:
                self.continues_right_click(0.1)
        else:
            self.nightfall_time = time.time()

        self.check_liber()
        if not self.in_liberation:
            return self.NIGHTFALL_LIBERATION_ENDED

        self.logger.info(
            f'ZFG {tag}: Nightfall result=DONE '
            f'elapsed={time.time() - start:.2f}s'
        )
        return self.NIGHTFALL_DONE

    def _trigger_p1_n1_protected_handoff_gate(self, tag):
        """P1 N1终夜保护：只认“终夜图标真实消失”，绝不再用E锁定放行。

        流程：
        1) A到终夜图标出现；
        2) 继续A触发终夜；
        3) 至少保护 P1_N1_PROTECT_MIN_AFTER_TRIGGER；
        4) 终夜图标连续消失若干帧后才允许切光主。
        若保护窗内始终不能确认图标消失，则保留当前phase，不盲切。
        """
        start = time.time()
        if not self.in_liberation:
            return self.NIGHTFALL_LIBERATION_ENDED

        while time.time() - start < self.N1_ICON_ACQUIRE_TIMEOUT:
            self.task.next_frame()
            if self.is_nightfall_ready():
                self.logger.info(
                    f'ZFG {tag}: PROTECTED Nightfall icon detected '
                    f'elapsed={time.time()-start:.2f}s'
                )

                trigger_start = time.time()
                last_attack = -100.0
                clear_frames = 0

                while time.time() - trigger_start < self.P1_N1_PROTECT_TIMEOUT:
                    if not self.in_liberation:
                        return self.NIGHTFALL_LIBERATION_ENDED

                    now = time.time()
                    # 终夜提交阶段持续补A，避免只按一帧A导致动作未真正进入。
                    if now - last_attack >= 0.045:
                        self.task.click()
                        last_attack = now

                    self.sleep(0.015)
                    self.task.next_frame()

                    icon_cleared = not self.is_nightfall_ready(threshold=0.035)
                    protected_for = time.time() - trigger_start

                    if icon_cleared:
                        clear_frames += 1
                    else:
                        clear_frames = 0

                    if (
                        protected_for >= self.P1_N1_PROTECT_MIN_AFTER_TRIGGER
                        and clear_frames >= self.P1_N1_PROTECT_CLEAR_FRAMES
                    ):
                        self.logger.info(
                            f'ZFG {tag}: PROTECTED Nightfall COMMIT confirmed '
                            f'icon-cleared={clear_frames}frames '
                            f'after_trigger={protected_for:.3f}s -> allow Rover'
                        )
                        # 很短的尾部保护，只防止切人输入和终夜提交处于同一帧。
                        self.sleep(0.08, check_combat=False)
                        return self.NIGHTFALL_DONE

                self.logger.warning(
                    f'ZFG {tag}: PROTECTED Nightfall commit timeout '
                    f'{self.P1_N1_PROTECT_TIMEOUT:.2f}s; DO NOT SWITCH, keep phase'
                )
                return self.NIGHTFALL_FAILED

            self.task.click()
            self.sleep(0.025)

        self.logger.warning(
            f'ZFG {tag}: PROTECTED Nightfall icon acquire timeout '
            f'{self.N1_ICON_ACQUIRE_TIMEOUT:.2f}s'
        )
        return self.NIGHTFALL_FAILED

    def _trigger_n1_and_wait_handoff_gate(self, tag):
        """N1极限早切：终夜图标 -> A -> 极短commit确认 -> 立即切光主。

        旧版曾为E灰态等1.2s，而日志证明该视觉不可靠。V2.0只把
        “E不可用”当加速确认条件；即使没识别到，也只保留0.22s短兜底。
        """
        start = time.time()
        if not self.in_liberation:
            return self.NIGHTFALL_LIBERATION_ENDED

        while time.time() - start < self.N1_ICON_ACQUIRE_TIMEOUT:
            self.task.next_frame()
            if self.is_nightfall_ready():
                self.logger.info(
                    f'ZFG {tag}: Nightfall icon detected elapsed={time.time()-start:.2f}s'
                )
                self.task.click()
                commit_start = time.time()
                clear_frames = 0

                while time.time() - commit_start < self.N1_COMMIT_CONFIRM_TIMEOUT:
                    self.task.next_frame()
                    if not self.in_liberation:
                        return self.NIGHTFALL_LIBERATION_ENDED

                    icon_cleared = not self.is_nightfall_ready()
                    e_locked = not bool(self.resonance_available())
                    if icon_cleared or e_locked:
                        clear_frames += 1
                    else:
                        clear_frames = 0

                    if clear_frames >= self.N1_COMMIT_CLEAR_FRAMES:
                        self.logger.info(
                            f'ZFG {tag}: EARLY HANDOFF commit confirmed '
                            f'icon_cleared={icon_cleared} E_locked={e_locked} '
                            f'after_trigger={time.time()-commit_start:.3f}s'
                        )
                        return self.NIGHTFALL_DONE
                    self.sleep(0.015)

                self.logger.info(
                    f'ZFG {tag}: EARLY HANDOFF bounded fallback '
                    f'after {self.N1_COMMIT_CONFIRM_TIMEOUT:.2f}s'
                )
                return self.NIGHTFALL_DONE

            self.task.click()
            self.sleep(0.025)

        self.logger.warning(
            f'ZFG {tag}: Nightfall icon acquire timeout {self.N1_ICON_ACQUIRE_TIMEOUT:.2f}s'
        )
        return self.NIGHTFALL_FAILED

    def _handle_nightfall_failure(self, state, result, tag):
        if result == self.NIGHTFALL_DONE:
            return False

        if result == self.NIGHTFALL_FAILED:
            self.logger.warning(
                f'ZFG {tag}: Nightfall failed -> keep current phase for retry'
            )
            return True

        self.logger.warning(
            f'ZFG {tag}: abnormal result={result} -> RECOVER_P2_PHOEBE'
        )
        state['step'] = self.STEP_RECOVER_P2_PHOEBE
        state.pop('phase', None)
        return True

    def _r1_n1_early_handoff(self, state, rover_step, tag):
        phase = state.get('phase', 'r1')

        if phase == 'r1':
            if not self._cast_r1():
                return
            state['nightfall_count'] = 0
            # 以R1确认后的Inferno计时为唯一R2硬时钟；使用冻结修正后的游戏时间。
            state['zani_r1_timer_start'] = float(getattr(self, 'liberation_time', 0) or time.time())
            self.logger.info(
                f'ZFG V2.0 {tag}: R1 TIMER armed -> R2 hard deadline T+{self.R2_HARD_DEADLINE:.2f}s'
            )
            # R1后Q只是机会动作，不作为phase门。
            self._try_liber_echo_soft(f'{tag}-after-R1')
            state['phase'] = 'nightfall1_trigger'
            phase = 'nightfall1_trigger'

        if phase == 'nightfall1_trigger':
            self._liber_phase = 1
            if tag.startswith('P1-'):
                result = self._trigger_p1_n1_protected_handoff_gate(tag)
            else:
                result = self._trigger_n1_and_wait_handoff_gate(tag)
            if self._handle_nightfall_failure(state, result, tag):
                return
            state['nightfall_count'] = 1
            state['phase'] = 'switch_rover'
            phase = 'switch_rover'

        if phase == 'switch_rover':
            self._switch_route(
                state,
                'Rover',
                rover_step,
            )

    def _nightfall_then_switch(
        self,
        state,
        nightfall_number,
        target,
        next_step,
        tag,
        prehold_phoebe=False,
    ):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._try_liber_echo_soft(f'{tag}-entry')
            state['phase'] = 'nightfall'
            phase = 'nightfall'

        if phase == 'nightfall':
            if not self.in_liberation:
                state['step'] = self.STEP_RECOVER_P2_PHOEBE
                state.pop('phase', None)
                return

            # 最终下砸保护只依赖phase=3；N2/N3普通执行不需要特殊数值。
            self._liber_phase = min(3, max(1, int(nightfall_number)))
            result = self._run_nightfall_step(state, tag, prehold_phoebe=prehold_phoebe)

            if self._handle_nightfall_failure(state, result, tag):
                return

            state['nightfall_count'] = nightfall_number
            state['phase'] = 'switch'
            phase = 'switch'
            self.logger.info(
                f'ZFG V2.0 Zani Nightfall #{nightfall_number} complete'
            )

        if phase == 'switch':
            self._switch_route(
                state,
                target,
                next_step,
            )

    # =========================================================
    # R2 + R2后E
    # =========================================================

    def _cast_post_r2_e_required(self):
        start = time.time()

        while time.time() - start < self.POST_R2_E_TIMEOUT:
            self.task.next_frame()

            if self.resonance_available():
                clicked, _, _ = self.click_resonance(
                    send_click=False,
                    time_out=0.8,
                )
                if clicked:
                    self.logger.info(
                        'ZFG V2.0 Zani post-R2 E confirmed'
                    )
                    return True

            self.task.click()
            self.sleep(self.POLL)

        self.logger.warning(
            'ZFG V2.0 Zani post-R2 E not ready/confirmed -> keep phase'
        )
        return False

    def _r1_elapsed(self, state):
        start = float(state.get('zani_r1_timer_start', 0) or 0)
        if start <= 0:
            start = float(getattr(self, 'liberation_time', 0) or 0)
        if start <= 0:
            return 0.0
        return max(0.0, float(self.time_elapsed_accounting_for_freeze(start)))

    def _r2_deadline_reached(self, state):
        return self._r1_elapsed(state) >= self.R2_HARD_DEADLINE

    def _trigger_final_nightfall_fast(self, state, tag):
        """最终终夜专用：优先触发N4/N3，但T+19.50s一到就交给R2。"""
        start = time.time()
        if not self.in_liberation:
            return self.NIGHTFALL_LIBERATION_ENDED

        while time.time() - start < self.FINAL_N_ICON_TIMEOUT:
            self.task.next_frame()
            if not self.in_liberation:
                return self.NIGHTFALL_LIBERATION_ENDED

            if self._r2_deadline_reached(state):
                self.logger.warning(
                    f'ZFG {tag}: R2 hard deadline reached before final Nightfall ready '
                    f'R_elapsed={self._r1_elapsed(state):.2f}s'
                )
                return self.NIGHTFALL_R2_DEADLINE

            if self.is_nightfall_ready():
                self.logger.info(
                    f'ZFG {tag}: FINAL Nightfall icon ready '
                    f'R_elapsed={self._r1_elapsed(state):.2f}s '
                    f'liber_left={self.liberation_time_left():.2f}s'
                )
                trigger_at = time.time()
                self.task.click()
                clear_frames = 0

                while time.time() - trigger_at < self.FINAL_N_COMMIT_TIMEOUT:
                    self.task.next_frame()
                    if not self.in_liberation:
                        return self.NIGHTFALL_LIBERATION_ENDED
                    if not self.is_nightfall_ready(threshold=0.035):
                        clear_frames += 1
                    else:
                        clear_frames = 0
                    if clear_frames >= 1:
                        break
                    self.task.click()
                    self.sleep(0.015)

                self.nightfall_time = trigger_at
                self.logger.info(
                    f'ZFG {tag}: FINAL Nightfall TRIGGERED '
                    f'commit={time.time()-trigger_at:.3f}s '
                    f'R_elapsed={self._r1_elapsed(state):.2f}s '
                    f'liber_left={self.liberation_time_left():.2f}s'
                )
                return self.NIGHTFALL_DONE

            self.task.click()
            self.sleep(0.02)

        self.logger.warning(
            f'ZFG {tag}: FINAL Nightfall icon timeout; keep final-N phase '
            f'R_elapsed={self._r1_elapsed(state):.2f}s'
        )
        return self.NIGHTFALL_FAILED

    def _wait_final_nightfall_r2_gate(self, state, tag, policy):
        """
        P1: N4完成后继续压到T+19.50s再R2。
        P2: N3完整下砸后立即R2；若N3未完成但到T+19.50s则强制R2。
        """
        while self.in_liberation:
            r_elapsed = self._r1_elapsed(state)
            smash_left = max(0.0, float(self.nightfall_time_left()))
            deadline = r_elapsed >= self.R2_HARD_DEADLINE
            smash_done = smash_left <= self.FINAL_N_SMASH_DONE_LEFT

            if policy == 'p1_deadline':
                if deadline:
                    self.logger.info(
                        f'ZFG {tag}: R2 gate=P1_DEADLINE '
                        f'R_elapsed={r_elapsed:.2f}s smash_left={smash_left:.2f}s'
                    )
                    return True
            else:
                if smash_done or deadline:
                    reason = 'N3_DONE' if smash_done else 'HARD_DEADLINE'
                    self.logger.info(
                        f'ZFG {tag}: R2 gate={reason} '
                        f'R_elapsed={r_elapsed:.2f}s smash_left={smash_left:.2f}s'
                    )
                    return True

            self.sleep(0.02)
            self.task.next_frame()

        return True

    def _final_nightfall_r2_e(
        self,
        state,
        nightfall_number,
        next_phoebe_step,
        tag,
        mark_new_cycle,
        r2_policy,
    ):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            # Q已经统一挪到R持续期机会动作；最终终夜前不再尝试Q，给N4/R2留时间。
            state['phase'] = 'final_nightfall'
            phase = 'final_nightfall'

        if phase == 'final_nightfall':
            result = self._trigger_final_nightfall_fast(state, tag)
            if result == self.NIGHTFALL_FAILED:
                return
            if result == self.NIGHTFALL_R2_DEADLINE:
                self.logger.warning(
                    f'ZFG {tag}: skip unfinished final Nightfall and protect R2 at hard deadline'
                )
                state['phase'] = 'r2'
                phase = 'r2'
            elif result != self.NIGHTFALL_DONE:
                self.logger.warning(
                    f'ZFG {tag}: final Nightfall lost liberation result={result} '
                    '-> recovery'
                )
                state['step'] = self.STEP_RECOVER_P2_PHOEBE
                state.pop('phase', None)
                return
            else:
                state['nightfall_count'] = nightfall_number
                state['phase'] = 'r2_buffer'
                phase = 'r2_buffer'

        if phase == 'r2_buffer':
            self._wait_final_nightfall_r2_gate(state, tag, r2_policy)
            state['phase'] = 'r2'
            phase = 'r2'

        if phase == 'r2':
            result = self.click_liber2()
            self.task.next_frame()
            still_liber = bool(self.check_liber())
            if not result and still_liber:
                self.logger.warning(
                    f'ZFG V2.0 {tag}: R2 not confirmed -> keep R2 phase'
                )
                return

            self.in_liberation = False
            self._liber_phase = 0
            self.logger.info(
                f'ZFG V2.0 {tag}: R2 complete result={result} still_liber={still_liber}'
            )
            state['phase'] = 'post_r2_e'
            phase = 'post_r2_e'

        if phase == 'post_r2_e':
            if not self._cast_post_r2_e_required():
                return
            if mark_new_cycle:
                state['new_cycle_pending'] = True
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            self._switch_route(
                state,
                'Phoebe',
                next_phoebe_step,
            )

    # =========================================================
    # 大招异常恢复
    # =========================================================

    def _recover_liberation(self, state):
        phase = state.get('phase', 'safe_finish')

        if not self.in_liberation:
            state['step'] = self.STEP_RECOVER_P2_PHOEBE
            state.pop('phase', None)
            return

        if phase == 'safe_finish':
            self.logger.warning(
                'ZFG V2.0 RECOVER_ZANI_LIBERATION: '
                'attempt one safe Nightfall then R2'
            )
            self._liber_phase = 3

            if (
                self.is_nightfall_ready()
                or self.liberation_time_left() > 2.5
            ):
                result = self._run_nightfall_step(state, 'RECOVER-N')
                if result in (
                    self.NIGHTFALL_LIBERATION_ENDED,
                    self.NIGHTFALL_R2_TRIGGERED,
                ):
                    state['phase'] = 'switch_phoebe'
                    phase = 'switch_phoebe'
                else:
                    state['phase'] = 'q_r2'
                    phase = 'q_r2'
            else:
                state['phase'] = 'q_r2'
                phase = 'q_r2'

        if phase == 'q_r2':
            if self.in_liberation:
                self.should_end_liberation(force_finish=True)
                if self.echo_available():
                    self.click_echo(time_out=0)
                self.click_liber2()

            self.in_liberation = False
            self._liber_phase = 0
            state['phase'] = 'post_r2_e'
            phase = 'post_r2_e'

        if phase == 'post_r2_e':
            # 恢复入口也尽量补R2后E；若E确实不可用，保持phase下轮再试。
            if not self._cast_post_r2_e_required():
                return
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            self._switch_route(
                state,
                'Phoebe',
                self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI,
            )
