"""
赞菲光固定轴 V2.0 - Spectro Rover（衍射漂泊者 / 光主）

定位：
- P1开场：菲比R/E/Q后，光主E/Q/R回菲比。
- P1 N1后：零等待机会槽，只看当前帧“强化E > 普通E > 空过”，绝不AZ、绝不等CD。
- P1 N2后：时间极紧，继续保留快照式“有什么放什么”并尽快回赞妮；V2.0不收紧此处。
- P2：三终夜时间更宽裕，采用动作完整优先；R/E确认后留短结算保护再Q/切赞妮。
- F处决主要由光主承担，但P1两个极限短窗口禁主动F，避免吞掉赞妮20秒R时间。

学习建议：
- do_perform()：看哪些 STEP 允许 F，哪些明确禁 F。
- _p1_opportunity_e_to_phoebe()：典型“机会动作，不等待未来资源”。
- _p2_rover_slot()：典型“时间宽裕的资源短轴”。
"""


import time

from src.char.BaseChar import SwitchPriority, Elements
from src.char.Rover import Rover as BuiltinRover


# =============================================================================
# V2.0 学习 / 调试总览
# -----------------------------------------------------------------------------
# 这组三个角色脚本不是“各打各的优先级AI”，而是一条共享 STEP 状态机：
#
# 1) task.zanfei_rotation_state
#    三个角色共用同一份字典，核心字段是 step / phase / cycle / nightfall_count。
#    step = 大阶段；phase = 大阶段内部的小阶段。某个动作一旦确认成功，就先推进 phase，
#    这样后续切人失败、F处决、UI识别抖动都不会让已经完成的动作重放。
#
# 2) STEP_ACTOR
#    每个 STEP 都指定唯一应该站场的角色。当前角色不对时，先精确切回目标角色，
#    而不是继续执行错误角色自己的输出逻辑。
#
# 3) SPECIAL_INTRO_TARGET
#    特殊变奏交通固定为 Phoebe -> Zani -> Rover -> Phoebe。
#    如果满协奏时“想切的人”不是正确特殊变奏接收者，就先走 detour，
#    再自然切到最终目标，避免满协奏把固定轴交通撞乱。
#
# 4) 成功确认原则
#    重要技能尽量不以“按键已经发出”当作成功，而以图标消耗、状态变化、
#    角色切换结果等可观测条件确认。软动作（Q/F机会槽）则允许失败直接放行。
#
# 5) 调试方法
#    先看日志中的 "ZFG V2.0 <Actor> step=... phase=..."，再找该 STEP 的方法。
#    调时间时优先改类顶部的常量；不要先改主流程中的 sleep，避免破坏其它阶段。
# =============================================================================


class _ZFGFSM:
    ACTOR = None

    # --- 共享状态键：三个角色必须完全一致，不能只改其中一份。 ---
    STATE_KEY = 'zanfei_rotation_state'  # 共享FSM主体：step/phase/cycle等都放这里
    TEAM_SIGNATURE_KEY = 'zanfei_rotation_team_signature'  # 队伍变化检测；换队后重置固定轴
    SWITCH_LOG_KEY = 'zanfei_rotation_switch_logged'  # 避免重复刷同一条切人日志
    PHOEBE_PREHOLD_E_KEY = 'phoebe_prehold_e_active'  # 跨角色按住E：是否仍应保持按键
    PHOEBE_PREHOLD_SOURCE_KEY = 'phoebe_prehold_e_source'  # 记录是谁发起的预输入，便于查日志
    # P1-N1插入的Starflash已确认消费后，菲比蓝色forte理论上应为空。
    # 后续P1-N3跨detour预按E时，如果菲比入场首帧已经>=1/2，
    # 可用这个上下文判定“告解已在切人途中提交”，避免漏掉0->1的跃迁。
    P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY = 'p1_phoebe_forte_expected_empty'

    # P2告解动态等待：三个角色都要知道这些状态键，才能在菲比/光主之间安全往返。
    PHOEBE_LAST_CONFESSION_TIME_KEY = 'phoebe_last_confession_time'
    PHOEBE_LAST_R_CAST_TIME_KEY = 'phoebe_last_r_cast_time'
    P2_CONFESSION_AZ_USED_KEY = 'p2_confession_az_detour_used'  # 兼容旧日志：本轮是否至少走过一次光主等待槽
    P2_CONFESSION_AZ_COUNT_KEY = 'p2_confession_az_count'
    P2_CONFESSION_AZ_TARGET_KEY = 'p2_confession_az_target'
    P2_CONFESSION_RETRY_AFTER_KEY = 'p2_confession_retry_after'

    # P2 告解/R 等待调度的共享参数。Phoebe负责算初始计划，Rover每发AZ后重算。
    PHOEBE_R_COOLDOWN = 25.0
    ZANI_R2_HARD_DEADLINE_SHARED = 19.50
    P2_CONFESSION_R2_RESERVE = 6.00  # 给告解+R动画+切赞妮+N3/R2留出的尾端保护
    P2_CONFESSION_AZ_COST = 0.85
    P2_CONFESSION_SWITCH_TOTAL = 0.35
    P2_CONFESSION_PLAN_SAFETY = 0.25
    P2_CONFESSION_MAX_AZ = 6

    # =========================
    # V2.0 共享 STEP
    # P1 = 四终夜启动轴；P2 = 三终夜稳态循环
    # =========================

    STEP_P1_ZANI_OPEN_AE_TO_PHOEBE = 'P1_ZANI_OPEN_AE_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER = 'P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER'
    STEP_P1_ROVER_EQR_TO_PHOEBE = 'P1_ROVER_EQR_TO_PHOEBE'
    STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI = 'P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI'

    STEP_P1_ZANI_EFORTE_PREP = 'P1_ZANI_EFORTE_PREP'
    STEP_P1_ZANI_R1_N1_TO_ROVER = 'P1_ZANI_R1_N1_TO_ROVER'
    STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE = 'P1_ROVER_OPPORTUNITY_E_TO_PHOEBE'
    STEP_P1_PHOEBE_STAR_TO_ZANI = 'P1_PHOEBE_STAR_TO_ZANI'
    STEP_P1_ZANI_N2_TO_ROVER_R = 'P1_ZANI_N2_TO_ROVER_R'
    STEP_P1_ROVER_R_TO_ZANI = 'P1_ROVER_R_TO_ZANI'
    STEP_P1_ZANI_N3_TO_PHOEBE = 'P1_ZANI_N3_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI = 'P1_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P1_ZANI_N4_R2_E_TO_PHOEBE = 'P1_ZANI_N4_R2_E_TO_PHOEBE'

    STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI = 'P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI'
    STEP_P2_ZANI_EFORTE_PREP = 'P2_ZANI_EFORTE_PREP'
    STEP_P2_ZANI_R1_N1_TO_ROVER = 'P2_ZANI_R1_N1_TO_ROVER'
    STEP_P2_ROVER_SLOT_TO_ZANI = 'P2_ROVER_SLOT_TO_ZANI'
    STEP_P2_ZANI_N2_TO_PHOEBE = 'P2_ZANI_N2_TO_PHOEBE'

    # P2告解不再“切到菲比就盲长E”。
    # CHECK先判断还要等多久；时间长则让光主AZ一次，时间短则菲比A等待；
    # 只有真正进入告解后才进入原本的 R -> 赞妮N3。
    STEP_P2_PHOEBE_CONFESSION_CHECK = 'P2_PHOEBE_CONFESSION_CHECK'
    STEP_P2_ROVER_AZ_WAIT_CONFESSION = 'P2_ROVER_AZ_WAIT_CONFESSION'
    STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI = 'P2_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P2_ZANI_N3_R2_E_TO_PHOEBE = 'P2_ZANI_N3_R2_E_TO_PHOEBE'

    STEP_RECOVER_ZANI_LIBERATION = 'RECOVER_ZANI_LIBERATION'
    STEP_RECOVER_P2_PHOEBE = 'RECOVER_P2_PHOEBE'

    # STEP -> 应该站场的角色。角色不对时先纠错切人，不执行本角色其它动作。
    STEP_ACTOR = {
        STEP_P1_ZANI_OPEN_AE_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER: 'Phoebe',
        STEP_P1_ROVER_EQR_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI: 'Phoebe',

        STEP_P1_ZANI_EFORTE_PREP: 'Zani',
        STEP_P1_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_STAR_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N2_TO_ROVER_R: 'Zani',
        STEP_P1_ROVER_R_TO_ZANI: 'Rover',
        STEP_P1_ZANI_N3_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N4_R2_E_TO_PHOEBE: 'Zani',

        STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_EFORTE_PREP: 'Zani',
        STEP_P2_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P2_ROVER_SLOT_TO_ZANI: 'Rover',
        STEP_P2_ZANI_N2_TO_PHOEBE: 'Zani',
        STEP_P2_PHOEBE_CONFESSION_CHECK: 'Phoebe',
        STEP_P2_ROVER_AZ_WAIT_CONFESSION: 'Rover',
        STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_N3_R2_E_TO_PHOEBE: 'Zani',

        STEP_RECOVER_ZANI_LIBERATION: 'Zani',
        STEP_RECOVER_P2_PHOEBE: 'Phoebe',
    }

    # 满协奏时的“合法特殊变奏接收者”。detour交通完全依赖这张表。
    SPECIAL_INTRO_TARGET = {
        'Phoebe': 'Zani',
        'Zani': 'Rover',
        'Rover': 'Phoebe',
    }

    CONCERTO_EFFECTIVE_FULL = 0.99
    INTRO_CONFIRM_FRAMES = 3
    INTRO_CONFIRM_TIMEOUT = 1.0
    POLL = 0.05

    SWITCH_TIMEOUT = 6.0
    SWITCH_RETRY_INTERVAL = 0.04

    def _release_phoebe_prehold(self, state, reason='cleanup'):
        if not isinstance(state, dict) or not state.get(self.PHOEBE_PREHOLD_E_KEY):
            return False
        try:
            self.task.send_key_up(self.get_resonance_key())
        except Exception:
            pass
        source = state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)
        state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
        self.logger.info(
            f'ZFG Phoebe-E prehold RELEASE reason={reason} source={source}'
        )
        return True

    def _clear_zfg_state(self):
        state = getattr(self.task, self.STATE_KEY, None)
        self._release_phoebe_prehold(state, reason='clear-zfg-state')
        for key in (self.STATE_KEY, self.SWITCH_LOG_KEY):
            if hasattr(self.task, key):
                delattr(self.task, key)

    def _zfg_team_matches(self):
        """仅精确的“赞妮 + 菲比 + 漂泊者”三人队启用赞菲光固定轴。

        角色身份完全沿用OK-WW框架已经识别出的char_name，不依赖中文显示名、
        队伍顺序或当前站场角色。Rover形态已知时必须是Spectro；首次载入若
        ring_index仍为-1，只作为“形态待确认”的启动兼容，避免真正的赞菲光
        因光主尚未上场识别形态而误走默认代码。一旦框架明确识别为非Spectro，
        会立即清空固定轴状态并回落到对应角色的OK-WW内置逻辑。
        """
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            chars = ()

        # 与红绿灯轴一致：使用框架角色身份做精确三人签名；不按中文名猜队伍。
        # 不过滤None，这样角色尚未识别完整时绝不会误判为完整三人队。
        signature = tuple(
            (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.'),
                getattr(char, 'index', None),
            )
            for char in chars
        )
        required = {'char_zani', 'char_phoebe', 'char_rover'}
        identity_ok = (
            len(chars) == 3
            and {name for name, _ in signature} == required
            and any(char is self for char in chars)
        )

        rover = None
        if identity_ok:
            for char in chars:
                name = (
                    str(getattr(char, 'char_name', '') or '')
                    .casefold()
                    .removeprefix('labels.')
                )
                if name == 'char_rover':
                    rover = char
                    break

        rover_form = -1
        if rover is not None:
            # Rover当前在场时，先让框架尽可能完成一次形态识别，再读取缓存。
            try:
                if (
                    getattr(rover, 'is_current_char', False)
                    and hasattr(rover, 'ensure_display_form')
                ):
                    rover.ensure_display_form()
            except Exception:
                pass

            try:
                if hasattr(self.task, 'get_known_ring_index'):
                    rover_form = self.task.get_known_ring_index(rover)
                else:
                    rover_form = getattr(rover, 'ring_index', -1)
            except Exception:
                rover_form = getattr(rover, 'ring_index', -1)

        try:
            rover_form = int(rover_form)
        except (TypeError, ValueError):
            rover_form = -1

        spectro_confirmed = identity_ok and rover_form == int(Elements.SPECTRO)
        rover_form_pending = identity_ok and rover_form < 0

        # 形态pending只用于解决OK-WW首次加载时Rover尚未上场、ring_index=-1的问题。
        # 它不是“任意Rover都算光主”：一旦已知形态不是Spectro，马上退出固定轴。
        matched = spectro_confirmed or rover_form_pending

        previous_signature = getattr(self.task, self.TEAM_SIGNATURE_KEY, None)
        rover_form_key = 'zanfei_rotation_rover_form'
        previous_form = getattr(self.task, rover_form_key, None)

        if signature != previous_signature:
            # 真正换队/调整位置：清掉旧队伍的P1/P2进度，从新队伍重新判断。
            self._clear_zfg_state()
            setattr(self.task, self.TEAM_SIGNATURE_KEY, signature)
            setattr(self.task, rover_form_key, rover_form)
            if spectro_confirmed:
                mode = 'ZFG V2.0 fixed rotation (Spectro confirmed)'
            elif rover_form_pending:
                mode = 'ZFG V2.0 fixed rotation (Rover form pending)'
            else:
                mode = 'builtin character rotation'
            self.logger.info(
                f'ZFG team gate -> {mode}; '
                f'rover_form={rover_form} members={signature}'
            )
        elif rover_form != previous_form:
            # 同一队伍中，首次 -1 -> Spectro 只是“确认光主”，绝不能重置已在执行的P1。
            setattr(self.task, rover_form_key, rover_form)
            if (
                identity_ok
                and previous_form is not None
                and int(previous_form) < 0
                and spectro_confirmed
            ):
                self.logger.info(
                    'ZFG team gate Rover form pending -> Spectro confirmed; '
                    'preserve current FSM/STEP'
                )
            else:
                # 已知形态发生真实变化，或确认成非Spectro：旧固定轴不可继续继承。
                self._clear_zfg_state()
                mode = (
                    'ZFG V2.0 fixed rotation (Spectro confirmed)'
                    if spectro_confirmed
                    else 'builtin character rotation'
                )
                self.logger.info(
                    f'ZFG team gate Rover form changed -> {mode}; '
                    f'old={previous_form} new={rover_form}'
                )
        elif not matched:
            # 非指定队伍不能残留任何赞菲光FSM/独占切人状态。
            self._clear_zfg_state()

        if not matched and hasattr(self, '_zanfei_guang'):
            self._zanfei_guang = False

        return matched

    def _zfg_state(self):
        """Return shared FSM state.

        First creation starts from P1.  If an already-existing state is damaged,
        do not replay the one-time opening: route to the agreed recovery entry.
        """
        state = getattr(self.task, self.STATE_KEY, None)

        if state is None:
            state = {
                'step': self.STEP_P1_ZANI_OPEN_AE_TO_PHOEBE,
                'cycle': 1,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self.logger.info(
                'ZFG FSM initialize -> P1_ZANI_OPEN_AE_TO_PHOEBE'
            )
            return state

        if not isinstance(state, dict) or 'step' not in state:
            old_cycle = state.get('cycle', 1) if isinstance(state, dict) else 1
            state = {
                'cycle': old_cycle,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self._route_broken_state_to_recovery(
                state,
                reason='state-missing-step',
            )

        return state


    def _advance_step(self, state, next_step):
        old = state.get('step')
        state['step'] = next_step
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        self.logger.info(
            f'ZFG FSM advance {old} -> {next_step} '
            f'cycle={state.get("cycle", 1)} '
            f'nightfall={state.get("nightfall_count", 0)}'
        )

    def _expected_actor(self, state):
        if state.get('detour_active'):
            return state.get('detour_actor')
        return self.STEP_ACTOR.get(state.get('step'))

    def _route_broken_state_to_recovery(self, state, reason='unknown'):
        """Route a damaged FSM without replaying the one-time P1 opening.

        - Zani still in R state -> RECOVER_ZANI_LIBERATION.
        - Otherwise -> RECOVER_P2_PHOEBE.
        """
        if not isinstance(state, dict):
            return 'Phoebe'

        self._clear_detour(state)
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        zani = self if self.ACTOR == 'Zani' else self._find_target_char('Zani')
        if zani is not None and getattr(zani, 'in_liberation', False):
            state['step'] = self.STEP_RECOVER_ZANI_LIBERATION
            actor = 'Zani'
        else:
            state['step'] = self.STEP_RECOVER_P2_PHOEBE
            actor = 'Phoebe'

        self.logger.error(
            f'ZFG broken FSM recovery reason={reason} '
            f'-> step={state.get("step")} actor={actor}'
        )
        return actor

    def get_switch_priority(
        self,
        current_char=None,
        has_intro=False,
        target_low_con=False,
    ):
        if not self._zfg_team_matches():
            return super().get_switch_priority(
                current_char,
                has_intro,
                target_low_con,
            )

        state = self._zfg_state()
        expected = self._expected_actor(state)

        if expected is None:
            expected = self._route_broken_state_to_recovery(
                state,
                reason=f'unknown-step:{state.get("step")}',
            )

        if not getattr(self.task, self.SWITCH_LOG_KEY, False):
            self.logger.info(
                f'ZFG FSM-exclusive switching enabled '
                f'step={state.get("step")} expected={expected}'
            )
            setattr(self.task, self.SWITCH_LOG_KEY, True)

        return (
            SwitchPriority.MUST
            if expected == self.ACTOR
            else SwitchPriority.NO
        )

    def _find_target_char(self, target_name):
        target_name = target_name.casefold()

        for char in getattr(self.task, 'chars', []):
            if char is None or char is self:
                continue

            names = (
                getattr(char, 'name', None),
                char.__class__.__name__,
                getattr(char, 'display_name', None),
            )

            for name in names:
                if name and str(name).casefold() == target_name:
                    return char

        return None

    def _raw_con_full(self):
        try:
            return bool(self.task.is_con_full())
        except Exception:
            return bool(self.is_con_full())

    def _read_concerto(self):
        if self._raw_con_full():
            return 1.0

        try:
            value = float(self.get_current_con())
        except Exception:
            try:
                value = float(self.task.get_current_con())
            except Exception:
                value = 0.0

        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        return (
            self._raw_con_full()
            or self._read_concerto() >= self.CONCERTO_EFFECTIVE_FULL
        )

    def _confirm_hard_intro_ready(self, target_name):
        start = time.time()
        full_frames = 0

        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            if self._raw_con_full():
                full_frames += 1

                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'ZFG hard-intro guard passed '
                        f'{self.ACTOR}->{target_name} '
                        f'{full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                    )
                    return True
            else:
                full_frames = 0

            self.sleep(self.POLL)
            self.task.next_frame()

        self.logger.warning(
            f'ZFG hard-intro guard failed '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _switch_to(self, target_name, expect_intro=None):
        target = self._find_target_char(target_name)

        if target is None:
            self.logger.error(
                f'ZFG {self.ACTOR}: target not found -> {target_name}'
            )
            return False

        if expect_intro is True:
            allowed = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

            if target_name != allowed:
                self.logger.error(
                    f'ZFG invalid special intro '
                    f'{self.ACTOR}->{target_name}; '
                    f'allowed={allowed}'
                )
                return False

            if not self._confirm_hard_intro_ready(target_name):
                return False

            has_intro = True

        elif expect_intro is False:
            if self._concerto_effectively_full():
                self.logger.warning(
                    f'ZFG block forced-normal switch '
                    f'{self.ACTOR}->{target_name}: concerto full'
                )
                return False
            has_intro = False

        else:
            has_intro = self._concerto_effectively_full()

        target.has_intro = has_intro
        target.has_sub_dps_intro = (
            has_intro and getattr(self, 'is_sub_dps', False)
        )

        start = time.time()
        last_send = 0.0

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.check_combat()

            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, -1

            if in_team and current_index == target.index:
                self.task.in_liberation = False
                target.is_current_char = True

                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(
                        now,
                        target.intro_motion_freeze_duration,
                        -100,
                    )
                    self.last_outro_time = now

                self.logger.info(
                    f'ZFG exact switch success '
                    f'{self.ACTOR}->{target_name} '
                    f'intro={has_intro}'
                )
                return True

            if (
                in_team
                and current_index == self.index
                and not target.wait_switch()
            ):
                now = time.time()

                if now - last_send >= self.SWITCH_RETRY_INTERVAL:
                    self.task.send_key(target.index + 1)
                    last_send = now

            self.sleep(self.SWITCH_RETRY_INTERVAL)
            self.task.next_frame()

        self.logger.error(
            f'ZFG exact switch timeout '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _clear_detour(self, state):
        for key in (
            'detour_active',
            'detour_actor',
            'detour_final_target',
            'detour_next_step',
            'detour_resume_step',
            'detour_resume_phase',
        ):
            state.pop(key, None)

    def _switch_route(
        self,
        state,
        planned_target,
        next_step,
        force_intro=False,
    ):
        """
        正常切人入口。

        若协奏满，但planned_target不是当前角色正确的特殊变奏目标：
        保存主轴step/phase -> 先让正确角色吃特殊变奏
        -> 再自然切planned_target -> 进入next_step。
        """

        if force_intro:
            if self._switch_to(planned_target, expect_intro=True):
                self._advance_step(state, next_step)
                return True
            return False

        full = self._concerto_effectively_full()
        special_target = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

        if (
            full
            and special_target
            and planned_target != special_target
        ):
            # V2.0：P1赞妮N3后的Phoebe-E预按即使遇到特殊变奏detour也继续保持。
            # 代价是中转光主可能额外吃到一次E输入，但实机优先保证菲比到场时
            # 长按E链不断，避免“已经进入告解但蓝圈漏识别”后脚本反复重试。
            if planned_target == 'Phoebe' and state.get(self.PHOEBE_PREHOLD_E_KEY):
                self.logger.info(
                    f'ZFG Phoebe-E prehold PRESERVE across detour '
                    f'{self.ACTOR}->{special_target}->Phoebe'
                )
            resume_step = state.get('step')
            resume_phase = state.get('phase')

            self.logger.warning(
                f'ZFG intro detour required: '
                f'source={self.ACTOR} '
                f'planned={planned_target} '
                f'correct_intro={special_target} '
                f'resume={resume_step}/{resume_phase}'
            )

            if not self._switch_to(
                special_target,
                expect_intro=None,
            ):
                return False

            state['detour_active'] = True
            state['detour_actor'] = special_target
            state['detour_final_target'] = planned_target
            state['detour_next_step'] = next_step
            state['detour_resume_step'] = resume_step
            state['detour_resume_phase'] = resume_phase
            return True

        if self._switch_to(planned_target, expect_intro=None):
            self._advance_step(state, next_step)
            return True

        return False

    def _run_detour_if_needed(self, state):
        if not state.get('detour_active'):
            return False

        expected = state.get('detour_actor')

        if expected != self.ACTOR:
            self._recover_wrong_actor(state)
            return True

        final_target = state.get('detour_final_target')
        next_step = state.get('detour_next_step')
        resume_step = state.get('detour_resume_step')
        resume_phase = state.get('detour_resume_phase')

        self.logger.info(
            f'ZFG detour actor={self.ACTOR} '
            f'return={final_target} '
            f'resume={resume_step}/{resume_phase}'
        )

        if self._switch_to(final_target, expect_intro=None):
            self._clear_detour(state)
            self._advance_step(state, next_step)

        return True

    def _recover_wrong_actor(self, state):
        expected = self._expected_actor(state)

        if expected and expected != self.ACTOR:
            self.logger.warning(
                f'ZFG wrong actor: current={self.ACTOR} '
                f'step={state.get("step")} expected={expected}'
            )
            return self._switch_to(
                expected,
                expect_intro=None,
            )

        # If dispatch reached here while the current actor is already the
        # expected actor, the STEP itself has no valid handler. Treat that as
        # FSM damage and use the agreed recovery entrance instead of P1.
        recovery_actor = self._route_broken_state_to_recovery(
            state,
            reason=f'unhandled-step:{state.get("step")}',
        )

        if recovery_actor != self.ACTOR:
            return self._switch_to(
                recovery_actor,
                expect_intro=None,
            )

        return False


    def on_combat_end(self, chars):
        self._clear_zfg_state()

        if hasattr(self.task, self.TEAM_SIGNATURE_KEY):
            delattr(self.task, self.TEAM_SIGNATURE_KEY)
        if hasattr(self.task, 'zanfei_rotation_rover_form'):
            delattr(self.task, 'zanfei_rotation_rover_form')

        return super().on_combat_end(chars)



# IMPORTANT - OK-WW custom loader entrypoint:
# 公开类名必须保持“Rover”，不要改成RoverV2/CustomRover等名称；
# 否则框架不会把当前自定义代码热替换到该角色实例，实战会继续执行内置代码。
class Rover(_ZFGFSM, BuiltinRover):
    ACTOR = 'Rover'

    # =============================================================================
    # 光主调试索引
    # -----------------------------------------------------------------------------
    # P1与P2的设计目标不同：
    # - P1四终夜：赞妮20秒R时间非常紧，光主只做“当前有就拿”的机会动作，禁止等未来资源。
    # - P2三终夜：时间宽裕，可以做AZ/强化E/R等较完整资源循环。
    #
    # F处决：
    # - 光主是队伍主要F执行者；
    # - 但P1 N1后的机会槽、P1 N2后的快照槽禁主动F，避免吞赞妮爆发时间。
    #
    # 调日志时重点看：
    #   "P1 N1 OPPORTUNITY-SLOT"、"P1 FAST-SNAPSHOT"、"P2 selected slot"
    # 这些日志直接告诉你光主当帧选择了什么，以及有没有等待。
    # =============================================================================

    R_TO_Q_SETTLE = 0.60  # R后给UI恢复的短稳定窗；只用于需要继续判Q/E的阶段
    AZ_A_TO_Z_GAP = 0.08
    AZ_SETTLE = 0.12

    # P2时间宽裕，采用“动作完整优先”：R/E确认后再留短结算窗，之后才Q/切赞妮。
    # 注意：这些保护只用于P2，P1两个FAST窗口保持V1.1的最快切人逻辑不变。
    P2_R_ACTION_SETTLE = 0.60
    P2_E_ACTION_SETTLE = 0.25

    # “REQUIRED”只用于硬动作阶段；机会槽不会等待这些timeout。
    REQUIRED_E_TIMEOUT = 1.8
    REQUIRED_Q_TIMEOUT = 1.8
    REQUIRED_R_TIMEOUT = 2.8
    REQUIRED_EFORTE_TIMEOUT = 2.2

    # 赞菲光中F处决统一由光主承担。外部自动F仍禁用，只在本文件受控窗口检查。
    F_CHECK_INTERVAL = 0.18
    F_POST_ACTION_SETTLE_TIME = 0.12

    def f_break(
        self,
        check_f_on_switch=False,
        force=False,
    ):
        if self._zfg_team_matches():
            return False
        return super().f_break(
            check_f_on_switch=check_f_on_switch,
            force=force,
        )

    def do_perform(self):
        self.init()

        if not self._zfg_team_matches():
            return super().do_perform()

        state = self._zfg_state()

        if self._run_detour_if_needed(state):
            return

        step = state.get('step')

        # P1四终夜的两个光主短窗口都极度吃时间：
        # N1后的机会槽与N2后的FAST-SNAPSHOT都禁用主动F，避免处决吞掉窗口。
        # P1开场EQR与P2光主站场仍保留统一F机会检测。
        if (
            step not in (
                self.STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE,
                self.STEP_P1_ROVER_R_TO_ZANI,
                self.STEP_P2_ROVER_AZ_WAIT_CONFESSION,
            )
            and self._field_f_check(resume_label=f'step={step}')
        ):
            return

        self.logger.info(
            f'ZFG V2.0 Rover step={step} phase={state.get("phase")} '
            f'intro={self.has_intro} forte={self.is_forte_full()} '
            f'E={self.resonance_available()} R={self.liberation_available()}'
        )

        if step == self.STEP_P1_ROVER_EQR_TO_PHOEBE:
            return self._p1_eqr_to_phoebe(state)

        if step == self.STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE:
            return self._p1_opportunity_e_to_phoebe(state)

        if step == self.STEP_P1_ROVER_R_TO_ZANI:
            return self._p1_r_to_zani(state)

        if step == self.STEP_P2_ROVER_SLOT_TO_ZANI:
            return self._p2_rover_slot(
                state,
                self.STEP_P2_ZANI_N2_TO_PHOEBE,
            )

        if step == self.STEP_P2_ROVER_AZ_WAIT_CONFESSION:
            return self._p2_az_wait_confession(state)

        return self._recover_wrong_actor(state)

    # =========================================================
    # 光主专属F处决窗口（红绿灯忌炎式：保存phase，F后原地续轴）
    # =========================================================

    def _run_f_break_with_freeze(self, label):
        f_start = time.time()
        if not super().f_break(check_f_on_switch=False, force=False):
            return False
        f_duration = max(0.0, time.time() - f_start)
        if self.F_POST_ACTION_SETTLE_TIME > 0:
            self.sleep(self.F_POST_ACTION_SETTLE_TIME)
            self.task.next_frame()
        blocked = max(0.0, time.time() - f_start)
        self.add_freeze_duration(f_start, blocked)
        self.logger.info(
            f'ZFG V2.0 Rover F execution during {label}; '
            f'F={f_duration:.2f}s freeze={blocked:.2f}s'
        )
        return True

    def _field_f_check(self, force=False, resume_label='Rover on-field'):
        if not self.is_current_char:
            return False
        now = time.time()
        last = getattr(self, '_zfg_last_f_check', -100.0)
        if not force and now - last < self.F_CHECK_INTERVAL:
            return False
        self._zfg_last_f_check = now
        self.task.next_frame()
        return self._run_f_break_with_freeze(resume_label)

    # =========================================================
    # 基础动作
    # =========================================================

    def _cast_normal_e_once(self):
        if not self.resonance_available():
            return False

        clicked, _, _ = self.click_resonance(
            send_click=True,
            time_out=0.8,
        )
        if clicked:
            self.logger.info('ZFG V2.0 Rover normal/available E confirmed')
        return bool(clicked)

    def _cast_enhanced_e_once(self):
        if not (
            self.is_forte_full()
            and self.resonance_available()
        ):
            return False

        clicked, _, _ = self.click_resonance(
            send_click=True,
            time_out=0.8,
        )
        if clicked:
            self.logger.info('ZFG V2.0 Rover enhanced E confirmed')
        return bool(clicked)

    def _cast_any_e_required(self, tag):
        start = time.time()

        while time.time() - start < self.REQUIRED_E_TIMEOUT:
            self.task.next_frame()

            if self.is_forte_full() and self.resonance_available():
                if self._cast_enhanced_e_once():
                    return True

            if self.resonance_available():
                if self._cast_normal_e_once():
                    return True

            self.task.click()
            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V2.0 Rover {tag}: E not confirmed'
        )
        return False

    def _cast_q_required(self, tag):
        start = time.time()

        while time.time() - start < self.REQUIRED_Q_TIMEOUT:
            self.task.next_frame()

            if self.echo_available():
                result = self.click_echo(time_out=0.8)
                self.task.next_frame()
                consumed = not self.echo_available()

                if result or consumed:
                    self.logger.info(
                        f'ZFG V2.0 Rover {tag}: Q confirmed '
                        f'base_result={bool(result)} consumed={consumed}'
                    )
                    return True

            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V2.0 Rover {tag}: Q not confirmed'
        )
        return False

    def _cast_r_required(self, tag):
        start = time.time()

        while self.time_elapsed_accounting_for_freeze(start) < self.REQUIRED_R_TIMEOUT:
            self.task.next_frame()
            if self._field_f_check(resume_label=f'{tag}-wait-R'):
                continue

            if self.liberation_available():
                result = self.click_liberation(send_click=True)
                if result:
                    self.logger.info(f'ZFG V2.0 Rover {tag}: R confirmed')
                    return True

            self.task.click()
            self.sleep(self.POLL)

        self.logger.warning(f'ZFG V2.0 Rover {tag}: R not confirmed')
        return False

    def _cast_q_soft(self, tag):
        if not self.echo_available():
            self.logger.info(f'ZFG V2.0 Rover {tag}: soft Q skip cooldown')
            return False
        result = self.click_echo(time_out=0)
        self.logger.info(f'ZFG V2.0 Rover {tag}: soft Q result={result}')
        return bool(result)

    def _cast_az_slot(self):
        self.logger.info('ZFG V2.0 Rover AZ start')
        self.task.click()
        self.sleep(self.AZ_A_TO_Z_GAP)
        self.task.next_frame()
        self.heavy_attack()
        self.sleep(self.AZ_SETTLE)
        self.logger.info('ZFG V2.0 Rover AZ end')
        return True

    # =========================================================
    # P1开场插入：E -> Q -> R -> 菲比
    # =========================================================

    def _p1_eqr_to_phoebe(self, state):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self.wait_down()
            state['phase'] = 'e'
            phase = 'e'

        if phase == 'e':
            if not self._cast_any_e_required('P1 EQR'):
                return
            state['phase'] = 'q'
            phase = 'q'

        if phase == 'q':
            if not self._cast_q_required('P1 EQR'):
                return
            state['phase'] = 'r'
            phase = 'r'

        if phase == 'r':
            if not self._cast_r_required('P1 EQR'):
                return
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            self._switch_route(
                state,
                'Phoebe',
                self.STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI,
            )

    # =========================================================
    # P1第一终夜插入：零等待机会E -> 菲比重击
    # =========================================================

    def _p1_opportunity_e_to_phoebe(self, state):
        """
        P1 N1后的光主只做“当前帧机会动作”，绝不为了强化E站场等待。

        优先级：
          1) 当前已经满足强化E条件 -> 尝试一次强化E；
          2) 否则当前普通E可用 -> 尝试一次普通E；
          3) 两者都没有 -> 空过。

        明确禁止：AZ、A补回路、等待未来CD、等待强化E、R、Q、主动F。
        不论E是否成功，随后都立即切菲比。
        """
        phase = state.get('phase', 'snapshot')

        if phase == 'snapshot':
            # N1通常是普通切光主；若因为满协奏交通实际变奏光主，
            # 只给一个很短的入场解锁窗，不做任何补资源动作。
            if self.has_intro:
                self.wait_intro(time_out=0.8, click=False)

            self.task.next_frame()
            forte_now = bool(self.is_forte_full())
            e_now = bool(self.resonance_available())
            primary = 'NONE'

            if forte_now and e_now:
                clicked, _, _ = self.click_resonance(
                    send_click=False,
                    time_out=0.55,
                )
                primary = 'ENHANCED_E' if clicked else 'ENHANCED_E_ATTEMPT_FAILED'
            elif e_now:
                clicked, _, _ = self.click_resonance(
                    send_click=False,
                    time_out=0.55,
                )
                primary = 'NORMAL_E' if clicked else 'NORMAL_E_ATTEMPT_FAILED'

            self.logger.info(
                f'ZFG V2.0 Rover P1 N1 OPPORTUNITY-SLOT '
                f'forte_now={forte_now} e_now={e_now} primary={primary}; '
                f'NO-AZ NO-WAIT NO-Q NO-F -> Phoebe'
            )

            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            self._switch_route(
                state,
                'Phoebe',
                self.STEP_P1_PHOEBE_STAR_TO_ZANI,
            )

    # =========================================================
    # P1第二终夜后：只放R -> 赞妮
    # =========================================================

    def _p1_r_to_zani(self, state):
        """
        P1第二终夜后的极短光主窗口：只看“当前这一帧有什么”，绝不等未来CD。

        优先级：
          1) R当前可用 -> 只尝试一次R；
          2) 否则强化E当前可用 -> 强化E；
          3) 否则普通E当前可用 -> 普通E；
          4) 都没有 -> 主动作直接跳过。
        随后Q只做soft机会动作，立即回赞妮。

        这个STEP不等待R、不A补资源、不AZ、不主动F，专门给P1四终夜省时间。
        """
        phase = state.get('phase', 'snapshot')

        if phase == 'snapshot':
            self.task.next_frame()

            primary = 'NONE'

            if self.liberation_available():
                # 只在“此刻已经亮”的情况下尝试一次；不使用_required等待器。
                result = self.click_liberation(
                    send_click=False,
                    click_f=False,
                )
                primary = 'R' if result else 'R_ATTEMPT_FAILED'
                self.logger.info(
                    f'ZFG V2.0 Rover P1 FAST-SNAPSHOT '
                    f'R available-now result={bool(result)}'
                )

            elif self.is_forte_full() and self.resonance_available():
                if self._cast_enhanced_e_once():
                    primary = 'ENHANCED_E'
                else:
                    primary = 'ENHANCED_E_ATTEMPT_FAILED'

            elif self.resonance_available():
                if self._cast_normal_e_once():
                    primary = 'NORMAL_E'
                else:
                    primary = 'NORMAL_E_ATTEMPT_FAILED'

            self.logger.info(
                f'ZFG V2.0 Rover P1 FAST-SNAPSHOT primary={primary}; '
                f'no-wait -> soft-Q -> Zani'
            )

            self._cast_q_soft(f'P1 FAST-SNAPSHOT after {primary}')
            state['phase'] = 'switch_zani'
            phase = 'switch_zani'

        if phase == 'switch_zani':
            self._switch_route(
                state,
                'Zani',
                self.STEP_P1_ZANI_N3_TO_PHOEBE,
            )

    # =========================================================
    # V2.0 P2告解等待绕路：只打一套AZ，然后马上回菲比重新检查
    # =========================================================

    def _p2_confession_prayer_remaining_rover(self, state):
        last = state.get(self.PHOEBE_LAST_CONFESSION_TIME_KEY)
        if not isinstance(last, (int, float)) or last <= 0:
            return None
        return max(0.0, 24.0 - max(0.0, time.time() - last))

    def _p2_confession_r_remaining_rover(self, state):
        last = state.get(self.PHOEBE_LAST_R_CAST_TIME_KEY)
        if not isinstance(last, (int, float)) or last <= 0:
            return None
        elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(last)))
        return max(0.0, self.PHOEBE_R_COOLDOWN - elapsed)

    def _p2_confession_fill_room_rover(self, state):
        start = float(state.get('zani_r1_timer_start', 0) or 0)
        if start <= 0:
            return None, None
        elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(start)))
        r2_left = max(0.0, self.ZANI_R2_HARD_DEADLINE_SHARED - elapsed)
        return r2_left, max(0.0, r2_left - self.P2_CONFESSION_R2_RESERVE)

    def _p2_az_wait_confession(self, state):
        """V2.0动态填轴：AZ×n，每发后重算；离场前E可用则E->立刻切菲比。"""
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self.wait_down()
            state['phase'] = 'az_loop'
            phase = 'az_loop'

        if phase == 'az_loop':
            target = int(state.get(self.P2_CONFESSION_AZ_TARGET_KEY, 0) or 0)
            done = int(state.get(self.P2_CONFESSION_AZ_COUNT_KEY, 0) or 0)

            while done < target and done < self.P2_CONFESSION_MAX_AZ:
                prayer = self._p2_confession_prayer_remaining_rover(state)
                r_rem = self._p2_confession_r_remaining_rover(state)
                retry_after = float(state.get(self.P2_CONFESSION_RETRY_AFTER_KEY, 0.0) or 0.0)
                retry_wait = max(0.0, retry_after - time.time())
                known = [x for x in (prayer, r_rem) if isinstance(x, (int, float))]
                if retry_wait > 0:
                    known.append(retry_wait)
                need = max(known) if known else None
                r2_left, fill_room = self._p2_confession_fill_room_rover(state)

                # 每发AZ前重新确认：如果等待已经不够一发，或R2保护窗逼近，就停止。
                if need is not None and need <= self.P2_CONFESSION_AZ_COST + self.P2_CONFESSION_PLAN_SAFETY:
                    self.logger.info(
                        f'ZFG V2.0 Rover P2 CONFESSION-WAIT stop AZ: need={need:.2f}s too short'
                    )
                    break
                if fill_room is not None and fill_room < self.P2_CONFESSION_AZ_COST + self.P2_CONFESSION_PLAN_SAFETY:
                    self.logger.warning(
                        f'ZFG V2.0 Rover P2 CONFESSION-WAIT stop AZ for R2 reserve '
                        f'R2_left={r2_left:.2f}s fill_room={fill_room:.2f}s'
                    )
                    break

                self.logger.info(
                    f'ZFG V2.0 Rover P2 CONFESSION-WAIT AZ #{done + 1}/{target} start '
                    f'Prayer={prayer} Rrem={r_rem} need={need} R2left={r2_left}'
                )
                self._cast_az_slot()
                done += 1
                state[self.P2_CONFESSION_AZ_COUNT_KEY] = done
                state[self.P2_CONFESSION_AZ_USED_KEY] = True

            state['phase'] = 'exit_e'
            phase = 'exit_e'

        if phase == 'exit_e':
            # E作为离场动作：有就放，成功后不留结算sleep，直接用切人吃掉后摇。
            e_result = False
            if self.is_forte_full() and self.resonance_available():
                e_result = self._cast_enhanced_e_once()
                e_kind = 'ENHANCED_E' if e_result else 'ENHANCED_E_FAILED'
            elif self.resonance_available():
                e_result = self._cast_normal_e_once()
                e_kind = 'NORMAL_E' if e_result else 'NORMAL_E_FAILED'
            else:
                e_kind = 'NONE'
            self.logger.info(
                f'ZFG V2.0 Rover P2 CONFESSION-WAIT exit E={e_kind}; '
                'NO settle -> Phoebe immediately'
            )
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            state.pop(self.P2_CONFESSION_AZ_TARGET_KEY, None)
            self._switch_route(
                state, 'Phoebe', self.STEP_P2_PHOEBE_CONFESSION_CHECK,
            )

    # =========================================================
    # P2第一终夜插入：R可用 -> R；否则 AZ -> 强化E；Q软放
    # =========================================================

    def _cast_r_slot(self):
        if not self.liberation_available():
            return False
        result = self.click_liberation(send_click=True)
        self.logger.info(f'ZFG V2.0 Rover P2 SLOT=R result={result}')
        return bool(result)

    def _wait_enhanced_e_after_az(self, tag):
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.REQUIRED_EFORTE_TIMEOUT:
            self.task.next_frame()
            if self._field_f_check(resume_label=f'{tag}-wait-enhanced-E'):
                continue
            if self._cast_enhanced_e_once():
                return True
            # AZ后若还差少量回路，用A补，不允许误放普通E。
            self.task.click()
            self.sleep(self.POLL)
        self.logger.warning(f'ZFG V2.0 Rover {tag}: enhanced E not confirmed after AZ')
        return False

    def _p2_rover_slot(self, state, zani_next_step):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.continues_normal_attack(0.12)
            self.wait_down()
            state['phase'] = 'choose'
            phase = 'choose'

        if phase == 'choose':
            if self.liberation_available() and self._cast_r_slot():
                state['rover_last_slot'] = 'R'
                state['phase'] = 'post_r_e_snapshot'
                phase = 'post_r_e_snapshot'
            else:
                state['phase'] = 'az'
                phase = 'az'

        if phase == 'post_r_e_snapshot':
            # V2.0 P2完整结算版：P2时间充足，R成功后先让动作/UI稳定，再判断E。
            # 这里仍然“不为了E等未来CD”，但不会像P1那样R确认后一帧就接Q/切人。
            self.logger.info(
                f'ZFG V2.0 Rover P2 R confirmed -> action settle '
                f'{self.P2_R_ACTION_SETTLE:.2f}s before E snapshot'
            )
            self.sleep(self.P2_R_ACTION_SETTLE)
            self.task.next_frame()

            e_after_r = 'NONE'
            if self.resonance_available():
                if self.is_forte_full():
                    if self._cast_enhanced_e_once():
                        e_after_r = 'ENHANCED_E'
                    else:
                        e_after_r = 'ENHANCED_E_ATTEMPT_FAILED'
                else:
                    if self._cast_normal_e_once():
                        e_after_r = 'NORMAL_E'
                    else:
                        e_after_r = 'NORMAL_E_ATTEMPT_FAILED'

            # 只有E真正确认成功才给额外结算保护；NONE/失败不白等。
            if e_after_r in ('ENHANCED_E', 'NORMAL_E'):
                self.logger.info(
                    f'ZFG V2.0 Rover P2 after R: {e_after_r} confirmed -> '
                    f'action settle {self.P2_E_ACTION_SETTLE:.2f}s'
                )
                self.sleep(self.P2_E_ACTION_SETTLE)
                self.task.next_frame()

            self.logger.info(
                f'ZFG V2.0 Rover P2 after R: E snapshot={e_after_r}; '
                f'action-complete -> Q -> Zani'
            )
            state['rover_last_slot'] = f'R+{e_after_r}'
            state['phase'] = 'q'
            phase = 'q'

        if phase == 'az':
            self._cast_az_slot()
            self._field_f_check(resume_label='P2 after AZ')
            state['phase'] = 'enhanced_e'
            phase = 'enhanced_e'

        if phase == 'enhanced_e':
            if not self._wait_enhanced_e_after_az('P2 AZ+E'):
                return
            state['rover_last_slot'] = 'AZ+ENHANCED_E'
            state['phase'] = 'q'
            phase = 'q'

        if phase == 'q':
            self._cast_q_soft(
                f'P2 after {state.get("rover_last_slot", "slot")}'
            )
            if getattr(self, 'buff_time', 0) > 0:
                self.last_buff_time = time.time()
            state['phase'] = 'switch_zani'
            phase = 'switch_zani'

        if phase == 'switch_zani':
            self._switch_route(
                state,
                'Zani',
                zani_next_step,
            )
