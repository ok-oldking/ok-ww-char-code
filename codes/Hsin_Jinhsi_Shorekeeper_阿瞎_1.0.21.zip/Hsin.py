import time

from src.char.BaseChar import SwitchPriority
from src.char.Hsin import Hsin as NativeHsin


class Hsin(NativeHsin):
    """心月狐。心/今汐/守岸人队（Codex 优化版：战斗流程与 v20 完全一致，仅整理结构）。

    非变奏入场 → 切守岸人(opener1)
    一形态变奏入场(phase=1):
      Q好了就放 → 普攻到重击亮(5秒超时) → 长按2秒放重击 → 等大招亮(3秒)
      → 放一段大招 → phase=2 → 点E到进CD(3秒) → 变奏切今汐(loop)
    二形态变奏入场(phase=2):
      Q好了就放 → 固定普攻3次 → 闪避(连续右键0.15秒) → 普攻到重击亮(不限时)
      → 长按2秒重击 → 等重击动画结束 → 强制放二段大招(不限时等亮+失败无限重试)
      → phase=1 → 放E → 0.3秒 → 变奏切守岸人(loop)

    保留的已验证技术:
    - skip_combat_check() 重写（乐山方案：HUD 消失给宽限，不误判脱战）
    - click() 按住 A_TAP 秒（默认10ms会被游戏吞）
    - switch_to 用 count>=team_size 确认切人成功，不可信命中连续3次也算
    - check_f_on_switch=False（切人时不自动插处决）
    - cast_liberation_force()（二段大招放不出来绝不切人）
    - 闪避用 continues_right_click（单次10ms右键游戏识别不到）
    """

    # ===== 类属性（不被框架 reset_state 清除）=====
    intro_pending = False   # 变奏入场标记：切人时置位，do_perform 读取后清除
    phase = 1               # 1=一形态，2=二形态

    # ===== 普攻 / 切人 =====
    A_TAP = 0.06                    # 普攻按住时长(默认10ms会被游戏吞)
    UNTRUSTED_CONFIRM = 3           # 切人不可信命中连续确认次数
    SWITCH_TIMEOUT = 8.0            # 切人最大等待时间
    SWITCH_KEY_DOWN = 0.02          # 切人键按下时长
    SWITCH_RETRY_INTERVAL = 0.08    # 切人轮询间隔

    # ===== 脱战判定（乐山方案）=====
    HUD_GRACE = 5.0                 # HUD消失后继续跳过战斗判定的宽限时间

    # ===== 重击 =====
    HEAVY_HOLD = 2.0                # 重击长按时长
    HEAVY_READY_TIMEOUT = 5.0       # 一形态等重击亮超时(二形态不限时)
    HEAVY_ANIM_TIMEOUT = 3.0        # 等重击动画结束超时
    HEAVY_ANIM_POLL = 0.08          # 等重击动画结束的轮询间隔
    HEAVY_BUILD_INTERVAL = 0.1      # 一形态攒重击的普攻间隔

    # ===== 大招 =====
    LIB_READY_TIMEOUT = 3.0         # 一形态等大招亮超时
    LIB_POLL_INTERVAL = 0.05        # 等大招亮的轮询间隔
    LIB_WAIT_IF_CD_READY = 0.5      # click_liberation 的就绪等待
    LIB_RETRY_INTERVAL = 0.5        # 强制放大招失败后的重试间隔
    LIB_ENERGY_CLICK_INTERVAL = 1.5 # 强制等大招亮期间，每隔这么久补一次普攻攒能量
    LIB_ENERGY_POLL_INTERVAL = 0.1  # 强制等大招亮期间的轮询间隔

    # ===== 一形态点E =====
    E_SPAM_TIMEOUT = 3.0
    E_SPAM_INTERVAL = 0.05

    # ===== 二形态节奏 =====
    ATTACK_INTERVAL = 0.12          # 固定普攻 / 攒重击的普攻间隔
    DODGE_HOLD = 0.15               # 闪避连续右键时长
    DODGE_INTERVAL = 0.05           # 闪避右键间隔
    DODGE_SETTLE = 0.3              # 闪避后稳定等待
    E_AFTER_LIB_DELAY = 0.3         # 二段大招后放E到切人的间隔

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._entry_mode = None
        self._last_combat_start = -1
        self._pending_switch = None
        # 借鉴宏模式: 切人时不自动按处决(F), 防止打断切人节奏
        self.check_f_on_switch = False

    def reset_state(self):
        super().reset_state()
        # 内置非治疗角色默认True, 换类时会被打回, 在这里重申
        self.check_f_on_switch = False

    # ========== 战斗判定 ==========

    def skip_combat_check(self):
        """乐山方案: 重写战斗判定跳过逻辑。
        HUD在 → 跳过; HUD消失 → 再给HUD_GRACE秒宽限; 真消失超过宽限才判脱战。
        比 task.skip_combat_check=True + 定时器 更可靠: HUD回来时宽限自动重置。"""
        if not self.in_team_rot:
            return super().skip_combat_check()
        now = time.time()
        if self.task.in_team()[0]:
            self.task._hud_last_seen = now
            return True
        if not getattr(self.task, '_hud_last_seen', 0):
            self.task._hud_last_seen = now
        return now - self.task._hud_last_seen < self.HUD_GRACE

    def _check_combat_reset(self):
        """新战斗开始 → 形态重置为一形态。"""
        combat_start = getattr(self.task, 'combat_start', -1)
        if combat_start > 0 and combat_start != self._last_combat_start:
            self._last_combat_start = combat_start
            Hsin.phase = 1

    # ========== 工具方法 ==========

    @property
    def in_team_rot(self):
        """当前队伍是不是心+今汐+守岸人队。不是的话走原版逻辑。"""
        return (any(c and c.__class__.__name__ == 'Jinhsi' for c in self.task.chars)
                and any(c and c.__class__.__name__ == 'ShoreKeeper' for c in self.task.chars))

    def find_char(self, name):
        for c in self.task.chars:
            if c and c.__class__.__name__ == name:
                return c
        return None

    def click(self, *args, **kwargs):
        """本队里普攻按住A_TAP秒(默认10ms会被游戏吞)。不在本队走原版。"""
        if not self.in_team_rot:
            return super().click(*args, **kwargs)
        self.task.mouse_down()
        try:
            self.sleep(self.A_TAP)
        finally:
            self.task.mouse_up()

    def switch_to(self, name, intro=False, mode=None):
        """切到指定角色。用 count>=team_size 确认切人成功, 不可信命中连续3次也算。"""
        t = self.find_char(name)
        if not t:
            return
        t.has_intro = intro
        if intro and hasattr(t, 'intro_pending'):
            t.intro_pending = True
        if mode is not None and hasattr(t, '_entry_mode'):
            t._entry_mode = mode
        self._pending_switch = (name, intro, mode)
        team_size = len([c for c in self.task.chars if c is not None])
        start = time.time()
        success = False
        untrusted_hits = 0
        while time.time() - start < self.SWITCH_TIMEOUT:
            self.task.send_key(t.index + 1, down_time=self.SWITCH_KEY_DOWN)
            self.task.next_frame()
            in_team, idx, count = self.task.in_team()
            hit = in_team and idx == t.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                success = True
                break
            self.sleep(self.SWITCH_RETRY_INTERVAL)
        if success:
            self._pending_switch = None
            self.switch_out(con_full=intro)
            t.is_current_char = True
            t.last_switch_in_time = time.time()

    # ========== 技能操作 ==========

    def cast_q_if_ready(self):
        """Q(声骸)好了就放，脱手技能不影响循环。"""
        if self.echo_available():
            self.click_echo(time_out=0)

    def release_heavy(self, hold_time=None):
        """长按重击。"""
        if hold_time is None:
            hold_time = self.HEAVY_HOLD
        self.task.mouse_down()
        self.sleep(hold_time)
        self.task.mouse_up()

    def wait_heavy_anim_end(self, timeout=None):
        """等重击动画结束(长按动作消失)。"""
        if timeout is None:
            timeout = self.HEAVY_ANIM_TIMEOUT
        start = time.time()
        while time.time() - start < timeout:
            self.task.next_frame()
            if not self.has_long_action():
                return
            self.sleep(self.HEAVY_ANIM_POLL)

    def wait_lib_ready(self, timeout=None):
        """等大招亮(一形态用, 有超时)。"""
        if timeout is None:
            timeout = self.LIB_READY_TIMEOUT
        start = time.time()
        while time.time() - start < timeout and not self.liberation_available():
            self.sleep(self.LIB_POLL_INTERVAL)

    def _click_liberation_once(self):
        """清掉大招状态缓存后尝试放大招一次，返回是否成功。"""
        self.task.in_liberation = False
        return self.click_liberation(wait_if_cd_ready=self.LIB_WAIT_IF_CD_READY)

    def cast_liberation(self):
        """一形态：放一段大招（等亮由调用方 wait_lib_ready 负责）。"""
        self._click_liberation_once()

    def cast_liberation_force(self):
        """二形态：强制放二段大招，放不出来绝不返回。
        不限时等大招亮(期间放Q+普攻攒能量)，click_liberation 失败则无限重试。"""
        attempt = 0
        while True:
            attempt += 1
            # 等大招亮(不限时, 顺便放Q和普攻攒能量)
            idle_start = time.time()
            while not self.liberation_available():
                self.cast_q_if_ready()
                if time.time() - idle_start > self.LIB_ENERGY_CLICK_INTERVAL:
                    self.click()
                    idle_start = time.time()
                self.sleep(self.LIB_ENERGY_POLL_INTERVAL)
            if self._click_liberation_once():
                return
            # 失败了, 等一会再重试(可能还在重击后摇里)
            self.logger.info(f'二段大招第{attempt}次释放失败, 重试')
            self.sleep(self.LIB_RETRY_INTERVAL)

    # ========== 形态流程 ==========

    def _perform_phase1(self):
        """一形态：普攻到重击亮 → 长按重击 → 放一段大招 → 点E到进CD → 变奏切今汐。"""
        start = time.time()
        while time.time() - start < self.HEAVY_READY_TIMEOUT and not self.heavy_available():
            self.click()
            self.sleep(self.HEAVY_BUILD_INTERVAL)
        self.release_heavy()
        self.wait_lib_ready()
        self.cast_liberation()
        Hsin.phase = 2
        start = time.time()
        while time.time() - start < self.E_SPAM_TIMEOUT:
            self.send_resonance_key()
            self.sleep(self.E_SPAM_INTERVAL)
            self.task.next_frame()
            if self.has_cd('resonance'):
                break
        self.switch_to('Jinhsi', intro=True, mode='loop')

    def _perform_phase2(self):
        """二形态：固定普攻3次 → 闪避 → 普攻到重击亮(不限时) → 长按重击 → 等重击动画
        → 强制放二段大招 → 放E → 变奏切守岸人。"""
        for _ in range(3):
            self.click()
            self.sleep(self.ATTACK_INTERVAL)
        # 闪避(连续点右键, 单次10ms右键太短游戏识别不到)
        self.continues_right_click(self.DODGE_HOLD, interval=self.DODGE_INTERVAL)
        self.sleep(self.DODGE_SETTLE)
        # 普攻到重击亮(不限时, 重击不亮二段大不解锁)
        while not self.heavy_available():
            self.cast_q_if_ready()
            self.click()
            self.sleep(self.ATTACK_INTERVAL)
        self.release_heavy()
        self.wait_heavy_anim_end()
        # 强制放二段大招(不限时等待 + 失败无限重试, 放不出来绝不切人)
        self.cast_liberation_force()
        Hsin.phase = 1
        self.send_resonance_key()
        self.sleep(self.E_AFTER_LIB_DELAY)
        self.switch_to('ShoreKeeper', intro=True, mode='loop')

    # ========== 主循环 ==========

    def do_perform(self):
        # 保底：确保鼠标左键已抬起；新战斗则重置形态
        self.task.mouse_up()
        self._check_combat_reset()

        # 优先级1：HUD 不在(动画中/脱战) → 不动作
        if not self.task.in_team()[0]:
            return
        # 优先级2：不是本队 → 走原版
        if not self.in_team_rot:
            return super().do_perform()
        # 优先级3：上次切人未成功 → 先重试切人
        if self._pending_switch:
            name, intro, mode = self._pending_switch
            self.switch_to(name, intro=intro, mode=mode)
            return

        # 读取并清除一次性入场标记（心的 _entry_mode 只由别处写入，这里无需读取）
        self._entry_mode = None
        is_variation = Hsin.intro_pending or self.has_intro
        Hsin.intro_pending = False

        # 优先级4：非变奏入场 → 切守岸人开启动轴
        if not is_variation:
            self.switch_to('ShoreKeeper', intro=False, mode='opener1')
            return

        # 优先级5：变奏入场 → 放Q(脱手) → 按形态执行
        self.cast_q_if_ready()
        if Hsin.phase == 1:
            self._perform_phase1()
        else:
            self._perform_phase2()

    # ========== 框架接口 ==========

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """返回 NO 表示不让框架自动切人，全部手动控制。不是本队时走原版。"""
        if not self.in_team_rot:
            return super().get_switch_priority(current_char, has_intro, target_low_con)
        return SwitchPriority.NO

    def on_combat_end(self, chars):
        self._entry_mode = None
        self._pending_switch = None
        self.task.mouse_up()
        return super().on_combat_end(chars)
