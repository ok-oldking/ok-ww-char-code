import time

from src.char.BaseChar import SwitchPriority
from src.char.ShoreKeeper import ShoreKeeper as NativeShoreKeeper


class ShoreKeeper(NativeShoreKeeper):
    """守岸人 —— 心/今汐/守岸人队的辅助位（Codex 优化版：战斗流程与 v20 完全一致，仅整理结构）。

    【入场模式】由切人时传入的 mode 决定：
      opener1 —— 开局第一次上场(或变奏入场)：普攻1.2秒 → 切今汐(opener1)
      opener2 —— 今汐放完E切回来：普攻1秒 → 放E → 等E进CD → 切今汐(opener2)
      opener3 —— 今汐第二次放完E切回来：Q按到进CD → 等大招亮 → 放大招
                 → 普攻到协奏满 → 回路重击 → 变奏切今汐(loop)
    循环轴(mode='loop')也重跑启动轴 opener1，不区分启动/循环（用户明确确认）。

    【关键机制】
    - intro_pending：类属性，变奏入场标记（切人时置位，do_perform 读取后清除）。
    - _entry_mode：实例属性，一次性入场模式；_pending_switch：切人失败重试目标。
    - skip_combat_check：乐山方案，HUD 消失先给宽限，不把动画误判成脱战。

    保留的已验证技术: click() 按住 A_TAP 秒、switch_to 用 count>=team_size 确认、
    check_f_on_switch=False 防插处决、协奏用 float(get_current_con())>=1.0 检测
    (避开 is_con_full() 的 0.99 哨兵值问题)、大招后等HUD回来多帧确认防闪帧。
    """

    # ===== 类属性（不被框架 reset_state 清除）=====
    intro_pending = False   # 变奏入场标记：切人时置位，do_perform 读取后清除

    # ===== 普攻 / 切人 =====
    A_TAP = 0.06                    # 普攻按住时长(默认10ms会被游戏吞)
    UNTRUSTED_CONFIRM = 3           # 切人不可信命中连续确认次数
    SWITCH_TIMEOUT = 5.0            # 默认切人超时
    SWITCH_TIMEOUT_OPENER1 = 3.0    # opener1 切人超时(变奏入场HUD可能消失)
    SWITCH_KEY_DOWN = 0.02          # 切人键按下时长
    SWITCH_RETRY_INTERVAL = 0.08    # 切人轮询间隔(用原生 time.sleep 绕过框架 sleep_check)

    # ===== 脱战判定（乐山方案）=====
    HUD_GRACE = 5.0                 # HUD消失后继续跳过战斗判定的宽限时间

    # ===== opener1 =====
    OPENER1_ATTACK_TIME = 1.2       # opener1 普攻时长
    OPENER1_ATTACK_INTERVAL = 0.08  # opener1 普攻间隔

    # ===== opener2 =====
    OPENER2_ATTACK_TIME = 1.0       # opener2 普攻时长
    OPENER2_ATTACK_INTERVAL = 0.08  # opener2 普攻间隔
    OPENER2_E_CD_WAIT = 1.0         # opener2 等E进CD超时
    OPENER2_E_CD_POLL = 0.05        # opener2 等E进CD的轮询间隔

    # ===== opener3 =====
    OPENER3_ECHO_POLL = 0.03        # opener3 Q按到进CD的轮询间隔
    OPENER3_LIB_WAIT = 4.0          # opener3 等大招亮超时
    OPENER3_LIB_ATTACK_INTERVAL = 0.1  # opener3 等大招亮期间的普攻间隔
    LIB_WAIT_IF_CD_READY = 0.3      # click_liberation 的就绪等待

    # ===== 协奏 / 回路 =====
    CON_FULL_THRESHOLD = 1.0        # 协奏真满阈值(0.99是环没闭合的哨兵值)
    ATTACK_INTERVAL = 0.08          # 普攻到协奏满的普攻间隔
    FORTE_WAIT = 5.0                # 等回路条满超时
    FORTE_ATTACK_INTERVAL = 0.12    # 攒回路的普攻间隔
    HEAVY_SWITCH_DELAY = 0.3        # 回路重击后切人延迟

    # ===== HUD 多帧确认（防闪帧）=====
    HUD_BACK_CONFIRM = 2            # HUD连续回来帧数=演出真的结束了
    HUD_MIN_GONE = 0.5              # 演出开始后这么久内的"回来"不认(防闪帧)
    HUD_BACK_TIMEOUT = 3.0          # 等HUD回来超时
    HUD_BACK_POLL = 0.05            # 等HUD回来的轮询间隔
    HUD_NO_ANIM_GRACE = 0.35        # HUD从未消失(无动画)时直接返回的宽限

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._entry_mode = None      # 一次性入场模式（opener1/opener2/opener3/loop）
        self._pending_switch = None  # 待重试的切人目标 (name, intro, mode)
        # 借鉴宏模式: 切人时不自动按处决(F), 防止打断切人节奏
        self.check_f_on_switch = False

    def reset_state(self):
        super().reset_state()
        # 内置非治疗角色默认True, 换类时会被打回, 在这里重申
        self.check_f_on_switch = False

    def skip_combat_check(self):
        """乐山方案: 重写战斗判定跳过逻辑。
        HUD在 → 跳过; HUD消失 → 再给HUD_GRACE秒宽限; 真消失超过宽限才判脱战。"""
        if not self.in_team_rot:
            return super().skip_combat_check()
        now = time.time()
        if self.task.in_team()[0]:
            self.task._hud_last_seen = now
            return True
        if not getattr(self.task, '_hud_last_seen', 0):
            self.task._hud_last_seen = now
        return now - self.task._hud_last_seen < self.HUD_GRACE

    # ========== 工具方法 ==========

    @property
    def in_team_rot(self):
        """当前队伍是不是心+今汐+守岸人队。不是的话走原版逻辑。"""
        return (any(c and c.__class__.__name__ == 'Hsin' for c in self.task.chars)
                and any(c and c.__class__.__name__ == 'Jinhsi' for c in self.task.chars))

    def find_char(self, name):
        for c in self.task.chars:
            if c and c.__class__.__name__ == name:
                return c
        return None

    def click(self, *args, **kwargs):
        """本队里普攻按住A_TAP秒(默认10ms会被游戏吞)。不在本队走原版。"""
        if not self.in_team_rot:
            return super().click(*args, **kwargs)
        self.task.mouse_down()
        try:
            self.sleep(self.A_TAP)
        finally:
            self.task.mouse_up()

    def switch_to(self, name, intro=False, mode=None, timeout=None, force_after_timeout=False):
        """切到指定角色。用 count>=team_size 确认切人成功, 不可信命中连续3次也算。
        timeout: 切人最大等待时间, None 用默认 SWITCH_TIMEOUT。
        force_after_timeout: True=超时后即使没检测到目标也标记切成功(变奏入场HUD消失时用)。
        """
        if timeout is None:
            timeout = self.SWITCH_TIMEOUT
        t = self.find_char(name)
        if not t:
            return
        t.has_intro = intro
        if intro and hasattr(t, 'intro_pending'):
            t.intro_pending = True   # 类属性，不被reset清除
        if mode is not None and hasattr(t, '_entry_mode'):
            t._entry_mode = mode
        self._pending_switch = (name, intro, mode)
        team_size = len([c for c in self.task.chars if c is not None])
        start = time.time()
        success = False
        untrusted_hits = 0
        while time.time() - start < timeout:
            self.task.send_key(t.index + 1, down_time=self.SWITCH_KEY_DOWN)
            self.task.next_frame()
            in_team, idx, count = self.task.in_team()
            hit = in_team and idx == t.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                success = True
                break
            # 用原生 time.sleep 绕过框架 sleep_check
            time.sleep(self.SWITCH_RETRY_INTERVAL)
        # 切成功了 或 force_after_timeout 超时保底: 清除重试标记，标记退场/上场
        if success or force_after_timeout:
            self._pending_switch = None
            self.switch_out(con_full=intro)
            t.is_current_char = True
            t.last_switch_in_time = time.time()

    def wait_hud_back(self, timeout=None):
        """等HUD重新出现(大招动画结束后HUD会消失再回来)。
        需连续 HUD_BACK_CONFIRM 帧确认，且演出开始后 HUD_MIN_GONE 秒内的"回来"不认(防闪帧)。
        HUD 从未消失过(没有动画)时，超过 HUD_NO_ANIM_GRACE 直接返回。"""
        if timeout is None:
            timeout = self.HUD_BACK_TIMEOUT
        start = time.time()
        gone_at = None
        back_hits = 0
        while time.time() - start < timeout:
            self.task.next_frame()
            if not self.task.in_team()[0]:
                # HUD消失了, 记录消失时刻
                if gone_at is None:
                    gone_at = time.time()
                back_hits = 0
            elif gone_at is not None:
                # HUD回来了, 检查是否超过min_gone(防动画中途闪帧)
                if time.time() - gone_at >= self.HUD_MIN_GONE:
                    back_hits += 1
                    if back_hits >= self.HUD_BACK_CONFIRM:
                        return
            elif time.time() - start >= self.HUD_NO_ANIM_GRACE:
                # HUD从来没消失过(没有动画), 超过宽限期直接返回
                return
            self.sleep(self.HUD_BACK_POLL)

    def _is_con_full(self):
        """借鉴宏模式: 协奏真满判断。
        不用 is_con_full() —— 它有缓存和 0.99 哨兵值问题(percent>1但返回False)。
        直接读原始值 >= CON_FULL_THRESHOLD(1.0)。"""
        try:
            return float(self.task.get_current_con()) >= self.CON_FULL_THRESHOLD
        except Exception:
            return False

    def _attack_for(self, duration, interval):
        """普攻循环指定时长。用 time.sleep 绕过框架 sleep_check。"""
        start = time.time()
        while time.time() - start < duration:
            self.click()
            time.sleep(interval)

    def _attack_until_con_full(self):
        """大招结束后普攻到协奏满(用 float(get_current_con())>=1.0 判断, 不用 is_con_full())。"""
        while True:
            self.click()
            self.sleep(self.ATTACK_INTERVAL)
            if self._is_con_full():
                break

    def _heavy_then_switch(self):
        """协奏满后放回路重击，然后变奏切今汐。
        - 守岸人的重击不是高亮重击，是回路条满了之后的派生攻击
        - 用 is_mouse_forte_full() 检测回路条满，用 heavy_click_forte() 释放
        - 最多等 FORTE_WAIT 秒回路条满，期间普攻攒回路；重击后等 HEAVY_SWITCH_DELAY 秒切人
        """
        forte_start = time.time()
        while time.time() - forte_start < self.FORTE_WAIT and not self.is_mouse_forte_full():
            self.click()
            self.sleep(self.FORTE_ATTACK_INTERVAL)
        self.heavy_click_forte(self.is_mouse_forte_full)   # 放回路重击
        self.sleep(self.HEAVY_SWITCH_DELAY)
        self.switch_to('Jinhsi', intro=True, mode='loop')  # 变奏切今汐

    # ========== 各 opener 阶段 ==========

    def _do_opener1(self):
        """opener1：开局第一次上场 / 变奏入场。普攻1.2秒后切今汐。"""
        self._attack_for(self.OPENER1_ATTACK_TIME, self.OPENER1_ATTACK_INTERVAL)
        # 切今汐: 3秒超时 + 超时保底(变奏入场HUD消失可能检测不到切人成功)
        self.switch_to('Jinhsi', intro=False, mode='opener1',
                       timeout=self.SWITCH_TIMEOUT_OPENER1, force_after_timeout=True)

    def _do_opener2(self):
        """opener2：今汐放完E切回来。普攻1秒→放E→等E进CD→切今汐。"""
        self.continues_normal_attack(self.OPENER2_ATTACK_TIME, interval=self.OPENER2_ATTACK_INTERVAL)
        self.send_resonance_key()   # 按E
        # 等E进CD，确认E放出来了
        start = time.time()
        while time.time() - start < self.OPENER2_E_CD_WAIT and not self.has_cd('resonance'):
            self.sleep(self.OPENER2_E_CD_POLL)
        self.switch_to('Jinhsi', intro=False, mode='opener2')

    def _do_opener3(self):
        """opener3：今汐第二次放完E切回来，启动轴最后一步。"""
        # Q按到进CD(Q是脱手技能)
        while not self.has_cd('echo'):
            self.send_echo_key()
            self.sleep(self.OPENER3_ECHO_POLL)
        # 等大招亮, 期间普攻
        self.task.in_liberation = False   # 清大招状态缓存
        lib_start = time.time()
        while time.time() - lib_start < self.OPENER3_LIB_WAIT and not self.liberation_available():
            self.click()
            self.sleep(self.OPENER3_LIB_ATTACK_INTERVAL)
        # 放大招(内部等大招动画结束)
        self.click_liberation(wait_if_cd_ready=self.LIB_WAIT_IF_CD_READY)
        self.wait_hud_back()   # 等HUD重新出现(多帧确认)
        # 普攻到协奏满 → 回路重击 → 变奏切今汐
        self._attack_until_con_full()
        self._heavy_then_switch()

    # ========== 主循环 ==========

    def do_perform(self):
        # 优先级1：不是本队 → 走原版守岸人逻辑
        if not self.in_team_rot:
            return super().do_perform()
        # 优先级2：上次切人未成功 → 先重试切人
        if self._pending_switch:
            name, intro, mode = self._pending_switch
            self.switch_to(name, intro=intro, mode=mode)
            return

        # 读取并清除一次性入场标记
        mode = self._entry_mode
        self._entry_mode = None
        ShoreKeeper.intro_pending = False

        # 优先级3：循环轴(loop)也重跑启动轴 opener1，不区分启动/循环(用户明确确认)
        if mode is None or mode == 'loop':
            mode = 'opener1'

        # 优先级4：按模式分发（单一优先级链）
        if mode == 'opener1':
            self._do_opener1()
        elif mode == 'opener2':
            self._do_opener2()
        elif mode == 'opener3':
            self._do_opener3()

    # ========== 框架接口 ==========

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """返回 NO 表示不让框架自动切人，全部手动控制。不是本队时走原版。"""
        if not self.in_team_rot:
            return super().get_switch_priority(current_char, has_intro, target_low_con)
        return SwitchPriority.NO

    def on_combat_end(self, chars):
        self._entry_mode = None
        self._pending_switch = None
        return super().on_combat_end(chars)
