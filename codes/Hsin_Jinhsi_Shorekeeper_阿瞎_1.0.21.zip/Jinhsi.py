import time

from src.char.BaseChar import SwitchPriority
from src.char.Jinhsi import Jinhsi as NativeJinhsi


class Jinhsi(NativeJinhsi):
    """今汐 —— 心/今汐/守岸人队的副C（Codex 优化版：战斗流程与 v20 完全一致，仅整理结构）。

    【入场模式】由切人时传入的 mode 决定：
      opener1 —— 开局守岸人切过来：普攻2.2秒 → 放E → 切守岸人(opener2)
      opener2 —— 守岸人放完E切回来：普攻1秒 → 放E → 切守岸人(opener3)
      loop    —— 变奏入场：等入场动画 → 放Q → 狂按E+普攻到龙喷 → 变奏切心

    【关键机制】
    - intro_pending：类属性，变奏入场标记（切人时置位，do_perform 读取后清除）。
      用类属性是因为实例属性会被框架 reset_state 清除。
    - _entry_mode：实例属性，一次性入场模式；_pending_switch：切人失败重试目标。
    - skip_combat_check：乐山方案，HUD 消失先给宽限，不把动画/出招误判成脱战。
    - 龙喷判断：不看E图标亮度，看HUD。HUD 连续3帧消失=龙喷开始；
      连续2帧回来且距消失超过0.5秒=龙喷结束（防动画中途闪帧误判）。

    保留的已验证技术: click() 按住 A_TAP 秒、switch_to 用 count>=team_size 确认、
    check_f_on_switch=False 防插处决、龙喷多帧确认。
    """

    # ===== 类属性（不被框架 reset_state 清除）=====
    intro_pending = False   # 变奏入场标记：切人时置位，do_perform 读取后清除

    # ===== 普攻 / 切人 =====
    A_TAP = 0.06                    # 普攻按住时长(默认10ms会被游戏吞)
    UNTRUSTED_CONFIRM = 3           # 切人不可信命中连续确认次数
    SWITCH_TIMEOUT = 8.0            # 切人最大等待时间
    SWITCH_KEY_DOWN = 0.02          # 切人键按下时长
    SWITCH_RETRY_INTERVAL = 0.08    # 切人轮询间隔

    # ===== 启动轴 =====
    OPENER1_ATTACK_TIME = 2.2       # opener1 普攻时长
    OPENER2_ATTACK_TIME = 1.0       # opener2 普攻时长
    OPENER_ATTACK_INTERVAL = 0.1    # 启动轴普攻间隔

    # ===== 龙喷（多帧确认，防闪帧）=====
    SPAM_INTERVAL = 0.12            # 狂按E+普攻的循环间隔
    SPAM_MAX_TIME = 10.0            # 狂按E+普攻最大时长(超时保护)
    HUD_GONE_CONFIRM = 3            # HUD连续消失帧数=龙喷动画真的开始
    HUD_BACK_CONFIRM = 2            # HUD连续回来帧数=龙喷动画真的结束
    HUD_MIN_GONE = 0.5              # 龙喷开始后这么久内的"回来"不认(防闪帧)
    HUD_POLL_INTERVAL = 0.02        # 检测龙喷开始的轮询间隔
    HUD_BACK_POLL_INTERVAL = 0.03   # 等龙喷结束的轮询间隔
    DRAGON_TIMEOUT = 5.0            # 龙喷动画最大等待时间

    # ===== 脱战判定（乐山方案）=====
    HUD_GRACE = 5.0                 # HUD消失后继续跳过战斗判定的宽限时间

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._entry_mode = None      # 一次性入场模式（opener1/opener2/loop）
        self._pending_switch = None  # 待重试的切人目标 (name, intro, mode)
        # 借鉴宏模式: 切人时不自动按处决(F), 防止打断切人节奏
        self.check_f_on_switch = False

    def reset_state(self):
        super().reset_state()
        # 内置非治疗角色默认True, 换类时会被打回, 在这里重申
        self.check_f_on_switch = False

    def skip_combat_check(self):
        """乐山方案: 重写战斗判定跳过逻辑。
        HUD在 → 跳过; HUD消失 → 再给HUD_GRACE秒宽限; 真消失超过宽限才判脱战。"""
        if not self.in_team_rot:
            return super().skip_combat_check()
        now = time.time()
        if self.task.in_team()[0]:
            self.task._hud_last_seen = now
            return True
        if not getattr(self.task, '_hud_last_seen', 0):
            self.task._hud_last_seen = now
        return now - self.task._hud_last_seen < self.HUD_GRACE

    # ========== 工具方法 ==========

    @property
    def in_team_rot(self):
        """当前队伍是不是心+今汐+守岸人队。不是的话走原版逻辑。"""
        return (any(c and c.__class__.__name__ == 'Hsin' for c in self.task.chars)
                and any(c and c.__class__.__name__ == 'ShoreKeeper' for c in self.task.chars))

    def find_char(self, name):
        for c in self.task.chars:
            if c and c.__class__.__name__ == name:
                return c
        return None

    def click(self, *args, **kwargs):
        """本队里普攻按住A_TAP秒(默认10ms会被游戏吞)。不在本队走原版。"""
        if not self.in_team_rot:
            return super().click(*args, **kwargs)
        self.task.mouse_down()
        try:
            self.sleep(self.A_TAP)
        finally:
            self.task.mouse_up()

    def switch_to(self, name, intro=False, mode=None):
        """切到指定角色。用 count>=team_size 确认切人成功, 不可信命中连续3次也算。"""
        t = self.find_char(name)
        if not t:
            return
        t.has_intro = intro
        if intro and hasattr(t, 'intro_pending'):
            t.intro_pending = True   # 类属性，不被reset清除
        if mode is not None and hasattr(t, '_entry_mode'):
            t._entry_mode = mode
        self._pending_switch = (name, intro, mode)
        team_size = len([c for c in self.task.chars if c is not None])
        start = time.time()
        success = False
        untrusted_hits = 0
        while time.time() - start < self.SWITCH_TIMEOUT:
            self.task.send_key(t.index + 1, down_time=self.SWITCH_KEY_DOWN)
            self.task.next_frame()
            in_team, idx, count = self.task.in_team()
            hit = in_team and idx == t.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                success = True
                break
            self.sleep(self.SWITCH_RETRY_INTERVAL)
        if success:
            self._pending_switch = None
            self.switch_out(con_full=intro)
            t.is_current_char = True
            t.last_switch_in_time = time.time()

    # ========== 技能操作 ==========

    def cast_q_if_ready(self):
        """Q(声骸)好了就放，脱手技能不影响循环。"""
        if self.echo_available():
            self.click_echo(time_out=0)

    def _opener_attack(self, attack_time):
        """启动轴公共动作：持续普攻 attack_time 秒后放E。"""
        self.continues_normal_attack(attack_time, interval=self.OPENER_ATTACK_INTERVAL)
        self.send_resonance_key()

    def _wait_hud_back_confirm(self, timeout=None, min_gone=None):
        """等HUD回来(龙喷结束): 需连续 HUD_BACK_CONFIRM 帧确认，
        且龙喷开始后 min_gone 秒内的"回来"不认(防动画中途闪帧误判)。
        调用前应已确认HUD消失(龙喷开始)。"""
        if timeout is None:
            timeout = self.DRAGON_TIMEOUT
        if min_gone is None:
            min_gone = self.HUD_MIN_GONE
        start = time.time()
        gone_at = time.time()   # 调用时HUD已消失
        back_hits = 0
        while time.time() - start < timeout:
            self.task.next_frame()
            if self.task.in_team()[0]:
                if time.time() - gone_at >= min_gone:
                    back_hits += 1
                    if back_hits >= self.HUD_BACK_CONFIRM:
                        return
            else:
                # HUD又消失了(闪帧), 重置回来计数
                back_hits = 0
            self.sleep(self.HUD_BACK_POLL_INTERVAL)

    def spam_e_until_dragon(self, max_time=None):
        """狂按E + 普攻，直到龙喷动画出现，等动画结束后返回。

        龙喷判断(多帧确认, 防闪帧): 不看E图标亮度, 看HUD 是否消失。
        - HUD 连续 HUD_GONE_CONFIRM(3) 帧消失 = 龙喷开始
        - HUD 连续 HUD_BACK_CONFIRM(2) 帧回来且距消失超过 HUD_MIN_GONE(0.5秒) = 龙喷结束
        最多循环 SPAM_MAX_TIME(10) 秒(超时保护)。
        """
        if max_time is None:
            max_time = self.SPAM_MAX_TIME
        start = time.time()
        gone_frames = 0   # HUD连续消失帧数
        while time.time() - start < max_time:
            self.send_resonance_key()   # 按E
            self.click()                # 普攻
            # 在 SPAM_INTERVAL 内反复检测HUD是否连续消失(龙喷开始)
            cycle_start = time.time()
            while time.time() - cycle_start < self.SPAM_INTERVAL:
                self.task.next_frame()
                if not self.task.in_team()[0]:
                    gone_frames += 1
                    if gone_frames >= self.HUD_GONE_CONFIRM:
                        # 龙喷真的开始了 → 等HUD确认回来(连续2帧且超过min_gone)
                        self._wait_hud_back_confirm()
                        return
                else:
                    gone_frames = 0   # HUD回来了，重置消失计数
                self.sleep(self.HUD_POLL_INTERVAL)

    # ========== 主循环 ==========

    def do_perform(self):
        # 优先级1：不是本队 → 走原版今汐逻辑
        if not self.in_team_rot:
            return super().do_perform()
        # 优先级2：上次切人未成功 → 先重试切人
        if self._pending_switch:
            name, intro, mode = self._pending_switch
            self.switch_to(name, intro=intro, mode=mode)
            return

        # 读取并清除一次性入场标记
        mode = self._entry_mode
        self._entry_mode = None
        is_variation = Jinhsi.intro_pending or self.has_intro
        Jinhsi.intro_pending = False

        # 模式未指定时按入场类型推定：变奏走 loop，普通走 opener1
        if mode is None:
            mode = 'loop' if is_variation else 'opener1'

        # 优先级3：启动轴 opener1 / opener2
        if mode == 'opener1':
            self._opener_attack(self.OPENER1_ATTACK_TIME)
            self.switch_to('ShoreKeeper', intro=False, mode='opener2')
            return
        if mode == 'opener2':
            self._opener_attack(self.OPENER2_ATTACK_TIME)
            self.switch_to('ShoreKeeper', intro=False, mode='opener3')
            return

        # 优先级4：循环轴 loop —— 变奏入场
        if is_variation:
            self.wait_intro()   # 等变奏入场动画结束
        self.cast_q_if_ready()  # Q好了就放，脱手不影响循环
        self.spam_e_until_dragon()   # 狂按E+普攻到龙喷，等龙喷结束
        self.switch_to('Hsin', intro=True, mode='loop')   # 变奏切心

    # ========== 框架接口 ==========

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """返回 NO 表示不让框架自动切人，全部手动控制。不是本队时走原版。"""
        if not self.in_team_rot:
            return super().get_switch_priority(current_char, has_intro, target_low_con)
        return SwitchPriority.NO

    def on_combat_end(self, chars):
        self._entry_mode = None
        self._pending_switch = None
        return super().on_combat_end(chars)
