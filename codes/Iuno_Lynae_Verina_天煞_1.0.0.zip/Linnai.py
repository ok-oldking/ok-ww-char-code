"""1.0.0 发布版的琳奈动作。

本模块只负责发送琳奈自身的技能、普攻和跳跃输入；角色切换、协奏门槛与
动作顺序由 :mod:`Iuno` 队伍控制器统一协调。需要确认的输入均在有限窗口
内重试，并在 HUD 确认成功后立即结束等待。
"""

from __future__ import annotations

import time

import cv2
import numpy as np

from src.char.BaseChar import SwitchPriority
from src.char.Linnai import Linnai as NativeLinnai


class Linnai(NativeLinnai):
    """琳奈动作实现；时序由队伍控制器统一协调。"""

    AXIS_E_SETTLE = 0.16
    # R 动画约四秒；避免仅因冷却图标变化就提前切出。
    AXIS_R_MIN_WAIT = 4.2
    AXIS_INTRO_WAIT = 1.3
    AXIS_FORTE_WAIT = 2.5
    AXIS_Z_HOLD = 5.0
    AXIS_Z_MIN_HOLD = 0.25
    AXIS_Z_CONFIRM_FRAMES = 2
    # Z 消耗确认后立即进入三跳检测，让首个跳跃输入穿过收招恢复。
    AXIS_AFTER_Z_WAIT = 0.0
    # 开局 R 后追击仍可在后台持续；切人前发送两个短 A 以覆盖吞键。
    AXIS_OPENING_A_TAPS = 2
    AXIS_OPENING_A_INTERVAL = 0.06
    # 三次成功跳攻对应三段本色，而不是三次按键；只有三段均确认后才发送
    # A 收尾。跳跃间的 A 可能转为下落攻击，因此由检测结果决定下一步。
    AXIS_JUMP_TIMEOUT = 5.0
    AXIS_JUMP_INPUT_INTERVAL = 0.12
    AXIS_THIRD_JUMP_TAIL = 0.35
    AXIS_FINISHER_TIMEOUT = 2.5
    AXIS_CHAIN_TAIL = 0.22
    # 本色条检测区域按设计分辨率定义，由框架负责高度缩放和水平居中。
    AXIS_TRUE_COLOR_BOXES = (
        (2225, 2660, 2375, 2682),
        (2470, 2660, 2625, 2682),
        (2730, 2660, 2875, 2682),
    )

    def _axis_controller(self):
        for char in getattr(self.task, "chars", None) or ():
            if char is self:
                continue
            if getattr(char, "name", None) == "Iuno" and callable(
                    getattr(char, "run_team_turn", None)):
                return char
        return None

    def _axis_tick(self):
        self.check_combat()
        check_f_break = getattr(self.task, "check_f_break", None)
        if callable(check_f_break):
            check_f_break()

    def _axis_wait(self, duration: float):
        end = time.monotonic() + max(0.0, float(duration))
        while time.monotonic() < end:
            self._axis_tick()
            remaining = end - time.monotonic()
            if remaining <= 0:
                break
            self.sleep(min(0.05, remaining))

    def _axis_normals(self, duration: float):
        """在有限时长内发送 A，并持续执行战斗与处决检查。"""
        end = time.monotonic() + max(0.0, float(duration))
        while time.monotonic() < end:
            self._axis_tick()
            self.click()
            self.sleep(0.10)
        return True

    def _axis_wait_intro(self):
        """等待变奏动画结束；该阶段不额外发送未编排的 A。"""
        if self.has_intro:
            wait_intro = getattr(self, "wait_intro", None)
            if callable(wait_intro):
                wait_intro(time_out=self.AXIS_INTRO_WAIT, click=False)
            else:
                self._axis_wait(0.12)
            entered = getattr(self, "last_switch_in_time", -1)
            settle = max(0.9, getattr(self, "intro_motion_freeze_duration", 0.9)) + 0.12
            if entered >= 0:
                settle -= max(0.0, time.time() - entered)
            self._axis_wait(max(0.0, settle))
        return True

    def _axis_resonance_once(self, wait_after=True):
        """在技能锁定期间重试 E，并确认 HUD 已接受本次施放。"""
        controller = self._axis_controller()
        if not controller or not controller._skill_until_cd(
                self, "resonance", allow_icon_drop=True):
            return False
        if wait_after:
            self._axis_wait(self.AXIS_E_SETTLE)
        return True

    def _axis_release_z_preinput(self):
        self._axis_z_control_started = None
        if getattr(self, "_axis_preheld_z_started", None) is not None:
            try:
                self.task.mouse_up()
            finally:
                self._axis_preheld_z_started = None

    def _axis_z_ready_for_preinput(self):
        """连续两帧确认满资源；检测期间不补攻击。"""
        for _ in range(2):
            self.task.next_frame()
            visible, index, count = self.task.in_team()
            if not (visible and count == 3 and index == self.index):
                return False
            full = self.is_mouse_forte_full()
            # 检测器可能刷新画面；检测后必须重新确认当前角色仍归本模块。
            visible, index, count = self.task.in_team()
            if not (full and visible and count == 3 and index == self.index):
                return False
        return True

    def _axis_hold_z(self, source):
        """满足预输入条件时按住 Z，由转换确认流程或异常清理负责释放。"""
        if getattr(self, "_axis_preheld_z_started", None) is not None:
            return
        # 先记录按住状态，确保后端异常时 finally 仍能释放鼠标。
        self._axis_preheld_z_started = time.monotonic()
        self.task.mouse_down()
        self.logger.info(f"[月琳维轴] 琳奈 Z 提前按住；时机={source}")

    def _axis_r_z_start(self):
        # R 前已确认资源和角色归属；仅在 R 已发送且动画开始后调用，不能只凭
        # 冷却图标触发。动画隐藏 HUD 时不运行资源检测器。
        if getattr(self, "_axis_r_z_preinput_ready", False):
            self._axis_hold_z("R动画")

    def _axis_z_preinput_frame(self, q_accepted):
        if getattr(self, "_axis_preheld_z_started", None) is not None:
            return
        full = self.is_mouse_forte_full()
        self._axis_z_ready_frames = self._axis_z_ready_frames + 1 if full else 0
        visible, index, count = self.task.in_team()
        if not (visible and count == 3 and index == self.index):
            self._axis_z_ready_frames = 0
            return
        if q_accepted and self._axis_z_ready_frames >= 2:
            # Q 已确认，且连续两帧均为满资源；贯穿 Q 收尾按住 Z，控制恢复
            # 时即可开始消耗。
            self._axis_preheld_z_started = time.monotonic()
            self.task.mouse_down()
            self.logger.info("[月琳维轴] 琳奈 Q 已发动，预输入 Z；回路连续两帧就绪")

    def _axis_echo_once(self):
        """确认 Q；在 Z 链中利用确认帧预输入 Z。"""
        controller = self._axis_controller()
        preinput = getattr(self, "_axis_z_preinput_enabled", False)
        self._axis_z_ready_frames = 0
        kwargs = {"on_frame": self._axis_z_preinput_frame} if preinput else {}
        success = False
        try:
            success = bool(controller and controller._skill_until_cd(self, "echo", **kwargs))
            if not success:
                return False
            if not preinput:
                self._axis_wait(self.AXIS_E_SETTLE)
            return True
        finally:
            if not success:
                self._axis_release_z_preinput()

    def _axis_liberation_once(self):
        """重试 R，直到游戏确认本次施放。"""
        controller = self._axis_controller()
        kwargs = ({"on_animation_start": self._axis_r_z_start}
                  if getattr(self, "_axis_r_z_preinput_ready", False) else {})
        return bool(controller and controller._liberation_until_accepted(
            self, min_wait=self.AXIS_R_MIN_WAIT, **kwargs))

    def _axis_prepare_z(self):
        """用有限的 A 补齐 Z 所需资源，避免无输入空等。"""
        self._axis_z_retryable = False
        end = time.monotonic() + self.AXIS_FORTE_WAIT
        attacks = 0
        while time.monotonic() < end:
            self._axis_tick()
            self.task.next_frame()
            visible, index, count = self.task.in_team()
            if not (visible and count == 3 and index == self.index):
                self.logger.warning("[月琳维轴] 琳奈 Z 准备时角色画面未确认")
                return False
            if self.is_mouse_forte_full():
                self.sleep(0.05)
                self.task.next_frame()
                visible, index, count = self.task.in_team()
                if not (visible and count == 3 and index == self.index):
                    self.logger.warning("[月琳维轴] 琳奈 Z 二次确认时角色画面未确认")
                    return False
                if self.is_mouse_forte_full():
                    self.logger.info(f"[月琳维轴] 琳奈 Z 就绪，补 A 次数={attacks}")
                    return True
            self.click()
            attacks += 1
            self.sleep(0.12)
        # 此时尚未按 Z，只有本阶段可安全重试；已完成的 Q/R 进度保持不变。
        self._axis_z_retryable = True
        self.logger.warning(f"[月琳维轴] 琳奈 Z 仍未就绪，已补 A {attacks} 次；保留 R/Q 进度")
        return False

    def _axis_consume_z(self):
        """继续预输入的 Z，或在开始按住前补齐所需资源。"""
        self._axis_z_released_at = None
        preheld = getattr(self, "_axis_preheld_z_started", None)
        if preheld is None and not self._axis_prepare_z():
            return False
        consumed = False
        gone_frames = 0
        started = time.monotonic() if preheld is None else preheld
        # 预输入可能已经覆盖变奏或 R 动画；控制恢复后仍给资源转化一个有限窗口。
        control_started = getattr(self, "_axis_z_control_started", None)
        if preheld is not None and control_started is not None:
            started = max(started, control_started)
        end = started + self.AXIS_Z_HOLD
        try:
            if preheld is None:
                self.task.mouse_down()
                self.logger.info("[月琳维轴] 琳奈 Z 开始按住（常规就绪）")
            while time.monotonic() < end:
                self.task.next_frame()
                visible, index, count = self.task.in_team()
                if not (visible and count == 3):
                    gone_frames = 0
                    self.sleep(0.05, check_combat=False)
                    continue
                if index != self.index:
                    return False
                self._axis_tick()
                # 战斗检查可能刷新 HUD；不能消耗其他角色资源，也不能把隐藏 HUD
                # 当成 Z 已完成。
                visible, index, count = self.task.in_team()
                if not (visible and count == 3):
                    gone_frames = 0
                    self.sleep(0.05, check_combat=False)
                    continue
                if index != self.index:
                    return False
                if (time.monotonic() - started >= self.AXIS_Z_MIN_HOLD
                        and not self.is_mouse_forte_full()):
                    gone_frames += 1
                    if gone_frames >= self.AXIS_Z_CONFIRM_FRAMES:
                        consumed = True
                        break
                else:
                    gone_frames = 0
                self.sleep(0.05)
        finally:
            self._axis_preheld_z_started = None
            self._axis_z_control_started = None
            self.task.mouse_up()
        if not consumed:
            self.logger.warning("[月琳维轴] 琳奈 Z 按住达到上限，未确认回路消耗")
            return False
        self._axis_z_released_at = time.monotonic()
        self.logger.info(f"[月琳维轴] 琳奈 Z 消耗确认，按住={time.monotonic() - started:.3f}秒，"
                         f"预输入={preheld is not None}")
        self._axis_wait(self.AXIS_AFTER_Z_WAIT)
        return True

    def _axis_chain_view(self):
        """刷新角色归属；None 表示 HUD 尚未完整或正处于过渡帧。"""
        self.task.next_frame()
        visible, index, count = self.task.in_team()
        if not visible or count != 3:
            return None
        if index != self.index:
            return False
        self._axis_tick()
        visible, index, count = self.task.in_team()
        if not visible or count != 3:
            return None
        return index == self.index

    def _axis_true_color_stacks(self):
        """读取三段本色填充；动画过渡帧无法确定时返回 None。

        白色像素不代表本色。技能特效可能穿过空槽，因此每个槽位使用独立
        色相范围；满条必须同时检测到绿色、青色和第三槽的粉色。
        """
        frame = self.task.frame
        if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
            return None
        ratios, flashes = [], []
        bands = ((55, 90, 100, 130), (80, 96, 90, 180), (125, 179, 80, 140))
        for number, (coords, band) in enumerate(zip(self.AXIS_TRUE_COLOR_BOXES, bands)):
            box = self.task.box_of_screen_scaled(
                5120, 2880, *coords, name=f"axis_linnai_color_{number}", hcenter=True)
            crop = box.crop_frame(frame)
            if crop is None or not crop.size or min(crop.shape[:2]) < 2:
                return None
            hsv = cv2.cvtColor(crop[:, :, :3], cv2.COLOR_BGR2HSV)
            h, saturation, value = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
            low, high, min_saturation, min_value = band
            mask = ((h >= low) & (h <= high) & (saturation >= min_saturation)
                    & (value >= min_value))
            ratios.append(float(np.mean(mask)))
            flashes.append(float(np.mean((saturation < 50) & (value >= 180))))
        if max(flashes) > 0.60:
            return None
        green, cyan, pink = ratios
        if green >= 0.45 and cyan >= 0.45 and pink >= 0.45:
            return 3
        if green <= 0.12 and pink <= 0.12:
            return 0
        if green >= 0.45 and pink <= 0.12:
            if cyan >= 0.45:
                return 2
            if cyan <= 0.20:
                return 1
        return None

    def _axis_three_jump_a(self):
        """确认三次实际跳攻，再用 A 消耗三段本色。"""
        started = time.monotonic()
        last_input = started - self.AXIS_JUMP_INPUT_INTERVAL
        progress = presses = stable = 0
        candidate = None
        while time.monotonic() - started < self.AXIS_JUMP_TIMEOUT:
            view = self._axis_chain_view()
            if view is False:
                return False
            stacks = self._axis_true_color_stacks() if view is True else None
            if stacks is None:
                candidate, stable = None, 0
            elif stacks == candidate:
                stable += 1
            else:
                candidate, stable = stacks, 1
            if stable >= 2 and stacks > progress:
                progress = stacks
                self.logger.info(f"[月琳维轴] 琳奈跳攻进度={progress}/3，跳键次数={presses}")
            if progress == 3:
                break
            now = time.monotonic()
            # 只有完整队伍 HUD 明确显示琳奈时才继续补跳；疑似满条时先暂停并
            # 复核再发送 A。按键次数不作为跳攻成功依据。
            if (view is True and stacks != 3
                    and now - started < self.AXIS_JUMP_TIMEOUT
                    and now - last_input >= self.AXIS_JUMP_INPUT_INTERVAL):
                released = getattr(self, "_axis_z_released_at", None)
                if presses == 0 and released is not None:
                    self.logger.info(f"[月琳维轴] 琳奈三跳开始输入，"
                                     f"距 Z 松开={now - released:.3f}秒")
                self.task.jump(after_sleep=0.01)
                presses += 1
                last_input = now
            self.sleep(0.05, check_combat=False)
        if progress != 3:
            self.logger.warning(f"[月琳维轴] 琳奈三段跳攻未完成，本色={progress}/3，"
                                f"跳键次数={presses}；不提前 E 或换人")
            return False

        self._axis_wait(self.AXIS_THIRD_JUMP_TAIL)
        started = time.monotonic()
        last_input = started - self.AXIS_JUMP_INPUT_INTERVAL
        attacks = gone = 0
        while time.monotonic() - started < self.AXIS_FINISHER_TIMEOUT:
            view = self._axis_chain_view()
            if view is False:
                return False
            stacks = self._axis_true_color_stacks() if view is True else None
            if stacks is None:
                gone = 0
                self.sleep(0.05, check_combat=False)
                continue
            if attacks and stacks == 0:
                gone += 1
                if gone >= 2:
                    self.logger.info(f"[月琳维轴] 琳奈三段跳 A 收尾已确认，本色3→0，A次数={attacks}")
                    return True
            else:
                gone = 0
            now = time.monotonic()
            # 仅满三段允许发送收尾 A；部分或正在消失的本色等待结算，不再输入。
            if (stacks == 3 and now - started < self.AXIS_FINISHER_TIMEOUT
                    and now - last_input >= self.AXIS_JUMP_INPUT_INTERVAL):
                self.click(interval=0)
                attacks += 1
                last_input = now
            self.sleep(0.05, check_combat=False)
        self.logger.warning(f"[月琳维轴] 琳奈三跳后 A 未确认消耗本色，A次数={attacks}")
        return False

    def _axis_z_chain(self, with_r=False):
        """执行 Q/Z、三次确认跳攻、A 收尾和 E。"""
        controller = self._axis_controller()
        state = controller._state() if controller is not None else {}
        key = (getattr(controller, "AXIS_VERSION", "1.0.0"), state.get("round"),
               state.get("loop"), state.get("step"), with_r)
        if getattr(self, "_axis_chain_key", None) != key:
            self._axis_chain_key = key
            self._axis_chain_progress = {"r": False, "q": False, "z": False}
        progress = self._axis_chain_progress
        self._axis_z_retryable = False
        try:
            self._axis_z_preinput_enabled = True
            self._axis_r_z_preinput_ready = False
            if (not with_r and not progress["z"]
                    and self._axis_z_ready_for_preinput()):
                self._axis_hold_z("变奏入场")
            self._axis_wait_intro()
            if with_r and not progress["r"]:
                self._axis_r_z_preinput_ready = self._axis_z_ready_for_preinput()
                if not self._axis_liberation_once():
                    return False
                progress["r"] = True
            if (not progress["z"]
                    and getattr(self, "_axis_preheld_z_started", None) is None
                    and self._axis_z_ready_for_preinput()):
                self._axis_hold_z("Q之前")
            if getattr(self, "_axis_preheld_z_started", None) is not None:
                self._axis_z_control_started = time.monotonic()
            if not progress["q"]:
                if not self._axis_echo_once():
                    return False
                progress["q"] = True
            if not progress["z"]:
                if not self._axis_consume_z():
                    return False
                progress["z"] = True
        finally:
            self._axis_z_preinput_enabled = False
            self._axis_r_z_preinput_ready = False
            self._axis_release_z_preinput()

        # 三跳必须以本色条的实际变化确认，不能以发送过的跳键数量代替。
        if not self._axis_three_jump_a():
            return False
        # E 施放通过技能图标状态确认；保留 Z 链完成后的恢复检查。摩托追击只
        # 属于开局 R 后短 A，循环 Z 链不重复该动作。
        if not self._axis_resonance_once(wait_after=True):
            return False
        self._axis_wait(self.AXIS_CHAIN_TAIL)
        self._axis_chain_key = None
        return True

    def do_perform(self):
        controller = self._axis_controller()
        if controller is not None:
            return controller.run_team_turn(self)
        return super().do_perform()

    def get_switch_priority(self, current_char=None, has_intro=False,
                            target_low_con=False):
        controller = self._axis_controller()
        target = getattr(controller, "_ylv_target", None) if controller else None
        if target:
            return SwitchPriority.MUST if self.name == target else SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def ylv_ra(self):
        """开局：R 后短按摩托追击 A，再交接给维里奈。"""
        if not self._axis_liberation_once():
            return False
        # R 已确认 HUD 回归和技能状态；追击动画可在后台继续，不占用场上时间。
        # 每次短按前重新确认当前角色，避免切到维里奈后误输入。
        for attempt in range(self.AXIS_OPENING_A_TAPS):
            if attempt:
                self.sleep(self.AXIS_OPENING_A_INTERVAL)
            self.task.next_frame()
            visible, index, count = self.task.in_team()
            if not (visible and count == 3 and index == self.index):
                return False
            self.check_combat()
            self.click(interval=0)
        self.logger.info("[月琳维轴] 琳奈开局 R 后追击 A 短按 2 次，立即交接维里奈")
        return True

    def ylv_e(self):
        """循环准备：施放一次琳奈 E。"""
        self._axis_wait_intro()
        return self._axis_resonance_once()

    def ylv_z_chain(self):
        """开局变奏：执行琳奈 Q/Z 及其完整后续动作。"""
        return self._axis_z_chain()

    def ylv_r_z_chain(self):
        """循环变奏：琳奈 R 后接同一套 Q/Z 后续动作。"""
        return self._axis_z_chain(with_r=True)

    def reset_state(self):
        super().reset_state()
        self._axis_chain_key = None
        self._axis_chain_progress = None
        self._axis_z_retryable = False
