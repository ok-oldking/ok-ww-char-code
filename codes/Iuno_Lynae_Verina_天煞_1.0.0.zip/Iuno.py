"""1.0.0 正式版：满链尤诺·琳奈·维里奈队伍轴。

队伍固定为满链尤诺、琳奈、维里奈。本模块协调换人、协奏检查和尤诺输出，
其他角色的动作由各自模块执行。启动时执行一次开局流程，之后持续循环至战斗结束
或动作确认失败；F 处决由尤诺接管。A 表示普攻，Z 表示长按普攻，E 表示共鸣技能，
R 表示共鸣解放，Q 表示声骸，跳跃使用框架键位。HUD 变化可确认输入被接受或状态
发生变化，不能证明伤害命中。技能在有界窗口内补按，确认发动后停止补按。
"""

import base64
import time
import zlib
from contextlib import contextmanager

import cv2
import numpy as np

from src.char.BaseChar import CharType, SwitchPriority
from src.char.Iuno import Iuno as BuiltinIuno


class Iuno(BuiltinIuno):
    AXIS_VERSION = "1.0.0"
    SWITCH_TRACE_THRESHOLD = 0.30
    F_INPUT_TIMEOUT = 5.0
    Z_PREPARE_ATTEMPTS = 2
    INPUT_INTERVAL = 0.12
    R_INPUT_TIMEOUT = 3.0
    R_RETURN_TIMEOUT = 7.0
    BOW_ENTRY_TIMEOUT = 3.0
    # 普攻窗口按两组 E 约 3.3 秒的间隔校准，技能推进仍以 HUD 确认为准。
    A12_TIME = 1.50
    A3_TIME = 0.95
    E_FIRST_ARROW_DELAY = 0.55
    E4_TAIL_TIME = 0.80
    E_READY_TIMEOUT = 2.0
    E_INPUT_TIMEOUT = 2.5
    RETARGET_A_TIMEOUT = 2.0
    E_MAX_INPUTS = 3
    E_SHORT_INPUT_WINDOW = 0.28
    DODGE_RECOVERY = 0.20
    SPECIAL_HEAVY_TIMEOUT = 2.0
    SPECIAL_HEAVY_RECOVERY = 2.5
    CONCERTO_WAIT = 1.2

    # require_con 是离场条件。E4 属于本轮尤诺，不是下轮额外的一发。
    OPENING = (
        ("Linnai", "ra", False),
        ("Verina", "er_jump_aaq", True),
        ("Linnai", "z_chain", True),
        ("Iuno", "burst", True),
    )
    LOOP = (
        ("Linnai", "e", False),
        ("Verina", "er_jump_aaq", True),
        ("Linnai", "r_z_chain", True),
        ("Iuno", "burst", True),
    )

    # 仅取数字区域，排除中央补充冷却倒计时。模板覆盖多种光照与动画
    # 背景；每项是 16x24 灰度图块，不是 OCR。
    E_CHARGE_BOX = (2116, 1236, 2132, 1260)
    E_CHARGE_MIN_SCORE = 0.80
    E_CHARGE_MIN_MARGIN = 0.12
    _E_CHARGE_TEMPLATES = None
    _E_CHARGE_PATCHES = (
        (0, (  # 720p 次数模板：剩余 0 次，背景样本一。
            'eNoVzGtPgmAAhuG/2NbWVmlTW6XzlCmGKIIVgmnO0tKUlKVNBTEJwlDRPGUtnLnWOn2sH9Lb8+3ant1LBnfkUlKV'
            'chKFAiGCXLeHTlm5JTJx1OvHCTJI0TWlLZWTRABGggdkvshLiiJVzkgE8gEPuyLP1pUmm4IdMPjPJ2K5yHZ6t3m/'
            'EwG9B5UvFTm1f1ciYDQUpkShztcFWRYqdOIAOFuUB+NOJc9wveYxTlAnjKrNunQ83XifnQPnKv2pppyQGfnnK4eH'
            'IxfscPp0Q+HZ9u8n8GH6aqCNWAyhO9+zDHC80JtOONiTV+ejFEYe7p91Xl4lyMF0H5UETkbdlKB93Ifx6/GwEQc2'
            'QEz/fVatam9DLga86kgJD49K63nCZwicjG3uROlSTRS57N4uglFHZieIHhcKCcxhhTAiYtxweiA4gPq9rh0YxUMr'
            '+vUts9lssdrsLp8f8S0u6QxGMJPJZPEi7u2FxWWdfk3/vw3It237A04o3uw='
        )),
        (0, (  # 720p 次数模板：剩余 0 次，背景样本二。
            'eNoBgAF//lpdYmZpamppaGNaU05JQ0BdYGZpbG1tbWxoX1lUTkhFZGdtcHJzdHV1cmpkXlhRTmtrbXJ7goaHhX1v'
            'Z2VhWlhybmZviJmjo5qJbmRpaWNhc3FsfJ6wsbGxoYBwcG5pZ250f5i/xq+vyMSki3pwbGpsepWy0cmcncrUu6CD'
            'cm5tbYOvy9a7eni20MiwinVwbnKMwNrZtGpmp8zVwZB2cW99lsje2rRvZ57H4tKVdXFwfJfL4deycGiYwubXlnRx'
            'cHCOyeDSrG5nlbze0ZV2cXBqiMTbzKdrZ5m/18ePcnBwaYS80cWgZWelydC5g2pucWh/q8LDqnh7tM3FqXllbnJp'
            'd5OuyMSjo8TKs5VvYm50Z29/lrbAtLS+t52DamRxeGJmbXqOnqusoZOAcmlqd35bXWFpdYSWmIh7cWtqb3h9UlZd'
            'ZGtxd3h0cW5tbnB0dUlNVl1hYmJjZWZnam9wbWs+Q01UVldXWFpbXGJsbWRfOT5JT1FRUlNVVldeamtfWYzSxHs='
        )),
        (0, (  # 720p 次数模板：剩余 0 次，背景样本三。
            'eNodx+lLwlAAAPC/K4iiIK0swYbmppt7T9+29zanw5m2opswu8guw6DMMuguDKJDSzuMDjuIqE8F/SFFv28/U5OV'
            'cjhphra3Nprqq6uaW9ocjJvlOIayWsx1NTaK5oAPiRLiaIet2eykXUDRo0ZU87EsQ9l41sEbY3PJyR7kgtDNQJ71'
            'T62uZdfnIxIWIe9BwfjBcWatcJoaDGHk5ZRY9rqQmC4+HC4YWECe8Erh/kAL7t5dbfXLkiD05SpPWz4+XX7Nx2RJ'
            '1OL5t+dtDJKlr8cJBUuh8dJHZZPAmcLP25RKsDJy+XmfxXA6//2SCCpEjhXfb9IIJi8+b8f8iqLGzirnKR5myk9H'
            'vQLxa8N7lxfZUGS3fL6qAxLQBxZzt6X0cr64MU44ould8aWTYm7/aCdhIKCGNb1zaDazvbk42oF9om4QJRDuHU0t'
            'DP8VEb2Tg0SLdPf1hAMyxrIapJyQqKpfxpKECREFk6XdA70QAgC8WPS4ahtstJv9ByTBZf8F7M+9Ng=='
        )),
        (1, (  # 720p 次数模板：剩余 1 次，背景样本一。
            'eNoNkMtKw0AAAL9UUNCDouADtbY0bUxMto3JZrPZdLPZJM2jrVBUSqviCwVFEbRFtF7EkwiCUMGDgl7MfMAwjFrR'
            'oYmQCaGha1VVqWgQWRbG2LIQNLTqpmHZNqFuBqWOjZFFaiyII+4FYeAz13EclrY726EXN5Io8KnL0oPLm/OtMGk0'
            '0qju8qj39P7xfNSM6mkjTVjQPHn9+fu42g55lCaxF7aOX75+R3fdkGbGgAdpr//2/Tno+sTzuef7fnO/Pxrddhh2'
            'Pca4R3nr7PXteociUqs5jNq15ODh6bxNdJRFuw4i8V7//nTL1gwIISUmSQ8fh6dNXN3McGyTJIfD4VFiVSoAAIJN'
            'O94fDPbqCCiyJGEL2uHu5UXbNVR5vVzKzmDe6u56UFMVqVTUdd10eByYQN2Qy/lVFVR1w0QQyJIo5BbmREkBQFVk'
            'sSQUcovTU4WiKK2LZaGwlltZmp0cz+WFckko5ldXlpfmZybG/gHFXejH'
        )),
        (1, (  # 720p 次数模板：剩余 1 次，背景样本二。
            'eNotj0tLAmEYRv9VmxZCRVFgmnbRWngbnfmcme8+zs1SC7SLJUoUhZbhToqgglZRVIsWRVBBFFhmUP2MxujdnWdz'
            'zhsSVEoJxpRSGJ/xuaMJxP+PgEhgXJS5YZjpWVM3dKrEI0mVm3ZueSmd0nWNKklZQVqmWNuaw5gwClVFUfXi3unh'
            'CldVwjCCEGYaF893ezmUpLxrQvPN2++3ozUGMGfOgDL1q5+v821dUjHpslU+/vi+3jUlGRKnDbF09bF9WbckIOMu'
            'I1K5f7/YsUQxiRnBENH1p87ZtvHHjhHxzZfP04omAoVwBFVi1lqdg0UiKYjr0Mkyq6/t/QIGiBuWE4y0jYfWSZkB'
            'zZ6dk52HeOn8prmKgJnNZrvSVL7eKFnxRDq/kAvHJMjsQsFGUdGetw1/IOp0MoYVSU5pIDbimQ6FozFBiCdEIEx5'
            '+4c8/vGJyalAMBic9A64XH3D7lGP1zvm8/vcg709vxeBtxQ='
        )),
        (2, (  # 720p 次数模板：剩余 2 次，背景样本一。
            'eNodkMtOwkAARf/dBQsXLEhc+ELQQkCKFfucTqeddtoZCm2H0gdK5VEjxpj4Dzbe3UnuzUnuRJRmqqapTeTn6Wj4'
            '1KBhmsAwdE2WHkcvsg4dFzu2ZZmGIk11gFw6Z9QnHkZAniHHYzHnSbSYU4I0xcbBgq+zbL3iEXOBhhw/jNOsyIsi'
            'XfoIwGa+5OvidVttYuogEyIvTNKyOtTvq7nnmBBiFq/K3cfpsA4JBqaFWcTL/efpmP0zclmUlrtjXTV9bELbo1G2'
            '2b4Vq0Zom5ZD6IKnaUwJoxhBC5OAUoKhrBKKLct2WZLGoY9UjQQ2RA7hx+9Tvc2WNPCggQnLvn5/TvsNDwnSFUKj'
            '/FBXRRL6GOozCZOQ53ky9xBo/hkPVdD4KLGBMpuOhZtLUVJ0ADRFmowH/etOWxiMJqLYwH2/e9k5b931HoThcCD0'
            'urdXF+3W2R+g1CAa'
        )),
        (2, (  # 720p 次数模板：剩余 2 次，背景样本二。
            'eNo1zEkvA1EAwPHv5ebEBYeGJjRpBUPzOpt5fbO8mXlj2s4MytCWaixNJmiLJnZBJRqCxnIREiTEwZIIn4FD/a7/'
            '5O8PUDTHc1AjCk91tjQFQmGaplkBq7IAutvb+sMMTfVF+KiIopDpDf4lCEViGpqEkAAGGA6Z015xec7VocCBMAON'
            'dHl/b2enkFQENgJoOVU8qKxtXJ55jsSxTATnSquLmaX7p62MxvM8kKeyhsC6d2/HefNvDUQ3SYd6hu8+T7x4FCEA'
            'bXsQcKnb18p8DElyBCYSSBotXF2vTBqSghlk2ZKzW6uWXaJirLKiPebMnl+V00TEmqpykjOzvHm0Ma4qiq5rGi+P'
            'eNWb2n7eHbVjhq4L6tjaw8/X+8v19kLSJASR1Prj98fH93PFc+NDRI5ly6e1w8OL6lI6aRmaoE3kS4VcrrA4YSUM'
            'cZCicdy2TNNKEIwhFewKAe4fQ3W0+vyhvrqeYEdzY5uvK1gX8Lc2NvwCcyjIqA=='
        )),
        (1, (  # 实战样本：1440p，1 层且处于补充冷却
            'eNotjstLQkEYxf+gbBGRVFC0qKhA6UFtIsJ2SorO45u56rXL9XGzq5ZlZIsoIoiIoEUtKrg9Fm2DFv0HQbsgKFCh'
            '6Rvt2wy/c4ZzzuBotfXzcrZXdQsZshwYC56qr+eTWmXDydumEZ66VJ/eYa1czNmWmUqK1d+P24OdynrOyqQMKYC/'
            'X9e3SsUsmhI443C16zqF7ObTsSEBEeplJ2sdNdUj/tW37eYKry2lHjhrX8mx374vmspjlKHNHHvtPA0N5RGqBZa3'
            'zLTkDXWPf7VvmUksQgYpNWfavchcSIFCCkcxqpkDVgKO5IxoxjgQ0pDy39eFIA3cyTuMiyimYgrmeRQfSinGAfCb'
            'u31CcUEiKjpC22M0FomA0AJgKIlHw4vjoQQqQkgg8Uhopt8/HFiJES4NHluaHunx9fYNDE0GZxfm5yb83V0+3x/2'
            '4sfa'
        )),
    )

    def is_c6(self):
        return True

    def get_char_type(self):
        return CharType.MAIN_DPS

    def reset_state(self):
        super().reset_state()
        self._ylv_state = None
        self._ylv_target = None
        self._ylv_r_claim = False

    def _state(self):
        # CharFactory 会复制原对象属性；状态版本不符时重置为开局，避免跨版本续接半轮。
        state = getattr(self, "_ylv_state", None)
        if not state or state.get("version") != self.AXIS_VERSION:
            self._ylv_state = dict(version=self.AXIS_VERSION, loop=False,
                                   step=0, done=False, round=0)
        return self._ylv_state

    def _members(self):
        chars = [c for c in self.task.chars if c is not None]
        members = {c.__class__.__name__: c for c in chars}
        if len(chars) != 3 or set(members) != {"Iuno", "Linnai", "Verina"}:
            self._abort("需要尤诺、琳奈、维里奈三人队伍")
        required = {"Linnai": ("ylv_ra", "ylv_z_chain", "ylv_r_z_chain", "ylv_e"),
                    "Verina": ("ylv_er_jump_aaq",)}
        for name, methods in required.items():
            if not all(callable(getattr(members[name], method, None)) for method in methods):
                self._abort("队伍代码版本不完整，请同时导入三人的 1.0.0 代码")
        return members

    def _abort(self, reason):
        self._ylv_target = None
        self.task.raise_not_in_combat("[月琳维轴] " + reason)
        raise RuntimeError(reason)

    def _fault(self, reason):
        state = self._state()
        if not state.get("fault"):
            state["fault"] = reason
            message = ("[月琳维轴] 自动战斗已关闭：" + reason
                       + "；修正后请重新开启“自动战斗”开关，再重新开场")
            self.logger.warning(message)
            notify = getattr(self.task, "log_error", None)
            if callable(notify):
                notify(message, notify=True)
        disable = getattr(self.task, "disable", None)
        if callable(disable):
            disable()
        # 执行器会终止当前任务并显示错误；不能返回自动战斗继续重复半段流程。
        raise RuntimeError("[月琳维轴] " + state["fault"])

    def _active(self, actor):
        visible, index, count = self.task.in_team()
        return visible and count == 3 and index == actor.index

    def _await_active(self, actor, timeout=0.8):
        """等待过渡中的 HUD 稳定；稳定前不发送输入。"""
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            self.task.next_frame()
            visible, index, count = self.task.in_team()
            if visible and count == 3:
                return index == actor.index
            actor.sleep(0.05, check_combat=False)
        return False

    def _tick(self, actor, duration=0.05, check_break=True):
        actor.check_combat()
        if check_break:
            self.task.check_f_break()
        actor.sleep(duration)
        self.task.next_frame()

    def _poll(self, actor, predicate, timeout, *, fill_a=False, label="状态等待"):
        if fill_a:
            return self._wait_with_normals(actor, predicate, timeout, label)
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if self._active(actor) and predicate():
                return True
            self._tick(actor)
        return self._active(actor) and bool(predicate())

    def _wait_with_normals(self, actor, predicate, timeout, label, confirm_frames=1):
        """仅在资源或就绪条件尚未满足时用有界 A 补充。

        已发送技能、动画、鼠标长按和切换确认不得调用此方法。条件检测后还要
        重新检查 HUD，因为检测器可能推进画面。
        """
        end = time.monotonic() + max(0.0, timeout)
        last_input = time.monotonic() - self.INPUT_INTERVAL
        presses = stable = 0
        while time.monotonic() < end:
            self.task.next_frame()
            visible, index, count = self.task.in_team()
            if not visible or count != 3:
                stable = 0
                actor.sleep(0.05, check_combat=False)
                continue
            if index != actor.index:
                return False
            actor.check_combat()
            ready = bool(predicate())
            visible, index, count = self.task.in_team()
            if not visible or count != 3:
                stable = 0
                actor.sleep(0.05, check_combat=False)
                continue
            if index != actor.index:
                return False
            if ready:
                stable += 1
                if stable >= confirm_frames:
                    if presses:
                        self.logger.info(f"[月琳维轴] {label}已确认，补 A 次数={presses}")
                    return True
            else:
                stable = 0
                now = time.monotonic()
                if now >= end:
                    break
                if now - last_input >= self.INPUT_INTERVAL:
                    if not presses:
                        self.logger.info(f"[月琳维轴] {label}未就绪，有界补 A，上限={timeout:.2f}秒")
                    actor.click(interval=0)
                    presses += 1
                    last_input = now
            actor.sleep(0.05)
        self.logger.warning(f"[月琳维轴] {label}补 A 超时，输入次数={presses}")
        return False

    @contextmanager
    def _retarget_normal_assist(self, actor):
        """保留原生锁敌与血条判定，只在允许普攻的阶段提供辅助。

        原生锁敌可能在可见 Boss 血条下等待较久，阻塞整条轴。每次锁敌最多
        两秒补 A，且不把补 A 视为锁敌成功；锁敌结果仍由原生逻辑决定。
        """
        task = self.task
        target_enemy = getattr(task, "target_enemy", None)
        if actor is not self or not callable(target_enemy):
            yield
            return
        had_target = "target_enemy" in task.__dict__
        saved_target = task.__dict__.get("target_enemy")

        def assisted_target(*args, **kwargs):
            middle_click = getattr(task, "middle_click", None)
            health = getattr(task, "check_health_bar", None)
            if not callable(middle_click) or not callable(health):
                return target_enemy(*args, **kwargs)
            had_middle = "middle_click" in task.__dict__
            saved_middle = task.__dict__.get("middle_click")
            started = time.monotonic()
            last_a = started - self.INPUT_INTERVAL
            presses = 0

            def middle_and_a(*mid_args, **mid_kwargs):
                nonlocal last_a, presses
                result = middle_click(*mid_args, **mid_kwargs)
                now = time.monotonic()
                if (now - started >= self.RETARGET_A_TIMEOUT
                        or now - last_a < self.INPUT_INTERVAL
                        or getattr(task, "in_liberation", False)
                        or getattr(task, "can_break", False)):
                    return result
                if not self._active(self) or not health():
                    return result
                # 检测器可能刷新画面；发送 A 前再次确认角色归属和时间上限。
                now = time.monotonic()
                if (now - started < self.RETARGET_A_TIMEOUT and self._active(self)
                        and not getattr(task, "in_liberation", False)
                        and not getattr(task, "can_break", False)):
                    self.click(interval=0)
                    last_a = now
                    presses += 1
                    if presses == 1:
                        self.logger.info("[月琳维轴] 尤诺锁敌恢复：保留中键寻敌，有界补 A（最多2秒）")
                return result

            task.middle_click = middle_and_a
            try:
                return target_enemy(*args, **kwargs)
            finally:
                if had_middle:
                    task.middle_click = saved_middle
                else:
                    delattr(task, "middle_click")
                self.logger.info(f"[月琳维轴] 尤诺锁敌恢复结束，补 A 次数={presses}，"
                                 f"锁敌耗时={time.monotonic() - started:.3f}秒")

        task.target_enemy = assisted_target
        try:
            yield
        finally:
            if had_target:
                task.target_enemy = saved_target
            else:
                delattr(task, "target_enemy")

    def _normals(self, actor, duration):
        with self._retarget_normal_assist(actor):
            start = time.time()
            deadline = time.monotonic() + duration + 3.0
            while actor.time_elapsed_accounting_for_freeze(start) < duration:
                if time.monotonic() >= deadline or not self._active(actor):
                    return False
                actor.click()
                self._tick(actor, 0.10)
            return True

    def _full_con(self, actor):
        if not self._active(actor) or not self.task.is_con_full():
            return False
        self._tick(actor)
        return self._active(actor) and bool(self.task.is_con_full())

    def _wait_con(self, actor):
        # 协奏不足时用有界 A 补齐；不伪造变奏入场状态。
        return self._poll(actor, lambda: self._full_con(actor), self.CONCERTO_WAIT,
                          fill_a=True, label=actor.name + " 协奏")

    def _switch_to(self, actor, target):
        if actor is target:
            return self._active(target)
        self._ylv_target = target.__class__.__name__
        # 原生换人循环会附送左键，破坏「变奏月直接 R」和 E4 收尾。
        # 保留其角色确认、协奏、buff、冻结时间，只在该同步调用内禁用附送 A。
        # 只观察框架原本会执行的调用；换人进行中不额外等待新帧，也不附送 A。
        task = self.task
        started = time.monotonic()
        saved = {}
        had_switch_f = "check_f_on_switch" in actor.__dict__
        previous_switch_f = actor.__dict__.get("check_f_on_switch")
        trace = dict(keys=0, first_key=None, last_key=None, max_gap=0.0,
                     f_keys=0, hud=[], hud_last=None, hud_changes=0,
                     f_time=0.0, combat_time=0.0, f_ok=0)
        outcome = "异常"

        def replace(name, method):
            saved[name] = (name in task.__dict__, task.__dict__.get(name))
            setattr(task, name, method)

        send_key = task.send_key
        in_team = task.in_team

        def observed_key(*args, **kwargs):
            key = args[0] if args else kwargs.get("key")
            now = time.monotonic() - started
            if str(key) == str(target.index + 1):
                trace["keys"] += 1
                if trace["first_key"] is None:
                    trace["first_key"] = now
                if trace["last_key"] is not None:
                    trace["max_gap"] = max(trace["max_gap"], now - trace["last_key"])
                trace["last_key"] = now
            elif str(key).lower() == "f":
                trace["f_keys"] += 1
            return send_key(*args, **kwargs)

        def observed_team(*args, **kwargs):
            result = in_team(*args, **kwargs)
            state = tuple(result)
            if state != trace["hud_last"]:
                trace["hud_last"] = state
                trace["hud_changes"] += 1
                trace["hud"].append((time.monotonic() - started, state))
                # 噪声 HUD 不得造成无界诊断输出。
                trace["hud"] = trace["hud"][-8:]
            return result

        def timed_call(method, field):
            depth = 0

            def observed(*args, **kwargs):
                nonlocal depth
                entered = time.monotonic()
                depth += 1
                try:
                    result = method(*args, **kwargs)
                    if field == "f_time" and result:
                        trace["f_ok"] += 1
                    return result
                finally:
                    depth -= 1
                    if depth == 0:
                        trace[field] += time.monotonic() - entered

            return observed

        try:
            # F 只由尤诺在进出场检查点接管。原生换人可能在切换前后调用离场角色
            # 的 F，因此不能让换人路径决定处决归属。
            actor.check_f_on_switch = False
            replace("click", lambda *args, **kwargs: None)
            replace("send_key", observed_key)
            replace("in_team", observed_team)
            for name, field in (("f_break", "f_time"), ("check_combat", "combat_time")):
                method = getattr(task, name, None)
                if callable(method):
                    replace(name, timed_call(method, field))
            actor.current_con = 0  # 让原生换人重新读取当前画面的协奏。
            actor.switch_next_char()
            confirmed = self._await_active(target) and target.is_current_char
            outcome = "完成" if confirmed else "未确认"
            return confirmed
        finally:
            if had_switch_f:
                actor.check_f_on_switch = previous_switch_f
            else:
                delattr(actor, "check_f_on_switch")
            for name, (had_value, previous) in reversed(tuple(saved.items())):
                if had_value:
                    setattr(task, name, previous)
                else:
                    delattr(task, name)
            self._ylv_target = None
            elapsed = time.monotonic() - started
            if elapsed >= self.SWITCH_TRACE_THRESHOLD or outcome != "完成":
                first = trace["first_key"]
                first_text = "未发送" if first is None else f"{first:.3f}秒"
                hud = ";".join(f"{at:.3f}:{int(bool(state[0]))}/{state[1]}/{state[2]}"
                               for at, state in trace["hud"])
                self.logger.info(
                    f"[月琳维轴] 切人诊断 {actor.name}->{target.name} 结果={outcome} "
                    f"总耗时={elapsed:.3f}秒 首次切人键={first_text} "
                    f"切人键次数={trace['keys']} 最大键间隔={trace['max_gap']:.3f}秒 "
                    f"F键次数={trace['f_keys']} F处理={trace['f_time']:.3f}秒 "
                    f"F返回成功={trace['f_ok']} 战斗检查={trace['combat_time']:.3f}秒 "
                    f"HUD变化={trace['hud_changes']} HUD末8次(秒:可见/索引/人数)=[{hud}]")

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        target = getattr(self, "_ylv_target", None)
        if target:
            return SwitchPriority.MUST if target == "Iuno" else SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def do_perform(self):
        return self.run_team_turn(self)

    def run_team_turn(self, actor):
        try:
            return self._run_team_turn(actor)
        except Exception as error:
            # 保留真实脱战/框架异常的传播；若框架再调用，也不重发半段技能。
            self._state().setdefault("fault", "框架异常：" + type(error).__name__)
            raise

    def _run_team_turn(self, actor):
        members = self._members()
        state = self._state()
        if state.get("fault"):
            return self._fault(state["fault"])
        if not self._await_active(actor):
            return self._fault("当前角色画面未确认")
        stages = self.LOOP if state["loop"] else self.OPENING
        name, action, require_con = stages[state["step"]]
        expected = members[name]
        if actor is not expected:
            if not self._switch_to(actor, expected):
                self._fault("切换到 " + name + " 未确认")
            return
        if not state["done"]:
            self.logger.info(f'[月琳维轴] 第{state["round"] + 1}轮 '
                             f'{"循环" if state["loop"] else "启动"} {name}.{action}')
            if not self._run_action(actor, action):
                if (action in {"z_chain", "r_z_chain"}
                        and getattr(actor, "_axis_z_retryable", False)):
                    attempts = state.get("z_prepare_failures", 0) + 1
                    state["z_prepare_failures"] = attempts
                    if attempts < self.Z_PREPARE_ATTEMPTS:
                        self.logger.warning("[月琳维轴] 琳奈 Z 未就绪，继续补 A 重试 1/1；R/Q 不重放")
                        self._tick(actor, 0.10)
                        return
                return self._fault(name + "." + action + " 未完成，未跳过此段")
            state["done"] = True
            state.pop("z_prepare_failures", None)
        if require_con and not self._wait_con(actor):
            return self._fault(name + " 离场前未满协奏，不能触发下一个变奏")

        next_step = state["step"] + 1
        next_loop = state["loop"]
        if next_step == len(stages):
            next_step, next_loop = 0, True
        target = members[(self.LOOP if next_loop else self.OPENING)[next_step][0]]
        if not self._switch_to(actor, target):
            return self._fault("切换到 " + target.__class__.__name__ + " 未确认")
        if require_con and not target.has_intro:
            return self._fault(target.__class__.__name__ + " 未确认变奏入场")
        if next_step == 0:
            state["round"] += 1
        state.update(loop=next_loop, step=next_step, done=False)

    def _run_action(self, actor, action):
        if action == "burst":
            self._ylv_r_claim = False
            return self._burst()
        return bool(getattr(actor, "ylv_" + action)())

    def _liberation_until_accepted(self, actor, min_wait=4.2, on_return_frame=None,
                                   on_animation_start=None):
        """在输入锁定期间重试 R，出现首次施放证据后停止补按。

        发送按键不等于技能已发动；检测到冷却或队伍 HUD 隐藏即可锁定接受状态，
        即使后续动画或冷却确认较慢，也禁止继续发送 R。
        """
        if not self.task.use_liberation or self.task.in_liberation:
            return False
        if not self._await_active(actor) or actor.has_cd("liberation"):
            return False
        actor.check_combat()
        started = time.monotonic()
        last_input = started - self.INPUT_INTERVAL
        accepted_at = None
        animated = False
        hidden_frames = 0
        stable = 0
        presses = 0
        while time.monotonic() - started < self.R_INPUT_TIMEOUT + self.R_RETURN_TIMEOUT:
            self.task.next_frame()
            visible, index, count = self.task.in_team()
            now = time.monotonic()
            if not visible:
                if self.task.find_feature("revive_confirm_hcenter_vcenter", threshold=0.8):
                    return False
                if not presses:
                    if now - started >= self.R_INPUT_TIMEOUT:
                        break
                    actor.sleep(0.05, check_combat=False)
                    continue
                if accepted_at is None:
                    accepted_at = now
                if not animated:
                    hidden_frames += 1
                    if on_animation_start is not None and hidden_frames < 2:
                        # 单帧 HUD 丢失不足以确认动画开始；保持 R 已接受状态，但
                        # 不在此时预按 Z。
                        actor.sleep(0.05, check_combat=False)
                        continue
                    self.task.in_liberation = True
                    try:
                        # 调用方负责鼠标清理；本方法负责维护动画标志，包括回调异常。
                        if on_animation_start is not None:
                            on_animation_start()
                        # HUD 隐藏后进入动画阶段，不再调用原生 R 连按。
                        if not actor.click_liberation(wait_if_cd_ready=0, click_f=False):
                            return False
                    finally:
                        self.task.in_liberation = False
                    animated = True
                # 若调用方提供回场回调，可立即使用下一帧 HUD；此处已经结束 R
                # 的原生等待。
                if on_return_frame is None:
                    actor.sleep(0.05, check_combat=False)
                continue
            hidden_frames = 0
            if count != 3:
                stable = 0
                actor.sleep(0.05, check_combat=False)
                continue
            if index != actor.index:
                return False
            cooldown = actor.has_cd("liberation")
            if not presses and cooldown:
                return False
            if presses and cooldown:
                if accepted_at is None:
                    accepted_at = now
                if animated or now - accepted_at >= min_wait:
                    if animated and on_return_frame is not None:
                        if not self._active(actor) or self.task.in_liberation:
                            return False
                        on_return_frame()
                        if not self._active(actor) or self.task.in_liberation:
                            return False
                    stable += 1
                    if stable >= 2:
                        if not animated:  # 有动画时已由原生等待流程记录发动时间。
                            actor.record_liberation_use()
                        self.task.in_liberation = False
                        self.logger.info(f"[月琳维轴] {actor.name} R 已确认，输入次数={presses}")
                        return True
            else:
                stable = 0
            if accepted_at is None:
                if now - started >= self.R_INPUT_TIMEOUT:
                    break
                if now - last_input >= self.INPUT_INTERVAL:
                    actor.send_liberation_key(interval=0, down_time=0.04)
                    presses += 1
                    last_input = now
            elif now - accepted_at >= self.R_RETURN_TIMEOUT:
                break
            actor.sleep(0.05, check_combat=False)
        self.logger.warning(f"[月琳维轴] {actor.name} R 未确认，输入次数={presses}，已检测发动={accepted_at is not None}")
        return False

    def _skill_until_cd(self, actor, skill, timeout=2.5, allow_icon_drop=False, on_frame=None):
        """重试 E/Q，并在 HUD 状态变化后记录一次施放。

        琳奈强化 E 没有数字冷却；只有调用方明确允许时，才可额外确认
        共鸣图标稳定消失。
        """
        if not self._await_active(actor) or actor.has_cd(skill):
            return False
        send = actor.send_resonance_key if skill == "resonance" else actor.send_echo_key
        record = actor.record_resonance_use if skill == "resonance" else actor.record_echo_use
        baseline = self.task.get_resonance_percentage() if allow_icon_drop else 0
        started = time.monotonic()
        last_input = started - self.INPUT_INTERVAL
        presses = stable = 0
        latched = False
        while time.monotonic() - started < timeout:
            self.task.next_frame()
            visible, index, count = self.task.in_team()
            if not visible or count != 3:
                stable = 0
                actor.sleep(0.05, check_combat=False)
                continue
            if index != actor.index:
                return False
            actor.check_combat()
            cooldown = actor.has_cd(skill)
            if not presses and cooldown:
                return False
            brightness = self.task.get_resonance_percentage() if allow_icon_drop else 0
            baseline = max(baseline, brightness)
            icon_gone = (allow_icon_drop and baseline >= 0.03
                         and brightness < baseline * 0.45)
            if not presses and icon_gone:
                return False
            if on_frame is not None:
                # 调用方可以在确认期间准备下一动作，但只能作用于同一名完整显示
                # 且仍归属当前控制器的角色。
                if not self._active(actor):
                    return False
                on_frame(bool(presses and (cooldown or icon_gone)))
                if not self._active(actor):
                    return False
            if presses and (cooldown or icon_gone):
                latched = True
                stable += 1
                if stable >= 2:
                    record()
                    self.logger.info(f"[月琳维轴] {actor.name} {skill} 已确认，输入次数={presses}，"
                                     f"确认耗时={time.monotonic() - started:.3f}秒")
                    return True
            else:
                stable = 0
            now = time.monotonic()
            if not latched and now - last_input >= self.INPUT_INTERVAL:
                send(interval=0, down_time=0.04)
                presses += 1
                last_input = now
            actor.sleep(0.05)
        self.logger.warning(f"[月琳维轴] {actor.name} {skill} 未确认，输入次数={presses}，"
                            f"确认耗时={time.monotonic() - started:.3f}秒")
        return False

    def _bow_e_charges(self):
        """只读取 0/1/2 层数徽标；含糊帧保持未知。

        技能中心的数字冷却即使在有可用层数时也可能表示补充计时，不能覆盖
        层数徽标的结果。
        """
        frame = self.task.frame
        if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
            return None
        box = self.task.box_of_screen_scaled(
            2560, 1440, *self.E_CHARGE_BOX, name="axis_iuno_e_charges", hcenter=True)
        crop = box.crop_frame(frame)
        if crop is None or not crop.size or min(crop.shape[:2]) < 4:
            return None
        gray = cv2.cvtColor(cv2.resize(crop[:, :, :3], (16, 24),
                                      interpolation=cv2.INTER_LINEAR), cv2.COLOR_BGR2GRAY)
        patch = gray.astype(np.float32)
        if float(patch.std()) < 6.0:
            return None
        patch -= patch.mean()
        patch /= np.linalg.norm(patch)
        cls = type(self)
        if cls._E_CHARGE_TEMPLATES is None:
            templates = []
            for number, encoded in self._E_CHARGE_PATCHES:
                template = np.frombuffer(zlib.decompress(base64.b64decode(encoded)),
                                         dtype=np.uint8).reshape(24, 16).astype(np.float32)
                template -= template.mean()
                template /= np.linalg.norm(template)
                templates.append((number, template))
            cls._E_CHARGE_TEMPLATES = tuple(templates)
        scores = [-1.0, -1.0, -1.0]
        for number, template in cls._E_CHARGE_TEMPLATES:
            scores[number] = max(scores[number], float(np.sum(patch * template)))
        order = sorted(range(3), key=lambda number: scores[number], reverse=True)
        best, second = order[:2]
        if (scores[best] < self.E_CHARGE_MIN_SCORE
                or scores[best] - scores[second] < self.E_CHARGE_MIN_MARGIN):
            return None
        return best

    def _wait_bow_e_charges(self, expected, number):
        with self._retarget_normal_assist(self):
            return self._wait_bow_e_charges_core(expected, number)

    def _wait_bow_e_charges_core(self, expected, number):
        """用有界 A 补齐资源；不可读徽标不当作零层。

        每次 E 的首次输入前，必须连续两帧读到预期次数。A 只能补足资源不足，不能修复
        不可读或隐藏的 HUD。
        """
        end = time.monotonic() + self.E_READY_TIMEOUT
        stable = normals = 0
        last_a = time.monotonic() - self.INPUT_INTERVAL
        last_charge = None
        while time.monotonic() < end:
            self.task.next_frame()
            visible, index, count = self.task.in_team()
            if not visible or count != 3:
                stable = 0
                self.sleep(0.05, check_combat=False)
                continue
            if index != self.index:
                return False
            self.check_combat()
            if not self._active(self):
                stable = 0
                continue
            last_charge = self._bow_e_charges()
            if last_charge == expected:
                stable += 1
                if stable >= 2:
                    return True
            else:
                stable = 0
                now = time.monotonic()
                if (last_charge is not None and last_charge < expected
                        and now < end and now - last_a >= self.INPUT_INTERVAL):
                    self.click(interval=0)
                    last_a = now
                    normals += 1
            self.sleep(0.05)
        self.logger.warning(f"[月琳维轴] E{number}/4 层数就绪超时，"
                            f"期望={expected}，末次={last_charge}，补 A 次数={normals}")
        return False

    def _e(self, number):
        # 每组 E 的层数按 2→1→0 消耗。中间的冷却数字可能只是补充计时，不能
        # 单独证明层数可用、施放已接受或资源已耗尽。
        before = 2 if number in (1, 3) else 1
        after = before - 1
        if not self._wait_bow_e_charges(before, number):
            return self._fault(f"尤诺 E{number}/4 未确认 {before} 层可用")
        started = time.monotonic()
        last_input = started - self.INPUT_INTERVAL
        first_input = None
        stable = presses = 0
        latched = False
        last_charge = before
        while time.monotonic() - started < self.E_INPUT_TIMEOUT:
            self.task.next_frame()
            visible, index, count = self.task.in_team()
            if not visible or count != 3:
                stable = 0
                self.sleep(0.05, check_combat=False)
                continue
            if index != self.index:
                return False
            self.check_combat()
            if not self._active(self):
                stable = 0
                continue
            last_charge = self._bow_e_charges()
            now = time.monotonic()
            if presses and last_charge is not None and last_charge < before:
                # 首次下降即锁定状态，即使下一帧 HUD 有噪声；确认阶段绝不消耗下一层。
                latched = True
                stable = stable + 1 if last_charge == after else 0
                if stable >= 2:
                    self.record_resonance_use()
                    self.logger.info(f"[月琳维轴] 尤诺 E{number}/4 层数确认 "
                                     f"{before}->{after}，输入次数={presses}，"
                                     f"确认耗时={now - started:.3f}秒（非命中确认）")
                    # 保留从最后一次输入开始计算的首箭保护时间；视觉确认已经占用
                    # 其中一部分，不再额外追加完整等待。
                    remaining = max(0.0, self.E_FIRST_ARROW_DELAY - (now - last_input))
                    self._tick(self, remaining, check_break=False)
                    return self._active(self)
            else:
                stable = 0
            if (not latched and last_charge == before
                    and presses < self.E_MAX_INPUTS
                    and (first_input is None
                         or now - first_input < self.E_SHORT_INPUT_WINDOW)
                    and now - last_input >= self.INPUT_INTERVAL
                    and now - started < self.E_INPUT_TIMEOUT):
                # 所有重试都限制在同一支箭的短输入窗口内；徽标延迟不能让较长的
                # 观察超时窗口变成第二支箭的连续 E 连按。
                self.send_resonance_key(interval=0, down_time=0.04)
                presses += 1
                last_input = now
                if first_input is None:
                    first_input = now
            # E 已发送或层数徽标不可读时，不再补 A。
            self.sleep(0.05)
        return self._fault(f"尤诺 E{number}/4 未确认层数 {before}->{after}，"
                           f"末次={last_charge}，输入次数={presses}，"
                           f"已见下降={latched}")

    def _cast_r_confirmed(self):
        if not self.task.use_liberation or getattr(self, "_ylv_r_claim", False):
            return False
        if self.task.in_liberation:
            return self._fault("入场前大招动画状态残留，未发送本次 R")
        if self.has_intro:
            # 可用图标可能先于变奏动作结束点亮；安静等入场，不能靠 A 取消。
            settle = max(0.9, self.intro_motion_freeze_duration) + 0.12
            entered = getattr(self, "last_switch_in_time", -1)
            if entered >= 0:
                settle -= max(0.0, time.time() - entered)
            until = time.monotonic() + max(0.0, settle)
            while time.monotonic() < until:
                self._tick(self)
        # 入场先确认 R 发动，再执行后续动作。
        self._ylv_r_claim = True
        if self._liberation_until_accepted(self):
            return True
        return self._fault("尤诺入场 R 连续补按后仍未确认，请查看 R 输入次数")

    def _dodge(self):
        self.check_combat()
        self.task.send_key(self.task.key_config.get("Dodge Key", "lshift"))
        self._tick(self, self.DODGE_RECOVERY)
        return self._active(self)

    def _echo(self):
        if not self._skill_until_cd(self, "echo"):
            return self._fault("尤诺 R 后 Q 连续补按后仍未确认")
        self._tick(self, 0.10)
        return self._active(self)

    def _heavy_visible(self):
        return bool(self.task.find_feature("iuno_heavy", box="box_extra_action", threshold=0.6))

    def _jump_visible(self):
        return bool(self.task.find_feature("iuno_jump", box="box_extra_action", threshold=0.6))

    def _enter_bow(self):
        """按原生转弓提示完成月弓入场，再进入弓轴。

        R 不会自动把尤诺变为月弓；仅在转弓提示存在时补按跳跃。
        本次已发送跳跃输入后，要求提示消失、同角色完整 HUD、连续两帧可读
        弓 E 的 0/1/2 次数，随后接 Q/A。
        发箭前另行确认 E 次数；本次未发送跳跃时，要求两次 E 作为保守入场条件。
        """
        if not self._await_active(self):
            return False
        started = time.monotonic()
        end = started + self.BOW_ENTRY_TIMEOUT
        last_jump = started - self.INPUT_INTERVAL
        clear_frames = presses = 0
        first_jump = prompt_gone = None
        last_charge = None
        charge_reads = {0: 0, 1: 0, 2: 0, None: 0}
        combat_time = 0.0
        while time.monotonic() < end:
            self.task.next_frame()
            visible, index, count = self.task.in_team()
            if not visible or count != 3:
                clear_frames = 0
                self.sleep(0.05, check_combat=False)
                continue
            if index != self.index:
                return False
            check_started = time.monotonic()
            self.check_combat()
            combat_time += time.monotonic() - check_started
            if not self._active(self):
                clear_frames = 0
                continue
            prompt = self._jump_visible()
            if not self._active(self):
                clear_frames = 0
                continue
            if prompt:
                clear_frames = 0
                now = time.monotonic()
                if now - last_jump >= self.INPUT_INTERVAL:
                    if first_jump is None:
                        first_jump = now
                        self.logger.info(f"[月琳维轴] 尤诺转弓首次跳输入，距检查开始={now - started:.3f}秒")
                    self.task.jump(after_sleep=0.02)
                    last_jump = now
                    presses += 1
            else:
                if presses and prompt_gone is None:
                    prompt_gone = time.monotonic()
                last_charge = self._bow_e_charges()
                if not self._active(self):
                    clear_frames = 0
                    continue
                charge_reads[last_charge if last_charge in (0, 1, 2) else None] += 1
                # 循环转弓可能只有一层 E；在形态确认阶段等待两层会拖慢 Q/A。
                # 未知徽标仍不能确认月弓形态。
                ready = last_charge in (0, 1, 2) and (presses > 0 or last_charge == 2)
                clear_frames = clear_frames + 1 if ready else 0
                if clear_frames >= 2:
                    now = time.monotonic()
                    after_jump = "无" if first_jump is None else f"{now - first_jump:.3f}"
                    after_prompt = "无" if prompt_gone is None else f"{now - prompt_gone:.3f}"
                    self.logger.info(
                        f"[月琳维轴] 尤诺月弓入场检查通过，转弓跳输入次数={presses}，"
                        f"总耗时={now - started:.3f}秒，跳后={after_jump}秒，"
                        f"提示消失后={after_prompt}秒，E次数={last_charge}，"
                        f"读数(0/1/2/未知)={charge_reads[0]}/{charge_reads[1]}/"
                        f"{charge_reads[2]}/{charge_reads[None]}，战斗检查={combat_time:.3f}秒")
                    return True
            self.sleep(0.05)
        self.logger.warning(
            f"[月琳维轴] 尤诺转月弓未确认，跳输入次数={presses}，E末值={last_charge}，"
            f"读数(0/1/2/未知)={charge_reads[0]}/{charge_reads[1]}/"
            f"{charge_reads[2]}/{charge_reads[None]}，战斗检查={combat_time:.3f}秒，未发送弓 E")
        return False

    def _heavy_ready(self):
        if not self._heavy_visible():
            return False
        self._tick(self)
        return self._active(self) and self._heavy_visible()

    def _heavy_gone(self):
        if not self._active(self) or self._heavy_visible():
            return False
        self._tick(self)
        return self._active(self) and not self._heavy_visible()

    def _recover_heavy_prompt(self):
        """用 A 补足 E2 后的满月提示，但不额外消耗 E。

        固定 A 窗口可能因敌人移动或受击导致普攻未命中；单纯等待无法补充资源。
        看到提示后立即停止连点，连续两帧确认当前角色和提示后才允许重击；
        HUD 缺失时不发送输入。
        """
        return self._wait_with_normals(self, self._heavy_visible,
                                       self.SPECIAL_HEAVY_RECOVERY,
                                       "E2 后满月恢复", confirm_frames=2)

    def _special_heavy(self):
        if not self._poll(self, self._heavy_ready, self.SPECIAL_HEAVY_TIMEOUT,
                          fill_a=True, label="E2 后满月"):
            if not self._recover_heavy_prompt():
                return self._fault("第二个 E 后补 A 仍未出现满月提示")
        # 重击输入也可能被前一段动画吞掉；仅在自身提示仍存在时重试，提示消失后
        # 绝不再次发送重击。
        for attempt in range(3):
            self.task.next_frame()
            if not self._active(self):
                return False
            if not self._heavy_visible():
                if attempt and self._heavy_gone():
                    self.last_heavy = time.time()
                    return True
                # 就绪后单帧漏检不应导致盲目长按，也不应立即放弃已恢复的提示。
                # 这里只做只读确认，不再追加 A 连点。
                if attempt or not self._poll(self, self._heavy_ready, 0.30):
                    return False
                if not self._active(self) or not self._heavy_visible():
                    return False
            gone_frames = 0
            started = time.monotonic()
            consumed = False
            try:
                self.task.mouse_down()
                while time.monotonic() - started < 0.80:
                    self._tick(self, 0.05, check_break=False)
                    if not self._active(self):
                        return False
                    if time.monotonic() - started >= 0.25 and not self._heavy_visible():
                        gone_frames += 1
                        if gone_frames >= 2:
                            consumed = True
                            break
                    else:
                        gone_frames = 0
            finally:
                self.task.mouse_up()
            if consumed or self._poll(self, self._heavy_gone, 0.30):
                self.last_heavy = time.time()
                self.logger.info(f"[月琳维轴] 满月 Z 已确认；位置=E2 之后，输入次数={attempt + 1}")
                return True
            self._tick(self, 0.08, check_break=False)
        return self._fault("第二个 E 后满月连续输入后仍未确认消耗")

    def _axis_iuno_f_break(self, label):
        """仅由已确认在场的尤诺执行 F 处决。

        保留原生 0.5～5 秒输入窗口；F 期间不夹普攻，换人时不发送 F。没有
        处决提示时立即返回，不增加等待。
        """
        if not (self.task.check_f_break() or getattr(self.task, "can_break", False)):
            return True
        started = time.monotonic()
        last_input = started - self.INPUT_INTERVAL
        presses = 0
        self.logger.info(f"[月琳维轴] 尤诺 {label} 接管 F 处决")
        while time.monotonic() - started < self.F_INPUT_TIMEOUT:
            self.task.next_frame()
            visible, index, count = self.task.in_team()
            if not visible or count != 3:
                self.sleep(0.05, check_combat=False)
                continue
            if index != self.index:
                self.logger.warning("[月琳维轴] F 期间角色已变化，停止 F 输入")
                return False
            self.check_combat()
            now = time.monotonic()
            pending = self.task.check_f_break() or getattr(self.task, "can_break", False)
            if presses and now - started >= 0.5 and not pending:
                self.logger.info(f"[月琳维轴] 尤诺 {label} F 窗口结束，输入次数={presses}")
                return True
            # 战斗或提示检测可能刷新画面；唯一的 F 输入前立即再次确认角色归属。
            if not self._active(self):
                self.sleep(0.05, check_combat=False)
                continue
            if now - started >= self.F_INPUT_TIMEOUT:
                break
            if now - last_input >= self.INPUT_INTERVAL:
                self.task.send_key("f", down_time=0.04)
                self.task.can_break = False
                presses += 1
                last_input = now
            self.sleep(0.05, check_combat=False)
        self.logger.warning(f"[月琳维轴] 尤诺 {label} F 达到有界窗口，输入次数={presses}")
        return self._active(self)

    def _burst(self):
        if not self._axis_iuno_f_break("入场"):
            return False
        if not self._cast_r_confirmed():
            return False
        if not self._enter_bow():
            return self._fault("尤诺 R 后未完成转月弓，不能执行弓轴")
        if not self._echo():
            return False
        for number in range(1, 5):
            if not self._normals(self, self.A12_TIME) or not self._e(number):
                return False
            if number == 2 and not self._special_heavy():
                return False
            if number < 4:
                # E2 后允许 A 与满月收尾重叠，按校准窗口衔接 E3，不等待全部特效结束。
                if not self._normals(self, self.A3_TIME) or not self._dodge():
                    return False
        # E4 保留箭与多段伤害的收尾时间，不追加 A3 或闪避。
        end = time.monotonic() + self.E4_TAIL_TIME
        while time.monotonic() < end:
            if not self._active(self):
                return False
            self._tick(self, check_break=False)
        return self._active(self) and self._axis_iuno_f_break("E4 收尾")

    def on_combat_end(self, chars):
        self._ylv_state = None
        self._ylv_target = None
        self._ylv_r_claim = False
