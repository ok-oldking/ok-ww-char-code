import base64
import ctypes
import threading
import time

import cv2
import numpy as np

from src.char.BaseChar import SwitchPriority
from src.char.Hsin import Hsin as NativeHsin

# 卜灵的卦象判据要用 ok-ww 的模板(Labels.douling_gen/douling_zhen)和卦象裁剪函数。
# 这版 ok-ww 没有就整个退回框架的 mouse_forte(重击位)判, 再不行当"能用", 不影响其它段。
try:
    from src.Labels import Labels as _Labels
    from src.task.BaseWWTask import isolate_gua_strokes as _isolate_gua_strokes
    _GUA_AVAILABLE = all(hasattr(_Labels, n) for n in ('douling_gen', 'douling_zhen'))
except Exception:
    _Labels = None
    _isolate_gua_strokes = None
    _GUA_AVAILABLE = False


# ==================== 物理 F 键监视 ====================
# 跟 Iuno__JingRan__ShoreKeeper/JingRan.py 里那份逐字相同, 说明见 Chisa__Suisui__YangYangSp/YangYangSp.py。
F_VK = 0x46              # 'F'
F_POLL_INTERVAL = 0.05
F_LOG_DEBOUNCE = 1.0
F_TASK_NAME = 'FStartCombatTask'


def f_settings(task):
    """读界面上的(开关, F 之后等待秒数)。没装那张卡片就返回默认值(开, 0 秒)。"""
    executor = getattr(task, 'executor', None)
    for group in ('trigger_tasks', 'onetime_tasks'):
        for other in getattr(executor, group, None) or ():
            if type(other).__name__ == F_TASK_NAME:
                try:
                    return bool(other.enabled), float(getattr(other, 'f_start_delay', 0) or 0)
                except Exception:
                    return True, 0.0
    return True, 0.0


# ==================== 自动战斗开关监视 ====================
# 【玩家手动开关自动战斗, 必须从启动轴重跑】。手动停任务不走 combat_end(), opener_armed 会跨局留在
# False, 而角色对象常被粘性复用、reset_state() 不跑。只有独立线程能观察到 enabled 的 True->False->True。
ENABLE_POLL_INTERVAL = 0.2


def start_enable_watch(task, logger=None):
    """盯 task.enabled 的 False->True 跳变, 把时刻记到 task._ww_task_restarted_at。每个 task 只启一次。"""
    if getattr(task, '_ww_enable_watch_started', False):
        return
    task._ww_enable_watch_started = True
    if not hasattr(task, '_ww_task_restarted_at'):
        task._ww_task_restarted_at = -1

    def watch():
        was_on = None
        while True:
            try:
                now_on = bool(getattr(task, 'enabled', False))
                if was_on is False and now_on:
                    task._ww_task_restarted_at = time.time()
                    if logger:
                        logger.info('auto combat re-enabled -> opener re-armed')
                was_on = now_on
                time.sleep(ENABLE_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='ok_ww_enable_watch', daemon=True).start()


def start_f_watch(task, logger=None):
    """把【物理】F 键按下的墙钟时间记到 task._f_last_press。每个 task 只启一次。"""
    if getattr(task, '_f_watch_started', False):
        return
    task._f_watch_started = True
    if not hasattr(task, '_f_last_press'):
        task._f_last_press = -1

    def watch():
        try:
            user32 = ctypes.windll.user32
            user32.GetAsyncKeyState.restype = ctypes.c_short
        except Exception as e:
            task._f_watch_started = False
            if logger:
                logger.error(f'f watch: GetAsyncKeyState unavailable ({e}), '
                             f'the "press F to re-arm the opener" shortcut stays off')
            return
        last_log = 0
        was_down = False
        while True:
            try:
                down = bool(user32.GetAsyncKeyState(F_VK) & 0x8000)
                if down and not was_down and f_settings(task)[0]:
                    now = time.time()
                    # 宏正在跑 = 正在战斗, 这下 F 是玩家手动处决, 不是重开副本
                    if (getattr(task, '_three_fire_macro_busy', False)
                            or getattr(task, '_ww_macro_busy', False)):
                        if logger and now - last_log >= F_LOG_DEBOUNCE:
                            last_log = now
                            logger.info('physical F pressed while the macro is running '
                                        '(manual execution) - opener NOT re-armed')
                        was_down = down
                        time.sleep(F_POLL_INTERVAL)
                        continue
                    task._f_last_press = now
                    task._f_pressed_at = now
                    if logger and now - last_log >= F_LOG_DEBOUNCE:
                        last_log = now
                        logger.info('physical F pressed, opener re-armed')
                was_down = down
                time.sleep(F_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='ok_ww_f_watch', daemon=True).start()


# ==================== SendInput 左键(心的两段长按用) ====================
_INPUT_MOUSE = 0
_MOUSEEVENTF_LEFTDOWN = 0x0002
_MOUSEEVENTF_LEFTUP = 0x0004


class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [('wVk', ctypes.c_ushort), ('wScan', ctypes.c_ushort), ('dwFlags', ctypes.c_ulong),
                ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [('dx', ctypes.c_long), ('dy', ctypes.c_long), ('mouseData', ctypes.c_ulong),
                ('dwFlags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class _HARDWAREINPUT(ctypes.Structure):
    _fields_ = [('uMsg', ctypes.c_ulong), ('wParamH', ctypes.c_ushort), ('wParamL', ctypes.c_ushort)]


class _INPUTUNION(ctypes.Union):
    _fields_ = [('ki', _KEYBDINPUT), ('mi', _MOUSEINPUT), ('hi', _HARDWAREINPUT)]


class _INPUT(ctypes.Structure):
    _fields_ = [('type', ctypes.c_ulong), ('u', _INPUTUNION)]


def send_input_left(up):
    """系统级左键按下/抬起。返回是否发出去了(发不出去调用方退回 PostMessage)。"""
    try:
        inp = _INPUT(type=_INPUT_MOUSE)
        inp.u.mi = _MOUSEINPUT(0, 0, 0, _MOUSEEVENTF_LEFTUP if up else _MOUSEEVENTF_LEFTDOWN, 0, 0)
        return ctypes.windll.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT)) == 1
    except Exception:
        return False


class MacroBroken(Exception):
    """某一步切人没成功 / HUD 长时间不在, 后面的按键会落在错的人身上 —— 整圈放弃, 交回框架。"""


class Hsin(NativeHsin):
    """心。心锁卜(心 / 锁暝 / 卜灵)里她兼任【整条轴的持宏者】, 三个人的 do_perform 都转到 drive()。

    ================= 队伍 =================
    心(Hsin) + 锁暝(Suoming) + 卜灵(Douling)。卜灵在 ok-ww 里的类名是 Douling, 有的版本叫 Buling, 两个都认。
    轴沿用 10-25 定稿的【轮切轴(LQ)】: 一圈四次切人, 守岸人换成卜灵; 心、锁暝两段原样搬过来,
    卜灵那一段按她自己的机制重写 —— 她的资源是【卦象】, 增强重击吃 2 个卦象, 不够按出来是谬门占卜(自伤)。

    ================= 轴的形状 =================
    启动轴: 卜 3A-E-2A-[卦象>=2 增强重击]-R-演完 -> 协奏补满 + Q -> 变奏锁暝 (seg_lq_dl_open)
    循环轴: 卜(变奏入场) 3A-E-2A-[增强重击]-[有处决提示就处决]-Q-R
            -> R 前协奏够就演出里切锁暝, 不够演完补满再变奏 (seg_lq_dl)
    之后两条一样:
      锁暝 (变奏·闪裂, 念起 -> 念深) [R 在 CD 上就边 A 边等] R -> 演完 -> 点一下 A -> Q(暗鸟) -> 同奏切心 (seg_lq_so_a)
      心   (变奏·应世相) 声骸 -> 花图标亮了就按住 -> 步红尘 -> 转相 -> 演完照世相 E -> 同奏切锁暝 (seg_xn1)
      锁暝 (旋雷破·同奏 +200 妄执) 点 A 到妄执满 -> 点 E(无舍念) -> 按住刻心念 -> 协奏满变奏心 (seg_lq_so_b)
           【协奏不满不切】: 接着 A, 妄执满了再出无舍念/刻心念, 光圈出来才变奏心 (so_ensure_intro)
      心   (变奏·照世相, 统御众机) A 到第 5 颗雕像 -> 闪避 -> A 到第 7 颗 -> 按住(临寰宇) -> 万阙垂天
           -> 白屏时停里连按 E -> 协奏满变奏卜 (seg_xn2)
    宏在【卜灵变奏入场、HUD 回来】时返回, 下一次框架调的就是她。

    ================= 卜灵为什么这么打 =================
    - 她在一圈里的位置跟守岸人一样: 头尾各一次, 进场都是变奏入场(协奏满切人), 走之前要把协奏打到真满,
      让锁暝变奏入场 —— 锁暝要变奏·闪裂才从念起进念深, 念深才解锁 R, 心才拿得到同奏。
    - 她的输出窗口是【E 拿卦象 -> 增强重击(按住普攻)吃掉 2 个卦象】。普攻/E/重击/声骸/大都给协奏,
      所以 3A-E-2A-重击 这一段既是伤害也是攒协奏; R 之后不够就 dl_ensure_con 里 A/E/重击补。
    - 【卦象不够绝不按增强重击】: 只有 1 个卦象时按住 = 谬门占卜(自伤, 没伤害), 白给。判据 dl_gua_ready:
      连续 2 帧读到 >= 2 个卦象才按; 读不出卦象(模板不对/版本不支持)退回框架 mouse_forte(重击位)判。
    - 处决(F 提示)放在增强重击之后、Q 之前: 重击出了伤才脱手, 早按会把这一刀打断(同守岸人那套)。
    - R 的时机跟守岸人一样: 先 Q(声骸) 再 R; R 之前协奏 >= DL_R_EARLY_CON 就在演出白闪后切锁暝,
      不够就等演完补满再变奏。
    - 【R 只认"亮才放"】: 开战/刚复活时大招能量常常是空的, 站场攒能量等于白打十几秒。
      所以卜灵两段、锁暝第一段都是"R 亮就放, 不亮 1~3s 内跳过"(try_r_quick / LQ_SO_R_CAP),
      少一发 R 让轴先转起来; 顺带锁暝 R 没出时心1 会拿不到同奏, 这时心1/心2 走"没变奏"降级路径
      (普攻攒一点就交棒), 不去硬补应世心 / 硬等雕像 —— 否则又是十几秒空转。

    ================= 心 / 锁暝的判据(原样保留, 别改) =================
    - 应世心条: 回路条徽记两边紫色格子; 【满 = 重击位 hsin_h1 花图标】, 满了条变粉红高柱, 紫色判据不能用。
    - 步红尘出手 = 应世心清空; 转相解锁 = 清空后 1.86~2.06s。不认图标, 松手就连按 R(没解锁按 R 没反应)。
    - 照世相里 R 一直是亮的(借相·应世), 万阙垂天【只能认 hsin_lib2】; 统御众机重击位认 XN_TY / XN_READY。
    - 锁暝: 妄执满 = 框架的 suoming_forte_e; R 一演完就切(同奏只有 5 秒); 妄执条读数被特效污染, 只进日志。
    - 协奏真满看头像光圈(GLOW_*): 读数快满就报 1.00, 光圈跟真满同一帧出来。

    ================= 改这个文件之前先读 =================
    - 引擎那一半(macro_* / quick_switch / press_key_until_cd / fire_r / switch_to_dl ...)是实机标定过的;
      心、锁暝两段是从心锁守 v1.1.0 原样搬的, 动它们之前先看注释。
    - 【三个成员的文件必须内容相同】: ok-ww 的自定义队伍是【按成员分别加载代码】的 —— 在场的是谁,
      就调谁那个类的 do_perform。所以 Hsin.py / Suoming.py / Douling.py 三份是同一段宏, 只是基类和类名不同;
      只改一份 = 另外两个人上场后跑内置轴(表现就是"不切心, 锁暝/卜灵各打各的")。
    - 【心那几段用真的心对象】(run_cycle 里的 xn): 技能栏图标/CD/重击位按角色 index 读, 不能拿驱动者顶替。
    - 【自定义 __init__ 里跟内置版不同的字段会被打回内置值】, 要保住就在 reset_state() 里重申。
    - 普攻一律走 tap()(按住 A_TAP 秒): task.click() 只按 10ms, 打不出来。
    - 长按期间不调 click()/mouse_down()/send_key() —— 它们先投 WM_ACTIVATE, 会把按住打断。
    - 【被控制 / 怪跑太远会"卡住"】: 按键全被吞时各段自己的上限照样耗满, 所以有 watchdog():
        macro_wait 每 0.1s 采一次(HUD 在不在 / 场上是谁 / 协奏读数), 8s 没变化或一圈超 70s 就整圈放弃,
        perform_* 里 note_broken() 记连败并给 drive 一个递增冷却(冷却期一下都不按, 让框架走位/等控制结束);
        正常跑完一圈 note_ok() 清零。改窗口/循环时别把 watchdog 的调用点删了。
    - 卜灵的节奏(3A / E / 增强重击 / R 演出)是拿守岸人那套先摆的, 必须实机对表再调 DL_* 常量;
      卦象框 DL_GUA_BOX 跟 ok-ww Douling.gua() 同一个框, 分辨率/缩放不对就只认 mouse_forte 那条兜底。
    """

    # ==================== 全局节奏(引擎用) ====================
    A_INTERVAL = 0.12
    KEY_INTERVAL = 0.10
    A_TAP = 0.06                 # 普攻按住这么久才算一下; task.click() 的 10ms 会被吞

    # ---- 切人 ----
    SWITCH_TIME_OUT = 2.5
    SWITCH_KEY_DOWN_TIME = 0.02
    SWITCH_KEY_INTERVAL = 0.0
    UNTRUSTED_CONFIRM = 3
    TRACE_SWITCH = True

    # ---- 大招 / 演出 ----
    LIB_KEY_INTERVAL = 0.03
    LIB_ANIM_TIME_OUT = 8.0
    HUD_NO_ANIM_GRACE = 0.35
    LIB_GONE_CONFIRM = 3         # HUD 连续这么多帧不在 = 演出真的开始了
    HUD_UP_CAP = 1.0             # 按 R 之前等 HUD 在场的上限(防假成功)
    HUD_BACK_CONFIRM = 2         # 等"HUD 回来"要连读到这么多帧(演出中途会闪一两帧)

    # ---- 杂项 ----
    CON_SAMPLE_MAX = 24
    FIELD_SETTLE_TIME_OUT = 1.5
    E_RESEND_STEP = 0.06
    SKILL_BAR_SETTLE = 0.40      # 刚切进来多久没见过技能亮就当它在 CD 上

    # ==================== 防重入 ====================
    OPENER_MIN_GAP = 60.0

    # ==================== 队伍成员类名 ====================
    # ok-ww 的叫法在版本之间变过: 主仓是 Douling, 也有版本叫 Buling, 两个都认
    DL_NAMES = ('Douling', 'Buling')

    # ==================== 卜灵(Douling) ====================
    # 资源 = 卦象: E 给卦象, 增强重击(按住普攻)吃 2 个; 不够按住是谬门占卜(自伤), 所以只认 >= DL_GUA_MIN。
    DL_GUA_READ = True
    DL_GUA_MIN = 2
    DL_GUA_CONFIRM = 2
    DL_GUA_WAIT = 0.80           # E 出手后等卦象到账的上限(到点不够就不按重击)
    DL_GUA_BOX = (1664, 1776, 2138, 1869)   # 技能栏上方那一排卦象(4K, hcenter)
    DL_GUA_THRESHOLD = 0.65
    DL_HEAVY_HOLD = 1.10         # 增强重击按住时长(卜灵重击是长按派生); 读不到卦象时也按这么久
    DL_HEAVY_CAP = 1.80          # 长按硬上限
    DL_E_CD = 8.0                # 卜灵 E 冷却(补协奏/攒能量按上次放 E 的时间算, 技能栏 CD 兜底)
    DL_E_CAP = 0.60              # E 按到进 CD 的上限
    DL_E_DERIVE = 0.40           # E 之后接普攻的间隔
    DL_A3_WINDOW = 1.38          # 第一组三段普攻
    DL_E_TO_HEAVY = 1.43         # 从按下 E 起算的增强重击时刻
    DL_Q_PRESSES = 2
    DL_Q_WINDOW = 0.15
    DL_R_RESCUE = 1.80           # 补按 R 的窗口
    DL_R_ANIM_MIN = 2.40         # 卜灵大招藏 HUD 的时长(实机对表)
    DL_R_ANIM_CAP = 6.00
    DL_R_SWITCH_FROM = 1.70      # 演出白闪后开始连发切人键的时刻
    DL_R_EARLY_CON = 0.90        # R 之前协奏 >= 这个就演出里切锁暝(R 自己不给协奏的话演完也还是满的)
    DL_R_TOPUP_CAP = 1.80        # R 之前协奏不够时补普攻的上限
    DL_CON_READ = 0.25           # 交棒前读协奏的结算窗口
    DL_CON_ENOUGH = 1.0          # 0.99 是环没闭合的哨兵值, 要真满
    DL_CON_FULL_CONFIRM = 3
    DL_CON_POLL = 0.03
    DL_CON_RESCUE_CAP = 4.0      # 补协奏的上限
    DL_CON_READ_GRACE = 1.50     # 光圈认不出时: 读数满了再等这么久才信读数
    # 注: 卜灵两段的 R 都是"亮才放、不亮跳过"(try_r_quick), 不再设"攒能量硬放"的上限。
    #     真需要硬放 R 的段可以调 ensure_r(..., cap, build) —— 那是"只花时间"的保底, 别放在开局。
    DL_HEAVY_RETRIES = 1
    LQ_DL_GLOW_ONLY = True       # 交棒只认光圈(读数快满就报 1.00, 坑过好几次)

    # ---- 处决(F 提示) ----
    DL_BREAK = True
    DL_BREAK_UNTIL = 1.20        # 守a 起这么久之内盯提示
    DL_BREAK_AFTER_HEAVY = 0.40  # 强化重击出伤之后再按 F(早按会把这一刀打断)
    BREAK_READS = 3
    BREAK_CENTER_MIN = 0.90      # 屏幕中间的 F 提示
    BREAK_RING_MIN = 0.92        # boss 头像外圈满(框架 check_f_break 同一个阈值)
    BREAK_SEEN_FRESH = 5.00      # 切卜灵之前在心身上读到的提示, 到卜灵 HUD 回来这么久之内算数
    BREAK_RESEND = 0.30          # 按完这么久提示还在 = 被吞了, 再按
    BREAK_PRESSES = 5
    BREAK_GONE_FRAMES = 3        # 提示连这么多帧不见才算处决起手了
    BREAK_ANIM = 1.55            # 谐度破坏派生动画
    BREAK_ROUNDS = 2

    # ---- 切给卜灵 / 卜灵变奏入场 ----
    DL_INTRO_ANIM_CAP = 6.0
    DL_INTRO_NOANIM = 0.35
    DL_SWITCH_ANIM_HINT = 1.00   # quick_switch 超过这么久才判到场 = 强化变奏的演出已经在里面演完
    DL_TO_TIME_OUT = 4.00        # 心 -> 卜灵: 万阙垂天收招没完游戏不放人

    # ==================== 保底 ====================
    # 原则: 只花时间的保底默认开(切人重试 / 等 HUD / 判据没成立就再按那一个本该出去的键);
    # 会改状态的只在判据明确说"这一下没出去"时才补, 不凭猜测多按
    SWITCH_RETRIES = 2
    SWITCH_RETRY_TIME_OUT = 3.00
    HUD_LOST_ABORT = 8.00        # 队伍 HUD 连续这么久没见过 = 关卡结束/过场/窗口没了, 整圈放弃
    DRIVE_HUD_CAP = 1.50         # 框架调进来时 HUD 这么久都不在就什么都不做
    R_TRIES = 3                  # R 亮着但没放出去就再按, 最多这么多次
    R_BLIND_EVERY = 3            # R 读成暗时每这么多轮攒能量盲按一次
    R_BLIND_WINDOW = 0.40
    R_BUILD_SLICE = 0.60         # 攒能量每轮的连点时长

    # ==================== 健壮性(被控制 / 怪跑远 / 打不到) ====================
    # 被控制、被击飞、怪跑太远时按键全被吞, 而各段自己的上限是给"正常但慢"留的(最长 15s),
    # 光靠它们会白打一分钟才放弃, 然后立刻重来 —— 表现就是"卡住"。这里加三道闸:
    #   1) 一圈总预算; 2) 没进展检测(打不到怪); 3) 断轴冷却(冷却期内一下都不按, 让框架走位/等控制结束)
    MACRO_CYCLE_CAP = 70.0       # 一圈的总预算(冻结时间校正); 超了整圈放弃
    MACRO_STALL_SEC = 8.0        # HUD 在场但协奏/场上角色连续这么久没变化 = 打不到怪/被控制 -> 整圈放弃
    MACRO_STALL_POLL = 0.5       # 进展信号采样间隔
    BROKEN_BACKOFF_BASE = 1.2    # 断轴后这么久不按任何键, 按连败次数递增
    BROKEN_BACKOFF_MAX = 6.0
    NO_ENEMY_WAIT = 0.25         # 没读到怪时交回框架, 隔这么久再试(避免空转)
    NO_ENEMY_YIELD = 6           # 连续这么多次读不到怪就先让位; 再多就认为这关识别不了, 照常跑

    # ---- 协奏真满看头像光圈 ----
    GLOW_BOTH = 0.15             # 两格都 >= 这个, 而且有一格 >= GLOW_ONE
    GLOW_ONE = 0.35
    GLOW_SOLO = 0.60             # 一格就够
    GLOW_CONFIRM = 2

    # ==================== 心 ====================
    # ---- 应世心条(4K 坐标, hcenter): 回路条中间徽记左右两半的紫色格子 ----
    XN_GAUGE_L = (1627, 1999, 1837, 2011)
    XN_GAUGE_R = (1965, 1999, 2175, 2011)
    XN_GAUGE_VALID = 0.50        # 左半 >= 这个才算"在应世相、读数可信"
    XN_YING_READY = 0.70         # 右半到这么多就按重击
    XN_YING_LATE = 0.58          # 到 XN1_LATE_AT 右半 >= 这个也按(差的那截普通重击能补上)
    XN_CONSUMED = 0.15           # 按住之后左半掉到这个以下 = 整条清空 = 步红尘出手
    XN_FULL_THRESHOLD = 0.70     # 应世心满 = hsin_h1 花图标
    XN_HOLD_SENDINPUT = True     # 心的两段长按走 SendInput(前台时); PostMessage 的按下沿会被吞

    # ---- 第一段(变奏·应世相): 声骸 -> 花图标亮了就按住 -> 步红尘 -> R 转相 -> 照世相 E -> 切锁暝 ----
    XN1_SKIP_A_WHEN_FULL = True  # 上场就满(6 链)可以不打的 A 直接按住, 省 ~1.3s
    XN1_FULL_FROM = 0.20
    XN1_FULL_HOLD_AT = 0.50
    XN1_ENTRY_TAP_FROM = 0.70
    XN1_A1_AT = 1.05             # 从按切人键起算(不跳过 A 时)
    XN1_A_HOLD = 0.08
    XN1_TAP_EVERY = 0.25
    XN1_MIN_A = 2
    XN1_LATE_AT = 2.15
    XN1_BLIND_AT = 2.15
    XN1_FILL_CAP = 4.00
    XN1_FILL_EVERY = 0.40
    XN1_GAUGE_CONFIRM = 2
    XN1_HOLD_NOT_BEFORE = 1.50
    XN1_HOLD = 1.80              # 按住时长(宏表)。步红尘免疫打断, 演出里一直按着没有坏处
    XN1_RETRIES = 2
    XN1_RETRY_A = 2
    XN1_STALE_MIN = 0.95
    XN1_STALE_FULL = 0.45
    XN1_STALE_MAX = 1
    XN1_R1_SPAM = 2.50           # 松手就连按 R 到演出出来的窗口
    XN1_R1_UNLOCK = 2.06         # 清空后解锁时刻(补救用)
    XN1_R1_MARGIN = 0.08
    XN1_R1_READS = 2
    XN_R_WINDOW = 1.50           # R 连按到 HUD 消失的窗口
    XN1_ECHO = False             # 转相前不放声骸(声骸留给心1 进场)
    XN1_R1_RESCUE_CAP = 6.00     # 转相补救上限(原来 8s: 打不到怪时白等太久)
    XN1_R1_RESCUE_A = 0.80
    XN1_R1_LOST_ROUNDS = 3
    XN_R_ANIM_MIN = 3.90         # 转相/万阙垂天演出藏 HUD 4.3s, 中途会闪一帧
    XN_R_ANIM_CAP = 8.50         # 万阙垂天实测 7.0s 才回 HUD, 留余量

    # ---- 第二段(变奏·照世相, 直接进统御众机 + 300照世心) ----
    XN2_LEAD = 2.50
    XN2_DODGE_MIN = 1.00         # 从第一下 A 起这么久之前不认第 1 颗(入场闪光会让几颗一起"亮")
    XN2_DODGE_HOLD = 0.07        # 闪避 = 右键
    XN2_DODGE_TO_A = 0.03
    XN2_POST_DODGE_A_EVERY = 0.10
    XN2_EMPTY_CAP = 2.80
    XN2_HOLD_AT = 7
    XN2_HOLD_STALL = 1.00
    # 雕像坐标/阈值照抄心雷穗 v1.1.0(2K/1080 实机验过)
    XN_STATUE_XS = (1647, 1719, 1794, 1866, 1938, 2013, 2085, 2160)
    XN_STATUE_Y = 1980
    XN_STATUE_UP_Y = 1953
    XN_STATUE_HW = 9
    XN_STATUE_RED = 0.08
    XN_STATUE_GLOW = 0.30
    XN_STATUE_CONFIRM = 2
    XN_STATUE_BURST = 3          # 同一帧新亮 >= 这么多颗 = 闪光, 这一帧不算
    XN2_HOLD_CAP = 3.00
    XN2_READY_REPRESS = 0.60
    XN2_REPRESS_MAX = 2
    XN2_TY_A_EVERY = 0.18
    XN2_READY_CONFIRM = 2
    XN_READY_MIN = 0.80
    XN_READY_GLYPH = (
        'AAAAAAAGGDxjHgwAAAAAAAAAABQoWcH31Vg3Jg0AAAAAACGmh+r9+X82NzlcMgAAAAZ47tD9/c06R2NGZ2cWAAA32P38/f2+N0xtaDY3MQIa'
        '3/v9/v3x4DhNbFk2OEcVYf39/f34yMM4RGJWQjmCKmH9+vW6sa2FPT09WGFLyjZ5/c7E4fWaQD0/UHOX0POeYfmXotjqXz09PkBvmojMUTfc'
        'vZnUhD08PDw9mcfbvzMBauG+pJZJREA9P9L05XAFACb1+/38refMZD3D+oQjAAAAbfn9/tDY/LQ7tOMxAgAAAABU2f7is/y+QMd0AgAAAAAA'
        'AAhcpG3GgygPAAAAAA=='
    )
    XN_TY_MIN = 0.60             # 统御众机雕像 0.71~1.00 / 其他 <= 0.38
    XN_TY_GLYPH = (
        'AAAAAAAMJCEsJBYBAAAAAAAAABiR1cJ40tzbpyYAAAAAABK+4+Pt2unk48BaJAAAAAhQg6aMnN1/l6RzUVEbAAAzV3Dw9crHyvngXlFQRQIJ'
        'VFqs8dbtovLV8JdRUFAdIlmK7ZPT7IT7v6Dtbk9bOzdhj5en/O2E/PmHoXdelTpIsV1Xrv3thPz7iE9XwJuUJsCvW6797YX9+4dTsfjxriWy'
        '9KGQ++2E/fqGnvfU33sBpvjsmt/thPzfmeylk9cPADOnpLzM7IT4tc54Y+FhAAAASGKt+eyD5uiKUbyiBQAAAAAkjf3tg/j6h3aCCQAAAAAA'
        'AAZbpFvGrUwKAAAAAA=='
    )
    XN_TY_SLOT = (2826, 1893, 82, 79)   # 重击位(4K, 跟 hsin_h1 的标注框一样)
    XN2_READY_HOLD = 1.20
    XN2_BLIND_HOLD = 2.00
    XN2_RELEASE_AFTER_GONE = 0.30
    XN2_ANIM_MIN = 1.40          # 临寰宇藏 HUD ~2.0s
    XN2_ANIM_CAP = 4.00
    XN2_RETRIES = 2
    XN2_RETRY_CAP = 1.50
    XN2_LIB2_CAP = 0.30          # 临寰宇演完 HUD 回来, 不点普攻干看 hsin_lib2 的上限
    XN2_R2_BUILD_CAP = 5.00      # 没认出万阙垂天 = 能量不够, 边点普攻边看的上限
    XN2_LIB2_READS = 1
    XN2_R2_BLIND = False         # 认同认得出才按(盲按会放成借相)
    XN2_PRE_R2 = False           # 临寰宇演完直接开大(照世相普攻补协奏几乎不涨)
    XN2_PRE_R2_CON = 0.80
    XN2_PRE_R2_CAP = 2.00
    XN2_CON_READ = 0.20
    XN2_CON_CAP = 1.50
    XN_E_CD = 12.0               # 共鸣技能·应世相冷却
    XN2_E_AFTER_R2 = True
    # 万阙垂天之后: 演出里预按住普攻, 解冻后重击松手, 再按 E(时停里松手重击就整个不出)
    XN2_R2_HOLD_FROM = 3.60
    XN2_R2_FREEZE = 0.60
    XN2_R2_HEAVY_HOLD = 0.45
    XN2_R2_E_AT = 0.85
    XN2_E_CAP = 1.20
    # ---- 心第一次上场(锁暝 R 的同奏 -> 变奏·应世相): 声骸 -> 补满应世心 -> 步红尘 -> 转相 -> 照世相 E -> 切锁暝 ----
    LQ_XN1_ECHO = True           # 进场先放声骸(视频心的声骸在这里, 心2 万阙垂天前不放)
    LQ_XN1_ECHO_AT = 0.30        # 从切人键起(刚切进来那几帧技能栏还是锁暝的, 读声骸 CD 要等它换过来)
    LQ_XN1_ECHO_CAP = 0.80
    LQ_XN1_E = True              # 转相演完按一下照世相 E 再切(同奏 5s 够)
    LQ_XN1_E_CAP = 1.20

    # ---- 心第二次上场(锁暝协奏满 -> 变奏·照世相, 统御众机) ----
    LQ_XN2_DODGE_COUNT = 5       # 第 5 颗雕像(A3 楼阁打中)才闪避
    LQ_XN2_DODGE_CAP = 3.00      # 从第一下 A 起, 这一颗一直读不到就到这一刻闪
    LQ_XN2_ECHO = False          # 心的声骸挪到心1 进场(两次大招只隔 ~7s, 声骸冷却转不过来)
    LQ_XN2_R2_HEAVY = False      # 万阙垂天后: 视频只按 E, 不重击
    LQ_XN2_R2_HEAVY_OPENER = False

    # 万阙垂天把这一波打死了 -> 等新怪再重击 + E(默认关: 实机误判过)
    XN2_R2_WAVE_WAIT = False
    XN2_R2_TARGET_BY = 0.40
    XN2_R2_FRESH_HOLD = 0.45
    XN2_R2_FRESH_E_AT = 0.40
    XN2_WAVE_WAIT = 9.0
    TARGET_GONE_CONFIRM = 2
    ENEMY_CONFIRM = 2
    WAVE_LOCK_INTERVAL = 0.3
    XN2_TAIL_A = False
    XN2_TAIL_YING = 0.30
    XN2_TAIL_CAP = 2.00

    # ==================== 锁暝 ====================
    # ---- 第一次上场(心转相给的同奏 -> 变奏·锁妄念·同奏, 进念深): R -> 演完 -> 点一下 A -> Q(暗鸟) -> 同奏切心 ----
    SO_R_LEAD = 0.25
    SO_R_ANIM_MIN = 2.50
    SO_R_ANIM_CAP = 8.00
    SO_ECHO_CAP = 1.00
    SO_ECHO_RISE = 1.0           # 声骸 CD 比按之前高出这么多秒才算放出去
    SO_A_EVERY = 0.20            # 普攻点按间隔(动作里的点击被丢掉)
    SO_TO_XN_TIME_OUT = 4.00     # 刻心念收招没完游戏不放人

    # ---- 轮切轴: 锁暝第一次上场(守/卜变奏进来 = 变奏·闪裂, 念起 -> 念深) ----
    LQ_SO_A_TAPS = 1             # R 演完点几下普攻再放暗鸟
    LQ_SO_R_CAP = 3.00           # 锁暝 R 不亮最多等这么久(只等 CD 差的那零点几秒; 开局能量不够就跳过不攒)
    LQ_SO_R_ENTRY = 1.70         # 切人键起这么久是闪裂入场动作
    LQ_SO_R_BURST = 0.30         # 入场之后读到亮: 连按 R 这么久, HUD 没消失 = 其实还没好
    LQ_SO_R_BACKOFF = 0.40       # 第 n 次连按没出之后 n 倍这么久只点 A(每下 A 后照样按一下 R)
    LQ_SO_R_E_FROM = 1.50        # 没变奏入场(念起, R 不解锁)时: 进场这么久后妄执满就点 E(锁妄念进念深)

    # ---- 轮切轴: 锁暝第二次上场(心转相的同奏 -> 旋雷破·同奏, 念深 +200 妄执) ----
    LQ_SO_B_A_LEAD = 0.10
    LQ_SO_B_FILL_CAP = 7.00      # 点 A 到妄执满的上限
    # 刻心念按住(10-25 用户): 按住普攻 = 一直转陀螺, 伤害更高, 转圈是时停(倒计时不走), 多花的只是实时
    LQ_SO_KX_HOLD_MIN = 0.50
    LQ_SO_KX_HOLD_CAP = 4.00
    LQ_SO_KX_HOLD_BLIND = 2.40   # 按下时协奏已经满着(光圈一直在), 看不出什么时候收, 按满这么久松
    LQ_SO_KX_E_MAX = 3           # 按住期间 E 位又连 2 帧是无舍念 = 没放出来, 补齐几轮
    LQ_SO_KX_E_RESCUE_CAP = 6.00
    LQ_SO_KX_FINISH_CAP = 1.00
    LQ_SO_B_ENSURE_CAP = 10.00   # 协奏不满不切: 普攻 + 妄执满了再出无舍念/刻心念, 光圈出来才走
    LQ_SO_B_KX_MAX = 2
    LQ_SO_B_READ_GRACE = 2.00
    SO_KX_A_FROM = 0.30          # 无舍念出来后点 A 的起点(从无舍念停下起算)
    SO_KX_E_EVERY = 0.10
    SO_KX_E_TAP = 0.05
    SO_KX_WUSE_CAP = 2.50
    SO_KX_GLOW_GRACE = 0.50

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 启动轴状态记在 task 上(见 opener_armed 属性); 这里只补初值, 不覆盖运行中已有的值
        if not hasattr(self.task, '_xss_opener_armed'):
            self.task._xss_opener_armed = True
        if not hasattr(self.task, '_xss_last_opener'):
            self.task._xss_last_opener = -1
        self.macro_t0 = 0.0
        self.macro_marks = []
        self.cur = None
        self.holding_attack = False
        self.si_holding = False
        self.switch_press_at = 0.0
        self.lib_press_at = 0.0
        self.loop_count = 0
        self.cycle_started = 0.0
        self.hud_seen_at = 0.0
        self.hud_watch = False
        self.drive_log_at = 0.0
        self.timeline_logged = True
        self.dl_intro_done_at = 0.0
        self.so_tongzou_at = -99.0   # 锁暝 R 出手的时刻(给自己 5s 同奏, 切走时用来判变奏)
        # reset_state() 只在 load_chars() 时跑, 而角色对象会被粘性复用 —— 这里也要启一次
        try:
            start_enable_watch(self.task, self.logger)
        except Exception:
            pass

    def reset_state(self):
        super().reset_state()
        self.opener_armed = True
        # 内置非治疗角色默认 True, 换类时会被打回, 所以在这里重申(这条轴不在切人时按处决)
        self.check_f_on_switch = False
        start_f_watch(self.task, self.logger)
        start_enable_watch(self.task, self.logger)

    # ==================== 队伍判定 ====================

    @property
    def is_in_xss(self) -> bool:
        """本队 = 心 + 锁暝 + 卜灵。按类名判。"""
        names = {c.name for c in self.task.chars if c is not None}
        return 'Suoming' in names and bool(names.intersection(self.DL_NAMES))

    def teammate(self, name):
        for char in self.task.chars:
            if char is not None and char.name == name:
                return char
        return None

    def teammate_dl(self):
        for name in self.DL_NAMES:
            char = self.teammate(name)
            if char is not None:
                return char
        return None

    def teammate_xn(self):
        """心那个角色对象。宏可能由任意一个在场成员驱动, 心那几段必须拿【真的心对象】去读技能栏/重击位。"""
        for char in self.task.chars:
            if char is None:
                continue
            if char.name == 'Hsin' or type(char).__name__ == 'Hsin':
                return char
        return None

    def opener_pending(self):
        return self.opener_blocked_by() is None

    # 启动轴的"跑过没有"必须记在 task 上: 这份代码三个成员各一份, 宏可能由任意一个人驱动,
    # 换成另一个人驱动时 self 上的标记是初值, 会把启动轴再跑一遍。
    @property
    def opener_armed(self):
        return getattr(self.task, '_xss_opener_armed', True)

    @opener_armed.setter
    def opener_armed(self, value):
        self.task._xss_opener_armed = bool(value)

    @property
    def last_opener(self):
        return getattr(self.task, '_xss_last_opener', -1)

    @last_opener.setter
    def last_opener(self, value):
        self.task._xss_last_opener = value

    def opener_blocked_by(self):
        """启动轴不跑的原因; 返回 None 表示该跑。不查任何技能可用性(场下读数是旧的)。"""
        if not self.is_in_xss:
            return 'team is not hsin/suoming/douling'
        if not self.opener_armed:
            restarted = getattr(self.task, '_ww_task_restarted_at', -1)
            if restarted > self.last_opener:
                self.logger.info('auto combat 重开过 — 启动轴重新武装, 从头跑')
                self.opener_armed = True
                return None
            return 'already armed-down (ran once this combat)'
        f_press = getattr(self.task, '_f_last_press', -1)
        if f_press > self.last_opener:
            waited = time.time() - f_press
            delay = f_settings(self.task)[1]
            if waited < delay:
                return f'F pressed {waited:.2f}s ago, waiting {delay:.2f}s for the mobs'
            return None
        if self.last_opener >= 0 and time.time() - self.last_opener < self.OPENER_MIN_GAP:
            return f'ran {time.time() - self.last_opener:.1f}s ago (< {self.OPENER_MIN_GAP:.0f}s)'
        if not self.task.use_liberation:
            return 'task.use_liberation is off'
        return None

    # ==================== 宏原语(引擎) ====================

    def macro_wait(self, sec):
        """精确等待, 【不点击】。切成 0.1 秒一片, 片间检查任务是否被停用 + 跑看门狗。"""
        if sec <= 0:
            self.task.executor.check_enabled(check_pause=False)
            self.watchdog()
            return
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)
            self.watchdog()

    def wait_until_time(self, deadline):
        self.macro_wait(deadline - time.time())

    def macro_start(self):
        self.macro_t0 = time.time()
        self.macro_marks = []

    def macro_mark(self, name):
        self.macro_marks.append(f'{name}@{time.time() - self.macro_t0:.2f}')
        # 【看门狗】HUD 很久没出现 = 关卡结束/过场/窗口没了, 再按就是在结算画面上乱按
        if self.hud_watch and time.time() - self.hud_seen_at > self.HUD_LOST_ABORT:
            self.hud_watch = False
            raise MacroBroken(f'队伍 HUD {time.time() - self.hud_seen_at:.1f}s 没出现(关卡结束/过场/窗口没了?)')

    def hud_ok(self):
        """队伍 HUD 在不在(读当前帧)。见到就记下时刻, 给看门狗用。"""
        ok = bool(self.task.in_team()[0])
        if ok:
            self.hud_seen_at = time.time()
        return ok

    def watchdog(self):
        """轴跑着的时候每 0.1s 被 macro_wait 调一次(几乎每个循环都会走 macro_wait)。

        三种情况整圈放弃(抛 MacroBroken, 由 perform_* 接住 -> macro_exit -> drive 冷却后再重排):
          1. 一圈超过 MACRO_CYCLE_CAP(冻结校正);
          2. HUD 在, 但场上角色 + 协奏读数连续 MACRO_STALL_SEC 一点没变 = 打不到怪 / 被控制 / 卡在动作里;
          3. HUD 连续 HUD_LOST_ABORT 秒不在(关卡结束/过场/窗口没了)。
        演出里 HUD 不在的时候不判"没进展"(那时协奏本来就不变, 交给第 3 条)。
        """
        if not self.hud_watch:
            return
        now = time.time()
        if getattr(self, '_wd_next', 0.0) > now:
            return
        self._wd_next = now + self.MACRO_STALL_POLL
        try:
            el = self.time_elapsed_accounting_for_freeze(self.cycle_started)
        except Exception:
            el = now - self.cycle_started
        if el >= self.MACRO_CYCLE_CAP:
            self.hud_watch = False
            raise MacroBroken(f'一圈已经 {el:.0f}s(预算 {self.MACRO_CYCLE_CAP:.0f}s)还没打完 — 卡住了, 交回框架')
        try:
            in_team, index, _count = self.task.in_team()
            con = round(float(self.task.get_current_con()), 2)
        except Exception:
            return
        if not in_team:
            self._stall_since = now
            if now - self.hud_seen_at > self.HUD_LOST_ABORT:
                self.hud_watch = False
                raise MacroBroken(f'队伍 HUD {now - self.hud_seen_at:.1f}s 没出现(关卡结束/过场/窗口没了?)')
            return
        sig = (index, con)
        if sig != getattr(self, '_stall_sig', None):
            self._stall_sig = sig
            self._stall_since = now
            return
        if now - getattr(self, '_stall_since', now) >= self.MACRO_STALL_SEC:
            self.hud_watch = False
            raise MacroBroken(f'{self.MACRO_STALL_SEC:.0f}s 没有任何进展(HUD 在, 协奏和场上角色都没变: '
                              f'打不到怪 / 被控制 / 卡动作?) — 交回框架')

    def force_release_mouse(self):
        """不管是谁按下去的, 系统级左键先松开。换驱动者/异常路径靠它兜底, 免得"卡手"把整个鼠标卡住。"""
        try:
            send_input_left(True)
        except Exception:
            pass
        try:
            self.task.mouse_up()
        except Exception:
            pass
        self.si_holding = False
        self.holding_attack = False
        self.task._xss_mouse_down = False

    def note_ok(self):
        if getattr(self.task, '_xss_break_streak', 0):
            self.logger.info('轴恢复正常, 断轴计数清零')
        self.task._xss_break_streak = 0
        self.task._xss_backoff_until = 0.0

    def note_broken(self):
        streak = getattr(self.task, '_xss_break_streak', 0) + 1
        self.task._xss_break_streak = streak
        wait = min(self.BROKEN_BACKOFF_BASE * streak, self.BROKEN_BACKOFF_MAX)
        self.task._xss_backoff_until = time.time() + wait
        self.logger.warning(f'轴断了第 {streak} 次, 接下来 {wait:.1f}s 一下都不按(交给框架走位 / 等控制结束再重排)')

    def macro_timeline(self, since=0):
        return ' '.join(self.macro_marks[since:])

    def macro_spam(self, window, interval=None, tag='A'):
        """连点一个窗口。动画期间的点击被丢掉, 连点保证总有一下落在动画刚结束时。"""
        interval = self.A_INTERVAL if interval is None else interval
        start = time.time()
        n = 0
        cap = int(window / max(interval, 0.01)) + 2
        while time.time() - start < window and n < cap:
            self.click()
            n += 1
            remaining = window - (time.time() - start)
            if remaining <= 0:
                break
            # click 自己按住 A_TAP 秒, 不扣的话连点周期从 interval 变成 interval + A_TAP
            self.macro_wait(min(max(0.0, interval - self.A_TAP), remaining))
        self.macro_mark(f'{tag}(x{n})')
        return n

    def spam_key(self, send, window, interval=None, tag='key', poke=False, presses=None):
        """在一个窗口里反复发同一个技能键(动画期间的按键被丢掉、不排队, 单发必丢)。

        poke: 发键期间要不要照常点普攻。presses: 只发这么多次, 均匀铺在窗口里。
        """
        interval = self.KEY_INTERVAL if interval is None else interval
        if presses is not None and presses > 0:
            interval = max(interval, window / presses)
        start = time.time()
        n = 0
        clicks = 0
        next_click = 0.0
        while True:
            send()
            n += 1
            if presses is not None:
                if n >= presses:
                    break
                left = interval
            else:
                left = window - (time.time() - start)
                if left <= 0:
                    break
            step_end = time.time() + min(interval, left)
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + self.A_INTERVAL
                self.macro_wait(min(0.02, step_end - time.time()))
        self.macro_mark(f'{tag}(x{n},A x{clicks})')
        return n

    def game_foreground(self):
        try:
            return bool(self.task.executor.interaction.hwnd_window.is_foreground())
        except Exception:
            return False

    def attack_down(self, direct):
        """按下左键。direct = 走 SendInput(失败自动退回 PostMessage)。返回实际走没走 SendInput。"""
        if direct and send_input_left(False):
            self.si_holding = True
        else:
            direct = False
            self.task.mouse_down()
        self.holding_attack = True
        self.task._xss_mouse_down = True
        return direct

    def release_attack(self):
        # 【SendInput 按下的必须 SendInput 松开】: PostMessage 的 mouse_up 只进游戏窗口的消息队列,
        # 系统里那个左键会一直按着 —— 宏异常退出时整台电脑的左键都是按住的
        if self.si_holding:
            if not send_input_left(True):
                self.logger.warning('SendInput 左键松开没发出去 — 如果左键卡住, 手动点一下')
            self.si_holding = False
            self.holding_attack = False
        elif self.holding_attack:
            self.task.mouse_up()
            self.holding_attack = False
        self.task._xss_mouse_down = False

    def tap(self, hold=None):
        """点一下普攻, 【真的按住 hold 秒】。"""
        hold = self.A_TAP if hold is None else hold
        self.task.mouse_down()
        self.holding_attack = True
        try:
            self.macro_wait(hold)
        finally:
            self.task.mouse_up()
            self.holding_attack = False

    def click(self, *args, **kwargs):
        """本队里所有的 self.click() 都改成按住 A_TAP(BaseChar.click 强制 10ms, 等于没点)。不在本队走原版。"""
        if not self.is_in_xss:
            return super().click(*args, **kwargs)
        self.tap()

    def quick_switch(self, target, click_during=False, time_out=None, read_con=False, assume_con=False):
        """按数字键直切给指定角色(不走 switch_next_char 选人)。

        read_con: 按键之后读一次协奏决定按不按"带变奏"记账; assume_con: 不读屏直接按满协奏记。
        Returns: 是否真的切过去了。
        """
        if target is None:
            return False
        if target is self.cur:
            self.macro_mark(f'>{target.name[:3]}(already)')
            return True
        entry = time.time()
        time_out = self.SWITCH_TIME_OUT if time_out is None else time_out
        source = self.cur if self.cur is not None else self
        slot = target.index + 1
        self.switch_press_at = time.time()
        self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
        if assume_con:
            con_full = True
        elif read_con:
            # 不用 char.is_con_full(): 那层读到过一次满就一直缓存成满
            try:
                con_full = float(self.task.get_current_con()) >= 1.0
            except Exception:
                con_full = False
        else:
            con_full = False
        con_cost = time.time() - entry

        start = time.time()
        last = start
        next_click = 0.0
        trace = [] if self.TRACE_SWITCH else None
        team_size = len([c for c in self.task.chars if c is not None])
        untrusted_hits = 0
        clicks = 0
        while time.time() - start < time_out:
            now = time.time()
            if now - last >= self.SWITCH_KEY_INTERVAL:
                self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
                last = now
            if click_during and now >= next_click:
                self.click()
                clicks += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            hit = in_team and index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if trace is not None:
                trace.append(f'{time.time() - start:.2f}:'
                             f'{(index if trusted else f"?{index}") if in_team else "x"}')
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                self.handoff(source, target, con_full)
                self.macro_mark(f'>{target.name[:3]}{"^" if con_full else ""}'
                                f'({time.time() - entry:.2f}|con{con_cost:.2f}|A x{clicks})')
                if trace and time.time() - entry > 0.4:
                    self.logger.info(f'slow switch trace -> {target.name}: {" ".join(trace)}')
                return True
        # 一直是旧角色的 index = 游戏在拒绝切人; 带 ? 的都是目标 = count 判据挡住了; 全是 x = HUD 不在
        self.logger.warning(f'switch to {target.name} slot {slot} timed out '
                            f'after {time_out:.1f}s (stuck in an animation?)'
                            + (f' trace: {" ".join(trace)}' if trace else ''))
        self.macro_mark(f'>{target.name[:3]}FAIL')
        return False

    def handoff(self, from_char, to_char, con_full):
        """复刻 switch_next_char() 尾部那套交接记账。不补的话 get_current_char() 返回 None, 主循环当场崩。"""
        self.task.in_liberation = False
        from_char.switch_out(con_full=con_full)
        to_char.is_current_char = True
        to_char.has_intro = con_full
        to_char.has_sub_dps_intro = con_full and from_char.is_sub_dps
        to_char.last_switch_in_time = time.time()
        if con_full:
            now = time.time()
            self.task.add_freeze_duration(now, to_char.intro_motion_freeze_duration, -100)
            from_char.last_outro_time = now
        self.cur = to_char

    def switch_retry(self, target, tag, **kw):
        """quick_switch, 超时了先等 HUD 回来再切, 最多再试 SWITCH_RETRIES 次。只花时间。
        游戏不在前台时按键进不去, 别再白等 2×3s —— 直接算失败, 交给断轴冷却。"""
        if self.quick_switch(target, **kw):
            return True
        if not self.game_foreground():
            self.logger.info(f'{tag}: 切人失败且游戏不在前台, 不再重试(交给断轴冷却)')
            return False
        for i in range(self.SWITCH_RETRIES):
            self.wait_hud_up(cap=2.0, tag=f'{tag}重切前HUD')
            self.macro_mark(f'{tag}切{target.name[:3]}重试#{i + 1}')
            kw2 = dict(kw)
            kw2['time_out'] = self.SWITCH_RETRY_TIME_OUT
            if self.quick_switch(target, **kw2):
                return True
        return False

    def wait_hud_back(self, tag='anim', time_out=None, min_gone=0.0, tail=0.0, hold_from=None):
        """等演出结束(队伍 HUD 回来), 【期间一下都不点】。先确认消失过。

        min_gone: 从第一次读到消失起, 这么久之内读到的"回来"不认(演出中途 HUD 会闪一两帧)。
        hold_from: 消失后这么久按住普攻(预输入重击), 返回时还按着, 调用方负责松开。
        """
        time_out = self.LIB_ANIM_TIME_OUT if time_out is None else time_out
        start = time.time()
        gone_at = None
        back_hits = 0
        back = False
        while time.time() - start < time_out:
            self.task.next_frame()
            if (hold_from is not None and gone_at is not None and not self.holding_attack
                    and time.time() - gone_at >= hold_from):
                si = self.xn_attack_down()
                self.macro_mark(f'{tag}按住预输入({"SI" if si else "PM"},{time.time() - gone_at:.2f}s)')
            if not self.hud_ok():
                if gone_at is None:
                    gone_at = time.time()
                back_hits = 0
            elif gone_at is not None:
                if time.time() - gone_at >= min_gone:
                    back_hits += 1
                    if back_hits >= self.HUD_BACK_CONFIRM:
                        back = True
                        break
            elif time.time() - start >= self.HUD_NO_ANIM_GRACE:
                back = True
                break
            self.macro_wait(0.01)
        if gone_at is not None:
            self.add_freeze_duration(gone_at, time.time() - gone_at)
        self.macro_mark(f'{tag}({"ok" if back else "timeout"},'
                        f'{"anim" if gone_at is not None else "NOANIM"},{time.time() - start:.2f}s)')
        self.macro_wait(tail)
        return back

    def wait_hud_up(self, cap=None, tag='HUD'):
        """等队伍 HUD 【现在】在场。按 R 之前用 —— HUD 本来就不在的时候判"演出开始了"是假成功。"""
        cap = self.HUD_UP_CAP if cap is None else cap
        start = time.time()
        while time.time() - start < cap:
            self.task.next_frame()
            if self.hud_ok():
                if time.time() - start > 0.05:
                    self.macro_mark(f'{tag}在场({time.time() - start:.2f}s)')
                return True
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}一直不在({cap:.1f}s)')
        return False

    def on_field_char(self, time_out=None):
        """现在场上是谁 —— 只在拿不到入口角色时才用(开局 HUD 渐入时 in_team() 会说谎, 要 count 达标)。"""
        time_out = self.FIELD_SETTLE_TIME_OUT if time_out is None else time_out
        expected = len([c for c in self.task.chars if c is not None])
        end = time.time() + time_out
        while True:
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            if in_team and count >= expected:
                for char in self.task.chars:
                    if char is not None and char.index == index:
                        return char
                return None
            if time.time() >= end:
                self.logger.warning(f'team HUD never settled in {time_out:.1f}s '
                                    f'(in_team={in_team} index={index} count={count} '
                                    f'expected={expected}), cannot tell who is on field')
                return None
            self.macro_wait(0.03)

    def mark_busy(self, busy):
        """F 键监视线程靠它区分"战斗中手动处决"和"重开副本"。"""
        self.task._ww_macro_busy = busy
        self.task._three_fire_macro_busy = busy

    def need(self, ok, what):
        if not ok:
            raise MacroBroken(what)

    def press_key_until_cd(self, send, available, cap, tag, ready_grace=0.15, poke=False):
        """一直按某个技能键到它进 CD。返回放出去了没有(本来就在 CD 上返回 False)。

        【先见过"亮"才认"暗"】: 刚切人那几帧技能栏还是上一个人的, 读到的是上一个人的 CD。
        """
        start = time.time()
        n = live = clicks = 0
        seen_ready = False
        next_click = 0.0
        while time.time() - start < cap:
            self.task.next_frame()
            hud = bool(self.hud_ok())
            if hud:
                if available():
                    seen_ready = True
                elif seen_ready and live > 0:
                    self.macro_mark(f'{tag}_ok(x{n},A x{clicks},{time.time() - start:.2f}s)')
                    return True
                elif not seen_ready and time.time() - start >= ready_grace:
                    self.macro_mark(f'{tag}_没见过亮(x{n},{time.time() - start:.2f}s)')
                    return False
            send()
            n += 1
            if hud:
                live += 1
            step_end = time.time() + self.E_RESEND_STEP
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + self.A_INTERVAL
                self.macro_wait(min(0.02, step_end - now))
        self.macro_mark(f'{tag}_CD?(x{n},seen{int(seen_ready)},{cap:.1f}s)')
        self.logger.info(f'{tag}: never read as on-cooldown after {n} presses (seen ready={seen_ready})')
        return False

    def press_res_until_cd(self, char, cap, tag, ready_grace=None, poke=False):
        ready_grace = self.SKILL_BAR_SETTLE if ready_grace is None else ready_grace
        return self.press_key_until_cd(char.send_resonance_key, char.resonance_available, cap, tag,
                                       ready_grace=ready_grace, poke=poke)

    def fire_r(self, char, tag, window):
        """发大招到队伍 HUD【连续】消失 LIB_GONE_CONFIRM 帧。返回放出去没有。

        发键之前先等 HUD 在场(HUD 本来就不在会假成功)。确认期间继续按 R 没有副作用 —— 演出里的按键被丢掉。
        """
        self.wait_hud_up(tag=f'{tag}前HUD')
        start = time.time()
        self.lib_press_at = start
        n = gone = 0
        fired = False
        while time.time() - start < window:
            char.send_liberation_key()
            n += 1
            self.task.next_frame()
            if not self.hud_ok():
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    fired = True
                    break
            else:
                gone = 0
            self.macro_wait(self.LIB_KEY_INTERVAL)
        self.task.skip_combat_check = True
        if fired:
            char.record_liberation_use()
            self.macro_mark(f'{tag}_fired(x{n},{time.time() - start:.2f}s)')
            return True
        self.macro_mark(f'{tag}_NOFIRE(x{n})')
        try:
            lit = bool(char.liberation_available())
        except Exception:
            lit = 'err'
        # lit=True: 键被上一个动作吞了; lit=False: 能量不够
        self.logger.warning(f'{tag}: {char.name} liberation never started an animation '
                            f'after {n} presses (icon lit={lit})')
        return False

    def lib_ready_reads(self, char, frames):
        """HUD 在场时连续 frames 帧读到 char 的 R 可用。HUD 不在的帧不算, 最多读 frames*3 帧。"""
        hits = 0
        for _ in range(frames * 3):
            self.task.next_frame()
            if self.hud_ok():
                try:
                    ready = bool(char.liberation_available())
                except Exception:
                    ready = False
                if not ready:
                    return False
                hits += 1
                if hits >= frames:
                    return True
            self.macro_wait(0.02)
        return False

    def ensure_r(self, char, tag, window, cap, build):
        """R 一定要放出来。读 R 亮 -> 按; 亮着却没放出去就再按, 最多 R_TRIES 次;
        不亮 -> build(轮次) 攒一小段再读, 每 R_BLIND_EVERY 轮盲按一次防读数不准。上限 cap 只防打不到怪。
        """
        start = time.time()
        tries = rounds = 0
        while time.time() - start < cap:
            if self.lib_ready_reads(char, 2):
                tries += 1
                if self.fire_r(char, f'{tag}R' if tries == 1 else f'{tag}R重按#{tries - 1}', window):
                    if rounds:
                        self.logger.info(f'{tag}: {char.name} R 攒了 {time.time() - start:.1f}s 能量才放出去')
                    return True
                if tries >= self.R_TRIES:
                    break
                continue
            rounds += 1
            if rounds == 1:
                self.macro_mark(f'{tag}R没亮(攒能量)')
            build(rounds)
            if rounds % self.R_BLIND_EVERY == 0 and not self.lib_ready_reads(char, 2) and \
                    self.fire_r(char, f'{tag}R盲按#{rounds}', self.R_BLIND_WINDOW):
                return True
        self.logger.warning(f'{tag}: {char.name} 的 R 保底 {time.time() - start:.1f}s 还是没放出去 '
                            f'(亮了按 {tries} 次, 攒能量 {rounds} 轮), 不放了')
        return False

    def read_cd(self, name='resonance', char=None):
        """读技能框里的 CD 数字(秒)。不在 CD / 读不到都返回 0(框架没 CD 时返回负数, 截成 0)。"""
        try:
            index = None if char is None else char.index
            return max(0.0, float(self.task.get_cd(name, index)))
        except Exception:
            return 0.0

    def read_con(self, want, settle=None, click=False, tag=None):
        """读协奏: 自己刷帧、给结算留时间, 连着几帧达到 want 就立刻返回。返回期间读到的最大值。"""
        settle = 0.50 if settle is None else settle
        start = time.time()
        best = 0.0
        hits = 0
        next_click = 0.0
        while True:
            now = time.time()
            if click and now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            self.hud_ok()
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            best = max(best, con)
            hits = hits + 1 if con >= want else 0
            if hits >= self.DL_CON_FULL_CONFIRM or time.time() - start >= settle:
                break
            self.macro_wait(self.DL_CON_POLL)
        if tag:
            self.macro_mark(f'{tag}(con{best:.2f},{time.time() - start:.2f}s)')
        return best

    def glow_slot(self, frame, slot):
        """队伍栏第 slot 格(0 起)头像外面那圈细白环 -> 落在同一半径上的上半圈角度占比(0~1)。"""
        H, W = frame.shape[:2]
        s = H / 2160
        cx = W - (3840 - 3586.5) * s
        cy = (500 + 264 * slot) * s
        R = int(round(125 * s)) + 3
        xa, ya = int(cx) - R, int(cy) - R
        if xa < 0 or ya < 0 or xa + 2 * R + 1 > W or ya + 2 * R + 1 > H:
            return 0.0
        crop = frame[ya:ya + 2 * R + 1, xa:xa + 2 * R + 1, :3]
        white = np.ascontiguousarray(crop.min(axis=2)).astype(np.float32)
        polar = cv2.warpPolar(white, (R, 360), (cx - xa, cy - ya), R, cv2.WARP_POLAR_LINEAR)
        rows = polar[225:331]
        d = max(1, int(round(4.5 * s)))
        r = np.arange(int(80 * s), int(118 * s))
        ridge = rows[:, r] - np.maximum(rows[:, r - d], rows[:, r + d])
        k = ridge.argmax(axis=1)
        hit = ridge[np.arange(len(rows)), k] > 40
        if not hit.any():
            return 0.0
        hist = np.bincount(r[k][hit], minlength=int(r[-1]) + 2)
        win = max(2, int(round(4 * s)))
        return float(np.convolve(hist, np.ones(win), 'valid').max()) / len(rows)

    def glow_now(self, cur):
        """当前帧 cur 以外两格的光圈够不够"协奏满"。同一帧只算一次, 顺手数连着几帧(换人从头数)。"""
        frame = self.task.frame
        if frame is None:
            return False
        same_cur = getattr(self, 'glow_cur', None) == cur.index
        if same_cur and getattr(self, 'glow_frame', None) is frame:
            return self.glow_last
        others = [self.glow_slot(frame, i) for i in range(3) if i != cur.index]
        lo, hi = min(others), max(others)
        on = (lo >= self.GLOW_BOTH and hi >= self.GLOW_ONE) or hi >= self.GLOW_SOLO
        self.glow_hits = ((getattr(self, 'glow_hits', 0) if same_cur else 0) + 1) if on else 0
        self.glow_frame, self.glow_cur, self.glow_last = frame, cur.index, on
        return on

    def con_glow(self, cur):
        """光圈连着 GLOW_CONFIRM 帧都在 = 协奏真满。读当前帧(调用方负责 next_frame)。
        认出过一次就记下"这台机器光圈认得出"(glow_trusted), 之后 strict 的地方不再信读数。"""
        self.glow_now(cur)
        ok = getattr(self, 'glow_hits', 0) >= self.GLOW_CONFIRM
        if ok:
            self.glow_ok = True
        return ok

    def glow_trusted(self):
        return getattr(self, 'glow_ok', False)

    def con_ready(self, cur, settle, tag=None, strict=False):
        """交棒前读协奏: 光圈连 GLOW_CONFIRM 帧 = 满; 认不出光圈时读数连 DL_CON_FULL_CONFIRM 帧 1.00 也算满
        (strict 且光圈认得出过: 读数不算, 只认光圈)。settle 内都没有 = 不满。读数最大值留在 self.con_last。"""
        strict = strict and self.glow_trusted()
        start = time.time()
        best = 0.0
        hits = 0
        why = None
        while True:
            self.task.next_frame()
            self.hud_ok()
            if self.con_glow(cur):
                why = '光圈'
                break
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            best = max(best, con)
            hits = hits + 1 if con >= self.DL_CON_ENOUGH else 0
            if hits >= self.DL_CON_FULL_CONFIRM and not strict:
                why = f'con{best:.2f}'
                break
            if time.time() - start >= settle:
                break
            self.macro_wait(self.DL_CON_POLL)
        self.con_last = best
        self.con_why = why
        if tag:
            self.macro_mark(f'{tag}({why or f"没满con{best:.2f}"},{time.time() - start:.2f}s)')
        return why is not None

    # ==================== 卜灵 ====================

    def switch_to_dl(self, dl, tag):
        """切给卜灵并等她的变奏入场演完。返回时 HUD 在场、场上是她。"""
        for attempt in range(1 + self.SWITCH_RETRIES):
            got = self.switch_to_dl_once(dl, tag if attempt == 0 else f'{tag}重切#{attempt}')
            if got is not None:
                return got
            self.wait_hud_up(cap=2.0, tag=f'{tag}重切前HUD')
        return False

    def switch_to_dl_once(self, dl, tag):
        """切一次卜灵。返回 True/False(到场了, HUD 回没回来), None = 卜灵没上场。

        带演出的强化变奏入场一切进来 HUD 就藏了, quick_switch 读不到她到场会超时 ——
        所以不管切人判没判到, 都等 HUD 回来再认一次场上是谁。演出里一下都不点。
        """
        src = self.cur
        sw_at = time.time()
        full = False
        try:
            full = float(self.task.get_current_con()) >= 1.0
        except Exception:
            pass
        arrived = self.quick_switch(dl, assume_con=full, time_out=self.DL_TO_TIME_OUT)
        anim_in_switch = arrived and time.time() - sw_at >= self.DL_SWITCH_ANIM_HINT
        start = time.time()
        gone_at = None
        hits = 0
        back = False
        while time.time() - start < self.DL_INTRO_ANIM_CAP:
            self.task.next_frame()
            if not self.hud_ok():
                if gone_at is None:
                    gone_at = time.time()
                hits = 0
            elif gone_at is not None or anim_in_switch:
                hits += 1
                if hits >= self.HUD_BACK_CONFIRM:
                    back = True
                    break
            elif time.time() - start >= self.DL_INTRO_NOANIM:
                back = True
                break
            self.macro_wait(0.01)
        if gone_at is not None:
            self.add_freeze_duration(gone_at, time.time() - gone_at)
        self.macro_mark(f'{tag}卜入场({"anim" if gone_at is not None or anim_in_switch else "noanim"},'
                        f'{"ok" if back else "timeout"},{time.time() - start:.2f}s)')
        if not arrived:
            who = self.on_field_char(time_out=1.0)
            if who is not dl:
                self.macro_mark(f'{tag}卜没上场({who.name if who else "?"})')
                return None
            self.handoff(src if src is not None else self, dl, full)
            self.macro_mark(f'{tag}>Dou(演出里到场)')
        self.dl_intro_done_at = time.time()
        return back

    def dl_gua_n(self):
        """现在有几个卦象(0~3); 读不出来(这版 ok-ww 没卜灵模板 / 关了读卦象)返回 None。读当前帧。"""
        if not self.DL_GUA_READ or not _GUA_AVAILABLE:
            return None
        try:
            box = self.task.box_of_screen_scaled(3840, 2160, *self.DL_GUA_BOX, name='douling_gua', hcenter=True)
            found = []
            for label, kind in ((_Labels.douling_gen, 'G'), (_Labels.douling_zhen, 'Z')):
                for b in self.task.find_feature(label, box=box, threshold=self.DL_GUA_THRESHOLD,
                                                frame_processor=_isolate_gua_strokes):
                    found.append((b, kind))
        except Exception as e:
            self.logger.info(f'卦象读失败 {e}')
            return None
        kept = []
        for b, kind in sorted(found, key=lambda f: f[0].confidence, reverse=True):
            # 两个模板会同时弱匹配同一个位置, 只留更像的那个(位置按 x 排)
            if all(abs(b.x - k.x) > b.width * 0.6 for k, _ in kept):
                kept.append((b, kind))
        return len(kept)

    def dl_gua_ready(self, dl, reads=None):
        """增强重击能不能按: 卦象 >= DL_GUA_MIN 连读 reads 帧。
        卦象读不出来 -> 退回框架的重击位(mouse_forte); 都读不出来 -> 当能用(不卡死轴)。
        """
        reads = self.DL_GUA_CONFIRM if reads is None else reads
        hits = 0
        for _ in range(reads * 3):
            n = self.dl_gua_n()
            if n is None:
                try:
                    return bool(dl.is_mouse_forte_full())
                except Exception:
                    return True
            hits = hits + 1 if n >= self.DL_GUA_MIN else 0
            if hits >= reads:
                return True
            self.task.next_frame()
        return False

    def dl_gua_ready_wait(self, dl, cap):
        """等他到 cap 秒: E 出手后卦象要过一会儿才到账。"""
        start = time.time()
        while True:
            if self.dl_gua_ready(dl):
                return True
            if time.time() - start >= cap:
                return False
            self.macro_wait(0.03)

    def dl_hold_heavy(self, dl, hold, cap, tag):
        """卜灵增强重击(按住普攻): 卦象 >= DL_GUA_MIN 才按 —— 只有 1 个卦象按住出来的是谬门占卜(自伤)。
        按住 hold 秒(读不到卦象也按这么久), cap 是硬上限。
        """
        if not self.dl_gua_ready(dl):
            self.macro_mark(f'{tag}卦象不够,不按')
            return False
        self.task.mouse_down()
        self.holding_attack = True
        self.macro_mark(f'{tag}_down')
        start = time.time()
        try:
            while time.time() - start < max(cap, hold):
                self.task.next_frame()
                self.hud_ok()
                if time.time() - start >= hold:
                    break
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}_up({time.time() - start:.2f}s)')
        return True

    def dl_heavy(self, dl, tag):
        """卦象不够就一次都不按; 按了(不管卦象有没有到账)就算这一下出去了。"""
        for i in range(1 + self.DL_HEAVY_RETRIES):
            if self.dl_hold_heavy(dl, self.DL_HEAVY_HOLD, self.DL_HEAVY_CAP,
                                  tag=tag if i == 0 else f'{tag}重按#{i}'):
                return True
        return False

    def dl_e_ready(self, dl):
        """卜灵 E 好没好: 上次放 E 的时间 + 技能栏 CD 都要说好了(OCR 读漏过, 把 CD 中的 E 当成好了)。"""
        return time.time() - getattr(dl, 'last_res', 0) >= self.DL_E_CD - 0.3 and self.read_cd('resonance') <= 0

    def dl_build_energy(self, dl, tag, rounds):
        """卜灵攒能量/R 不亮时的一轮: 卦象够就增强重击(伤害高), E 好就 E(拿卦象 + 协奏), 否则普攻一小段。"""
        self.task.next_frame()
        if self.dl_gua_ready(dl):
            self.dl_heavy(dl, tag=f'{tag}攒能量重击#{rounds}')
        elif self.dl_e_ready(dl):
            self.spam_key(dl.send_resonance_key, 0.20, interval=0.06, tag=f'{tag}攒能量E#{rounds}')
            dl.record_resonance_use()
            self.macro_wait(self.DL_E_DERIVE)
        else:
            self.macro_spam(self.R_BUILD_SLICE, self.A_INTERVAL, tag=f'{tag}攒能量A#{rounds}')

    def dl_ensure_con(self, dl, tag, glow_only=False):
        """卜灵协奏没满就别交棒 —— 用能给协奏的技能补: E > 增强重击 > 普攻。
        glow_only: 只认光圈; 本局光圈还没认出过时, 读数满了再接着补 DL_CON_READ_GRACE 才信读数。"""
        start = time.time()
        taps = 0
        read_full_at = None
        while time.time() - start < self.DL_CON_RESCUE_CAP:
            if self.con_ready(dl, self.DL_CON_POLL, strict=glow_only):
                if not glow_only or self.con_why == '光圈':
                    self.macro_mark(f'{tag}补协奏(满,{self.con_why},A x{taps},{time.time() - start:.2f}s)')
                    return True
                read_full_at = read_full_at or time.time()
                if time.time() - read_full_at >= self.DL_CON_READ_GRACE:
                    self.macro_mark(f'{tag}补协奏(读数满没光圈,照切,A x{taps},{time.time() - start:.2f}s)')
                    return True
            if self.dl_e_ready(dl):
                self.spam_key(dl.send_resonance_key, 0.26, interval=0.06, tag=f'{tag}补协奏E')
                dl.record_resonance_use()
                self.macro_wait(self.DL_E_DERIVE)
                continue
            if self.dl_gua_ready(dl):
                self.dl_heavy(dl, tag=f'{tag}补协奏重击')
                continue
            # 一下一下打, 每下之后看卦象/协奏 —— 卦象一到 2 就立刻增强重击
            self.tap()
            taps += 1
            self.macro_wait(max(0.0, self.A_INTERVAL - self.A_TAP))
        self.macro_mark(f'{tag}补协奏(cap,A x{taps},{time.time() - start:.2f}s)')
        self.logger.warning(f'{tag}: 补了 {time.time() - start:.1f}s 协奏还是没满, 认赔交棒(打不到怪?)')
        return False

    def dl_hand_off(self, dl, target, tag, read=True, glow_only=False):
        """卜灵 -> target: 协奏满了才交棒(要的是变奏入场), 读一下不满就直接补(不干等)。
        read=False: 明知不满, 不先读, 直接补(补的每一下之前照样看协奏)。
        glow_only: 只认光圈, 读数满不算(见 LQ_DL_GLOW_ONLY)。"""
        full = self.con_ready(dl, self.DL_CON_READ, tag=f'{tag}协奏', strict=glow_only) if read else False
        if full and glow_only and self.con_why != '光圈':
            full = False
        if not full:
            full = self.dl_ensure_con(dl, tag, glow_only=glow_only)
        if not full:
            self.logger.warning(f'【协奏没满就交棒】卜灵 -> {target.name}: 拿不到变奏入场')
        self.need(self.switch_retry(target, f'{tag}切{target.name[:3]}', assume_con=full),
                  f'douling -> {target.name}')
        return full

    def dl_e_2a_heavy(self, dl, tag, check_e):
        """卜灵 E -> 2A -> 增强重击。重击锚在按下 E 之后 DL_E_TO_HEAVY; 卦象不够(被打断/E 被吞)就不按。
        check_e: E 冷却中就跳过 E(2A 照打)。返回重击按下的时刻(没按 = 0)。
        """
        e_at = time.time()
        if check_e and not self.dl_e_ready(dl):
            self.macro_mark(f'{tag}E冷却中')
        elif self.press_res_until_cd(dl, self.DL_E_CAP, f'{tag}E', ready_grace=0.15):
            dl.record_resonance_use()
        left = e_at + self.DL_E_TO_HEAVY - time.time()
        if left > 0:
            self.macro_spam(left, self.A_INTERVAL, tag=f'{tag}2A')
        else:
            self.macro_mark(f'{tag}2A(late{-left:.2f}s)')
        if self.dl_gua_ready_wait(dl, self.DL_GUA_WAIT):
            heavy_at = time.time()
            if self.dl_heavy(dl, tag=f'{tag}增强重击'):
                return heavy_at
        else:
            self.macro_mark(f'{tag}增强重击不按(卦象不够)')
        return 0.0

    def try_r_quick(self, char, tag, window=None):
        """R 亮就放(最多窗口这么久), 不亮【立刻跳过, 绝不攒能量】。

        开局/刚复活时大招能量经常不够: 站在场上 A 十几秒去攒, 亏的是整条轴的节奏和主 DPS 的输出。
        少一发 R 让轴先转起来, 能量由后面几圈的输出补回来, 比白打十几秒强。
        需要"R 一定要放出来"的场合(比如守岸人领域)再用 ensure_r。
        """
        window = self.DL_R_RESCUE if window is None else window
        if not self.lib_ready_reads(char, 2):
            self.macro_mark(f'{tag}(R没亮,跳过)')
            return False
        if self.fire_r(char, tag, window):
            return True
        self.macro_mark(f'{tag}(R按了没出,跳过)')
        return False

    def dl_topup_con(self, dl, tag, target=None, cap=None):
        """卜灵 R 之前把协奏补到 DL_R_EARLY_CON(普攻, 上限 DL_R_TOPUP_CAP)。

        实机: R 前协奏只有 0.66~0.71, 不够"演出里切锁暝", 于是 R 演完(3.5s)还要站桩补 2~3 秒,
        而且锁暝容易普通入场(后面 R 不亮 / 同奏断)。提前补这几下比演完再补划算。
        """
        target = self.DL_R_EARLY_CON if target is None else target
        cap = self.DL_R_TOPUP_CAP if cap is None else cap
        start = time.time()
        taps = 0
        while time.time() - start < cap:
            try:
                con = float(self.task.get_current_con())
            except Exception:
                return False
            if con >= target:
                if taps:
                    self.macro_mark(f'{tag}协奏补到{con:.2f}(A x{taps},{time.time() - start:.2f}s)')
                return True
            self.tap()
            taps += 1
            self.macro_wait(max(0.0, self.A_INTERVAL - self.A_TAP))
        self.macro_mark(f'{tag}协奏没补够(A x{taps},{time.time() - start:.2f}s)')
        return False

    def dl_qr_switch(self, dl, so, tag, glow_only=False):
        """卜灵 [补协奏] Q(声骸) -> R[亮才放] -> 协奏够就演出里切锁暝, 不够演完补满再变奏锁暝。"""
        self.dl_topup_con(dl, tag)
        self.spam_key(dl.send_echo_key, self.DL_Q_WINDOW, tag=f'{tag}Q', presses=self.DL_Q_PRESSES)
        dl.record_echo_use()
        con_pre = self.read_con(1.0, settle=0.06)
        con_full = con_pre >= self.DL_R_EARLY_CON
        if self.try_r_quick(dl, f'{tag}R'):
            if con_full:
                gone_at = time.time()
                self.wait_until_time(gone_at + self.DL_R_SWITCH_FROM)
                self.macro_mark(f'{tag}R演出里切锁暝(R前协奏{con_pre:.2f})')
                ok = self.quick_switch(so, assume_con=True,
                                       time_out=self.DL_R_ANIM_CAP - self.DL_R_SWITCH_FROM)
                self.add_freeze_duration(gone_at, time.time() - gone_at)
                if ok:
                    return True
                self.wait_hud_up(cap=2.0, tag=f'{tag}演出里没切过去')
            else:
                self.macro_mark(f'{tag}R前协奏{con_pre:.2f}(不够, 等演完)')
                self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.DL_R_ANIM_MIN, time_out=self.DL_R_ANIM_CAP)
        return self.dl_hand_off(dl, so, tag, glow_only=glow_only)

    def seg_lq_dl_open(self, dl, so, tag):
        """(LQ) 卜灵·启动段: 3A -> E -> 2A -> 增强重击 -> R[亮才放] -> 演完 -> Q -> 协奏补满 -> 变奏锁暝。

        锁暝要变奏入场(闪裂把她从念起带进念深, 念深才有 R), 所以交棒前协奏要真满(dl_hand_off: 光圈/读数, 不满就补)。
        启动轴开局能量常常不够: R 不亮就跳过(见 try_r_quick), 不攒能量。
        """
        self.macro_spam(self.DL_A3_WINDOW, self.A_INTERVAL, tag=f'{tag}3A')
        self.dl_e_2a_heavy(dl, tag, check_e=False)
        if self.try_r_quick(dl, f'{tag}R'):
            self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.DL_R_ANIM_MIN, time_out=self.DL_R_ANIM_CAP)
        else:
            self.logger.info(f'{tag}: 卜灵启动段 R 没亮(开局能量不够), 跳过不攒 — 先把轴跑起来')
        self.spam_key(dl.send_echo_key, self.DL_Q_WINDOW, tag=f'{tag}Q', presses=self.DL_Q_PRESSES)
        dl.record_echo_use()
        return self.dl_hand_off(dl, so, tag, glow_only=self.LQ_DL_GLOW_ONLY)

    def seg_lq_dl(self, dl, so, tag):
        """(LQ) 卜灵·循环段(心变奏进来, HUD 回来之后): 3A -> E -> 2A -> 增强重击 -> [有处决提示就处决] -> Q -> R
        -> R 前协奏够就演出里切锁暝, 不够演完补满再变奏锁暝。处决放在增强重击之后(DL_BREAK_AFTER_HEAVY)。"""
        t_in = time.time()
        if not dl.has_intro:
            self.macro_mark(f'{tag}无变奏')
        seen = getattr(self, 'break_seen_at', None)
        seen_before = seen is not None and t_in - seen < self.BREAK_SEEN_FRESH
        self.break_seen_at = None
        self.macro_spam(self.DL_A3_WINDOW, self.A_INTERVAL, tag=f'{tag}3A')
        heavy_at = self.dl_e_2a_heavy(dl, tag, check_e=True)
        if self.DL_BREAK:
            self.dl_break(f'{tag}', t_in, seen_before,
                          press_not_before=heavy_at + self.DL_BREAK_AFTER_HEAVY if heavy_at else 0.0)
        return self.dl_qr_switch(dl, so, tag, glow_only=self.LQ_DL_GLOW_ONLY)

    # ==================== 处决(通用: 只看屏幕中间的 F 提示) ====================

    def break_prompt(self):
        """怪身上有处决提示(屏幕中间那个 F, 排除拾取 F)。读当前帧。"""
        task = self.task
        try:
            hit = task.find_one('f_break',
                                box=task.box_of_screen(0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True),
                                target_height=720, threshold=self.BREAK_CENTER_MIN)
            return bool(hit) and not task.is_pick_f()
        except Exception as e:
            self.logger.info(f'处决提示读失败 {e}')
            return False

    def break_ring(self):
        """boss 头像外圈满了(共振度满, 能处决)。读当前帧。没有 boss 血条的怪永远 False。"""
        try:
            return bool(self.task.find_one('f_break_full', threshold=self.BREAK_RING_MIN))
        except Exception:
            return False

    def note_break_prompt(self):
        """切给卜灵之前读一帧处决提示: 小怪没有外圈, 靠这一下决定卜灵入场后要不要等提示回来。"""
        self.task.next_frame()
        if self.hud_ok() and self.break_prompt():
            self.break_seen_at = time.time()

    def break_press(self, tag):
        """提示在就按 F, 按完 BREAK_RESEND 提示还在再按; 提示连 BREAK_GONE_FRAMES 帧不见 = 起手了。
        返回(起手前最后一下 F 的时刻 或 None, 按了几下)。"""
        presses = 0
        last_f = 0.0
        gone = 0
        while True:
            if gone == 0 and time.time() - last_f >= self.BREAK_RESEND:
                if presses >= self.BREAK_PRESSES:
                    return None, presses
                self.task.send_key('f', down_time=0.05)
                presses += 1
                last_f = time.time()
            self.macro_wait(0.03)
            self.task.next_frame()
            if self.hud_ok() and self.break_prompt():
                gone = 0
            else:
                gone += 1
                if gone >= self.BREAK_GONE_FRAMES:
                    return last_f, presses

    def dl_break(self, tag, t_in, seen_before, press_not_before=0.0):
        """卜灵那一下处决。外圈满着 / 切人前读到过提示 -> 盯提示到 t_in + DL_BREAK_UNTIL;
        都没有 -> 只读 BREAK_READS 帧。有提示也等到 press_not_before 才按(别打断增强重击)。
        按到提示消失, 从生效那一下起等 BREAK_ANIM; 等完提示还在就再来一轮。返回处决了没有。"""
        ring = self.break_ring()
        armed = ring or seen_before
        deadline = t_in + self.DL_BREAK_UNTIL if armed else 0.0
        start = time.time()
        reads = 0
        while True:
            self.task.next_frame()
            if self.hud_ok() and self.break_prompt():
                break
            reads += 1
            if reads >= self.BREAK_READS and time.time() >= deadline:
                if armed:
                    self.macro_mark(f'{tag}处决提示没出来(圈{int(ring)},{time.time() - start:.2f}s)')
                    self.logger.info(f'{tag}: 外圈满着/切人前见过提示, 但 HUD 回来 {self.DL_BREAK_UNTIL:.1f}s 内'
                                     f'中间的 F 提示一直没出来(离怪太远/镜头没转回来?), 不处决')
                return False
            self.macro_wait(0.02)
        waited = time.time() - start
        self.wait_until_time(press_not_before)
        total = 0
        for rnd in range(self.BREAK_ROUNDS):
            hit_at, n = self.break_press(tag)
            total += n
            try:
                self.task.can_break = False
            except Exception:
                pass
            if hit_at is None:
                self.macro_mark(f'{tag}处决?(F x{total},提示一直在)')
                self.logger.warning(f'{tag}: 处决 F 按了 {total} 下提示一直没消失(一直被吞?), 不等了')
                return False
            self.wait_until_time(hit_at + self.BREAK_ANIM)
            self.wait_hud_up(cap=1.0, tag=f'{tag}处决后HUD')
            again = False
            for _ in range(2):
                self.task.next_frame()
                if self.hud_ok() and self.break_prompt():
                    again = True
                    break
            if not again:
                self.macro_mark(f'{tag}处决(F x{total},等提示{waited:.2f}s,圈{int(ring)}->{int(self.break_ring())})')
                return True
            self.macro_mark(f'{tag}处决没上(提示还在, 第{rnd + 2}轮)')
        self.logger.warning(f'{tag}: 处决按了 {self.BREAK_ROUNDS} 轮提示还在, 不等了')
        return False

    # ==================== 心 ====================

    def xn_gauge(self):
        """应世心条 -> (左半, 右半) 有紫色的列占比。读当前帧, 调用方负责 next_frame。"""
        frame = self.task.frame
        out = []
        for x1, y1, x2, y2 in (self.XN_GAUGE_L, self.XN_GAUGE_R):
            box = self.task.box_of_screen_scaled(3840, 2160, x1, y1, x2, y2, hcenter=True)
            crop = frame[box.y:box.y + box.height, box.x:box.x + box.width, :3]
            if crop.size == 0:
                return 0.0, 0.0
            hsv = cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_BGR2HSV)
            h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
            purple = (h >= 125) & (h <= 160) & (sat >= 70) & (v >= 90)
            out.append(float(purple.any(axis=0).mean()))
        return out[0], out[1]

    def xn_ying(self):
        """应世心 -> (满没满, 左半紫, 右半紫)。满 = 重击位的花图标 hsin_h1; 没满时条是紫色格子。读当前帧。"""
        try:
            full = bool(self.task.find_one('hsin_h1', threshold=self.XN_FULL_THRESHOLD))
        except Exception:
            full = False
        L, R = self.xn_gauge()
        return full, L, R

    def xn_icon(self, name):
        """心技能栏的图标模板(hsin_lib1 = 转相 / hsin_lib2 = 万阙垂天解锁)。读当前帧。"""
        try:
            return bool(self.task.find_one(name, threshold=0.7))
        except Exception:
            return False

    def xn_attack_down(self):
        return self.attack_down(self.XN_HOLD_SENDINPUT and self.game_foreground())

    def xn_fill_until_ready(self, tag, not_before=0.0):
        """连续点普攻(XN1_TAP_EVERY 一下), 每帧读应世心条, 打满 XN1_MIN_A 下、到线、而且过了 not_before 就返回。
        返回 'ready' 到线 / 'late' 到点差一点 / 'cap' 补到上限 / 'blind' 条读不出来。"""
        start = time.time()
        taps = 0
        next_tap = 0.0
        hits = 0
        valid_seen = False
        last_r = 0.0
        trace = []
        while True:
            now = time.time()
            if now >= next_tap:
                self.tap(self.XN1_A_HOLD)
                taps += 1
                next_tap = time.time() + max(0.0, self.XN1_TAP_EVERY - self.XN1_A_HOLD)
            self.task.next_frame()
            el = time.time() - start
            if self.hud_ok():
                full, L, R = self.xn_ying()
                if len(trace) < 30:
                    trace.append(f'{el:.2f}:{"满" if full else ""}{L:.2f}/{R:.2f}')
                if full or L >= self.XN_GAUGE_VALID:
                    valid_seen = True
                    last_r = 1.0 if full else R
                    hits = hits + 1 if (full or R >= self.XN_YING_READY) else 0
                    if taps >= self.XN1_MIN_A and hits >= self.XN1_GAUGE_CONFIRM and time.time() >= not_before:
                        self.macro_mark(f'{tag}应世心到线({R:.2f},A x{taps},{el:.2f}s)')
                        return 'ready'
                    if el >= self.XN1_LATE_AT and R >= self.XN_YING_LATE:
                        self.macro_mark(f'{tag}应世心将满({R:.2f},A x{taps},{el:.2f}s)')
                        return 'late'
            if el >= self.XN1_BLIND_AT and not valid_seen:
                self.macro_mark(f'{tag}应世心读不到(A x{taps}, 照按)')
                self.logger.info(f'{tag}: 应世心条读不出来 — {" ".join(trace)}')
                return 'blind'
            if el >= self.XN1_FILL_CAP:
                self.macro_mark(f'{tag}应世心不够(cap,{last_r:.2f},A x{taps})')
                self.logger.info(f'{tag}: 应世心补到上限还没到线 — {" ".join(trace)}')
                return 'cap'
            self.macro_wait(0.02)

    def xn1_entry_fill(self, xn, tag, sw):
        """心1 进场: 花图标(应世心满)连 2 帧就按住; 没亮就从 XN1_ENTRY_TAP_FROM 起点普攻补, 亮了再按住。"""
        self.wait_until_time(sw + self.XN1_FULL_FROM)
        tap_from = sw + self.XN1_ENTRY_TAP_FROM
        next_tap = tap_from
        taps = hits = 0
        valid_seen = False
        L = R = 0.0
        why = 'cap'
        while time.time() < tap_from + self.XN1_FILL_CAP:
            if time.time() >= next_tap:
                self.tap(self.XN1_A_HOLD)
                taps += 1
                next_tap = time.time() + max(0.0, self.XN1_TAP_EVERY - self.XN1_A_HOLD)
            self.task.next_frame()
            ok = False
            if self.hud_ok() and self.char_on_field(xn):
                full, L, R = self.xn_ying()
                valid_seen = valid_seen or full or L >= self.XN_GAUGE_VALID
                ok = full
            hits = hits + 1 if ok else 0
            if hits >= 2:
                why = 'full'
                break
            if not valid_seen and time.time() >= tap_from + self.XN1_BLIND_AT:
                why = 'blind'
                break
            self.macro_wait(0.02)
        el = time.time() - sw
        if why == 'full' and taps == 0:
            self.macro_mark(f'{tag}上场应世心就满({el:.2f}s)')
            self.wait_until_time(sw + self.XN1_FULL_HOLD_AT)
        elif why == 'full':
            self.macro_mark(f'{tag}普攻补满应世心(A x{taps},{el:.2f}s)')
        else:
            self.macro_mark(f'{tag}应世心{"读不到" if why == "blind" else "不够"}'
                            f'(照按,{L:.2f}/{R:.2f},A x{taps},{el:.2f}s)')

    def xn_hold_burn(self, tag):
        """按住重击 XN1_HOLD 秒, 期间看应世心条有没有被清空(= 步红尘出手)。

        返回 (状态, 清空时刻, 按下时刻)。状态:
          'burned'  清空了(时刻可能是 None: 按住期间没读到那一帧, 松手后读到是空的)
          'full'    松手后条还在 = 出的是普通重击(条差太多/被打断) -> 调用方补 A 再按
          'unknown' 条一次都没读出来, 不知道 -> 不重按(重按落在步红尘演出里会再起一个重击)
        """
        si = self.xn_attack_down()
        start = time.time()
        press_at = start
        self.macro_mark(f'{tag}按住({"SI" if si else "PM"})')
        seen_full = False
        burned_at = None
        low_at = None
        icon_since = None
        stale = 0
        lit_at_press = None
        lit_hits = 0
        trace = []
        try:
            while time.time() - press_at < self.XN1_HOLD:
                self.task.next_frame()
                if self.hud_ok() and burned_at is None:
                    now = time.time()
                    full, L, R = self.xn_ying()
                    if len(trace) < 30:
                        trace.append(f'{now - start:.2f}:{"满" if full else ""}{L:.2f}/{R:.2f}')
                    if lit_at_press is None:
                        lit_at_press = full
                    lit_hits = lit_hits + 1 if full else 0
                    if not lit_at_press and lit_hits >= 2 and stale < self.XN1_STALE_MAX:
                        stale += 1
                        self.release_attack()
                        self.macro_wait(0.05)
                        self.xn_attack_down()
                        press_at = time.time()
                        lit_at_press = True
                        icon_since = None
                        self.macro_mark(f'{tag}按下后才满,重按({now - start:.2f}s)')
                        continue
                    icon_since = (icon_since or now) if full else None
                    if (full and stale < self.XN1_STALE_MAX and now - press_at >= self.XN1_STALE_MIN
                            and now - icon_since >= self.XN1_STALE_FULL):
                        stale += 1
                        self.release_attack()
                        self.macro_wait(0.05)
                        self.xn_attack_down()
                        press_at = time.time()
                        icon_since = None
                        self.macro_mark(f'{tag}满了没出,重按({now - start:.2f}s)')
                        continue
                    if full or L >= self.XN_GAUGE_VALID:
                        seen_full = True
                        low_at = None
                    elif seen_full and L < self.XN_CONSUMED:
                        # 连着两帧空才算(特效闪一下会压暗一帧); 时刻记第一帧 —— 转相解锁从这一刻算
                        if low_at is None:
                            low_at = now
                        else:
                            burned_at = low_at
                            self.macro_mark(f'{tag}步红尘出手({burned_at - start:.2f}s)')
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        if burned_at is not None:
            self.macro_mark(f'{tag}松开')
            return 'burned', burned_at, start
        # 按住期间没读到清空: 松手后再读两帧, 条还在 = 真没出步红尘
        full = empty = 0
        for _ in range(6):
            self.task.next_frame()
            if self.hud_ok():
                is_full, L, R = self.xn_ying()
                if is_full or L >= self.XN_GAUGE_VALID:
                    full += 1
                    seen_full = True
                elif seen_full and L < self.XN_CONSUMED:
                    empty += 1
                if full >= 2 or empty >= 2:
                    break
            self.macro_wait(0.02)
        state = 'full' if full >= 2 else ('burned' if empty >= 2 else 'unknown')
        self.macro_mark(f'{tag}松开({state})')
        self.logger.info(f'{tag}: 按住 {self.XN1_HOLD:.1f}s 没读到应世心清空 -> {state} — {" ".join(trace)}')
        return state, None, start

    def xn_r1_ready(self):
        """转相能不能按: R 图标是转相(hsin_lib1)而且亮着。读当前帧。

        不查 CD(check_cd=False): 那一路每换一帧就 OCR 一次技能栏, 解锁那 0.3s 的窗口里读不了几次; 转相也没有 CD 数字。
        【用真的心对象读】: available() 只在 is_current_char 时读当前技能栏, 否则按 index 读 CD。
        """
        xn = getattr(self, 'xn_char', None) or self
        try:
            lit = bool(xn.available('liberation', check_color=True, check_cd=False))
        except Exception:
            lit = False
        return lit and self.xn_icon('hsin_lib1')

    def seg_xn1(self, xn, so, tag):
        """心·第一段(变奏·应世相): 进场先放声骸 -> 连续 A 到应世心到线(至少两下) -> 按住出步红尘
        -> 转相解锁 -> 转相 -> 演完 -> 照世相 E -> 同奏切锁暝。"""
        sw = self.switch_press_at
        if not xn.has_intro:
            # 没变奏入场(锁暝 R 没出 / 协奏没满): 应世心是 0, 步红尘打不出、转相也解锁不了,
            # 硬补 A + 转相补救会白耗十几秒。普攻攒一小段就交棒, 让后面那半先走完。
            self.logger.warning(f'{tag}: 心1 没变奏入场(锁暝 R 没出?), 只普攻攒一下, 不硬等转相')
            self.macro_spam(2.0, self.A_INTERVAL, tag=f'{tag}无变奏A')
            self.need(self.switch_retry(so, f'{tag}切锁暝', assume_con=False), 'hsin -> suoming')
            return False
        if self.LQ_XN1_ECHO:
            self.xn_echo(xn, tag, sw)
        if self.XN1_SKIP_A_WHEN_FULL:
            self.xn1_entry_fill(xn, tag, sw)
        else:
            self.wait_until_time(sw + self.XN1_A1_AT)
            self.xn_fill_until_ready(tag, not_before=sw + self.XN1_HOLD_NOT_BEFORE)

        state = 'unknown'
        hold_at = burned_at = None
        for attempt in range(1 + self.XN1_RETRIES):
            if attempt > 0:
                # 上一次松手后条还在 = 出的是普通重击: 花图标亮着就直接重按, 没亮补两下 A 再按
                self.task.next_frame()
                lit = self.hud_ok() and self.xn_ying()[0]
                if not lit:
                    for _ in range(self.XN1_RETRY_A):
                        self.tap(self.XN1_A_HOLD)
                        self.macro_wait(self.XN1_FILL_EVERY)
                self.macro_mark(f'{tag}重击重按#{attempt}{"(亮着)" if lit else ""}')
            state, burned_at, hold_at = self.xn_hold_burn(f'{tag}重击' if attempt == 0 else f'{tag}重击#{attempt}')
            if state != 'full':
                break
        fired = False
        if state == 'full':
            # 步红尘没出, 转相不会解锁, 连按 R 白等: 直接走补救
            self.logger.warning(f'{tag}: 重按 {self.XN1_RETRIES} 次应世心都没清空(步红尘没出), 转相多半放不出来')
        else:
            if self.XN1_ECHO:
                xn.send_echo_key(down_time=0.05)
                xn.record_echo_use()
                self.macro_wait(0.05)
            fired = self.fire_r(xn, f'{tag}转相', self.XN1_R1_SPAM)
            if fired and burned_at is not None:
                self.macro_mark(f'{tag}转相出手(清空后{time.time() - burned_at:.2f}s)')
        if not fired:
            fired = self.xn_r1_rescue(xn, tag)
        if not fired:
            self.logger.warning(f'{tag}: 补了 {self.XN1_R1_RESCUE_CAP:.0f}s 转相还是没放出去 — '
                                f'锁暝拿不到同奏(进不了念深), 照常往下走')
        else:
            self.wait_hud_back(tag=f'{tag}转相演出', min_gone=self.XN_R_ANIM_MIN, time_out=self.XN_R_ANIM_CAP)
            if self.LQ_XN1_E:
                # 照世相 E 跟应世相 E 冷却分开, 不记 last_res
                self.press_res_until_cd(xn, self.LQ_XN1_E_CAP, f'{tag}照世相E', ready_grace=0.15)
        # 同奏 5 秒: 转相一演完立刻切, 锁暝不用满协奏也是变奏入场(响应同奏 -> 锁妄念·同奏, 进念深)
        self.need(self.switch_retry(so, f'{tag}切锁暝', assume_con=fired), 'hsin -> suoming')
        return fired

    def xn_echo(self, xn, tag, sw):
        """心1 进场放声骸: 切人键 + LQ_XN1_ECHO_AT 后(技能栏换成心的)读声骸 CD, 好着就按到 CD 涨上来。"""
        self.wait_until_time(sw + self.LQ_XN1_ECHO_AT)
        self.task.next_frame()
        if self.char_on_field(xn) and self.read_cd('echo', xn) > self.SO_ECHO_RISE:
            self.macro_mark(f'{tag}声骸冷却中')
            return False
        return self.so_echo(xn, f'{tag}Q', cap=self.LQ_XN1_ECHO_CAP)

    def xn_r1_rescue(self, xn, tag):
        """转相第一次没放出去: 补到放出去为止(上限 XN1_R1_RESCUE_CAP)。返回放出去没有。

        每一轮看现在卡在哪:
          转相图标亮着(连两帧)       -> 按 R(被吞了就再来)
          应世心是满的(花图标 / 右半到线) -> 再按住出步红尘, 清空后等解锁
          都不是                     -> 普攻攒应世心
          HUD 不在(被击飞/演出)       -> 等它回来
        一直既看不到转相图标也读不到应世心条 = 已经进照世相了(转相其实出了), 不再按 R ——
        照世相里按 R 放的是借相。
        """
        start = time.time()
        rounds = 0
        lost = 0
        self.macro_mark(f'{tag}转相补救开始')
        while time.time() - start < self.XN1_R1_RESCUE_CAP:
            rounds += 1
            self.task.next_frame()
            if not self.hud_ok():
                self.wait_hud_up(cap=1.0, tag=f'{tag}转相补救等HUD')
                continue
            lit = 0
            for _ in range(self.XN1_R1_READS):
                if self.xn_r1_ready():
                    lit += 1
                self.task.next_frame()
            if lit >= self.XN1_R1_READS:
                lost = 0
                if self.fire_r(xn, f'{tag}转相补#{rounds}', self.XN_R_WINDOW):
                    self.macro_mark(f'{tag}转相补救成功({time.time() - start:.2f}s)')
                    return True
                continue
            full, L, R = self.xn_ying()
            if full or L >= self.XN_GAUGE_VALID or self.xn_icon('hsin_lib1'):
                lost = 0
            else:
                lost += 1
                if lost >= self.XN1_R1_LOST_ROUNDS:
                    self.macro_mark(f'{tag}转相补救: 已不在应世相(当转相出过了)')
                    return True
            if full or (L >= self.XN_GAUGE_VALID and R >= self.XN_YING_READY):
                state, burned_at, _hold_at = self.xn_hold_burn(f'{tag}补步红尘#{rounds}')
                if state == 'burned':
                    # 清空后 2.06s 解锁: 等到点(期间亮了就提前走), 下一轮去按
                    anchor = burned_at if burned_at is not None else time.time() - 0.3
                    due = anchor + self.XN1_R1_UNLOCK + self.XN1_R1_MARGIN
                    while time.time() < due:
                        self.task.next_frame()
                        if self.hud_ok() and self.xn_r1_ready():
                            break
                        self.macro_wait(0.01)
                continue
            self.macro_spam(self.XN1_R1_RESCUE_A, self.XN1_FILL_EVERY, tag=f'{tag}补应世心A#{rounds}')
        self.macro_mark(f'{tag}转相补救(cap,{rounds}轮)')
        return False

    def xn_hold_until_gone(self, cap, tag, watch_ready=False, stall=None):
        """按住左键到队伍 HUD 消失(临寰宇出手)。消失后再按 XN2_RELEASE_AFTER_GONE 秒松手。返回出手没有。

        watch_ready: 按住期间看重击位, 人像出来 XN2_READY_REPRESS 还没出手 = 这一下按住断了, 松开重按。
        stall: 按住期间数雕像, 这么多秒没再翻一颗也没出手就松手返回(交给调用方普攻补完再按)。
        """
        si = self.xn_attack_down()
        start = time.time()
        self.macro_mark(f'{tag}按住({"SI" if si else "PM"})')
        gone = 0
        fired = False
        ready_since = None
        repress = 0
        last_count = None
        moved_at = start
        try:
            while time.time() - start < cap:
                self.task.next_frame()
                if not self.hud_ok():
                    gone += 1
                    if gone >= self.LIB_GONE_CONFIRM:
                        fired = True
                        break
                else:
                    gone = 0
                    if stall is not None:
                        try:
                            count = self.xn_statue_count()
                        except Exception as e:
                            count = last_count
                            self.logger.info(f'xn_statue_count failed ({e})')
                        if count != last_count:
                            last_count = count
                            moved_at = time.time()
                        elif time.time() - moved_at >= stall:
                            self.macro_mark(f'{tag}停在{count}颗({time.time() - start:.2f}s)')
                            break
                    if watch_ready and repress < self.XN2_REPRESS_MAX:
                        if self.xn_slot_state() == 'ready':
                            ready_since = ready_since or time.time()
                            if time.time() - ready_since >= self.XN2_READY_REPRESS:
                                repress += 1
                                ready_since = None
                                self.release_attack()
                                self.macro_wait(0.05)
                                self.xn_attack_down()
                                self.macro_mark(f'{tag}人像出来没出手,重按#{repress}({time.time() - start:.2f}s)')
                        else:
                            ready_since = None
                self.macro_wait(0.02)
            if fired:
                self.macro_mark(f'{tag}临寰宇出手({time.time() - start:.2f}s)')
                self.macro_wait(self.XN2_RELEASE_AFTER_GONE)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}松开({"出手" if fired else "没出"})')
        return fired

    @staticmethod
    def glyph_vec(a):
        v = a.astype(np.float32).flatten()
        v = v - v.mean()
        n = float(np.linalg.norm(v))
        return v / n if n > 0 else v

    def xn_slot_glyph(self):
        """重击位 16x16 灰度(只取圆内像素), 已归一化。心不在场/HUD 不在返回 None。读当前帧。"""
        xn = getattr(self, 'xn_char', None) or self
        in_team, index, _count = self.task.in_team()
        if not in_team or index != xn.index:
            return None
        self.hud_seen_at = time.time()
        ref = getattr(self, '_slot_ref', None)
        if ref is None:
            yy, xx = np.mgrid[:96, :96]
            disk = ((((xx - 48) ** 2 + (yy - 44) ** 2) <= 25 ** 2)).astype(np.float32)
            mask = cv2.resize(disk[18:70, 22:74], (16, 16), interpolation=cv2.INTER_AREA) > 0.99

            def tpl(chunks):
                raw = base64.b64decode(''.join(chunks))
                return self.glyph_vec(np.frombuffer(raw, np.uint8).reshape(16, 16).astype(np.float32)[mask])

            ref = self._slot_ref = (mask, disk, tpl(self.XN_TY_GLYPH), tpl(self.XN_READY_GLYPH))
        mask, disk, _ty, _rd = ref
        x, y, w, h = self.XN_TY_SLOT
        box = self.task.box_of_screen_scaled(3840, 2160, x, y, x + w, y + h, hcenter=True)
        frame = self.task.frame
        cx, cy = int(box.x + box.width / 2), int(box.y + box.height / 2)
        half = int(box.height * 1.1)
        icon = frame[max(0, cy - half):cy + half, max(0, cx - half):cx + half, :3]
        g = cv2.cvtColor(cv2.resize(icon, (96, 96), interpolation=cv2.INTER_AREA),
                         cv2.COLOR_BGR2GRAY).astype(np.float32) * disk
        v = cv2.resize(g[18:70, 22:74], (16, 16), interpolation=cv2.INTER_AREA)
        return self.glyph_vec(v[mask])

    def xn_slot_state(self):
        """统御众机里重击位: 'statue'(照世心还没打空) / 'ready'(人像, 临寰宇可按) / '?' / None(HUD 不在)。读当前帧。"""
        try:
            v = self.xn_slot_glyph()
            if v is None:
                return None
            _mask, _disk, ty, rd = self._slot_ref
            self._ty_score = float(v @ ty)
            self._rd_score = float(v @ rd)
            if self._rd_score >= self.XN_READY_MIN:
                return 'ready'
            if self._ty_score >= self.XN_TY_MIN:
                return 'statue'
            return '?'
        except Exception as e:
            self.logger.info(f'xn_slot_state probe failed ({e})')
            return '?'

    def dodge(self, tag):
        """闪避(右键)。"""
        self.task.mouse_down(key='right')
        try:
            self.macro_wait(self.XN2_DODGE_HOLD)
        finally:
            self.task.mouse_up(key='right')
        self.macro_mark(f'{tag}闪避')

    def xn_statue_reset(self):
        self._statue_streak = [0] * len(self.XN_STATUE_XS)
        self._statue_latch = [False] * len(self.XN_STATUE_XS)

    def xn_statue_count(self):
        """照世心雕像从右往左连续翻了几颗(翻过的记住, 每次进统御众机先 xn_statue_reset)。读当前帧。
        照抄心雷穗 v1.1.0, 加了一条: 同一帧新记住 >= XN_STATUE_BURST 颗 = 闪光, 这一帧不算。"""
        frame = self.task.frame
        hw = self.XN_STATUE_HW
        newly = []
        for k, x in enumerate(self.XN_STATUE_XS):
            if self._statue_latch[k]:
                continue
            red = glow = 0.0
            for y, kind in ((self.XN_STATUE_Y, 'red'), (self.XN_STATUE_UP_Y, 'glow')):
                box = self.task.box_of_screen_scaled(3840, 2160, x - hw, y - hw, x + hw, y + hw, hcenter=True)
                crop = frame[box.y:box.y + box.height, box.x:box.x + box.width, :3]
                if crop.size == 0:
                    continue
                hsv = cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_BGR2HSV)
                h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
                if kind == 'red':
                    red = float((((h < 12) | (h > 160)) & (sat > 90) & (v > 110)).mean())
                else:
                    glow = float(((v > 235) & (sat < 60)).mean())
            hit = red >= self.XN_STATUE_RED or glow >= self.XN_STATUE_GLOW
            self._statue_streak[k] = self._statue_streak[k] + 1 if hit else 0
            if self._statue_streak[k] >= self.XN_STATUE_CONFIRM:
                newly.append(k)
        if len(newly) >= self.XN_STATUE_BURST:
            for k in newly:
                self._statue_streak[k] = 0
        else:
            for k in newly:
                self._statue_latch[k] = True
        n = 0
        for latched in reversed(self._statue_latch):
            if not latched:
                break
            n += 1
        return n

    def xn_ty_attack(self, tag, start, until_count, min_t, cap_t, every=None):
        """统御众机里点普攻(every 一下, 默认 XN2_TY_A_EVERY), 每帧数雕像、看重击位。时间从 start 起算:
        min_t 之前不停; 翻满 until_count 颗(或人像出来)就停; 到 cap_t 照停。返回 (原因, 翻了几颗)。"""
        every = self.XN2_TY_A_EVERY if every is None else every
        n = 0
        next_click = 0.0
        count = 0
        ready_hits = 0
        counts = []
        last_count = -1
        why = 'cap'
        while time.time() - start < cap_t:
            if time.time() >= next_click:
                self.tap()
                n += 1
                next_click = time.time() + max(0.0, every - self.A_TAP)
            self.task.next_frame()
            st = self.xn_slot_state()
            if st is not None:
                try:
                    count = self.xn_statue_count()
                except Exception as e:
                    self.logger.info(f'xn_statue_count failed ({e})')
                if count != last_count:
                    last_count = count
                    if len(counts) < 12:
                        counts.append(f'{count}@{time.time() - start:.2f}')
            ready_hits = ready_hits + 1 if st == 'ready' else 0
            if ready_hits >= self.XN2_READY_CONFIRM:
                why = 'ready'
                break
            if count >= until_count and time.time() - start >= min_t:
                why = 'count'
                break
            self.macro_wait(0.01)
        self.macro_mark(f'{tag}(A x{n},翻{count},{why},{time.time() - start:.2f}s)')
        if counts:
            self.logger.info(f'{tag}: 照世心雕像翻面(颗@秒) — {" ".join(counts)}')
        return why, count

    def xn_tongyu_phase(self, tag, cap):
        """统御众机里一直普攻到重击位换成人像(照世心打空)。返回 'ready'(人像连读几帧) / 'cap'(到上限没看到人像)。"""
        start = time.time()
        n = 0
        next_click = 0.0
        hits = 0
        why = 'cap'
        last = None
        statue_seen = False
        while time.time() - start < cap:
            now = time.time()
            if now >= next_click:
                self.tap()
                n += 1
                next_click = time.time() + max(0.0, self.XN2_TY_A_EVERY - self.A_TAP)
            self.task.next_frame()
            st = self.xn_slot_state()
            last = st
            statue_seen = statue_seen or st == 'statue'
            hits = hits + 1 if st == 'ready' else 0
            if hits >= self.XN2_READY_CONFIRM:
                why = 'ready'
                break
            self.macro_wait(0.01)
        self.macro_mark(f'{tag}照世心{"打空" if why == "ready" else "没看到打空(cap)"}'
                        f'(A x{n},{time.time() - start:.2f}s{"" if statue_seen else ",没见过雕像"})')
        if why != 'ready':
            self.logger.info(f'{tag}: {cap:.1f}s 没看到重击位换人像(最后读成 {last}, '
                             f'雕像{getattr(self, "_ty_score", -1):.2f} 人像{getattr(self, "_rd_score", -1):.2f})')
        return why

    def seg_xn2(self, xn, intro, tag, opener=False):
        """心·第二段(变奏·照世相, 直接进统御众机): 普攻到第 5 颗雕像(A3 楼阁打中) -> 闪避 -> 普攻到第 7 颗
        -> 按住到临寰宇(雕像停住/按住断了就松开补普攻再按) -> 演完 -> Q -> 万阙垂天(只认 hsin_lib2)
        -> [演出快完按住普攻、按过白屏时停 -> 重击] -> [E] -> 协奏补满(交棒给调用方)。
        不放声骸(心的声骸挪到心1 进场)。"""
        heavy = self.LQ_XN2_R2_HEAVY_OPENER if opener else self.LQ_XN2_R2_HEAVY
        if not intro:
            # 没变奏·照世相 = 进不了统御众机(照世心 0、重击位不是人像): 雕像翻不动、人像不出来,
            # 硬打只会白耗十几秒。普攻补满协奏就交棒, 后面 run_cycle 会切回卜灵。
            self.logger.warning(f'{tag}: 心2 没变奏入场(锁暝协奏没满?), 不进统御众机, 补协奏后交棒')
            self.macro_spam(1.8, self.A_INTERVAL, tag=f'{tag}无变奏A')
            self.xn_ensure_con(xn, tag)
            return
        self.wait_until_time(self.switch_press_at + self.XN2_LEAD)
        self.xn_statue_reset()
        why, count = self.xn_ty_attack(f'{tag}3A', time.time(), self.LQ_XN2_DODGE_COUNT, self.XN2_DODGE_MIN,
                                       self.LQ_XN2_DODGE_CAP)
        if why != 'ready':
            self.dodge(tag)
            self.macro_wait(self.XN2_DODGE_TO_A)
            self.xn_ty_attack(f'{tag}闪后2A', time.time(), self.XN2_HOLD_AT, 0.0, self.XN2_EMPTY_CAP,
                              every=self.XN2_POST_DODGE_A_EVERY)
        fired = self.xn_hold_until_gone(self.XN2_HOLD_CAP, f'{tag}按住', watch_ready=True,
                                        stall=self.XN2_HOLD_STALL)
        for attempt in range(1, 1 + self.XN2_RETRIES):
            if fired:
                break
            # 按满上限没出(照世心没打空 / 被打断): 普攻到人像再按。没拿到变奏(没进统御众机)时先按一下 E
            if attempt == 1 and not intro:
                self.spam_key(xn.send_resonance_key, 0.2, interval=0.06, tag=f'{tag}补E(没变奏)')
                xn.record_resonance_use()
            why = self.xn_tongyu_phase(f'{tag}补#{attempt}', self.XN2_RETRY_CAP)
            fired = self.xn_hold_until_gone(self.XN2_READY_HOLD if why == 'ready' else self.XN2_BLIND_HOLD,
                                            f'{tag}重按#{attempt}', watch_ready=True)
        if not fired:
            self.logger.warning(f'{tag}: 临寰宇一直没出手, 这一轮不放万阙垂天(按 R 会放成借相)')
        else:
            self.wait_hud_back(tag=f'{tag}临寰宇演出', min_gone=self.XN2_ANIM_MIN, time_out=self.XN2_ANIM_CAP)
            if self.XN2_R2_BLIND:
                unlocked = True
            else:
                # 【R 只认 hsin_lib2】: 照世相里 R 一直亮(借相·应世), 只有临寰宇之后、能量够了才换成万阙垂天的图标
                unlocked, t = self.xn_wait_lib2(self.XN2_LIB2_CAP)
                self.macro_mark(f'{tag}万阙垂天{"解锁" if unlocked else "图标没认出(能量不够?)"}({t:.2f}s)')
                if not unlocked:
                    unlocked, t = self.xn_wait_lib2(self.XN2_R2_BUILD_CAP, build=True)
                    self.macro_mark(f'{tag}普攻攒大招能量({"认出万阙垂天" if unlocked else "cap"},{t:.2f}s)')
            fired = False
            wave = True
            for attempt in range(2):
                if not unlocked:
                    break
                if attempt == 0:
                    if self.XN2_PRE_R2:
                        self.xn_pre_r2_con(tag)
                    if self.LQ_XN2_ECHO:
                        xn.send_echo_key(down_time=0.05)
                        xn.record_echo_use()
                        self.macro_wait(0.05)
                fired = self.fire_r(xn, f'{tag}万阙垂天' if attempt == 0 else f'{tag}万阙垂天重按',
                                    self.XN_R_WINDOW)
                if fired:
                    self.wait_hud_back(tag=f'{tag}万阙垂天演出', min_gone=self.XN_R_ANIM_MIN,
                                       time_out=self.XN_R_ANIM_CAP,
                                       hold_from=self.XN2_R2_HOLD_FROM if heavy else None)
                    back_at = time.time()
                    if heavy and not self.holding_attack:
                        self.xn_attack_down()
                        self.macro_mark(f'{tag}大招后才按住')
                    thaw_at = back_at + self.XN2_R2_FREEZE
                    if self.XN2_R2_WAVE_WAIT and not self.xn_r2_target(tag, back_at):
                        self.release_attack()
                        wave = self.xn_wait_wave(tag)
                        if wave and heavy:
                            self.wait_until_time(thaw_at)
                            self.xn_attack_down()
                            self.macro_wait(self.XN2_R2_FRESH_HOLD)
                            self.release_attack()
                            self.macro_mark(f'{tag}新怪重击松开({self.XN2_R2_FRESH_HOLD:.2f}s)')
                            self.macro_wait(self.XN2_R2_FRESH_E_AT)
                    elif heavy:
                        self.wait_until_time(thaw_at + self.XN2_R2_HEAVY_HOLD)
                        self.release_attack()
                        self.macro_mark(f'{tag}大招后重击松开(解冻+{self.XN2_R2_HEAVY_HOLD:.2f}s)')
                        self.wait_until_time(thaw_at + self.XN2_R2_E_AT)
                    break
                # 没放出去: 认一下 R 位还是不是万阙垂天, 认得出才重按。盲按没出多半是能量不够、已经放成借相
                if self.XN2_R2_BLIND:
                    unlocked, t = self.xn_wait_lib2(self.XN2_LIB2_CAP)
                else:
                    unlocked, t = self.xn_wait_lib2(1.50, build=True)
            if not fired:
                self.logger.warning(f'{tag}: 万阙垂天没放出去'
                                    f'({"能量攒不满/图标没认出, 不照按(会放成借相)" if not unlocked else "按了没出"})')
            elif not wave:
                self.macro_mark(f'{tag}没等到新怪(不重击不E)')
            elif self.XN2_E_AFTER_R2 and time.time() - getattr(xn, 'last_res', 0) >= self.XN_E_CD:
                if self.press_res_until_cd(xn, self.XN2_E_CAP, f'{tag}E偷伤害', ready_grace=0.15):
                    xn.record_resonance_use()
            if fired and heavy and self.XN2_TAIL_A:
                self.xn_tail_ying(tag, back_at)
        self.xn_ensure_con(xn, tag)

    def target_visible(self):
        """锁定目标在不在。照 CombatCheck.has_target() 的读框, 去掉它最后那个兜底分支 ——
        那个分支会 sleep(1) 再连按两次 ESC, 不能在轴里调。"""
        t = self.task
        try:
            has_name, no_name = t.get_target_names()
            scale = 1.2 if t.is_browser() else 1.1
            for box in (t.get_box_by_name(has_name).scale(scale), t.get_box_by_name('box_target_enemy_long'),
                        t.get_box_by_name('target_box_long2')):
                best = t.find_best_match_in_box(box, [has_name, no_name], threshold=0.6)
                if best:
                    return best.name == has_name
        except Exception as e:
            # 别的 ok-ww 版本这几个读框/方法可能改名了: 当成有怪, 退回"不等新怪、照常重击 + E"
            if not getattr(self, '_target_visible_warned', False):
                self._target_visible_warned = True
                self.logger.warning(f'xss target_visible unsupported in this ok-ww version ({e!r}), '
                                    f'assuming a target is there')
            return True
        return False

    def xn_enemy_here(self):
        """场上有没有怪: Boss 破盾/锁图标、怪物血条、锁定目标, 任一个读到就算有。"""
        t = self.task
        try:
            if t.is_boss() or t.has_health_bar():
                return True
        except Exception as e:
            if not getattr(self, '_health_bar_warned', False):
                self._health_bar_warned = True
                self.logger.warning(f'xss is_boss/has_health_bar unsupported in this ok-ww version ({e!r})')
        return self.target_visible()

    def xn_r2_target(self, tag, back_at):
        """万阙垂天 HUD 回来后的时停里看有没有怪: 读到一帧就算有。到 XN2_R2_TARGET_BY 一帧都没读到、
        且读够 TARGET_GONE_CONFIRM 帧 = 没怪; 帧数不够(卡帧)当有怪, 退回原来的预按住重击。"""
        gone = 0
        while time.time() < back_at + self.XN2_R2_TARGET_BY:
            self.task.next_frame()
            if self.xn_enemy_here():
                return True
            gone += 1
        if gone < self.TARGET_GONE_CONFIRM:
            return True
        self.macro_mark(f'{tag}时停里没怪(松手等新一波, {gone}帧)')
        return False

    def xn_wait_wave(self, tag):
        """没怪: 不点普攻(空挥), 每 WAVE_LOCK_INTERVAL 按中键, 连 ENEMY_CONFIRM 帧读到怪就返回 True。"""
        start = time.time()
        next_mid = 0.0
        hits = 0
        while time.time() - start < self.XN2_WAVE_WAIT:
            self.task.next_frame()
            self.hud_ok()
            hits = hits + 1 if self.xn_enemy_here() else 0
            if hits >= self.ENEMY_CONFIRM:
                self.macro_mark(f'{tag}等到新一波({time.time() - start:.2f}s)')
                return True
            if time.time() >= next_mid:
                self.task.middle_click()
                next_mid = time.time() + self.WAVE_LOCK_INTERVAL
            self.macro_wait(0.05)
        self.macro_mark(f'{tag}{self.XN2_WAVE_WAIT:.0f}s没等到新怪')
        return False

    def xn_tail_ying(self, tag, back_at):
        """万阙垂天之后(回到应世相): 普攻到应世心左半 >= XN2_TAIL_YING 再交棒, 上限从 HUD 回来起 XN2_TAIL_CAP。"""
        start = time.time()
        taps = 0
        next_tap = 0.0
        hits = 0
        L = 0.0
        while time.time() < back_at + self.XN2_TAIL_CAP:
            self.task.next_frame()
            if self.hud_ok():
                full, L, R = self.xn_ying()
                hits = hits + 1 if (full or L >= self.XN2_TAIL_YING) else 0
                if hits >= 2:
                    self.macro_mark(f'{tag}收尾应世心({L:.2f},A x{taps},{time.time() - start:.2f}s)')
                    return True
            if time.time() >= next_tap:
                self.tap(self.XN1_A_HOLD)
                taps += 1
                next_tap = time.time() + max(0.0, self.XN1_TAP_EVERY - self.XN1_A_HOLD)
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}收尾应世心(cap,{L:.2f},A x{taps})')
        return False

    def xn_wait_lib2(self, cap, build=False):
        """等 R 位变成万阙垂天(hsin_lib2 连读几帧)。build: 期间点普攻攒大招能量。返回 (认出没有, 用时)。"""
        start = time.time()
        hits = 0
        next_tap = 0.0
        while time.time() - start < cap:
            if build and time.time() >= next_tap:
                self.tap()
                next_tap = time.time() + max(0.0, self.A_INTERVAL - self.A_TAP)
            self.task.next_frame()
            if self.hud_ok():
                hits = hits + 1 if self.xn_icon('hsin_lib2') else 0
                if hits >= self.XN2_LIB2_READS:
                    return True, time.time() - start
            self.macro_wait(0.02)
        return False, time.time() - start

    def xn_pre_r2_con(self, tag):
        """万阙垂天之前: 协奏低于 XN2_PRE_R2_CON 就照世相普攻补(人还贴着怪), 每下之后读一次。"""
        start = time.time()
        con = self.read_con(1.0, settle=0.12)
        if con >= self.XN2_PRE_R2_CON:
            self.macro_mark(f'{tag}开大前协奏{con:.2f}')
            return
        samples = [f'0:{con:.2f}']
        taps = 0
        while time.time() - start < self.XN2_PRE_R2_CAP:
            self.tap()
            taps += 1
            self.macro_wait(max(0.0, self.A_INTERVAL - self.A_TAP))
            con = self.read_con(1.0, settle=0.03)
            if len(samples) < 20:
                samples.append(f'{time.time() - start:.2f}:{con:.2f}')
            if con >= self.XN2_PRE_R2_CON:
                break
        self.macro_mark(f'{tag}开大前补协奏({con:.2f},A x{taps},{time.time() - start:.2f}s)')
        if con < self.XN2_PRE_R2_CON:
            self.logger.info(f'{tag}: 开大前协奏补不到 {self.XN2_PRE_R2_CON:.2f} — {" ".join(samples)}')

    def xn_ensure_con(self, xn, tag):
        """心切卜灵之前协奏要真满: 读一下, 不满就 E -> 普攻, 每下之后读一次。返回满没满。"""
        start = time.time()
        if self.con_ready(xn, self.XN2_CON_READ):
            return True
        samples = [f'0:{self.con_last:.2f}']
        taps = 0
        used_e = False
        while time.time() - start < self.XN2_CON_CAP:
            if not used_e and time.time() - getattr(xn, 'last_res', 0) >= self.XN_E_CD:
                used_e = True
                self.spam_key(xn.send_resonance_key, 0.26, interval=0.06, tag=f'{tag}补协奏E')
                xn.record_resonance_use()
            else:
                self.tap()
                taps += 1
                self.macro_wait(max(0.0, self.A_INTERVAL - self.A_TAP))
            full = self.con_ready(xn, 0.03)
            if len(samples) < 20:
                samples.append(f'{time.time() - start:.2f}:{self.con_last:.2f}')
            if full:
                self.macro_mark(f'{tag}补协奏(满,E{int(used_e)},A x{taps},{time.time() - start:.2f}s)')
                return True
        self.macro_mark(f'{tag}补协奏(cap,E{int(used_e)},A x{taps},{time.time() - start:.2f}s)')
        self.logger.warning(f'{tag}: 心补了 {time.time() - start:.1f}s 协奏还是没满, 卜灵拿不到变奏'
                            f' — {" ".join(samples)}')
        return False

    # ==================== 锁暝 ====================

    def so_forte_full(self, so):
        """妄执满(E 位是锁妄念/无舍念, 框架的 suoming_forte_e 模板)。读当前帧。"""
        try:
            return bool(so.forte_available())
        except Exception:
            return False

    def so_on_field(self, so):
        """队伍 HUD 在场而且当前是 so。读当前帧。"""
        try:
            in_team, index, _count = self.task.in_team()
        except Exception:
            return False
        return bool(in_team) and index == so.index

    def char_on_field(self, char):
        """通用版本: 队伍 HUD 在场而且当前是 char。读当前帧。"""
        return self.so_on_field(char)

    def so_r_asap(self, so, tag, cap, allow_e):
        """(LQ) 锁暝进场就放 R, R 没好(CD / 能量不够)就一直点 A, 好了马上出, 不站着等。
        每下 A 之后顺手按一下 R; 读到 R 亮: 入场动作里一直按, 入场之后连按 LQ_SO_R_BURST, HUD 没消失就回去点 A。
        allow_e: 没变奏入场(念起, R 锁着)时妄执满了点 E 进念深。放出去 = 按过 R 之后 HUD 连续 LIB_GONE_CONFIRM 帧不在。"""
        sw = self.switch_press_at
        start = time.time()
        taps = bursts = r_n = e_taps = 0
        next_tap = 0.0
        burst_until = backoff_until = 0.0
        last_r = -9.0
        next_e = sw + self.LQ_SO_R_E_FROM
        lit_hits = forte_hits = gone = 0
        fired = False
        while time.time() - start < cap:
            self.task.next_frame()
            now = time.time()
            if not self.hud_ok():
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM and now - last_r < 0.6:
                    fired = True
                    break
                self.macro_wait(0.01)
                continue
            gone = 0
            on = self.so_on_field(so)
            try:
                lit = on and bool(so.liberation_available())
            except Exception:
                lit = False
            lit_hits = lit_hits + 1 if lit else 0
            forte_hits = forte_hits + 1 if on and self.so_forte_full(so) else 0
            if now < burst_until:
                so.send_liberation_key()
                r_n += 1
                last_r = now
            elif lit_hits >= 2 and now >= backoff_until:
                bursts += 1
                burst_until = max(now + self.LQ_SO_R_BURST, sw + self.LQ_SO_R_ENTRY)
                # 一直读成亮却按不出 = 能量差一点: 连按越来越稀, 主要靠每下 A 后的那一下 R
                backoff_until = burst_until + self.LQ_SO_R_BACKOFF * bursts
                so.send_liberation_key()
                r_n += 1
                last_r = now
            elif allow_e and forte_hits >= 2 and not lit and now >= next_e:
                self.so_tap_e(so.get_resonance_key())
                so.record_resonance_use()
                e_taps += 1
                next_e = time.time() + 1.0
            elif now >= next_tap:
                self.tap()
                so.send_liberation_key()
                r_n += 1
                taps += 1
                last_r = time.time()
                next_tap = last_r + max(0.0, self.SO_A_EVERY - self.A_TAP)
            self.macro_wait(self.LIB_KEY_INTERVAL if time.time() < burst_until else 0.01)
        self.task.skip_combat_check = True
        el = time.time() - start
        e_note = f',E x{e_taps}' if e_taps else ''
        if fired:
            so.record_liberation_use()
            self.macro_mark(f'{tag}R_fired(A x{taps},R x{r_n},连按{bursts}次{e_note},{el:.2f}s)')
        else:
            self.macro_mark(f'{tag}R_NOFIRE(cap,A x{taps},R x{r_n},连按{bursts}次{e_note},{el:.2f}s)')
        return fired

    def so_echo(self, so, tag, cap=None):
        """一直按 Q 到声骸 CD 涨上来(比按之前高 SO_ECHO_RISE, 连 2 帧)。返回放出去没有。so 可以是任何人。"""
        cap = self.SO_ECHO_CAP if cap is None else cap
        cd0 = self.read_cd('echo', so)
        start = time.time()
        n = hits = 0
        fired = False
        while time.time() - start < cap:
            so.send_echo_key()
            n += 1
            self.task.next_frame()
            up = self.so_on_field(so) and self.read_cd('echo', so) > cd0 + self.SO_ECHO_RISE
            hits = hits + 1 if up else 0
            if hits >= 2:
                fired = True
                break
            self.macro_wait(0.06)
        if fired:
            so.record_echo_use()
        else:
            self.logger.info(f'{tag}: 按了 {n} 下声骸 CD 没涨(基线 {cd0:.1f}s) — 被收招吞了, 还是读不到数?')
        self.macro_mark(f'{tag}({"出" if fired else "cap"},x{n},{time.time() - start:.2f}s)')
        return fired

    def so_tap_e(self, key):
        """点一下 E, 真的按住 SO_KX_E_TAP 秒。"""
        self.task.send_key_down(key)
        try:
            self.macro_wait(self.SO_KX_E_TAP)
        finally:
            self.task.send_key_up(key)

    def so_wuse(self, so, tag):
        """点 E 出无舍念: E 位是无舍念就每 SO_KX_E_EVERY 点一下, 读到出了(连 2 帧不是无舍念)就停。
        返回 (E 键, 停下的时刻)。"""
        key = so.get_resonance_key()
        start = time.time()
        e_taps = gone = 0
        next_e = 0.0
        out = False
        while time.time() - start < self.SO_KX_WUSE_CAP:
            self.task.next_frame()
            if self.so_on_field(so):
                if self.so_forte_full(so):
                    gone = 0
                    if time.time() >= next_e:
                        self.so_tap_e(key)
                        e_taps += 1
                        next_e = time.time() + max(0.0, self.SO_KX_E_EVERY - self.SO_KX_E_TAP)
                else:
                    gone += 1
                    if gone >= 2 and e_taps:
                        out = True
                        break
            self.macro_wait(0.01)
        so.record_resonance_use()
        t_w = time.time()
        self.macro_mark(f'{tag}无舍念({"出" if out else "cap"},E x{e_taps},{t_w - start:.2f}s)')
        return key, t_w

    def so_kx_hold(self, so, key, t_w, tag):
        """(LQ) 无舍念出了之后按住普攻出刻心念, 一直按着转圈(时停, 倒计时不走), 转完收招 +40 协奏、光圈出来就松手。
        按下时协奏已经满着(光圈一直在)就按满 LQ_SO_KX_HOLD_BLIND。
        按住期间 E 位又是无舍念 = 没放出来(被打断 / 前面读错): 松开, 连点 E 到放出来, 再按住。"""
        self.wait_until_time(t_w + self.SO_KX_A_FROM)
        strict = self.glow_trusted()
        si = self.xn_attack_down()
        first_held = held_at = time.time()
        why = 'cap'
        pre_full = None
        e_more = e_hits = con_hits = 0
        try:
            while time.time() - held_at < self.LQ_SO_KX_HOLD_CAP:
                self.task.next_frame()
                el = time.time() - held_at
                if not self.hud_ok():
                    self.macro_wait(0.02)
                    continue
                on = self.so_on_field(so)
                e_hits = e_hits + 1 if on and self.so_forte_full(so) else 0
                if (e_hits >= 2 and e_more < self.LQ_SO_KX_E_MAX
                        and time.time() - first_held < self.LQ_SO_KX_E_RESCUE_CAP):
                    self.release_attack()
                    e_more += 1
                    key, t_w = self.so_wuse(so, f'{tag}补#{e_more}')
                    self.wait_until_time(t_w + self.SO_KX_A_FROM)
                    si = self.xn_attack_down()
                    held_at = time.time()
                    pre_full = None
                    e_hits = con_hits = 0
                    continue
                try:
                    con = float(self.task.get_current_con())
                except Exception:
                    con = 0.0
                if pre_full is None:
                    # 单帧: con_glow 要连 GLOW_CONFIRM 帧, 第一帧永远是 False
                    pre_full = self.glow_now(so) or (not strict and con >= self.DL_CON_ENOUGH)
                if pre_full:
                    if el >= self.LQ_SO_KX_HOLD_BLIND:
                        why = '原来就满'
                        break
                elif self.con_glow(so):
                    if el >= self.LQ_SO_KX_HOLD_MIN:
                        why = '光圈'
                        break
                elif not strict:
                    con_hits = con_hits + 1 if con >= self.DL_CON_ENOUGH else 0
                    if con_hits >= self.DL_CON_FULL_CONFIRM and el >= self.LQ_SO_KX_HOLD_MIN:
                        why = '读数'
                        break
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}刻心念按住({why},{"SI" if si else "PM"},{time.time() - held_at:.2f}s'
                        f'{f",补E x{e_more}" if e_more else ""})')
        return why

    def so_kx_wait_con(self, so, tag, cap):
        """刻心念之后不按键等协奏真满(光圈; 光圈认得出过就不信读数, 读数满了再给 SO_KX_GLOW_GRACE)。返回满没满。"""
        start3 = time.time()
        hits = 0
        samples = []
        full = False
        strict = self.glow_trusted()
        con_full_at = None
        while time.time() - start3 < cap:
            self.task.next_frame()
            if not self.hud_ok():
                self.macro_wait(0.02)
                continue
            if self.con_glow(so):
                full = True
                samples.append('光圈')
                break
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            if len(samples) < self.CON_SAMPLE_MAX and (not samples or time.time() - start3 >= len(samples) * 0.3):
                samples.append(f'{time.time() - start3:.2f}:{con:.2f}')
            hits = hits + 1 if con >= self.DL_CON_ENOUGH else 0
            if hits >= self.DL_CON_FULL_CONFIRM:
                if not strict:
                    full = True
                    break
                # 光圈认得出却只有读数满: 再给光圈 SO_KX_GLOW_GRACE, 还没有就当没满, 去普攻补
                con_full_at = con_full_at or time.time()
                if time.time() - con_full_at >= self.SO_KX_GLOW_GRACE:
                    samples.append('读数满没光圈')
                    break
            self.macro_wait(self.DL_CON_POLL)
        glow = ',光圈' if samples and samples[-1] == '光圈' else \
            (',读数满没光圈' if samples and samples[-1] == '读数满没光圈' else '')
        self.macro_mark(f'{tag}等协奏({"满" if full else "没满"}{glow},{time.time() - start3:.2f}s)')
        if not full:
            self.logger.info(f'{tag}: 刻心念之后 {cap:.1f}s 协奏没满 — {" ".join(samples)}')
        return full

    def seg_lq_so_a(self, so, xn, tag):
        """(LQ) 锁暝·第一次上场(卜灵变奏进来 = 变奏·闪裂, 念起 -> 念深): R [没好就一直 A 到好] -> 演完
        -> 点一下 A -> Q(暗鸟) -> 同奏切心。返回心带不带变奏(R 出没出)。

        R 给锁暝 5s 同奏(游戏时间, 演出里不走), A + 暗鸟 ~0.45s, 带着同奏切走心是变奏·应世相入场。
        """
        self.wait_until_time(self.switch_press_at + self.SO_R_LEAD)
        fired = self.so_r_asap(so, tag, self.LQ_SO_R_CAP, allow_e=not so.has_intro)
        if fired:
            self.so_tongzou_at = time.time()
            self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.SO_R_ANIM_MIN, time_out=self.SO_R_ANIM_CAP)
            for i in range(self.LQ_SO_A_TAPS):
                if i:
                    self.macro_wait(max(0.0, self.SO_A_EVERY - self.A_TAP))
                self.tap()
            self.macro_mark(f'{tag}R后A(x{self.LQ_SO_A_TAPS})')
        else:
            self.logger.warning(f'{tag}: 锁暝 R 没放出去(能量不够 / 没进念深) — 心拿不到同奏')
        self.so_echo(so, f'{tag}Q暗鸟')
        full = fired
        if not fired:
            full = self.read_con(1.0, settle=0.15) >= 1.0
        self.need(self.switch_retry(xn, f'{tag}切心', assume_con=full), 'suoming -> hsin')
        return full

    def seg_lq_so_b(self, so, xn, tag):
        """(LQ) 锁暝·第二次上场(心转相的同奏 -> 旋雷破·同奏, 念深 +200 妄执): 点 A 到妄执满 -> 点 E(无舍念)
        -> 按住普攻(刻心念转满) -> 协奏满变奏心。返回协奏满没满。

        妄执满 = E 位换成无舍念(suoming_forte_e), 读到连 2 帧才停手; 没满时按 E 是破隙(冷却 8s, 这一圈就没无舍念了)。
        """
        sw = self.switch_press_at
        self.wait_until_time(sw + self.LQ_SO_B_A_LEAD)
        start = time.time()
        taps = hits = 0
        next_tap = 0.0
        ok = False
        while time.time() - start < self.LQ_SO_B_FILL_CAP:
            self.task.next_frame()
            if self.so_on_field(so):
                hits = hits + 1 if self.so_forte_full(so) else 0
                if hits >= 2:
                    ok = True
                    break
            if time.time() >= next_tap:
                self.tap()
                taps += 1
                next_tap = time.time() + max(0.0, self.SO_A_EVERY - self.A_TAP)
            self.macro_wait(0.01)
        self.macro_mark(f'{tag}A到妄执满({"满" if ok else "cap"},A x{taps},{time.time() - start:.2f}s)')
        if ok:
            key, t_w = self.so_wuse(so, tag)
            self.so_kx_hold(so, key, t_w, tag)
            full = self.so_kx_wait_con(so, tag, self.LQ_SO_KX_FINISH_CAP)
        else:
            self.logger.warning(f'{tag}: 锁暝 {self.LQ_SO_B_FILL_CAP:.1f}s 妄执没满, 接着普攻到妄执满再出刻心念')
            full = False
        if not full:
            full = self.so_ensure_intro(so, tag)
        self.need(self.switch_retry(xn, f'{tag}切心', assume_con=full, time_out=self.SO_TO_XN_TIME_OUT),
                  'suoming -> hsin')
        return full

    def so_ensure_intro(self, so, tag):
        """(LQ) 锁暝协奏不满不切(心没变奏 = 进不了统御众机, 这一圈万阙垂天就没了):
        一直普攻, 妄执满了(E 位是无舍念)就再出一次无舍念 + 按住刻心念(+40 协奏), 光圈出来才走。
        普攻本身给的协奏很少, 主要靠刻心念; E 只在无舍念时点(妄执没满点 E 是破隙, 冷却 8s)。
        光圈认得出过就只认光圈, 读数满了 LQ_SO_B_READ_GRACE 还没光圈也走。返回满没满。"""
        start = time.time()
        strict = self.glow_trusted()
        taps = kx = forte_hits = con_hits = 0
        next_tap = 0.0
        read_full_at = None
        why = 'cap'
        while time.time() - start < self.LQ_SO_B_ENSURE_CAP:
            self.task.next_frame()
            if not self.hud_ok():
                self.macro_wait(0.02)
                continue
            if self.con_glow(so):
                why = '光圈'
                break
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            con_hits = con_hits + 1 if con >= self.DL_CON_ENOUGH else 0
            if con_hits >= self.DL_CON_FULL_CONFIRM:
                read_full_at = read_full_at or time.time()
                if not strict or time.time() - read_full_at >= self.LQ_SO_B_READ_GRACE:
                    why = f'读数{con:.2f}'
                    break
            else:
                read_full_at = None
            on = self.so_on_field(so)
            forte_hits = forte_hits + 1 if on and self.so_forte_full(so) else 0
            if forte_hits >= 2 and kx < self.LQ_SO_B_KX_MAX:
                kx += 1
                forte_hits = con_hits = 0
                read_full_at = None
                key, t_w = self.so_wuse(so, f'{tag}保变奏#{kx}')
                self.so_kx_hold(so, key, t_w, f'{tag}保变奏#{kx}')
                continue
            if time.time() >= next_tap:
                self.tap()
                taps += 1
                next_tap = time.time() + max(0.0, self.SO_A_EVERY - self.A_TAP)
            self.macro_wait(0.01)
        full = why != 'cap'
        self.macro_mark(f'{tag}保变奏({why},刻心念x{kx},A x{taps},{time.time() - start:.2f}s)')
        if not full:
            self.logger.warning(f'{tag}: 锁暝补了 {self.LQ_SO_B_ENSURE_CAP:.0f}s 协奏还是没满(打不到怪?), '
                                f'心只能普通入场')
        return full

    # ==================== 一圈 ====================

    def run_cycle(self, so, dl, opener, tag):
        """一圈(LQ): 卜灵(启动段/循环段) -> 锁暝 R 暗鸟 -> 心 转相 E -> 锁暝 刻心念 -> 心 统御众机 万阙垂天
        -> 卜灵变奏入场、HUD 回来。"""
        marks = len(self.macro_marks)
        self.timeline_logged = False
        # 【心那几段一定要用真的心对象】: 这条宏可能由任意一个在场成员驱动(三个文件内容相同),
        # 技能栏图标/CD/重击位都是按角色 index 读的, 拿驱动者顶替心会读到别人的栏位。
        xn = getattr(self, 'xn_char', None) or self.teammate_xn() or self
        self.xn_char = xn
        if opener:
            self.seg_lq_dl_open(dl, so, tag=f'{tag}卜')
        else:
            self.seg_lq_dl(dl, so, tag=f'{tag}卜')
        self.seg_lq_so_a(so, xn, tag=f'{tag}锁a')
        self.seg_xn1(xn, so, tag=f'{tag}心1')
        intro = self.seg_lq_so_b(so, xn, tag=f'{tag}锁b')
        self.seg_xn2(xn, intro, tag=f'{tag}心2', opener=opener)
        if self.DL_BREAK:
            self.note_break_prompt()
        self.need(self.switch_to_dl(dl, tag=f'{tag}切卜'), 'hsin -> douling')
        self.logger.info(f'{tag} cycle timeline: {self.macro_timeline(marks)}')
        self.timeline_logged = True

    def macro_enter(self, entry_char):
        so = self.teammate('Suoming')
        dl = self.teammate_dl()
        if so is None or dl is None:
            return None
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        self.mark_busy(True)
        self.cur = entry_char or self.on_field_char() or self
        self.xn_char = self.teammate_xn() or self
        for char in (self, so, dl):
            char.check_f_on_switch = False
        self.macro_start()
        self.timeline_logged = False
        self.hud_seen_at = time.time()
        self.hud_watch = True
        self.cycle_started = time.time()
        self._stall_sig = None
        self._stall_since = time.time()
        self._wd_next = 0.0
        # 上一轮如果是异常退出, 系统里那个左键可能还按着 —— 先松开再开打(防"卡手")
        if getattr(self.task, '_xss_mouse_down', False):
            self.logger.warning('上次的按住没收干净, 先松开左键')
            self.force_release_mouse()
        return so, dl, previous

    def macro_exit(self, previous):
        # 长按跨了好几个方法, 中途抛异常的话鼠标会一直按着。这里是唯一保证松手的地方
        self.release_attack()
        if getattr(self.task, '_xss_mouse_down', False):
            self.force_release_mouse()
        # 中途被停(关自动战斗/切出窗口)也要把时间轴写下来
        if not self.timeline_logged and self.macro_marks:
            self.logger.info(f'xss timeline (没跑完): {self.macro_timeline()}')
            self.timeline_logged = True
        self.hud_watch = False
        self.task.skip_combat_check = previous
        self.mark_busy(False)

    def perform_opener(self, entry_char=None):
        """启动轴: 切卜灵 -> 一圈(卜灵启动段)。返回时卜灵刚变奏入场、HUD 在场。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        so, dl, previous = got
        self.logger.info(f'xss opener entry: {self.cur.name}')
        try:
            self.loop_count = 0
            self.so_tongzou_at = -99.0
            if self.cur is not dl:
                self.need(self.switch_retry(dl, 'op'), 'opener: switch to douling')
            self.run_cycle(so, dl, opener=True, tag='op')
            self.note_ok()
            self.logger.info(
                f'xss opener total {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        except MacroBroken as e:
            self.note_broken()
            self.logger.warning(f'xss opener broke ({e}) — timeline: {self.macro_timeline()}')
            self.timeline_logged = True
        finally:
            self.macro_exit(previous)
        return True

    def perform_loop(self, entry_char=None):
        """循环轴一圈。场上不是卜灵(宏散过)就先把场子交给她。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        so, dl, previous = got
        try:
            if self.cur is not dl:
                self.need(self.switch_to_dl(dl, tag='L接卜'), 'loop: hand the field to douling')
            self.loop_count += 1
            n = self.loop_count
            self.run_cycle(so, dl, opener=False, tag=f'L{n}')
            self.note_ok()
            self.logger.info(
                f'xss loop #{n} {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        except MacroBroken as e:
            self.note_broken()
            self.logger.warning(f'xss loop broke ({e}) — timeline: {self.macro_timeline()}')
            self.timeline_logged = True
        finally:
            self.macro_exit(previous)
        return True

    # ==================== 框架接口 ====================

    def drive(self, entry):
        """三个人的 do_perform 都走这里。entry = 框架这次调的是谁(= 场上是谁)。"""
        # 【断轴冷却】刚断过轴就一下都不按: 让框架自己走位 / 等控制结束, 冷却完再重排(连败越久等越久)
        if time.time() < getattr(self.task, '_xss_backoff_until', 0.0):
            self.macro_wait(0.2)
            return None
        # 【HUD 不在就什么都不做】: 关卡结束/结算/过场时框架还会接着调进来(F 开始战斗那边撑着不脱战)
        if not self.wait_hud_up(cap=self.DRIVE_HUD_CAP, tag='drive'):
            if time.time() - self.drive_log_at > 10:
                self.drive_log_at = time.time()
                self.logger.info('xss: 队伍 HUD 不在(结算/过场/窗口没了?), 宏不动')
            return None
        # 【没锁定目标就先让位】(怪跑太远 / 刚换波): 硬打只会空挥, 交回框架它才会锁敌/靠近。
        # 连续读到怪就清零; 一直读不到(这关血条/锁定识别不了)就到次数后照常跑, 别把宏饿死。
        if not self.xn_enemy_here():
            n = getattr(self.task, '_xss_no_enemy', 0) + 1
            self.task._xss_no_enemy = n
            if n <= self.NO_ENEMY_YIELD:
                if n == 1 or time.time() - self.drive_log_at > 5:
                    self.drive_log_at = time.time()
                    self.logger.info('xss: 场上没读到怪(跑远/换波), 交回框架, 先不按')
                if n % 2 == 0:
                    try:
                        self.task.middle_click()
                    except Exception:
                        pass
                self.macro_wait(self.NO_ENEMY_WAIT)
                return None
            if n == self.NO_ENEMY_YIELD + 1:
                self.logger.warning('xss: 一直读不到怪(这关的血条/锁定可能识别不了), 照常跑轴')
        else:
            self.task._xss_no_enemy = 0
        blocked = self.opener_blocked_by()
        if blocked is None:
            # 标记要在跑之前落: 中途抛异常(脱战/任务被停)也不能让启动轴重跑
            self.opener_armed = False
            self.last_opener = time.time()
            return self.perform_opener(entry)
        self.logger.info(f'xss: opener not pending ({blocked}), running the loop')
        return self.perform_loop(entry)

    def do_perform(self):
        if not self.is_in_xss:
            return super().do_perform()
        try:
            self.drive(self)
        except Exception as e:
            # 【兜底】轴里自己的 bug/意外异常不能把整个 Auto Combat 任务停掉(ok-ww 会 "exception stopped",
            # 表现就是"人不动了")。这里记日志、松开鼠标、给一次冷却, 下一圈照常跑。
            # 只有框架自己的异常(任务被停 / 角色死亡 / 脱战)才继续往上抛。
            if type(e).__name__ in ('TaskDisabledException', 'TaskPausedException',
                                    'CharDeadException', 'NotInCombatException'):
                raise
            self.logger.error(f'xss: 轴里抛异常({type(e).__name__}: {e}), 本圈放弃, 不停任务')
            for fn in (self.force_release_mouse, self.note_broken):
                try:
                    fn()
                except Exception:
                    pass
            self.hud_watch = False
            try:
                self.task.skip_combat_check = False
                self.mark_busy(False)
            except Exception:
                pass

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时让卜灵先上。"""
        if self.is_in_xss and self.opener_pending():
            return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        self.release_attack()
        return super().on_combat_end(chars)
