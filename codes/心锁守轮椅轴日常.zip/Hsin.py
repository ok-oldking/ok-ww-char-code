"""心／锁冥／守岸人大世界配队中的心，可直接导入 ok-ww 自定义角色代码。

记号约定：A=普攻，E=共鸣技能，Q=声骸，R=共鸣解放；实际按键由任务配置取得。
H1 是应世相的强化重击，R1 是之后的转相；H2 是统御众机末段重击。
为兼容原生标签，代码中的 r2 / hsin_lib2 指最终的万阙垂天，不是照世相的借相。

正常路线：锁冥变奏进场 → H1 → 确认 R1 → 交锁冥 → 再变奏直接统御众机
→ H2 → 必须补出终结 R → 四段普攻收尾 → 满协奏后 Q 切守。开局已在后半形态时从实况续接。
所有按键只是尝试，形态、演出、协奏与交棒各自确认，不能用固定轴代替结果判断。
"""

import base64
import math
import time

from src.Labels import Labels
from src.char.Hsin import Hsin as NativeHsin


class _HandoffYield(Exception):
    """结束本次原生循环，避免切锁成功后继续执行心的技能。"""


class _BreakReady(Exception):
    """先释放重击持键，再在角色入口执行处决。"""


class Hsin(NativeHsin):
    """保留原生角色接口，改用同奏双入场流程与可跨执行片段恢复的状态。

    _form 保存较可靠的应世／照世结论；_phase 表示当前可执行步骤。
    一次较弱的 E 高亮或人像相似不能覆盖已确认形态，也不能决定跳过回锁。
    _clear_visit 清理单次上场状态；_reset_team_state 才清理整场形态与溯意。
    """

    CODE_REVISION = '2026-10-25-break-guard-21'
    # 用户确认此前用于右移定位的截图未装备声骸，现已装备并要求恢复旧布局。
    # 恢复第7版人像采样框：(2826,1893)~(2908,1972)，中心约(2867,1932.5)。
    # H1/H2 模板也恢复其原生元数据位置，不再强制使用右移后的搜索框。
    # 仍由 SDK 从3840×2160缩放；尺寸、遮罩、阈值及小范围容错沿用原识别逻辑。
    HEAVY_SLOT = (2826, 1893, 82, 79)
    # 一次调用的工作片段，不是整套输出的总上限；未完成的终结 R 会在下次续打。
    WORK_SLICE = 8.0
    POLL = .02
    CONFIRM = 2
    # 入场等待以实际切入时刻为锚点，采用参考轴数值，不重复添加“稳定停顿”。
    INTRO_FIRST = 1.05
    INTRO_FULL_HEAVY = .50
    INTRO_LATE = 2.50
    ATTACK_HOLD = .08
    ATTACK_INTERVAL = .25
    # 前半按住 1.8s；从按住起最多观察 3s 转相就绪，亮了便立即尝试 R。
    # 后半按住 3s；被打断但提示仍在时，最多有限松开／重按两次。
    HEAVY1_HOLD = 1.80
    FIRST_R_WINDOW = 3.00
    FIRST_FILL_BLIND_AT = 2.15
    FIRST_FILL_CAP = 4.00
    FIRST_FILL_MIN_TAPS = 2
    # 楽山心锁守 2.0.0 的 H1 后台补按条件：一直亮着说明按下沿可能被收招吞掉。
    # 最多一次松开 .05s 再按；只在失败路径延长到这次真实补按的有限观察期限。
    FIRST_REPRESS_MIN = .95
    FIRST_REPRESS_READY = .45
    FIRST_REPRESS_POLL = .10
    HEAVY2_HOLD = 3.00
    REHOLD_DELAY = .60
    REHOLD_RELEASE = .05
    HEAVY_ANIMATION_MIN = 1.40
    HEAVY_ANIMATION_TIMEOUT = 4.0
    # 发键启动预算与演出预算分开；到点只决定重试，绝不据此宣告 R 已释放。
    R_START_TIMEOUT = 1.50
    # 发键截止后，最后一次输入仍有原生接口同等的 .4s 启动确认窗口。
    # 此窗口只观测，不继续发键；任何疑似藏 HUD 都交给演出核实。
    R_START_CONFIRM = .40
    R_ANIMATION_MIN = 3.90
    R_ANIMATION_TIMEOUT = 7.0
    # R2 后的入口与收尾后的协奏／交棒各有一次3秒观察保护，不是 sleep。
    # 开始收尾时再按当前普攻预算建立本阶段截止，不能让收尾本身耗尽交棒余量。
    # 仅真实阶段转换时建立，普通循环／读图／切人失败不续期；正式交棒由协调器接管。
    POST_R_HANDOFF_GUARD = 3.0
    # 收尾目标为完整四段普攻，使用当前2.65s连续输入与.25s末段收尾。
    # 沿用心汐守 .25s 连点／.08s 持键，不把四次点击当作四段。
    # 2.65s 并非已有录像验证的 R2 后 A4 时长；用户实测后
    # 可独立调整，不影响前半补条、统御和技能窗口。代码没有普攻段数识别。
    POST_R_NORMAL_TIME = 2.65
    POST_R_NORMAL_TAIL = .25
    # 终结补能不设放弃上限，但仍使用原生敌人血条判断战斗是否继续。
    # 敌人线索最多每 .25s 读取一次；连续丢失超过原生索敌同等的 1.2s，
    # 就交回框架普通战斗检查，不靠反复刷新固定保护时间维持假战斗。
    FINISH_ENEMY_POLL = .25
    FINISH_ENEMY_LOST_GRACE = 1.20
    ACTION_RETRY = .06
    ACTION_RECOVERY_GUARD = .60
    R_KEY_INTERVAL = .03
    DOMINION_DURATION = 13.0
    # 使用参考轴统御补条的短 A 节奏；A 的次数只用于日志，绝不作为重击解锁条件。
    DOMINION_ATTACK_HOLD = .06
    DOMINION_ATTACK_INTERVAL = .18
    # 统御每帧仍读中心人像；未命中时，昂贵的备用 H2 模板最多每 .20s 扫一次。
    # 命中后的第二帧立即新读确认，绝不缓存上次命中来拼接双帧证据。
    H2_TEMPLATE_POLL = .20
    # 心汐守及心卜穗已使用的重击位雕像／人像，不新增 Labels。
    TY_GLYPH = (
        'AAAAAAAMJCEsJBYBAAAAAAAAABiR1cJ40tzbpyYAAAAAABK+4+Pt2unk48BaJAAAAAhQg6aMnN1/l6RzUVEbAAAzV3Dw9crHyvngXlFQRQIJ'
        'VFqs8dbtovLV8JdRUFAdIlmK7ZPT7IT7v6Dtbk9bOzdhj5en/O2E/PmHoXdelTpIsV1Xrv3thPz7iE9XwJuUJsCvW6797YX9+4dTsfjxriWy'
        '9KGQ++2E/fqGnvfU33sBpvjsmt/thPzfmeylk9cPADOnpLzM7IT4tc54Y+FhAAAASGKt+eyD5uiKUbyiBQAAAAAkjf3tg/j6h3aCCQAAAAAA'
        'AAZbpFvGrUwKAAAAAA=='
    )
    READY_GLYPH = (
        'AAAAAAAGGDxjHgwAAAAAAAAAABQoWcH31Vg3Jg0AAAAAACGmh+r9+X82NzlcMgAAAAZ47tD9/c06R2NGZ2cWAAA32P38/f2+N0xtaDY3MQIa'
        '3/v9/v3x4DhNbFk2OEcVYf39/f34yMM4RGJWQjmCKmH9+vW6sa2FPT09WGFLyjZ5/c7E4fWaQD0/UHOX0POeYfmXotjqXz09PkBvmojMUTfc'
        'vZnUhD08PDw9mcfbvzMBauG+pJZJREA9P9L05XAFACb1+/38refMZD3D+oQjAAAAbfn9/tDY/LQ7tOMxAgAAAABU2f7is/y+QMd0AgAAAAAA'
        'AAhcpG3GgygPAAAAAA=='
    )

    def __init__(self, *args, **kwargs):
        """初始化自定义状态，并输出版本标记，方便确认实测加载的是哪一版。"""
        super().__init__(*args, **kwargs)
        self._reset_team_state()
        self.logger.info(f'心锁守代码修订：Hsin {self.CODE_REVISION}')

    def _clear_visit(self):
        """清理本次上场的步骤与候选结果；不抹掉跨两次入场保存的形态／溯意。"""
        # 图像候选必须连续成立；日志只在稳定步骤发生改变时输出，避免逐帧刷屏。
        self._entry_done = False
        self._candidate, self._candidate_hits = None, 0
        self._reported_phase = None
        self._phase_observations = None
        self._phase_specific = (False, False, False, False)
        # pending 是“已尝试、待核实”，不是技能成功标记；可跨 WORK_SLICE 继续处理。
        self._r_pending = self._heavy_pending = None
        self._return_due = self._r1_this_visit = False
        self._return_armed = False
        self._r1_sent_at = None
        self._capture_r1 = False
        # 普通白色 R 检测可能在未解锁时误亮。一次补条过程不无限重复启动探测。
        self._r1_build_probe_done = False
        self._first_heavy_pending = None
        self._h1_guard_until = 0.0
        self._dominion_guard_until = 0.0
        # H1 模板漏识别时的有限补条数据；真正尝试一次重击才重新开始计数。
        self._first_fill_started = None
        self._first_fill_taps = 0
        self._first_fill_seen = False
        self._first_probe_reason = None
        self._h1_match_source = None
        # 同奏 5s 窗口由真实发键及已记录冻结计算，不能在演出结束时重新赠送 5s。
        self._r1_unison_until = 0.0
        self._next_e = self._next_r = self._next_heavy = 0.0
        self._dominion_presses = 0
        # H2 以中心人像为主判据。未知与识别异常分别记账，不能继续静默吞掉原因。
        self._h2_match_source = None
        self._slot_scores = None
        self._slot_error = None
        self._slot_error_reported = False
        self._slot_match = None
        self._slot_geometry = None
        self._h2_next_report = 0.0
        self._h2_next_template = 0.0
        self._h2_snapshot_saved = False
        # H2 -> 终结 R 单独保留有限保护，不能在确认 H2 的瞬间撤销。
        # 期限只在首次正面确认终结阶段时建立，不因反复读图无限续期。
        self._finisher_guard_until = 0.0
        self._post_r_guard_until = 0.0
        self._post_r_next_report = 0.0
        self._post_r_normals = None
        self._finish_enemy_seen = 0.0
        self._finish_enemy_probe_at = 0.0
        self._finish_fill_next_report = 0.0
        # h2_completed 一旦确认就锁定终结步骤；即使能量暂缺也不能倒退到借相。
        self._complete = self.lib2_cast_this_turn = self.h2_completed = False
        self.h2_guard_until = 0.0
        self._team_entry_guard_until = 0.0
        self._action_recovery_until = 0.0

    def _reset_team_state(self):
        """新战斗／框架重置时清除所有自定义记忆，以当下画面重新建立形态。"""
        self._form = self._phase = 'unknown'
        self._dominion_until = 0.0
        self._clear_visit()
        self.source_intent = None
        self.last_intro_unison = None
        self.last_intro_empowered = None
        self.intro_attack_buff_until = 0.0

    def reset_state(self):
        """先重置 BaseChar 通用状态，再清理本配队的形态与交接记忆。"""
        super().reset_state()
        self._reset_team_state()

    def on_team_intro(self, unison):
        """交棒确认后的变奏回调：True=同奏，False=普通满协奏，None=无法证明变奏。

        已经亲自确认照世相且本次有有效变奏，才直接进入统御众机。
        同奏提供溯意；随后普通变奏可消耗已知溯意。未知初始状态保持未知，
        这些记账用于解释增益来源，不会用它们伪造实际输出或技能成功。
        """
        guard = self._team_entry_guard_until
        self._clear_visit()
        self._team_entry_guard_until = guard
        if unison is not None and self._form == 'illumining':
            # 本人确认过转相，且这一次是实际有效变奏，才有直接统御的凭据。
            self._phase = 'dominion'
            self._dominion_until = time.time() + self.DOMINION_DURATION
        self.last_intro_unison = unison
        intent = getattr(self, 'source_intent', None)
        if unison is None:
            self.source_intent = None
            self.last_intro_empowered = None
        elif unison:
            self.source_intent = True
            self.last_intro_empowered = True
        elif intent is True:
            self.source_intent = False
            self.last_intro_empowered = True
        else:
            self.source_intent = intent
            self.last_intro_empowered = False if intent is False else None
        self.intro_attack_buff_until = time.time() + 8.0 if self.last_intro_empowered is True else 0.0
        self.logger.info(f'心锁守：心收到新变奏，形态记忆={self._form}，'
                         f'本次完成标记={self._complete}，'
                         f'既有入场保护剩余 {max(0.0, guard - time.time()):.2f}s')

    def switch_out(self, con_full=False):
        """实际切出后清理本次步骤；协奏是否消耗仍由真实交棒类型传给原生接口。"""
        super().switch_out(con_full=con_full)
        self.intro_attack_buff_until = 0.0
        self._clear_visit()

    def _team_suoming(self):
        """按角色身份和自定义交棒接口找锁冥，避免依赖用户的队伍槽位顺序。"""
        return next((c for c in self.task.chars if c is not None
                     and c.char_name == 'char_suoming'
                     and callable(getattr(c, 'handoff_from_hsin', None))), None)

    def _late_phase_visible(self):
        """判断是否有后半迹象，用于阻止应世 R1 分支误按照世相的借相。

        已确认 H2／有效统御状态优先；专用前半图标优先于通用 E 或人像猜测。
        此函数仅返回观测结果，不直接改写队伍轮次。
        """
        if self.h2_completed or (self._form == 'illumining' and self._phase == 'dominion'
                                 and time.time() < self._dominion_until):
            return True
        if self._icon(Labels.hsin_h2) or self._icon(Labels.hsin_lib2):
            return True
        if self._icon(Labels.hsin_h1) or self._icon(Labels.hsin_lib1):
            return False
        return bool(self.h2_completed or self.is_e_forte_full()
                    or self._slot_state() in ('statue', 'ready'))

    def do_perform(self):
        """先恢复未完成的交棒，再运行本次站场；成功交锁后立即退出心的调用栈。"""
        suo = self._team_suoming()
        if suo is not None:
            if suo.resume_hsin_handoff(self):
                return
            if suo.recover_hsin_handoff(self):
                return
        self._return_armed = bool(suo is not None and suo.round_phase == 'hsin_first' and self.has_intro)
        try:
            return self.perform_everything()
        except _HandoffYield:
            return

    def send_liberation_key(self, *args, **kwargs):
        """记录 R1 首次实际发送时刻，供同奏有效期计算；不把发键当成功。"""
        if getattr(self, '_capture_r1', False) and self._r1_sent_at is None:
            self._r1_sent_at = time.time()
        return super().send_liberation_key(*args, **kwargs)

    def lib(self, after_heavy=False):
        """选择当前正确的 R，确认施放后才提交形态、同奏或本轮完成状态。

        有待确认的 R 时只续接原候选。H2 后禁止回到 R1；其他时候必须见专用图标。
        R1 成功且属于首次心入场，立即请求回锁冥；终结成功后执行收尾普攻并补满协奏交守。
        """
        suo = self._team_suoming()
        pending = self._r_pending
        if pending is not None:
            kind = pending['kind']
        elif self._icon(Labels.hsin_lib2):
            kind = 'r2'
        elif (not after_heavy and not self.h2_completed and self._icon(Labels.hsin_lib1)
              and not self._late_phase_visible()):
            kind = 'r1'
        else:
            return False
        if time.time() < self._next_r or not self.task.use_liberation:
            return False
        if pending is None:
            self._r1_sent_at = None
        self._casting_kind = kind
        self._capture_r1 = kind == 'r1'
        try:
            confirmed = self.click_liberation(wait_if_cd_ready=0)
        finally:
            self._capture_r1 = False
        if (not confirmed and kind == 'r1' and self._r_pending is None
                and self._r1_sent_at is not None):
            self._r1_build_probe_done = True
        if confirmed:
            if kind == 'r1':
                self._first_heavy_pending = None
                self._h1_guard_until = 0.0
                self._form, self._phase = 'illumining', 'illumining'
                self._r1_this_visit = True
                self._return_due = bool(suo is not None and suo.round_phase == 'hsin_first')
                remaining = (max(0.0, 5.0 - self.time_elapsed_accounting_for_freeze(self._r1_sent_at))
                    if self._return_armed and self._r1_sent_at is not None else 0.0)
                self._r1_unison_until = time.time() + remaining if remaining > 0 else 0.0
                if self._return_due:
                    self._return_to_suoming(suo)
            else:
                self._form, self._phase = 'answering', 'done'
                # 必须在返回主循环（下一次 _frame 会先 check_combat）之前建立。
                # 放到 _complete 分支内部已经太晚；仅真实 R2 完成能开启此短窗。
                if not self._complete:
                    self._post_r_guard_until = time.time() + self.POST_R_HANDOFF_GUARD
                    self.logger.info('心锁守：终结 R 已完成，先执行延长后的收尾普攻，再核满协奏交守；'
                                     f'暂缓长索敌最多 {self.POST_R_HANDOFF_GUARD:.1f}s，不等待窗口结束')
                self._complete = self.lib2_cast_this_turn = True
                self.h2_guard_until = 0.0
                self._finisher_guard_until = 0.0
        return confirmed

    def _active(self):
        """仅认画面中的当前队伍槽位；HUD 隐藏返回 False，不推断换人或脱战。"""
        visible, index, _ = self.task.in_team()
        return bool(visible and index == self.index)

    def _frame(self):
        """推进一帧并保留任务停止／战斗检查；演出是否暂免索敌由角色保护接口决定。"""
        self.task.next_frame()
        self.check_combat()
        active = self._active()
        if not active:
            # HUD 中断打断形态的连续帧证据，不能跨演出或换人拼接两次图标。
            self._candidate, self._candidate_hits = None, 0
        return active

    def _reconcile_actor(self):
        """连续确认已换成其他角色后，修正框架当前角色并丢弃本次心的动作。

        单帧头像抖动或演出藏 HUD 均不能提交换人；不在错误角色身上继续发心的技能。
        """
        visible, index, _ = self.task.in_team()
        if not visible or index == self.index:
            return False
        self.sleep(self.POLL)
        self.task.next_frame()
        again, actual, _ = self.task.in_team()
        if not again or actual != index:
            return False
        for char in self.task.chars:
            if char is not None:
                char.is_current_char = char.index == index
        self.has_intro = self.has_sub_dps_intro = False
        self._clear_visit()
        return True

    def _icon(self, label):
        """匹配当前角色专用提示；H1/H2 额外用同阈值灰度与位置容错，避免亮重击漏检。"""
        if not self._active():
            return False
        found = self.task.find_one(label, threshold=.7)
        if found:
            if label == Labels.hsin_h1:
                self._h1_match_source = '原模板'
            return True
        if label in (Labels.hsin_h1, Labels.hsin_h2):
            # 默认搜索区在 4K 仅约 ±8×4px；保留 .7 阈值，增加位置／颜色容错。
            found = self.task.find_one(label, threshold=.7, use_gray_scale=True,
                                       horizontal_variance=.01, vertical_variance=.01)
            if label == Labels.hsin_h1:
                self._h1_match_source = '灰度扩大区域' if found else None
            return bool(found)
        return False

    def _stable_icon(self, label):
        """取得连续两帧专用图标证据；失败即返回，不追加固定稳定等待。"""
        for _ in range(self.CONFIRM):
            if not self._frame() or not self._icon(label):
                return False
            self.sleep(self.POLL)
        return True

    def _resonance_hud_ready(self):
        """只辅助判断 E 所在技能栏是否可读，不把 E 灰态当作全部动作的硬锁。"""
        # E 灰态／CD 漏识别不能代表普攻、重击、R 或切人被锁住。
        return self._active() and (self.task.available('resonance', check_color=True, check_cd=False)
                                   or self.task.has_cd('resonance'))

    def _attack(self, interval=None, hold=None):
        """只在心确实站场时普攻；interval 包含按住时间，沿用参考轴攻击节奏。"""
        if self._active():
            self.check_combat()
            # 战斗检查可能进入长索敌，期间用户可切人或重新导入代码。
            # 检查前的站场结果不能直接授权检查后的点击，发键前再核对一次。
            if not self._active() or not any(char is self for char in self.task.chars):
                return False
            interval = self.ATTACK_INTERVAL if interval is None else interval
            hold = self.ATTACK_HOLD if hold is None else hold
            self.task.click(down_time=hold)
            self.sleep(interval - hold)
            return True
        return False

    def _finish_work_has_enemy(self):
        """终结补能／收尾期间，以真实敌人线索避免同步长索敌饿死普攻。

        此函数只读画面，不调用 in_combat 或 target_enemy，避免战斗检查递归。
        仅已经持有 H2 后继候选、确认终结阶段或确认 R2 完成时生效；本角色
        必须仍在场。技能演出仍走自己的有限保护，敌人消失则恢复正常检查。
        """
        pending = getattr(self, '_heavy_pending', None)
        waiting_heavy_result = pending is not None and pending.get('result_since') is not None
        if (self._r_pending is not None or not self._active()
                or not (waiting_heavy_result or self.h2_completed or self._complete)):
            return False
        now = time.time()
        if now >= getattr(self, '_finish_enemy_probe_at', 0.0):
            self._finish_enemy_probe_at = now + self.FINISH_ENEMY_POLL
            if self.task.check_health_bar():
                self._finish_enemy_seen = time.time()
        seen = getattr(self, '_finish_enemy_seen', 0.0)
        return seen > 0 and time.time() - seen <= self.FINISH_ENEMY_LOST_GRACE

    def _build_finisher_energy(self):
        """R2 专用提示未就绪时持续短 A；工作片结束不等于放弃终结。"""
        if time.time() >= getattr(self, '_finish_fill_next_report', 0.0):
            self._finish_fill_next_report = time.time() + 2.0
            self.logger.info('心锁守：H2 后终结 R 尚未就绪，持续普攻补能；'
                             '跨工作片保留步骤，只在专用 R2 就绪后施放')
        return self._attack(interval=.12, hold=.06)

    def _post_r_normal_step(self):
        """实际 R2 完成后执行可续接的延长普攻时序，随后才允许交棒。

        用连续短按维持连段，不能把三个点击当成三段。进度只在本角色确实
        发出输入后累计，HUD 暂缺时不凭墙钟把整段算完；暂停／切出仍由框架
        处理。最后一拍给末段动作收尾。日志只声明时序完成，不虚构段数识别。
        """
        pending = getattr(self, '_post_r_normals', None)
        if pending is None:
            pending = {'elapsed': 0.0, 'done': False}
            self._post_r_normals = pending
            # 收尾是主动动作，其观察保护需覆盖完整输入预算及之后的交棒余量。
            # 只在本次收尾首次启动时锚定，不随每下 A 刷新。
            self._post_r_guard_until = (time.time() + self.POST_R_NORMAL_TIME
                                       + self.POST_R_NORMAL_TAIL + self.POST_R_HANDOFF_GUARD)
            self.logger.info('心锁守：开始 R2 后收尾普攻，目标完整四段后 Q 切守；'
                             f'连续输入 {self.POST_R_NORMAL_TIME:.2f}s，'
                             f'末段收尾 {self.POST_R_NORMAL_TAIL:.2f}s（时序待实测校准）')
        if pending['done']:
            return True
        remaining = self.POST_R_NORMAL_TIME - pending['elapsed']
        if remaining > .001:
            interval = min(self.ATTACK_INTERVAL, remaining)
            if self._attack(interval=interval, hold=min(self.ATTACK_HOLD, interval)):
                pending['elapsed'] += interval
            return False
        if not self._active():
            return False
        self.sleep(self.POST_R_NORMAL_TAIL)
        if not self._active() or not any(char is self for char in self.task.chars):
            return False
        pending['done'] = True
        # 即使 R2 已击杀目标／血条暂未识别，也先给真实满协奏核实与交棒机会。
        # 不能继续沿用 R2 结束时的三秒截止，否则末段刚打完就进入同步索敌。
        self._post_r_guard_until = time.time() + self.POST_R_HANDOFF_GUARD
        self.logger.info('心锁守：R2 后收尾普攻时序已执行，开始连续核实满协奏交守；'
                         f'交棒观察保护 {self.POST_R_HANDOFF_GUARD:.1f}s，满即交，不等到期')
        return True

    def _raw_con(self):
        """读取 0～1 协奏；无效、越界、NaN 都返回 None，不能当作零或满协奏。"""
        if not self._active():
            return None
        try:
            con = float(self.task.get_current_con())
        except (ValueError, TypeError):
            return None
        if not math.isfinite(con) or not 0 <= con <= 1:
            return None
        self.current_con = con
        return con

    def _full_con(self):
        """满协奏交棒前要求连续三次真实 1.0；0.99 不能冒充满协奏。"""
        for _ in range(3):
            if not self._frame() or self._raw_con() != 1:
                return False
            self.sleep(self.POLL)
        return True

    def _read_phase(self):
        """综合专用模板、已确认记忆及弱后备提示，只读出当前可执行步骤。

        优先级：已完成 H2 → 已知有效统御 → 专用后半／前半图标 → 已知应世相
        → E／人像／资源条后备。前后专用图标冲突返回 unknown，等下一帧裁决。
        资源条是图像特征，不代表共鸣能量；弱后半猜测不会在这里提交 _form。
        """
        r2, h2 = self._icon(Labels.hsin_lib2), self._icon(Labels.hsin_h2)
        r1, h1 = self._icon(Labels.hsin_lib1), self._icon(Labels.hsin_h1)
        self._phase_specific = (r1, h1, r2, h2)
        specific = f'H1={h1}, R1={r1}, H2={h2}, R末={r2}'
        self._phase_observations = specific
        if self.h2_completed:
            return 'finisher'
        if self._form == 'illumining' and self._phase == 'dominion' and time.time() < self._dominion_until:
            return 'finisher' if r2 else 'heavy2' if h2 else 'dominion'
        # 专用模板可判当前形态；通用 E 和相关性较弱的人像只作后备。
        if (r1 or h1) and (r2 or h2):
            return 'unknown'
        if r2:
            return 'finisher'
        if h2:
            return 'heavy2'
        if h1:
            return 'heavy1'
        if r1:
            return 'answering'
        # 已确认应世相后，重击清条／R 模板暂缺不能冒认为已转相。
        if self._form == 'answering' and not self._r1_this_visit:
            return 'answering'
        # 专用图标或已确认应世相已经足够时，不再额外跑人像 27 组位置/尺度
        # 和通用 E 识别。后备只在前面的判据均未知时执行，不削弱形态确认。
        full_e, slot = bool(self.is_e_forte_full()), self._slot_state()
        self._phase_observations = f'{specific}, E满={full_e}, 人像={slot}'
        if slot in ('statue', 'ready'):
            return 'dominion' if slot == 'statue' else 'heavy2'
        if full_e:
            return 'illumining'
        gauge = self._answering_gauge()
        if gauge is not None and gauge[0] >= .50:
            return 'answering'
        if (gauge is not None and gauge[0] < .15 and self._resonance_hud_ready()
                and self.task.available('liberation', check_color=True, check_cd=False)):
            # 心卜雷的多帧形态判据；没有可靠画面时不会据模板缺失冒认照世相。
            return 'illumining'
        if self._phase == 'dominion' and time.time() >= self._dominion_until:
            return 'illumining'
        return self._phase if self._form != 'unknown' else 'unknown'

    def _observe_phase(self):
        """连续两帧步骤一致才采用；后半轮次跳转还必须有更可靠的形态证据。"""
        phase = self._read_phase()
        if phase == 'finisher' and not self.h2_completed and not self._phase_specific[2]:
            # _clear_visit 会清 H2 确认但保留跨场形态；_read_phase 的旧步骤
            # 回退不等于当前终结图标。未知时继续实际识别，不能重新锁死 H2。
            phase = 'unknown'
        self._candidate_hits = self._candidate_hits + 1 if phase == self._candidate else 1
        self._candidate = phase
        if self._candidate_hits < self.CONFIRM:
            return None
        if phase != self._reported_phase:
            self.logger.info(f'心锁守：心当前 {phase}；{self._phase_observations}')
            self._reported_phase = phase
        if phase != 'unknown':
            self._phase = phase
            if phase in ('answering', 'heavy1'):
                self._form = 'answering'
            elif self._form == 'illumining' or self.h2_completed or any(self._phase_specific[2:]):
                self._form = 'illumining'
            if phase == 'finisher' and not self._complete:
                self._enter_finisher('终结专用图标连续确认')
            # 初次进场的弱 E／人像猜测可指导观测动作，不能永久跳过第一次回锁。
            if phase == 'dominion' and self._dominion_until <= 0:
                self._dominion_until = time.time() + self.DOMINION_DURATION
            suo = self._team_suoming()
            if (suo is not None and suo.round_phase == 'hsin_first'
                    and self._form == 'illumining' and not self._r1_this_visit):
                suo.round_skipped_to_late = True
                suo.round_phase = 'hsin_late'
                self._return_armed = False
        return phase

    def _prepare_entry(self):
        """按实际形态选择参考入场时刻；H1 已亮走直接重击的较短入场分支。

        结束入场等待不等于已经进入重击／R 演出。第二轮应世心未满时，还须先
        补 A；不能在此撤掉交棒器的有限入场保护，让下一帧被长索敌截走。
        原截止从真实切入算起，原样保留、自然到期，绝不重新计六秒或等待六秒。
        """
        # R1 成功后又确认变奏，已有直接统御的凭据。入场前不再扫描前半／E图标，
        # 否则读取开销会叠加到每次攻击，甚至在打出第四次 A 前耗尽统御窗口。
        confirmed_dominion = (self._form == 'illumining' and self._phase == 'dominion'
                              and time.time() < self._dominion_until)
        phase = 'dominion' if confirmed_dominion else self._read_phase()
        late = phase in ('illumining', 'dominion', 'heavy2', 'finisher')
        lead = self.INTRO_LATE if late else self.INTRO_FULL_HEAVY if phase == 'heavy1' else self.INTRO_FIRST
        if self.has_intro and self.last_switch_in_time >= 0:
            self.sleep(max(0, self.last_switch_in_time + lead - time.time()))
        if not self._active():
            return False
        self._entry_done = True
        guard_left = max(0.0, getattr(self, '_team_entry_guard_until', 0.0) - time.time())
        self.logger.info(f'心锁守：入场准备完成，当前步骤={phase}，'
                         f'保留原入场保护余量 {guard_left:.2f}s，立即按实际就绪状态补条／出手')
        return True

    def _build_first(self):
        """补应世心并累计本次补条时间／次数；不在这个函数中假定重击已经解锁。"""
        if self._first_fill_started is None:
            self._first_fill_started = time.time()
            self.logger.info('心锁守：开始前半应世心补条，继续普攻并核实重击就绪')
        self._attack()
        self._first_fill_taps += 1

    def _first_hold_due(self):
        """H1 视觉漏检时，在已知应世相中决定是否做一次有限重击尝试。

        花图标就绪优先由调用者处理。参考心锁守 2.0.0 的补条修正：紫条
        “将满”不能充当解锁证据，普通重击不会可靠地补出缺少的应世心。
        先继续 A 等花图标；完全读不到图像时保留早期探测，持续漏检则仍
        保留原四秒补条后的有限探测，避免读数偏差造成永久不重击。
        任何探测本身都不证明清条、转相或同奏成功。
        """
        if (self._form != 'answering' or self.h2_completed or self._r1_this_visit
                or self._first_fill_started is None):
            return False
        gauge = self._answering_gauge()
        valid = gauge is not None and gauge[0] >= .50
        self._first_fill_seen = self._first_fill_seen or valid
        if self._first_fill_taps < self.FIRST_FILL_MIN_TAPS:
            return False
        elapsed = self.time_elapsed_accounting_for_freeze(self._first_fill_started)
        reason = None
        if not valid and elapsed >= self.FIRST_FILL_BLIND_AT and not self._first_fill_seen:
            reason = f'花／紫条未识别，补 A {elapsed:.2f}s 后有限尝试'
        if reason is None and elapsed >= self.FIRST_FILL_CAP:
            reason = f'H1 持续未识别，补 A {elapsed:.2f}s 后有限尝试（不据紫条近满认定就绪）'
        self._first_probe_reason = reason
        return reason is not None

    def _hold_first(self, probe=False):
        """执行前半重击并保留紧接 R1 的观测步骤。

        正常入口要求双帧 H1；漏检探测还要求已知应世相且无后半专用提示。
        保护只覆盖有限动作窗口，避免演出丢锁引发框架长时间索敌；无论异常、
        中途切人还是正常结束都松开鼠标。不会凭按够 1.8s 写入技能成功。
        """
        if time.time() < self._next_heavy:
            return
        if probe:
            if (not self._active() or self._form != 'answering' or self.h2_completed
                    or self._icon(Labels.hsin_h2) or self._icon(Labels.hsin_lib2)):
                return
        elif not self._stable_icon(Labels.hsin_h1):
            return
        reason = self._first_probe_reason if probe else self._h1_match_source
        self.logger.info(f'心锁守：心尝试前半重击；依据={reason}，不据此认定成功')
        self._r1_build_probe_done = False
        self._first_fill_started = None
        self._first_fill_taps = 0
        self._first_fill_seen = False
        start = time.time()
        pressed_at, hold_until = start, start + self.HEAVY1_HOLD
        full_at_press = not probe or self._icon(Labels.hsin_h1)
        next_probe, ready_since, ready_hits, repressed = start, None, 0, False
        # 与心汐守一致，以本次按住为锚点给转相解锁最多 3s；不是固定等满 3s。
        # 必须先设置保护再按鼠标，sleep/check_combat 也会调用框架的索敌逻辑。
        self._first_heavy_pending = {'deadline': start + self.FIRST_R_WINDOW}
        self._h1_guard_until = start + self.FIRST_R_WINDOW
        try:
            self.task.mouse_down()
            while time.time() < hold_until:
                if not self._frame():
                    # 演出藏 HUD 不代表被打断；只有稳定确认换成其他角色才放弃。
                    if self._reconcile_actor():
                        return
                    ready_since, ready_hits = None, 0
                elif not repressed and time.time() >= next_probe:
                    full = self._icon(Labels.hsin_h1)
                    now = time.time()
                    next_probe = now + self.FIRST_REPRESS_POLL
                    ready_hits = ready_hits + 1 if full else 0
                    ready_since = (ready_since if ready_since is not None else now) if full else None
                    stale = (full and ready_hits >= self.CONFIRM
                             and (not full_at_press
                                  or (now - pressed_at >= self.FIRST_REPRESS_MIN
                                      and now - ready_since >= self.FIRST_REPRESS_READY)))
                    if stale and now < hold_until:
                        # 按住后才亮，或亮着持续未消耗：只重建一次后台按下沿。
                        # 没有正面 H1 图标时不因超时猜测被吞，更不能重复打断演出。
                        self.task.mouse_up()
                        self.sleep(self.REHOLD_RELEASE)
                        if not self._active() or not any(c is self for c in self.task.chars):
                            return
                        repressed = True
                        pressed_at = time.time()
                        deadline = min(start + self.HEAVY1_HOLD + self.FIRST_R_WINDOW,
                                       pressed_at + self.FIRST_R_WINDOW)
                        hold_until = min(deadline, pressed_at + self.HEAVY1_HOLD)
                        self._first_heavy_pending['deadline'] = deadline
                        self._h1_guard_until = deadline
                        self.task.mouse_down()
                        self.logger.info('心锁守：H1 仍连续就绪，后台重击按下沿可能未被接受；'
                                         '有限松开重按一次，继续核实 R1，不记重击成功')
                self.sleep(self.POLL)
        except BaseException:
            self._first_heavy_pending = None
            self._h1_guard_until = 0.0
            raise
        finally:
            self.task.mouse_up()
        self._next_heavy = time.time() + self.ACTION_RETRY
        # 不凭按住完成认定步红尘成功。下一步骤只观察实际 R1，不插入补条 A。

    def _await_first_liberation(self):
        """衔接重击与 R1，避免清条后误回普攻，也避免索敌阻塞解锁窗口。

        截止时间始终锚定那一次鼠标按下，不在续调时刷新。专用 R1 图标及可用
        检测成立就调用 lib；真正成功仍由完整 R 演出判定。超时则撤销有限保护，
        重新允许实时补条／重击与 R 探测，不能声称已转相或免费切锁。
        """
        pending = self._first_heavy_pending
        while pending is not None and time.time() < pending['deadline']:
            if not self._frame():
                if self._reconcile_actor():
                    return
                self.sleep(self.POLL)
                continue
            # 已有后半专用提示时交还形态识别，不能在照世相盲按借相。
            if self._icon(Labels.hsin_h2) or self._icon(Labels.hsin_lib2):
                break
            if (self._icon(Labels.hsin_lib1)
                    and self.task.available('liberation', check_color=True, check_cd=False)):
                # 低帧率下，R 已亮但双帧模板确认可能跨过 3s 边界。只把这一轮
                # 确认交给现有 R 启动预算保护；不延长 pending 的主动观察截止点。
                self._h1_guard_until = max(pending['deadline'], time.time() + self.R_START_TIMEOUT)
                try:
                    if self.lib() or self._r_pending is not None:
                        return
                finally:
                    if self._first_heavy_pending is pending:
                        self._h1_guard_until = pending['deadline']
            self.sleep(self.POLL)
        self._first_heavy_pending = None
        self._h1_guard_until = 0.0
        self._r1_build_probe_done = False
        self.logger.warning('心锁守：前半重击后的 R1 窗口未确认，恢复实时补条／重击，不记转相成功')

    def _hold_second(self, ready_checked=False):
        """统御众机的持续输出与 H2 尝试；提示长时间保留时有限松开重按。

        连续藏 HUD 只建立待确认演出，不立刻认定 H2 完成；后续由 _await_heavy
        检查恢复画面。finally 保证鼠标释放，真正切到其他角色时立即停止。
        """
        # 备用形态分支也必须核实当前图像，不能凭记忆中的 heavy2 直接重按。
        if not ready_checked and not self._second_heavy_ready():
            return
        start, ready_since, repress, gone = time.time(), None, 0, 0
        hidden_since = None
        self.h2_guard_until = start + self.HEAVY_ANIMATION_TIMEOUT + self.HEAVY2_HOLD
        try:
            self.task.mouse_down()
            while time.time() - start < self.HEAVY2_HOLD:
                self.task.next_frame()
                self.check_combat()
                visible, index, _ = self.task.in_team()
                if visible and index != self.index:
                    return
                if not visible:
                    if hidden_since is None:
                        hidden_since = time.time()
                    gone += 1
                    if gone >= 3:
                        self._heavy_pending = {'start': hidden_since, 'hits': 0}
                        self.logger.info('心锁守：H2 按住后连续藏 HUD，保留演出候选，继续核实终结 R 图标')
                        return
                else:
                    if hidden_since is not None and time.time() - hidden_since >= self.HEAVY_ANIMATION_MIN:
                        # 慢帧只采到一两帧隐藏时保留弱候选。采样跨度不能证明
                        # 实际演出时长，必须继续等正面的终结提示，不能据此记成功。
                        self._heavy_pending = {'start': hidden_since, 'hits': 0,
                                               'sparse': True, 'back_at': time.time()}
                        return
                    hidden_since = None
                    gone = 0
                    # 参考轴在长按期间仅用中心人像检测受击后的重按条件。
                    # H2 模板不作每帧扫描：同奏下可能来不及显示，且扫描耗时会挤掉持键窗口。
                    ready = self._slot_state() == 'ready'
                    ready_since = (ready_since or time.time()) if ready else None
                    if ready_since is not None and time.time() - ready_since >= self.REHOLD_DELAY and repress < 2:
                        self.task.mouse_up()
                        self.sleep(self.REHOLD_RELEASE)
                        if not self._active():
                            return
                        self.task.mouse_down()
                        repress += 1
                        ready_since = None
                self.sleep(self.POLL)
            if hidden_since is not None:
                # 持键上限到时仍在演出，采样未满三帧也不能直接丢掉已见的藏 HUD。
                self._heavy_pending = {'start': hidden_since, 'hits': 0,
                                       'sparse': True, 'back_at': None}
        finally:
            self.task.mouse_up()
            if self._heavy_pending is None:
                self.h2_guard_until = 0.0
        self._dominion_presses = 0

    def _await_heavy(self):
        """所有后半重击候选均核对正面后继，不能凭旧提示全部消失宣告完成。

        连续藏 HUD 也可能来自无关画面，统一等专用终结 R 提示；能量暂缺可
        补 A，让真实提示出现。看到 H2／统御人像仍在则交回就绪识别与重试。
        """
        return self._await_heavy_result()

    def _await_heavy_result(self):
        """只凭正面终结提示确认后半重击，不能拿未知像素充当成功。

        两次采样相隔很久不证明 HUD 实际一直隐藏。图案全缺时持续补 A 恢复能量，
        让真实终结提示出现；只有 H2／统御人像连续仍在，才交回重击重试。
        四秒仅是本次观察工作片，不是能量补足的总上限，不能到点丢弃候选。
        不重复固定四下与长按，也不提前允许照世相的借相 R。
        """
        pending, start = self._heavy_pending, time.time()
        pending.setdefault('hud_deadline', pending['start'] + self.HEAVY_ANIMATION_TIMEOUT)
        while time.time() - start < self.HEAVY_ANIMATION_TIMEOUT:
            self.task.next_frame()
            if self._reconcile_actor():
                return False
            if not self._active():
                pending['hits'] = 0
                pending['retry_hits'] = 0
                if time.time() >= pending['hud_deadline']:
                    # 没有恢复画面就不能永远占住 H2；这不是重击成功，后续仍
                    # 按实际形态识别。已经恢复并进入补能的候选不走此超时。
                    self._heavy_pending = None
                    self.h2_guard_until = 0.0
                    self._action_recovery_until = time.time() + self.ACTION_RECOVERY_GUARD
                    self.logger.warning('心锁守：H2 候选未在动画观察期限内恢复 HUD，'
                                        '解除旧候选并重新识别，不记成功')
                    return False
                # HUD 丢失期间只做有限恢复观测，不在截止处理前进入长索敌。
                self.sleep(self.POLL, check_combat=False)
                continue
            self.check_combat()
            # 这是连续缺失 HUD 的期限，不是补能上限。真实画面已经恢复并
            # 持续补能后，不能因偶发一帧 HUD 抖动撤销原候选。
            pending['hud_deadline'] = time.time() + self.HEAVY_ANIMATION_TIMEOUT
            if self._icon(Labels.hsin_lib2):
                pending['retry_hits'] = 0
                pending['hits'] += 1
                if pending['hits'] >= self.CONFIRM:
                    self._heavy_pending = None
                    # 原来这里清掉保护后，下一次 _frame 先进入最长30s索敌，
                    # 终结 R 还没机会执行。正面图标确认后连续交给终结步骤。
                    self._enter_finisher('H2 演出后双帧终结 R 图标')
                    return True
                self.sleep(self.POLL)
                continue
            pending['hits'] = 0
            # 人像很小可随 A 读取；H2 大模板只做一次候选复核，避免又把补能拆成卡顿。
            prompt_still_there = self._slot_state() in ('ready', 'statue')
            if not pending.get('prompt_checked'):
                pending['prompt_checked'] = True
                prompt_still_there = prompt_still_there or self._icon(Labels.hsin_h2)
            pending['retry_hits'] = pending.get('retry_hits', 0) + 1 if prompt_still_there else 0
            if pending['retry_hits'] >= self.CONFIRM:
                self._heavy_pending = None
                # 连续看见原提示才回到重击识别；保留原有限保护覆盖调度衔接，
                # 不用恢复动画中的一帧人像/雕像立刻撤保护并触发索敌。
                self.logger.info('心锁守：H2 后原重击提示连续仍在，重新核实重击；保留原保护期限')
                return False
            if prompt_still_there:
                self.sleep(self.POLL)
                continue
            if pending.get('result_since') is None:
                pending['result_since'] = time.time()
            self._build_finisher_energy()
        # 观察片结束只让出调度，原候选和补能进度继续保留。不能把能量不足
        # 误作重击失败，也不能清保护后让长索敌阻塞下一片的普通攻击。
        return False

    def _enter_finisher(self, reason):
        """正面终结提示确认后，连续保护 H2 到 R 的衔接；不以保护期限认定施放。

        原生战斗检查在每次取帧以及 perform 返回外层时都可能重新索敌。
        此保护跨工作片保留，首次进入只给既有 R 动画观察上限；到期后
        由真实敌人线索决定是否继续补能，原截止不续期。真正开始 R 后由
        其独立演出保护接管，不能凭保护或能量补足用时认定 R 已成功。
        """
        if not self.h2_completed:
            self._finisher_guard_until = time.time() + self.R_ANIMATION_TIMEOUT
            self.logger.info(f'心锁守：{reason}，直接衔接终结 R，取消开大前补协奏')
        self.h2_completed = True
        self._phase, self._form = 'finisher', 'illumining'

    def click_liberation(self, **kwargs):
        """专用 R 图标＋实际演出确认；发键、模板消失、HUD 闪烁都不能单独算成功。

        start 限制发键启动；last_send 是最近重试；accepted 保存候选演出的发键。
        gone_at／hud_back_at／hidden 记录每段实际藏 HUD，用于最短演出和冻结记账。
        两种 R 均须有完整演出、旧 R 提示消耗、本角色 HUD 连续恢复。R2 回应世后
        不一定有满条 H1 或已解锁 R1，它们不是常驻形态标志，不能作为完成门槛。
        同一候选只使用一个绝对截止；跨工作片不能再赠送七秒空等。截止后仍取一帧
        先核实结果，再进入恢复／补能，不把超时本身或单独的图标消失当成施放成功。
        """
        kind = self._r_pending['kind'] if self._r_pending else self._casting_kind
        label = Labels.hsin_lib1 if kind == 'r1' else Labels.hsin_lib2
        if self._r_pending is None:
            if not self._stable_icon(label) or not self.task.available('liberation', check_color=True, check_cd=False):
                return False
            # 在 R 前捕获协奏，不能在 R1 完成后的同奏窗口再读 OCR。
            self._raw_con()
            self._r_pending = {'kind': kind, 'start': time.time(), 'last_send': -1.0,
                               'gone': 0, 'gone_at': None, 'hud_back_at': None, 'hidden': [],
                               'started': False, 'back': 0, 'accepted': None}
        pending = self._r_pending
        # 兼容重新导入时继承的旧 pending。首次真正发键会把截止锚定到该次输入；
        # 后续重试、调用重入及 result_only 都不能不断延长演出保护。
        pending.setdefault('deadline', pending['start'] + self.R_ANIMATION_TIMEOUT)
        self.h2_guard_until = pending['deadline']
        try:
            while True:
                self.task.next_frame()
                # 失败观察按取帧时刻计时，不能把后续模板读取耗时当成新画面。
                # 否则末发后过早的一帧，可能因识别跨过 .4s 而被误当成超时证据。
                frame_at = time.time()
                # 截止帧先被动核实 R 结果，不能在读结果之前进入长索敌。
                # 未到截止时照常检查；截止后本次不再启动新 R 输入。
                if frame_at < pending['deadline']:
                    self.check_combat()
                if self._reconcile_actor():
                    return False
                now = time.time()
                if not self._active():
                    pending['gone'] = pending['gone'] + 1 if pending['last_send'] >= 0 else 0
                    if pending['last_send'] >= 0 and (pending['gone_at'] is None or pending['hud_back_at'] is not None):
                        pending['gone_at'] = frame_at
                    pending['hud_back_at'] = None
                    pending['back'] = 0
                    if pending['gone'] >= 3 and not pending['started']:
                        pending['started'] = True
                        pending['accepted'] = pending['last_send']
                        if kind == 'r1':
                            self._r1_sent_at = pending['accepted']
                        self.logger.info(f'心锁守：{kind} 发键后 HUD 连续隐藏，核实完整演出')
                    self.task.in_liberation = pending['started']
                elif pending['started'] or (pending['gone_at'] is not None and not self._icon(label)):
                    # 低帧率可能只看见一帧隐藏；真实 R 图标转相与恢复双帧仍可确认。
                    if not pending['started']:
                        pending['started'] = True
                        pending['accepted'] = pending['last_send']
                        if kind == 'r1':
                            self._r1_sent_at = pending['accepted']
                    if pending['hud_back_at'] is None:
                        pending['hud_back_at'] = frame_at
                        pending['hidden'].append((pending['gone_at'], frame_at))
                    # 沿用心汐守的完整 R 演出＋恢复确认，并额外保留旧专用 R 提示
                    # 已消耗的要求。R2 后不能强求下一轮 H1 满条／R1 解锁图标。
                    # 发键前稳定专用模板、发键后的藏 HUD、完整演出及恢复双帧缺一不可。
                    full_animation = (pending['accepted'] is not None
                                      and pending['last_send'] >= 0
                                      and pending['gone_at'] >= pending['accepted']
                                      and pending['hud_back_at'] - pending['accepted'] >= self.R_ANIMATION_MIN)
                    if full_animation and not self._icon(label):
                        pending['back'] += 1
                        if pending['back'] >= self.CONFIRM:
                            for began, ended in pending['hidden']:
                                self.add_freeze_duration(began, ended - began)
                            self.record_liberation_use()
                            self.current_con = min(1.0, self.current_con + .20)
                            self._r_pending = None
                            self.h2_guard_until = 0.0
                            self.logger.info(f'心锁守：{kind} 完整演出、HUD 恢复及专用提示消耗已确认，'
                                             f'演出观察 {pending["hud_back_at"] - pending["accepted"]:.2f}s，'
                                             '继续交棒流程')
                            return True
                    else:
                        pending['back'] = 0
                else:
                    pending['gone'] = 0
                    send_deadline = pending['start'] + self.R_START_TIMEOUT
                    sent_this_frame = False
                    if (now < send_deadline and self._icon(label)
                            and self.task.available('liberation', check_color=True, check_cd=False)):
                        # 图像读取可能跨过发键截止，必须在真正发键前重新读时钟。
                        send_at = time.time()
                        if (send_at < send_deadline
                                and send_at - pending['last_send'] >= self.R_KEY_INTERVAL):
                            first_send = pending['last_send'] < 0
                            pending['last_send'] = send_at
                            if first_send:
                                pending['deadline'] = send_at + self.R_ANIMATION_TIMEOUT
                                self.h2_guard_until = pending['deadline']
                            pending['gone_at'] = None
                            pending['hud_back_at'] = None
                            pending['hidden'] = []
                            self.send_liberation_key(down_time=.01)
                            sent_this_frame = True
                            if first_send:
                                self.logger.info(f'心锁守：已发送 {kind} 首次 R，等待实际演出确认')
                    observe_until = max(
                        send_deadline,
                        pending['last_send'] + self.R_START_CONFIRM
                        if pending['last_send'] >= 0 else send_deadline)
                    # 末次输入至少经过下一帧观察，不能发完就丢候选。
                    # 截止后见过疑似藏 HUD，则继续原有演出核实，不能抢发补条 A。
                    if (not sent_this_frame and frame_at >= observe_until
                            and pending['gone_at'] is None):
                        self._r_pending = None
                        self._next_r = time.time() + self.ACTION_RETRY
                        self.h2_guard_until = 0.0
                        return False
                if not pending['started'] and pending['last_send'] < 0 and now - pending['start'] >= self.R_START_TIMEOUT:
                    self._r_pending = None
                    self._next_r = now + self.ACTION_RETRY
                    self.h2_guard_until = 0.0
                    return False
                if pending.get('result_only') and self._active():
                    # 等结果的状态不能饿死补条；旧 R 提示回来了则重做真实就绪判断。
                    if self._icon(label):
                        self._r_pending = None
                        self._next_r = now + self.ACTION_RETRY
                    else:
                        self.check_combat()
                        self._attack(interval=.12, hold=.06)
                    return False
                # 即使继承的 deadline 已过，也保证上面的当前帧结果核实／result_only
                # 至少执行一次；否则待结果状态会跳过循环，既不观察也不补条。
                if time.time() >= pending['deadline']:
                    break
                self.sleep(self.POLL)
        finally:
            self.task.in_liberation = False
        # 发键被吞后碰上无关 HUD 消失：真正恢复后 R 仍是原图标，不能永久卡在假演出。
        if self._active():
            full_animation = (pending['hud_back_at'] is not None and pending['accepted'] is not None
                              and pending['hud_back_at'] - pending['accepted'] >= self.R_ANIMATION_MIN)
            if self._icon(label) or not full_animation:
                # 短暂丢 HUD 不能锁死步骤；不报成功，交还实际重击／补能流程。
                self._r_pending = None
                self._next_r = time.time() + self.ACTION_RETRY
                self.h2_guard_until = 0.0
            else:
                # 旧提示已消耗、完整演出已有记录，但连续恢复帧尚不足。
                # 保留同一结果凭据供下一帧核实；不重开七秒演出窗口。
                pending['result_only'] = True
            self.logger.warning(f'心锁守：心 {kind} 已到本次 R 观察截止，完整演出={full_animation}，'
                                '结果未确认，恢复观测／补能，不记解放成功')
        else:
            # 截止时仍没有 HUD，解除旧 R 独占；不能每片都恢复同一假演出。
            # 仅清候选，不记 R 成功，也不清掉必须完成终结的已有 H2 进度。
            self._r_pending = None
            self.h2_guard_until = 0.0
            self._next_r = time.time() + self.ACTION_RETRY
            self._action_recovery_until = time.time() + self.ACTION_RECOVERY_GUARD
            self.logger.warning(f'心锁守：{kind} 结果观察期限已到且 HUD 未恢复，'
                                '解除未决演出，恢复实际形态／补能判断，不记成功')
        return False

    def _use_e(self, special=False):
        """尝试当前 E 并核对结果；普通 E 看 CD，特殊 E 看统御人像。

        只有实际特殊 E 消耗才写入统御状态和 13s 时间窗；被吞键不推进形态。
        """
        if time.time() < self._next_e or not self._resonance_hud_ready():
            return
        if not special and not self.task.available('resonance', check_color=True, check_cd=True):
            return
        self.send_resonance_key(down_time=.01)
        self._next_e = time.time() + self.ACTION_RETRY
        start, hits = time.time(), 0
        while time.time() - start < .9:
            if not self._frame():
                return
            consumed = self._slot_state() == 'statue' if special else self.task.has_cd('resonance')
            hits = hits + 1 if consumed else 0
            if hits >= self.CONFIRM:
                self.record_resonance_use()
                if special:
                    self._form, self._phase = 'illumining', 'dominion'
                    self._dominion_until = time.time() + self.DOMINION_DURATION
                return
            self.sleep(self.POLL)

    def _build_con(self):
        """交棒条件不足时用当前可用 E 或短普攻补协奏，不绕过尚未完成的终结 R。"""
        if self._active() and self.task.available('resonance', check_color=True, check_cd=True):
            self._use_e(special=bool(self.is_e_forte_full()))
        else:
            self._attack(interval=.12, hold=.06)

    def _return_to_suoming(self, suo):
        """委托锁冥的统一交棒器处理同奏／普通回锁；成功或已发切人即退出心的流程。

        同奏过期只会改为补满协奏后普通回锁，不能凭过期窗口伪造有效变奏。
        Q 与首个切人键的相邻发送由锁冥交棒器保证，这里不插入其他动作。
        """
        switched = suo.handoff_from_hsin(self, self._r1_unison_until)
        if switched or suo._pending is not None:
            raise _HandoffYield()
        # 同奏过期不伪造免费回锁，也不直接放弃双入场；补协奏后正常回锁。
        self._build_con()

    def _second_heavy_ready(self):
        """逐帧核实 H2：专用模板或中心就绪人像必须连续双帧成立。

        不是只在一组 A 前检查一次；连续补条过程中反复调用。图像没认出来就
        继续 A，不能凭四次 A、按够时长或统御剩余时间推测已能重击。
        """
        previous_match = None
        for frame_index in range(self.CONFIRM):
            if not self._frame():
                return False
            # 心汐守明确说明 hsin_h2 在同奏录像中可能完全不命中，人像才是主判据。
            slot_ready = self._slot_state() == 'ready'
            if slot_ready and self._slot_match is not None:
                current = self._slot_match
                if previous_match is not None and (abs(current[0] - previous_match[0]) > .101
                                                   or abs(current[1] - previous_match[1]) > .081
                                                   or abs(current[2] - previous_match[2]) > .081):
                    # 两帧必须来自相同或相邻的小范围采样，不能把不同干扰位置拼接。
                    return False
                previous_match = current
            template_ready = False
            if not slot_ready:
                now = time.time()
                if frame_index == 0 and now < getattr(self, '_h2_next_template', 0.0):
                    self._report_h2_observation()
                    return False
                self._h2_next_template = now + self.H2_TEMPLATE_POLL
                template_ready = self._icon(Labels.hsin_h2)
            if not (slot_ready or template_ready):
                self._report_h2_observation()
                return False
            self._h2_match_source = '重击位中心人像' if slot_ready else 'H2 专用模板'
            self.sleep(self.POLL)
        return True

    def _report_h2_observation(self, snapshot=False):
        """限频输出真实识别分数；持续漏检时保存一次技能位裁图，供实际复核。

        不发任何游戏操作，也不会据 A 次数或时间把未知判为就绪。截图仅在本次
        用户实际运行过程中生成；本文件导入或语法检查不会读取游戏窗口。
        """
        now = time.time()
        if now >= self._h2_next_report:
            self._h2_next_report = now + 2.0
            self.logger.info(f'心锁守：H2识别观察；人像/雕像分数={self._slot_scores}，'
                             f'位置尺度={self._slot_match}，画面={self._slot_geometry}，'
                             f'异常={self._slot_error}，A={self._dominion_presses}')
        if snapshot and not self._h2_snapshot_saved and self._active():
            try:
                # 与第7版识别位置配套恢复诊断框，便于核对装备声骸后的布局。
                box = self.task.box_of_screen_scaled(3840, 2160, 2670, 1760, 3060, 2100, hcenter=True)
                frame = self.task.frame
                crop = frame[max(0, box.y):box.y + box.height, max(0, box.x):box.x + box.width, :3]
                if crop.size:
                    self.task.screenshot(f'hsin_h2_unrecognized_{int(now)}', frame=crop.copy())
                    self._h2_snapshot_saved = True
                    self.logger.info('心锁守：已保存本次 H2 未识别的实际技能位截图')
            except (AttributeError, ValueError, IndexError, TypeError) as exc:
                self.logger.warning(f'心锁守：H2 诊断截图失败：{exc}')

    def _perform_dominion(self):
        """已确认统御时连续 A，并反复识别实际重击就绪；确认后才开始长按。

        不分固定四下小组，不盲试三秒长按，也不扫描前半 H1/R1/E。A 采用
        独立节拍，图像检查没有额外固定等待；当次读图较慢就按实际当前时刻
        发下一次 A，不积压补发。形态／任务／输入异常仍能退出并清理保护。
        """
        # 这里只暂停短动作段中的自动索敌，不新增等待。最晚在本次工作片或
        # 已确认统御窗口结束时失效；异常／换人／正常返回都在 finally 撤销。
        self._dominion_guard_until = min(self._dominion_until, time.time() + self.WORK_SLICE)
        try:
            if self._stable_icon(Labels.hsin_lib2):
                # 后继专用提示本身可证明已到终结阶段，不重放补条和长按。
                self._enter_finisher('统御步骤读到连续终结 R 图标')
                return
            if self._dominion_presses == 0:
                self.logger.info('心锁守：统御持续短 A，逐帧核实 H2 就绪后才长按，不以 A 次数判定')
            next_attack = time.time()
            while time.time() < self._dominion_guard_until:
                if self._second_heavy_ready():
                    self.logger.info(f'心锁守：H2 图像连续就绪，开始后台长按；依据={self._h2_match_source}，'
                                     f'分数={self._slot_scores}，累计 A={self._dominion_presses}')
                    self._hold_second(ready_checked=True)
                    return
                if not self._active():
                    if self._reconcile_actor():
                        return
                    self.sleep(self.POLL)
                    continue
                now = time.time()
                if now >= self._dominion_guard_until:
                    break
                if now >= next_attack:
                    # 图像确认与输入分开；未就绪时只继续短 A，不开始无效长按。
                    self.task.click(down_time=self.DOMINION_ATTACK_HOLD)
                    self._dominion_presses += 1
                    next_attack = now + self.DOMINION_ATTACK_INTERVAL
                self.sleep(min(self.POLL, max(0.0, next_attack - time.time())))
            self.logger.info(f'心锁守：本片段 H2 未取得连续就绪图像，继续观察；累计 A={self._dominion_presses}')
            self._report_h2_observation(snapshot=True)
        finally:
            self._dominion_guard_until = 0.0

    def perform_everything(self):
        """按观测状态执行工作片段，而非机械播放一条固定时间轴。

        先续接 R／H2／H1→R1 未决动作，再处理回锁或完成后的交守。
        应世相先打已亮 H1；后半直接统御，不补电磁玩法的二阶段 A／E。
        finisher 分支能量不足持续补能，WORK_SLICE 结束也不会跳过终结 R。
        """
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.WORK_SLICE:
            if self._r_pending is not None:
                self.lib()
                continue
            if self._heavy_pending is not None:
                if not self._await_heavy():
                    return
                continue
            if self._first_heavy_pending is not None:
                self._await_first_liberation()
                continue
            if not self._frame():
                if self._reconcile_actor():
                    return
                self.sleep(self.POLL)
                continue
            if not self._entry_done and not self._prepare_entry():
                self.sleep(self.POLL)
                continue
            suo = self._team_suoming()
            if self._return_due and suo is not None:
                self._return_to_suoming(suo)
                continue
            if self._complete:
                if not self._post_r_normal_step():
                    continue
                con = self._raw_con()
                # 先记录真实初读，再进入连续确认；即使后续检查被截断，日志也能
                # 区分缺协奏、满值复核和交棒未送达，不能把三种情况都当作停手。
                if time.time() >= getattr(self, '_post_r_next_report', 0.0):
                    self._post_r_next_report = time.time() + 1.0
                    observed = f'{con:.0%}' if con is not None else '未知'
                    self.logger.info(f'心锁守：收尾完成，本轮初读协奏={observed}，'
                                     '满值则连续核实后交守，不满继续补条')
                if con == 1 and self._full_con():
                    handoff = getattr(suo, 'handoff_to_keeper_from_hsin', None)
                    if callable(handoff):
                        handoff(self)
                    return
                # 用户取消 R2 收尾后的 E。四段目标结束但协奏仍缺时只补 A，
                # 不能从通用补协奏入口再次插入 E／变身。
                self._attack()
                continue
            if self.h2_completed:
                # 已确认后半重击不再扫整套 H1/R1/E，也不为80%协奏插 A。
                # 终结图标可用时先 R；能量确实不足或输入失败才补 A，绝不跳过。
                if not self.lib(after_heavy=True) and self._r_pending is None:
                    self._build_finisher_energy()
                continue
            if (self._form == 'illumining' and self._phase == 'dominion'
                    and time.time() < self._dominion_until):
                # 仅可靠统御记忆走连续段；初始弱 E／人像猜测仍必须走下方形态核实。
                self._perform_dominion()
                continue
            phase = self._observe_phase()
            if phase is None:
                self.sleep(self.POLL)
                continue
            if phase == 'finisher':
                if not self.lib(after_heavy=True) and self._r_pending is None:
                    self._build_finisher_energy()
            elif phase in ('answering', 'heavy1'):
                # 重击已亮先打重击，不能让通用 R 高亮抢走本次动作。
                if self._icon(Labels.hsin_h1):
                    self._hold_first()
                elif self._first_hold_due():
                    self._hold_first(probe=True)
                elif (not self._r1_build_probe_done and self._icon(Labels.hsin_lib1)
                      and self.task.available('liberation', check_color=True, check_cd=False)):
                    if not self.lib() and self._r_pending is None:
                        # 通用白色检测不等于已解锁；R 被吞/未解锁不能饿死普攻补条。
                        if self._icon(Labels.hsin_h1):
                            self._hold_first()
                        else:
                            self._build_first()
                else:
                    self._build_first()
            elif phase == 'heavy2':
                # 已被图像认定 H2 的路径才允许长按；计数满四次 A 不再是入口。
                self._hold_second()
            elif phase == 'dominion':
                self._attack(interval=.18, hold=.06)
                self._dominion_presses += 1
            elif phase == 'illumining':
                if self.is_e_forte_full():
                    self._use_e(special=True)
                else:
                    self._attack()
            else:
                self._attack()

    def _answering_gauge(self):
        """按参考轴坐标读取左右紫条覆盖率，返回 (左, 右) 或 None。

        坐标以 3840×2160 为基准经 SDK 缩放；只识别 HSV 指定紫色，粉红满条
        可能读得较低，所以只能作为 H1 模板的后备，不能当作实际能量百分比。
        CV 库缺失或图像无效返回未知，由上层有限探测处理。
        """
        try:
            import cv2
            import numpy as np
            out = []
            for x1, x2 in ((1627, 1837), (1965, 2175)):
                box = self.task.box_of_screen_scaled(3840, 2160, x1, 1999, x2, 2011, hcenter=True)
                crop = self.task.frame[box.y:box.y + box.height, box.x:box.x + box.width, :3]
                if not crop.size:
                    return None
                hsv = cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_BGR2HSV)
                h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
                out.append(float(((h >= 125) & (h <= 160) & (s >= 70) & (v >= 90)).any(axis=0).mean()))
            return tuple(out)
        except (ImportError, AttributeError, ValueError, IndexError):
            return None

    def _slot_state(self):
        """复用参考轴重击位人像：返回统御 statue、H2 就绪 ready，或未知 None。

        使用参考中心遮罩与原始阈值，加入小范围位置／尺度容错。只比较中心
        图案，不将技能槽外围文字／高亮当作就绪。识别异常必须记录，不能把
        计算失败和正常未命中都静默返回 None。此结果仍不能独自跳过第一次回锁。
        """
        if not self._active() or not hasattr(self.task, 'frame'):
            return None
        try:
            import cv2
            import numpy as np
            ref = getattr(self, '_slot_ref', None)
            if not isinstance(ref, tuple) or len(ref) != 5 or not callable(ref[-1]):
                yy, xx = np.mgrid[:96, :96]
                disk = (((xx - 48) ** 2 + (yy - 44) ** 2) <= 25 ** 2).astype(np.float32)
                mask = cv2.resize(disk[18:70, 22:74], (16, 16), interpolation=cv2.INTER_AREA) > .99
                def vec(a):
                    a = a.astype(np.float32)
                    a = a - a.mean()
                    return a / max(float(np.linalg.norm(a)), 1e-6)
                def tpl(text):
                    return vec(np.frombuffer(base64.b64decode(text), np.uint8).reshape(16, 16)[mask])
                self._slot_ref = mask, disk, tpl(self.TY_GLYPH), tpl(self.READY_GLYPH), vec
            mask, disk, ty, ready, vec = self._slot_ref
            x, y, w, h = self.HEAVY_SLOT
            box = self.task.box_of_screen_scaled(3840, 2160, x, y, x + w, y + h, hcenter=True)
            cx, cy = int(box.x + box.width / 2), int(box.y + box.height / 2)
            frame = self.task.frame
            self._slot_geometry = (tuple(frame.shape), str(frame.dtype),
                                   (self.task.screen_width, self.task.screen_height),
                                   (box.x, box.y, box.width, box.height))
            best_ready, best_statue, rival, match = -1.0, -1.0, 1.0, None
            base_ready = base_statue = None
            qualified = None
            base_half = max(1, int(box.height * 1.1))
            # 原中心首先检查；没有稳定形状时才扩大取样。仍保持 .80 就绪阈值，
            # 且就绪图案须明显领先同一位置的雕像图案，不靠降低门槛制造命中。
            shifts = ((0, 0), (-.08, 0), (.08, 0), (0, -.08), (0, .08),
                      (-.08, -.08), (-.08, .08), (.08, -.08), (.08, .08))
            for scale in (1.0, .9, 1.1):
                # 基础尺度必须保留原参考的截断方式，4K 为 half=86，不变成87。
                half = max(1, int(round(base_half * scale)))
                for dx, dy in shifts:
                    px, py = int(round(cx + dx * box.width)), int(round(cy + dy * box.height))
                    left, top, right, bottom = px - half, py - half, px + half, py + half
                    if left < 0 or top < 0 or right > frame.shape[1] or bottom > frame.shape[0]:
                        continue
                    crop = frame[top:bottom, left:right, :3]
                    if not crop.size:
                        continue
                    gray = cv2.cvtColor(cv2.resize(crop, (96, 96), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY).astype(np.float32) * disk
                    v = vec(cv2.resize(gray[18:70, 22:74], (16, 16), interpolation=cv2.INTER_AREA)[mask])
                    rd, st = float(v @ ready), float(v @ ty)
                    if scale == 1.0 and dx == 0 and dy == 0:
                        base_ready, base_statue = rd, st
                    best_statue = max(best_statue, st)
                    if rd > best_ready:
                        best_ready, rival, match = rd, st, (scale, dx, dy)
                    if rd >= .80 and rd - st >= .10 and (qualified is None or rd > qualified[0]):
                        qualified = (rd, st, (scale, dx, dy))
                    if scale == 1.0 and dx == 0 and dy == 0 and rd >= .80 and rd - st >= .10:
                        break
                if qualified is not None:
                    break
            if qualified is not None:
                best_ready, rival, match = qualified
            self._slot_scores = {'ready': round(best_ready, 3), 'statue_same': round(rival, 3),
                                 'statue_max': round(best_statue, 3),
                                 'base_ready': None if base_ready is None else round(base_ready, 3),
                                 'base_statue': None if base_statue is None else round(base_statue, 3)}
            self._slot_match = match
            self._slot_error = None
            if best_ready >= .80 and best_ready - rival >= .10:
                return 'ready'
            if best_statue >= .60:
                return 'statue'
        except Exception as exc:
            # 仅消化图像／依赖问题；任务停止或执行器异常必须继续向外传播。
            if not isinstance(exc, (ImportError, AttributeError, ValueError, IndexError, TypeError)) and type(exc).__module__ != 'cv2':
                raise
            self._slot_error = f'{type(exc).__name__}: {exc}'
            if not self._slot_error_reported:
                self._slot_error_reported = True
                self.logger.warning(f'心锁守：重击位图像识别出错：{self._slot_error}')
            return None
        return 'unknown'

    def _opening_keeper(self):
        """按身份寻找同队守岸人的首发协调接口，不假定守岸人固定在一号槽。"""
        return next((c for c in self.task.chars if c is not None
                     and c.char_name == 'char_shorekeeper'
                     and callable(getattr(c, 'ensure_opening', None))), None)

    def perform(self):
        """接入框架角色入口；新战斗先确保守岸人完成首发接管，再执行心。"""
        try:
            keeper = self._opening_keeper()
            if keeper is not None and not keeper.ensure_opening(self):
                return
            return super().perform()
        except _BreakReady:
            # 异常已退出持鼠标的动作栈，其 finally 先松键，才允许发处决 F。
            suo = self._team_suoming()
            execute = getattr(suo, 'perform_ready_break', None)
            if callable(execute) and execute(self):
                pending = getattr(self, '_post_r_normals', None)
                if self._complete and pending is not None and not pending['done']:
                    # 处决打断了普通攻击连段，不能沿用打断前的时序充当完整收尾。
                    # 原地清共享字典，使热重载时继承它的新实例也重新衔接。
                    pending['elapsed'] = 0.0
                    # 确实执行处决后才重新开始收尾阶段；不是普通循环续保护。
                    self._post_r_guard_until = (time.time() + self.POST_R_NORMAL_TIME
                                               + self.POST_R_NORMAL_TAIL + self.POST_R_HANDOFF_GUARD)

    def check_combat(self):
        """及时响应处决，但先退出原动作栈，确保重击的持键 finally 能执行。"""
        suo = self._team_suoming()
        probe = getattr(suo, 'break_ready', None)
        if callable(probe) and probe(self):
            raise _BreakReady()
        return super().check_combat()

    def switch_other_char(self, allow_auto_combat=False):
        """将框架战前／战后切奶请求交给首发协调器，正常战中交棒仍走自定义流程。"""
        keeper = self._opening_keeper()
        if keeper is not None and allow_auto_combat:
            return keeper.ensure_opening(self, commit=False, check_combat=False)
        return super().switch_other_char(allow_auto_combat=allow_auto_combat)

    def skip_combat_check(self):
        """演出使用有限保护；终结补能和收尾按真实敌人线索保持可执行。

        返回 True 的作用是避免丢锁时进入 target_enemy 的长循环；暂停／停止仍由
        任务基础设施处理。固定保护到期后，终结步骤只有持续看到真实敌人线索
        才暂缓同步长索敌；线索消失即恢复普通检测，切出／重置会清理全部记忆。
        """
        keeper = self._opening_keeper()
        suo = self._team_suoming()
        return (time.time() < getattr(self, '_team_entry_guard_until', 0.0)
                or time.time() < self._h1_guard_until
                or time.time() < self._dominion_guard_until
                or time.time() < self._finisher_guard_until
                or time.time() < getattr(self, '_post_r_guard_until', 0.0)
                or time.time() < getattr(self, '_action_recovery_until', 0.0)
                or bool(keeper is not None and keeper.opening_guard_active())
                or bool(suo is not None and time.time() < suo._guard_until)
                or self._finish_work_has_enemy()
                or super().skip_combat_check())
