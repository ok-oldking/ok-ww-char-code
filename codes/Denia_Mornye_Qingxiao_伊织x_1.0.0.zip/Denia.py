"""清宵 0 链 / 达妮娅 3 链 / 莫宁 3 链：启动、次轮、循环。

Three-file workshop package: this file owns the coordinator; the other two
characters find it through task.chars, never through a sibling-file import.
Timing windows use the reference video and live-test feedback; revisions still
need live calibration on the target setup.
"""
import time
import base64
from contextlib import contextmanager

import cv2
import numpy as np
import win32api
import win32con
import win32gui

from ok import PostMessageInteraction
from src.Labels import Labels
from src.char.BaseChar import SwitchPriority
from src.char.Denia import Denia as NativeDenia



_MORN_Z2_AIM_TEMPLATE = cv2.imdecode(np.frombuffer(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAFsAAACSCAAAAAAPuuk5AAADBElEQVRoBbXBAWKjOBQFwe77H/qtzSRIwiKGr6VKbgvIFXJbQK6Q2wJyhfwlYBgYXuQCOQj3yCnphBVyIJ2wRgbShGXSkSask0aa8D+QnXTCD0OV7KQT3uQlFMlOOuFNCGWykyb8Y6iTnTRhnTTShHXSSBOWSUeasEp60oRV0pMmrJKeNGGRDKQJi2QgTVgkA2nCIhlIExbJQJqwSAbShEUykCYskoE0YZEMpAmLZCBNWCQDacIiGUgTFslAmrBIBtKERTKQJiySgTRhjYykE4pkRjqhRqakCUUyJU2okhnphCKZkU4oksgH6YQimZFeqJEZGYQamZBBqJIPMgpVciSjUCVHMgpF8kFGoUg+yChUyZEMQpkcySCUyZH0Qp0cSROWyIHswho5kF1YYIyMZBcWSORAdmGBxMhAdmGRjGQXaiRsZCS7UCIv4UVGsgsV8hZADmQXKmQTQEbyK5TIj8iB/Ao1ckZ24Q6JEJAzAgEk3GIEAnJGCC8SbpG3ALILyE4ICIQ7ZBNeZBdkJwHkJdwgm/Amv4LsJCCbcJ1swptMSROuk014kynphatkEzYyI71wlWzCRmZkEC6STdjIjByEK+RHeJEpY5BB+EauMIAMwjdyhQRkEL6RKyTIKHwhl8in8IVcIp/CN3KFfArfyBXyKVwjhI3MyChCuEVOyCDcI0FOSBNukyAnpAn3yTlpwn1yTppQIKekCffJOWnCfXJOOuE2OSedcJuck064Tc5JE+6Tc9KE2+QP8isUyB/kRyiRc7IJVXLK8GIklEgn0jH8PwQC8hZ5Mdwim4AQGoEgHfkn3CPfyUy4TQYB5FR4k3/CHfIifwggU+GT/Apv8oeAXBSQ0JOnBHmOPEeeI8+R58hz5DnyHHmOPEfOhDepkxNhI3UyF35ImUyFnVTJTGikSmZCI1UyETpSJROhJ0XyKYykRj6EIymRUZiRChmEKamQXpiTCumFOamQXjghBdILJ6RAeuGEFEgvnJAC6YUTUiCDMCMlchAOpEqeI8+R58hz/gPg78GP0I5G+AAAAABJRU5ErkJggg=='), np.uint8), cv2.IMREAD_GRAYSCALE)
_MORN_Z2_AIM_SCALES = tuple(cv2.resize(_MORN_Z2_AIM_TEMPLATE, None, fx=s/2, fy=s/2, interpolation=cv2.INTER_NEAREST)
                            for s in (.85, 1, 1.15))

# Clear triangular core and lower marker, before the red overlay blooms.
_MORN_Z2_CORE_TEMPLATE = cv2.imdecode(np.frombuffer(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAGAAAACiCAAAAACb05dbAAACzUlEQVRoBbXBh4GgOAAEwe78g55b+4+QRayq5DA5TA6Tw+QwOUwOk8PkMDlMKmGPQJCS3IV3pCCl8J5cSCH8AbmQQvgDciGF8AfkQgrhD8iFFMIfkAsphPfkSkrhNbmSQnhNClIKb0lBSuElKUkpvCQluQnvSEluwityIzfhDbmTm/CG3Mld2CcVuQv7pCJ3YZvU5C5sk5rchV3SIHdhlzRIJeyRFqmEPdIilbBHWqQStkiTVMIWaZJa2CBtUgsbpE1q4TnpkFp4THqkFh6THmkIT0mPNISnpEcawkPSJQ3hGemThvCIDEhLeEIGpCU8IQPSEh6QEWkJD8iINIVlMiRNYZkMSVNYJWPSFFbJmLSEVTIhLWGVTEhDWCUz0hTWyIw0hSUyJW1hgcxJR5iTOekIczInbWFOapGStIU5WSAdYUZWSE+YkBXSE8ZkifSEMVkiPWFI1khPGJI10hNGZJH0hAFZJT1hQFZJTxiQVdIT+mSZ9IQuWSc9oUsmIr+kJ/QIRIjMSU/okS9B5qQjdMmngMxJR+iSTwGZk7bQJRAMyJw0hT4hYJAF0hL6BIIskobwydAgz0hD+CChJg/JQKjIQzIQ7uQpGQh38pSMhJI8JiOhJI/JSCjJYzIUruQ5GQpX8pwMhQvZIEPhf7JDxsIv2SJj4YfskbHwQ/bIWPghe2QsfJNNMha+ySYZC19kl0yET7JLxsIn2SYT4YNsk4kAsk9mArJP+iIQQAiyRSYC8it8EyJLZCYyEAwfpEMOk8PkMDlMDpPD5DA5TA6Tw+QwOUwOk8NkLPKODAV5R0YCyCsyED7JG9IXvsgb0hV+yAvSE37JC9IR/iMvSFu4kH3SEgqyT1pCSbZJQ7iRbVILFdkllVCTXXIXWmST3IUW2SSV0CJ7pBIaZJPUQkV2yUj4JtvkMDlMDpPD5DA5TA6Tw+QwOUwOk8PkMDnsHwaVkaPzV/seAAAAAElFTkSuQmCC'), np.uint8), cv2.IMREAD_GRAYSCALE)
_MORN_Z2_CORE_SCALES = tuple(cv2.resize(_MORN_Z2_CORE_TEMPLATE, None, fx=s/2, fy=s/2, interpolation=cv2.INTER_NEAREST)
                             for s in (.85, 1, 1.15))

def mornye_z2_aim(frame):
    """Positive Z2 aiming-overlay fallback, only consulted during opening EZ.

    Match the inverted triangle together with its small lower marker. The
    core becomes pale/white during bloom, so saturated red alone loses it.
    White-core matches additionally require red surroundings, not just a
    bright combat effect. A low resource bar is never proof of Z2.
    """
    if frame is None or frame.size == 0 or frame.ndim != 3 or frame.shape[2] < 3:
        return False
    height, width = frame.shape[:2]
    if abs(width/height-16/9) > .04:
        return False
    crop = frame[round(height*150/720):round(height*520/720),
                 round(width*320/1280):round(width*850/1280), :3]
    # Match only this small combat-view crop; keep the input loop responsive.
    hsv = cv2.cvtColor(cv2.resize(crop, (265, 185)), cv2.COLOR_BGR2HSV)
    mask = ((((hsv[:, :, 0] <= 12) | (hsv[:, :, 0] >= 160)) &
             (hsv[:, :, 1] >= 90) & (hsv[:, :, 2] >= 100)).astype(np.uint8)*255)
    if any(cv2.minMaxLoc(cv2.matchTemplate(mask, template, cv2.TM_CCOEFF_NORMED))[1] >= .72
           for template in _MORN_Z2_AIM_SCALES):
        return True
    # Early clear pink core: its saturation falls below the old 90 threshold.
    pale = ((((hsv[:, :, 0] <= 12) | (hsv[:, :, 0] >= 170)) &
             (hsv[:, :, 1] >= 30) & (hsv[:, :, 2] >= 220)).astype(np.uint8)*255)
    if any(cv2.minMaxLoc(cv2.matchTemplate(pale, template, cv2.TM_CCOEFF_NORMED))[1] >= .72
           for template in _MORN_Z2_CORE_SCALES):
        return True
    # Bloom can whiten the core completely. Keep the same two-part geometry
    # and require red on both sides of the match before accepting white pixels.
    bright = (hsv[:, :, 2] >= 220).astype(np.uint8)*255
    red = (((hsv[:, :, 0] <= 12) | (hsv[:, :, 0] >= 160)) &
           (hsv[:, :, 1] >= 60) & (hsv[:, :, 2] >= 100))
    for template in _MORN_Z2_CORE_SCALES:
        _, score, _, (x, y) = cv2.minMaxLoc(cv2.matchTemplate(bright, template, cv2.TM_CCOEFF_NORMED))
        if score < .72:
            continue
        h, w = template.shape
        left = red[y:y+h, max(0, x-w//2):x]
        right = red[y:y+h, x+w:min(red.shape[1], x+w+w//2)]
        if left.size and right.size and left.mean() >= .25 and right.mean() >= .25:
            return True
    return False

TEAM = frozenset({'Denia', 'Mornye', 'Qingxiao'})
STATE_KEY = '_qdm_c3_full_cycle_v1'
PACKAGE_ID = 'qdm-c3-full-cycle-v1'
ENTRY_HOOK = '_qdm_challenge_entry_v1'


def install_challenge_entry(task):
    """Task-local entry hook, installed during the framework's team refresh.

    No background polling or input thread. Keep the original bound checker,
    and resolve the current coordinator on each call so hot reload/team
    changes cannot leave an old character in charge of combat detection.
    """
    if type(task).__name__ != 'AutoCombatTask':
        return
    previous = getattr(task, ENTRY_HOOK, None)
    if previous is not None and previous.get('version') == 2:
        return
    # Replace our older wrapper on hot reload; never wrap a wrapper again.
    original = previous['original'] if previous else getattr(task, 'do_check_in_combat', None)
    if not callable(original):
        return
    hook = {'version': 2, 'original': original, 'absent_since': None, 'armed': False,
            'grace_until': 0.0, 'target_pending': False, 'detected_at': None}
    reset_challenge_start(task, hook)

    def check(target=False):
        axis = next((c for c in task.chars if c is not None
                     and callable(getattr(c, '_challenge_entry', None))
                     and c.qdm_team), None)
        if axis is not None:
            try:
                if axis._challenge_entry(hook):
                    return True
            except (KeyboardInterrupt, InterruptedError):
                reset_challenge_start(task, hook)
                raise
            except Exception as exc:
                reset_challenge_start(task, hook)
                hook.update(armed=False, absent_since=None, grace_until=0,
                            target_pending=False)
                axis.logger.warning(f'QDM challenge entry unavailable; native check: {exc}')
        else:
            reset_challenge_start(task, hook)
            hook.update(armed=False, absent_since=None, grace_until=0,
                        target_pending=False)
        result = original(target)
        if result:
            reset_challenge_start(task, hook)
            hook.update(armed=False, absent_since=None)
        return result

    hook['wrapper'] = check
    setattr(task, ENTRY_HOOK, hook)
    task.do_check_in_combat = check


def reset_challenge_start(task, hook):
    """Restore only the temporary polling interval owned by this hook."""
    old_interval = hook.get('trigger_interval_before')
    if old_interval is not None and getattr(task, 'trigger_interval', None) == .02:
        task.trigger_interval = old_interval
    hook.update(start_prompt_since=None, start_prompt_at=None,
                start_pressed_at=None, trigger_interval_before=None)


def challenge_activation_input(task):
    """Observe F/click only while the challenge prompt is being tracked.

    No listener, background thread or injected challenge interaction. Read
    just the game's foreground window; unsupported backends use countdown.
    The first prompt sample drains stale 'pressed since last read' bits.
    """
    interaction = getattr(getattr(task, 'executor', None), 'interaction', None)
    hwnd = getattr(interaction, 'hwnd', None)
    if not hwnd:
        return False, False
    foreground = win32gui.GetForegroundWindow()
    if not foreground or (foreground != hwnd and not win32gui.IsChild(foreground, hwnd)):
        return False, False
    f_pressed = bool(win32api.GetAsyncKeyState(ord('F')) & 0x8001)
    clicked = bool(win32api.GetAsyncKeyState(win32con.VK_LBUTTON) & 0x8001)
    if clicked:
        x,y = win32gui.ScreenToClient(hwnd, win32api.GetCursorPos())
        left,top,right,bottom = win32gui.GetClientRect(hwnd)
        width,height = right-left,bottom-top
        clicked = (width > 0 and height > 0 and .62 <= x/width <= .89
                   and .43 <= y/height <= .62)
    return True, f_pressed or clicked

# Default 16:9 normal-attack glyph, sampled from the user's recording after
# Qingxiao's Z2 impact. Embedded to preserve the workshop's four-file format.
QING_NORMAL_PNG = 'iVBORw0KGgoAAAANSUhEUgAAABoAAAAXCAAAAAAwvwDMAAACRklEQVQoFQXBTUhUURQA4HPufe/NjOO4GN1UCxXGVNIyKyt/KsiEQI2gP4hMkgQ3gYYtihDKXBQiFbRQCDStKCwrQySolCACIaLQVVCKSqGpM/Nm3rv33Hv7PiQv9fntL6kFgrR2y+U1iXQsdi8pEbUS8enhv0EjmArorceXp4PN0Zs/pQAk0BR/M7UoEYyfwcP19cHQ+/Zs6QG6DmLCmupftbQyjr2eeztq/nTPJxnhZGUGSu6NjbhoJAb02SPv/oUrv48uMWw+2mijocSX+4IU4w05U8u+2VRRvPASq6JtdYIjp6GxBCEvcOdymK8ha3sVHqYtl2NhzZQ//ijJFRg0pAy3TBrrdDD3/E5gYLyHExshgYpImKDhAg+GrVT5yXIFtko+HRXgGS1Ba2YRVgeYoljTfgckyL5PbgqYrxjXBFgWAiBV0lFkLKXdJy90ioC0pRliaTBAmll5nSXaYzwxNr6AhtmYsAlrXeAaBS+9GHNQ2TA0sha2EV1DeP1DJCUyFafi09siTDiJwefpIF/hHPDq3LqLh5bmLT+vYwfZqNMDw5FdP1aJYcveV1ibPcCM4oWtZUxxSvVvbpy5ETdY0xnNVLd+Z0pksqK1iBFRwo5M9yQNHmivhmuzNhkJYO27UAhaoP+h17MN1vTli3O+IzRKh8uaLsbVxscuO6IAH1cEdYsPqKWl0ORfKbbciQFHe5jGr3cibQ9mGQigDLaypyfHTPYWdH4bjKfwTHyxqeSuSwJRhzZOXZIz3VknGuzXz5L/AfHOMi1QuiNtAAAAAElFTkSuQmCC'
QING_NORMAL_TEMPLATE = cv2.imdecode(
    np.frombuffer(base64.b64decode(QING_NORMAL_PNG), np.uint8), cv2.IMREAD_GRAYSCALE)


def qing_normal_visible(frame):
    """Positive normal-icon match; missing/hidden HUD is never a hit signal."""
    if frame is None or frame.ndim != 3:
        return False
    height, width = frame.shape[:2]
    if abs(width / height - 16 / 9) > .04:
        return False
    crop = frame[round(height * 624 / 720):round(height * 665 / 720),
                 round(width * 934 / 1280):round(width * 976 / 1280), :3]
    if crop.size == 0:
        return False
    crop = cv2.cvtColor(cv2.resize(crop, (42, 41)), cv2.COLOR_BGR2GRAY)
    score = cv2.minMaxLoc(cv2.matchTemplate(
        crop, QING_NORMAL_TEMPLATE, cv2.TM_CCOEFF_NORMED))[1]
    return score >= .86


# Positive enhanced-normal glyph between Z1 and Z2, from 20261019-111004.
# A missing heavy label alone can be glow/occlusion, not stage completion.
QING_ENHANCED_NORMAL_TEMPLATE = cv2.imdecode(np.frombuffer(base64.b64decode(
    'iVBORw0KGgoAAAANSUhEUgAAACIAAAAgCAAAAABS5PUVAAAEDElEQVQ4EQ3BbUzUdRwA8N/3/3j3v2c4uDtxaHDEoaIB0cJGw+jJAc16Yatl0puGDzW3fFMoD9VWc8ialS3Lrdyy9aKGzaRMmSvHxF2C2LQZs47xdBz34N3/+f97qM8H1Jn3C7zlVpnAMUMWO/dOnc5LyIeZxfOsRD96+FMw07N3M3NZS6OOJWO2deTeiTsCZYbgz25s9j/4WCQLFJHUzcsreUsJprPg8x9PnsopzO2mMv94eyws2AUwRMZRTb2ngr0494+MR5e/1Msf2CI74UqvxFG8dA36fXXrvZ6oCIxiuwghEayixwXYBCgWciu5tQw8Nw8Bvz9eEwxIiiKpEQ+fdnN0ds3MLamqoeGoBC/+ysqDHFYk5NdJefuGUCT1/c28n/nd+axkI0+8HA5O52V/0B8QLEPC1btI2us6N0G8lZVmXjcLaH3cgXeLWeQjekEtaEjefDSWMbWzF5i/tkGak5RM1rdBgQ+N+8yj3l0msoFI3XvaHTH+3ZWyYFVIs11SMa2U+2BovsAr4MtpayoHsa7Ev794k3N1QbkBSaKlFUNBAY78nrHc8royr6lLKB9hjrhC7YgT9lqLKVSSNza4YeDaquY4ZQnvDcxBcN0jvrQZmj2/ydNSOo85Et6UQDA0vVCycUVzOLnguFxvt4Q4tjz+NVa6CmOMI9GmhApDs6mSjWPtseSMKUhtfVt5OHM2WRHsyY0xnlY+VK/DwO1UySAbWgM3btki7NjTwqAvyVh4Z/5HytPItnoNBv+cv29BrEa+k7ER+cZ35jX0ks4pru7sBQwkuq3egKGbCyUHVTS7Z5YtQsf1V0+hXsR5UFfmMqE02hjHMPzHkoaRZ4f416Kj4YuF3i/o61SQybMrkwTjaGMNhcHraY0g8WlluoDW4Jy+5zP6BhVFvSeVpLYTbaxh0H9tTSeIdEszBmToT9orn5ODjJe1roVp7OCKzbUI3pnM6IzBTmXKRCU0hnefRPupKFlPzt+mFg7V1fMw8NuqxpCr0z1VBAdGE90n2AEqCrRxdcmxqLc2IcDwRNogyNPhmlTBFA7t6vwY9iEB+Hg2TSzirm2QYOjiqkFQaLt8xXZM6a3ejuNoHwWREGDUwt7qJh4Gx1dMisJt4iXiKnF9bz71AeqzZYyBMupgf/RRAY7+vGoQFN7OX6JujX+5/4Uj5gE9aNsUbISdQKxNgMMTGZux8q38FAMidB/beyh7yAHAlDFKsS/S6oL9V/OEglKNljAj8jMjI8//fdhiPEOMMULcZds80HtdRRQJXjAEwGLH6LdPXB3WEA+IAcJYDicCsPuWyqH/AZN4KrV+cmPLD8d0RwSEGCWOUBUvg56UhhFQACaKWGw6eT/y1ahKBWCMUYKFqrqy/wCCGCksEKUVqgAAAABJRU5ErkJggg=='), np.uint8), cv2.IMREAD_GRAYSCALE)


def qing_enhanced_normal_visible(frame):
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return False
    height, width = frame.shape[:2]
    if not height or not width or abs(width/height-16/9) > .04:
        return False
    crop = frame[round(height*624/720):round(height*665/720),
                 round(width*934/1280):round(width*976/1280), :3]
    if crop.size == 0:
        return False
    crop = cv2.cvtColor(cv2.resize(crop, (42, 41)), cv2.COLOR_BGR2GRAY)
    score = cv2.minMaxLoc(cv2.matchTemplate(
        crop, QING_ENHANCED_NORMAL_TEMPLATE, cv2.TM_CCOEFF_NORMED))[1]
    return score >= .86


# Chinese "开启挑战" interaction caption from the supplied local recording.
# Match the text, never a generic F prompt, loot interaction or execution F.
CHALLENGE_START_TEMPLATE = cv2.imdecode(np.frombuffer(base64.b64decode(
    'iVBORw0KGgoAAAANSUhEUgAAAEUAAAAcCAAAAAASZy3KAAAA40lEQVQ4Ea3BsZHjQAAEMXT+Qc+Toqg6570FckJOyAk5ISfkhJyQE/Jfy9fCstwmTF55zE+YV1hYk9uEIY+8JiaXyWMxl9a0MGFaHnlNTC6Tx8K01rQwZJp85DUxuYzcJiymIUyMvPKamFzmJyysyW3CtDzyMX9k8sfIGjGXmJZHXhOTy/xkxHxkMhnyyGthchlyW1jWmpbJZOQrXxMml2m5LSysCZPJyFe+lsvksiy3hcU0WZPJZPnIY3KZXJZ5hGUyWXNraPnIx+Q2+ZjcFtOEkcm0TB45ISfkhJyQE3JCTvgHUSmAHQvaJTgAAAAASUVORK5CYII='), np.uint8), cv2.IMREAD_GRAYSCALE)


def challenge_start_prompt(frame):
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return False
    height, width = frame.shape[:2]
    if not height or abs(width/height-16/9) > .04:
        return False
    hud = cv2.resize(frame[:,:,:3], (1280,720))
    hsv = cv2.cvtColor(hud[300:445,795:1130], cv2.COLOR_BGR2HSV)
    mask = np.uint8((hsv[:,:,1] < 80) & (hsv[:,:,2] > 170))*255
    score = cv2.minMaxLoc(cv2.matchTemplate(mask, CHALLENGE_START_TEMPLATE,
                                          cv2.TM_CCOEFF_NORMED))[1]
    return score >= .88


def qing_normal_ready(frame):
    """Recognized Qing normal glyph AND bright strokes, not its grey outline."""
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return False
    height, width = frame.shape[:2]
    if not height or abs(width/height-16/9) > .04:
        return False
    crop = frame[round(height*624/720):round(height*665/720),
                 round(width*934/1280):round(width*976/1280), :3]
    if not crop.size:
        return False
    crop = cv2.resize(crop, (42,41))
    score = cv2.matchTemplate(cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY),
                              QING_NORMAL_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    _, confidence, _, (x,y) = cv2.minMaxLoc(score)
    if confidence < .86:
        return False
    hsv = cv2.cvtColor(crop[y:y+23,x:x+26], cv2.COLOR_BGR2HSV)
    bright = (hsv[:,:,1] < 90) & (hsv[:,:,2] > 175)
    return float(bright[QING_NORMAL_TEMPLATE > 175].mean()) >= .75


# Binary E glyphs from the supplied reference video (45.5s / 65.9s).
# Search only the E HUD area, covering the two recorded default HUD layouts.
QING_E_TEMPLATES = {}
QING_E_TEMPLATES['air-a3'] = cv2.imdecode(np.frombuffer(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAACcAAAAdCAAAAAAMKSoiAAAAxklEQVQ4EXXBAXIaQQAEMfX/Hz1ZKDB3OJZyN+S33M2RX3I3R37J3TzkW+7mId/yZZojN7mYjOYtL7lY5oh5yVMu1jzkZchDPqZ5ysvIQz7mKcvTZGHyMU+ZvE1YXpZjhMnbwjIPeRo5lpcJa+THyLG8LMeafAw5lqs1uRhyTH6sJhdz5G7K5GOO3C0x+TFHbhZheZsjV5OV5WOOXExGk48hFxOj5W8jjJY/DHkYLf81R46RJr/NkYflaPIywjzlqskxN/nyD8QfWRReHnmjAAAAAElFTkSuQmCC'), np.uint8), cv2.IMREAD_GRAYSCALE)
QING_E_TEMPLATES['ground'] = cv2.imdecode(np.frombuffer(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAACcAAAAdCAAAAAAMKSoiAAAAY0lEQVQ4EY3BAQrDMBDEQOn/j97ikJbaHHhnpCMd6UhHOtKRjnSkIx3pyBK5EAiyhD+ykXCQgeEgE8NGZgbkziAFIw0jDQNyZzjIxHCSgYSTLAH5EcKVyFcYyUN24SUb6UjnA8dtEh7XPrMiAAAAAElFTkSuQmCC'), np.uint8), cv2.IMREAD_GRAYSCALE)


def qing_e_icon(frame):
    """Positive E glyph classification; a missing/occluded icon is unknown."""
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return None
    height, width = frame.shape[:2]
    if abs(width / height - 16 / 9) > .04:
        return None
    crop = frame[round(height*618/720):round(height*665/720),
                 round(width*1025/1280):round(width*1180/1280), :3]
    if crop.size == 0:
        return None
    hsv = cv2.cvtColor(cv2.resize(crop, (155,47)), cv2.COLOR_BGR2HSV)
    mask = np.uint8((hsv[:,:,1] < 85) & (hsv[:,:,2] > 175))*255
    scores = {}
    for name, template in QING_E_TEMPLATES.items():
        scores[name] = max(cv2.minMaxLoc(cv2.matchTemplate(
            mask, cv2.resize(template, None, fx=scale, fy=scale),
            cv2.TM_CCOEFF_NORMED))[1] for scale in (.8,.9,1,1.1))
    name = max(scores, key=scores.get)
    return name if scores[name] >= .78 else None


_DENIA_FOLLOWUP_E_TEMPLATE = cv2.imdecode(np.frombuffer(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAABwAAAAbCAAAAABKY7DwAAAAkklEQVQoFXXBAZKiAAAEsfT/Hz2HiChVe0m+Joy85TZyGDnlY+Q08pLLCAsjh7xNXpavnEZelq8m5k85TB6WIUb+MBlhYcjHmhyGGDF5aXlbGLGccpuYLG/5seaQS37MKZf8mFMuzf/lZchcmhzyY0655MeccsltMrK85bYYsZzyMGI55WFaPvI0ueVpcsvT5PYP2zU6F35mc1MAAAAASUVORK5CYII='), np.uint8), cv2.IMREAD_GRAYSCALE)
_DENIA_FOLLOWUP_E_SCALES = tuple(cv2.resize(_DENIA_FOLLOWUP_E_TEMPLATE, None, fx=s, fy=s) for s in (.85,1,1.15))

def denia_followup_e_visible(frame):
    """Star/cross E glyph; only a new post-input transition can acknowledge E1."""
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return False
    height, width = frame.shape[:2]
    if not height or abs(width/height-16/9) > .04:
        return False
    crop = frame[round(height*618/720):round(height*665/720),
                 round(width*1055/1280):round(width*1110/1280), :3]
    if crop.size == 0:
        return False
    hsv = cv2.cvtColor(cv2.resize(crop, (55,47)), cv2.COLOR_BGR2HSV)
    mask = np.uint8((hsv[:,:,1] < 90) & (hsv[:,:,2] > 175))*255
    return any(cv2.minMaxLoc(cv2.matchTemplate(mask, template, cv2.TM_CCOEFF_NORMED))[1] >= .78
               for template in _DENIA_FOLLOWUP_E_SCALES)


def portrait_concerto_full(frame, current_index):
    """Both OFF-FIELD portraits show the expanding intro halo, not the active ring.

    Default 16:9 HUD, normalized to 720p. Sample the upper-left outer arc:
    exclude the portrait/hair, elemental/R-ready dot, slot number and HP bar.
    Broad white flashes are not a thin halo. Unknown framing is never full.
    """
    if (frame is None or frame.ndim != 3 or frame.shape[2] < 3 or
            current_index not in (0, 1, 2)):
        return False
    height, width = frame.shape[:2]
    if not height or abs(width/height - 16/9) > .04:
        return False
    hud = cv2.resize(frame[:,:,:3], (1280,720))
    # Crop first to keep HSV conversion and the two arc reads inexpensive.
    hsv = cv2.cvtColor(hud[120:390,1150:1240], cv2.COLOR_BGR2HSV)
    angles = np.deg2rad(np.arange(225,280))
    radii = np.arange(30,39,.5)[:,None]
    xs = np.rint(47 + np.cos(angles)*radii).astype(int)
    for index in range(3):
        if index == current_index:
            continue
        ys = np.rint(47.5 + 88.5*index + np.sin(angles)*radii).astype(int)
        pixels = hsv[ys,xs]
        white = (pixels[:,:,1] < 100) & (pixels[:,:,2] > 145)
        if white.any(axis=0).mean() < .78 or not .04 <= white.mean() <= .65:
            return False
    return True


def enemy_health_visible(frame):
    """Fresh visible HP fill, never cached boss HP or the empty bar border.

    Used only with the team HUD visible. False requests a bounded spawn pause,
    not proof of combat ending. No target-lock input or blood-bar wait loop.
    """
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return None
    height, width = frame.shape[:2]
    if not height or abs(width/height - 16/9) > .04:
        return None
    hud = cv2.resize(frame[:,:,:3], (1280,720))
    boss = cv2.cvtColor(hud[35:47,440:850], cv2.COLOR_BGR2HSV)
    mask = np.uint8((boss[:,:,0] < 40) & (boss[:,:,1] > 100) & (boss[:,:,2] > 140))
    _, _, stats, _ = cv2.connectedComponentsWithStats(mask)
    if any(w >= 2 and h >= 2 and area >= 6 for x,y,w,h,area in stats[1:]):
        return True
    # Floating red mob bars: avoid minimap/team HUD, damage digits and player HP.
    scene = cv2.cvtColor(hud[80:580,140:1150], cv2.COLOR_BGR2HSV)
    mask = np.uint8(((scene[:,:,0] < 12) | (scene[:,:,0] > 174)) &
                   (scene[:,:,1] > 100) & (scene[:,:,2] > 125))
    _, _, stats, _ = cv2.connectedComponentsWithStats(mask)
    return any(w >= 10 and 2 <= h <= 7 and w/h >= 4 and area/(w*h) >= .65
               for x,y,w,h,area in stats[1:])


# Default 16:9 countdown glyphs from the supplied 13:34 recording. Only the
# first five digits (MM:SS:t) are read; F's last centisecond digit can jitter.
EXECUTION_CLOCK_DIGITS = '000000001111111112222233445555566778899'
EXECUTION_CLOCK_STRIP = cv2.imdecode(np.frombuffer(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAdQAAAASCAAAAADHinCtAAAP5klEQVRoBXXBf2id133A4c/5oy5Z5Rohe1IMJY4iexGNXcL7DrqAqQ3WVSSiMgvuTQ2+qsu6cwLFIiMKuHctstZOBByVRKZrzjGpPMmrl3tBBsuzoh9gBw/1j7wvIaaegpWqDhmytCg1I2oKhnJ2vu97b21K9zwKrEY4g4gSRUOUEKfUnRmaGqDuzNDUAMJqhDOIKCFOyUWJ4mEeUOQ8ipxHKIQHFA0eUAgPKHIdK9A7S8YjFMIjFMUqmVoJilUytRIUq4hSDeGplaiLEuKUnKdWoi5KFA9JItKYjAcUYDWZNKZaJFcrUS2Sq5XAajJpTLVIrlYiM3RggIahAwOA589TwGQZ5rvJTJaZGiCjLcQpuSghTgHFVPeu5TJTnZ/MlWH02Lbdd6hcJBg9tm03a/cvVggmDzbv2Nr8oIdg8mDzjq3ND3pgqnvXcpmpzk/myjB6bNtu1u5frACjx7btvgMXK4irQA+ggKtAD7P0AgkRQpEAEZASAwkQAYqrQA+gCF5+ni8+Bb2zBFfpQSgSIAJifkTb073AVdbf+0ua22Mg4d7q/9D2dC9w9b11egFPrYS4vJ9tu1m7f7ECP+1lD7/7hO9dhcv72bb7DlyskLv6zA7SmIwHFGA1mTSmWiRXK1EtkquVwGoyaUy1SK5WIvjJ0S//xwC5nxz98rZLA+BpWC4nPKBg8mgT/P6dHoLJo01sbX7QA5f3b2+BtaGLwOX9bNvN2v2LFZTt33njtWn6XzyYxti+dAwsbgxs36O3DXbf3RkDbx5tfoMX2FrohzePNr/xVldla6Hf9u+88do0/S8eTGNs36O3DXbf3RmD7Xv0tsHuuztj4CTj5BQnGSensGhyDk2DwqLJDTJObpCzT5185ilE7yycZJycQ5NTjD/L24OAB4zGOUDriLPP8vYgMP7sXlS1SKZU41q0/coY2H13Z8y1r+7iMIeG+a/qyLXIXQHsvrszhowH0hhxchxQgO28gNicptruyKwuUm13ZFYXwXZeQGxOU213ZFYX4c32zta3RpbJnClfeovf3gRN7vjBNNbUHTyO4s2jP1uAeHihH948+rMFiIcX+q9F27ltrnF77ba5Fm2/MsY1uDtjlAdnAKvTeKKvxRl47qXdvxiZ6Gu5PnaFJCKNeb3c7MYZ1Gy08Xq52Y3feuKFoY02D84AVn80+jd9LdfHrvDcS4fSeKKv5frYFZKINO5ghQ/pQOxlhQ/pQBgsDk2DQyMMFofmT5mvDi79ih3PQ+9sByt8SAc5B2hAwTiDBCttTSiNQ1SLqHEGEdUiqlokU6rhOe9+CUlEGvt/eZfz7Dk0wZ3rJzAOSCLSmOCLX1kB0hjhCRRgMdRVKdFQpURD/4vLhpzWqyX+6P0D7pe/Ssj8099dGb/Fw+zBC6PUHdTPTpvXy2++8WsozG208Xq5eWAKCnMbbZ7z72xeOcG3D6WxB2c4wbcPpbHyfORGAauXywk4A1idxh6cAa2jtXOn11sZmOLAUHlr7PR6KwNTUJjbGhvmIzcKWI1wBrB67dwwOANaR2vnhgGFp0HhESkQ4xEpEOPJpcR4/lQKZ96iYwUGlxJA4REpMeABxR9ViyjqqkUUddUiQlGsQq10mpkU0DpK49O1WwgPjDCTAklEGhNECUEaIzyBgs4fbxpy0Sv3SjRUKdGQRM6Q89RKNAwNtQ5MkRsaah2Y4mGdP940NNijc2XWW6devQmFuY021lsZmILC3EabxzgCq9PYM3NuBrB67ZzyGEdgNcHSufOA1XdGJlg6dx6wGr7z2o75kSUozIFab50fWYLCHIFxBFYTLJ07D1hNsHTuPGA17AU+xCP2Ah/iEQrhEQrhySnAI/YiVhAK0bFCsBf4EI9QCA8oGlbamlDUVYsocittTQhFsQq1ErnnXjqUxtR5QJFJItKYIEr2XnqKNCZY6di7AgqSyBlynlqJhiolGpLIGXKeWomG9db5kSUyJ17bMT+yxMOSyBkaLAZeLzcPTEFhbqON9Vbc+C0KcxttHuMIrL4zMoFxBFaD8hhHYDWBcQRWExhHYDWisAB0zcPh6ebCAtA1T2AcgdUExhFYTWAcgdWgEB6hEB6hEB6hEB6hEB6hEB6hEB0rBArhEQrhAUWDBxQ5DyhynqBUQ3hAkUki0pjMrq9e45Nbh8kkEWkMPPO3H59NItIYGD85eNaDgiQil8aeulINT12pBklELo09daUah6abX04IthI8FP67FX57k4bEORqSyBng/QOjC9BevtfPdFcTb7xFe/lev8c4AqsJjCOwGpTHOAKrCYwjsJrAOAKrEYUFoGseUVgAuuYJjCOwmsA4AqsJjCOwGhTCIxTCIxTCIxTCAzEpwiMUwiMUomOFQCE8QiE8oMi1PX2V9fd6EUdeiVg8lSLanr7K+ns9pRrCAwqx5/L+z65/E7Gr+FOolQi27eby/s+ufxOe0s/EJBFpDPjZXjwoSCKWy0x18vlyxOIpOPIKq7VTnsVTcOQVVmunSCIgnurk8+WIutV7RNQtd3/sYeDoUbgx8IePySSd/+CoSzpfcx8Bs994BLjxrTVg9huPAPPd4Km4TwGrCYwDHh07BspjHIHVBMYRWE1gHIHViO55oDCH6J4HCnMExhFYTWAcgdUExhFYDQrhEQrhEQrhEQrhAUXOIxTCIxSiYwXGbzmERyiEBxS5YhVqJTLFKq62SKZYhVqJOg8ohAdnyFSLQK1EECWAM4DVaUwSkcaAV+BBQbJ8Y3Oa/hcPgmF1EdqPWFYXU1YXof2IZXXRJMs3wPW/eBAMOcvDNto8DRttZPw//9sydR7jEHMFgptfI5grAPPd4MEZwGoC44AkApTHOAKrCYwjsJrAOAKrEd3zQGEO0T0PFOYIjCOwmsA4AqsJjCOwGhTCIxTCIxTCIxTCA4qcRyiERyhExwr0zpLxCIXwgCJXrEKthDhS1M6l5IpVqJWo84BCeIyjrliFWomMB9IYrE5jkog0BrwCDwoqN24QWA2KnAcUOQ+oyo0bBFaDIufJDUxRnmSjzUP3PJQn2Wgj2Nlv45Tczn6LcQTvHxg4MARstMH7BwYODAEbbR6cgSQi4wwkEaA8xhFYTWAcgdUExhFYDY+/u7OwAHTNw+Pv7iwsAF3zBMYRWE1gHIHVBMYRWA0K4REK4REK4REK4QFFziMUwiMUomMFemfJeIRCeECR+X7x6d731hHRK9FqTN33i0/3vrdOgwcUsP/ynr53PqPuS7t+w+8+eRyxh9FjaUwSOQPP/KAnjbnaowAPigarQZHzgCKXtDejyFkNipwnM3Bpi/IkG20eCgtQnmSjjSBKiFNyUcLyD6aBdw9899IXhirwh48ff/fAdy99YcfRn/CHjw9f3v/Zp2BOHIPHL+//7FMwJ46B8hhHYDWBcQRWExhHYDWo9dbCAtA1D2q9tbAAdM0TGEdgNcFtNwZYTWAcgdWgEB6hEB6hEB6hEB5Q5DxCITxCITpWoHeWjEcohAcU4uR3mt4eJOeplag7+Z2mtwd5wAMKnjsdHU4/4wEPKHJWf5YeTv7XvQVY/fGZsx4FJ8dB0WA1KHIeUNRViyhyVoMi58kUFqA8yf2lQ1BYgNbymftLh4EoIU7JRQlxSrBeuXSPr7xQAdR65dI9aC2fARVtJ0hf1bfN9Wg7QfqqBuXBGcBqgqVz5wGr74xMsHTuPGA1qPXW+ZElKMyBWm+dH1mCwhzCGcBqhDOA1QRL584DVoNCeIRCeIRCeIRCeECR8wiF8AiF6FiB3lkyHqEQHlAIv14bpM6XajT49dogf1SsQq0EJ/5+98h5HuYBRc5q2HvprX8n+NG3YO8Ke2EF2MuH5KwGRc4DirpqEUXOalDkPJnueShPkumeBwpzoEBbiFMy2kKcAhPPf/0m8MQLQ3D++a/fJCjMgSJndRpTZ/WdEeXBGcDq5XICzgBWp7EHZwCr186dXm9lYAoKc1tjp9dbGZiCwtzW2DA4A1i9XE7AGdA6Wjs3DM6A1tHaudMIj1AIj1AIj1AIDyhyHqEQHqEQHSvQO0vGIxTCAwrhSzVyR14xq/do8KUaDxSrUCuhNc6ROV27hfDAiFtDWM3/S01dmiawGtJTiwgPKHJJezOKnNWQnlpEeDLd81CeZGtsGLrn4cBQeWvsNGhLvPw5GW0hTgHP124SFOYIvnaToDAHiozWURqT0zpKY6UrjzkDleOdaTzR1+IMPPfSoTSe6GtxBp576VAas97KwBRPvDC00cbr5eaBKZ54YWijTVcecwYqxzvTeKKvxRlIItJ4oq/FGUgi0piMRyiERyiERyiEBxwG4REK4REK0bECvbNkPEIhPKBgvIee9S2Epf2II2foGe9Z3+KBYhVqpRPDe67/K7mJUg3Yc2iC4PTF28BzLx36dOYEf9bel/v/0RFYDZRqCA84lyI84Lhwg8BqoFRDeOD884+8+savKU+y0Tbx/COvvvFrypNstMFxfRBFnbYQp4Dnhz9fAwpzBD/8+RpQmAOFODG85/YvRsicGN5z+xcjisrxzQtQeWz5wii2Lx0Du+/ujMH2pWNg992dMUx3NY0u0FXZWuiHN4/+bIGuytZCP5Xjmxeg8tjyhVGS6MoY2H13Zwy2Lx0Du+/ujCHjEQrhEQrhEQrhAYdBeIRCeIRCdKxA7ywZj1AIDyjGn93LWYKJ9/A8cJaOnrPkBhHFKtRKnoeMXAcODcMntw4xdgWw++7OmJNkXv4KH58hNw6DZ23/2zcIjh/cnNYuRVhWF7VLEZbVRfrfvkFw/ODmtHYpwrK6aKa7mkYX6KpsLfQz3dU0ukBXZWuhH6wGRe6gPg5xClwjHkmAeDgB4pEEiM/cXzoMj/4V17jtxiDaDlzjthtDQUU/BsufT48Co7oF1u5frACjugX41FWA2Sd3NrG1+UEPweTRJrY2P+gBKv1/0cny59OjcHn/9hZYu3+xAozqFli7f7FCziMUwiMUIiECFMIDipwnBWKERyhExwr0zpLxCIXwgMJTN/qfXF29R7R6DxHxgCKoFqFU4zePfhG4A9ub7sKXdhHc4er3fkPLdoJPXYW6JCKNyXlme2Gqc+djwEeby+WE5naClMVTCc3tBCmLp5jq3PkY8NHmcjmhuZ0gZfEUzD65swl+/04PMPvkzia2Nj/oAaz+fDkmV9G7likvI2afpHnH1uYHPcDsNx4Bfr+x+dfQoofvQuUikETAHSoXQQHaQpyS0RbilIy2gHFkJstMDZCbLDM1QC5KiFMy2kKcktEW4pQGj1AIj1DkPKAQHlDkPIoGj1CIjhXonSXjEQrhAYXnIaUavlRDeB5QBNUilGqQRIACrWMoVgkUwmoC42hIItKYnEchtAWMIyhWCRSiWCVQZLQFjCMoVgkUuckyzHeTmSwzNYCwOo1p0DrmgTNDUwNk5grAfDeB1WlMLokAhfg/CieDRgkaiRMAAAAASUVORK5CYII='),
    np.uint8), cv2.IMREAD_GRAYSCALE)


def execution_clock_tenths(frame):
    """Positive five-digit HUD reading; unreadable/unsupported means None."""
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return None
    height, width = frame.shape[:2]
    if not height or abs(width / height - 16 / 9) > .04:
        return None
    # Normalize before cropping: rounding a 1080p half-pixel crop first
    # changes the strokes of these small digits.
    crop = cv2.resize(frame[:,:,:3], (1280,720))[92:112,607:699]
    if not crop.size:
        return None
    hsv = cv2.cvtColor(cv2.resize(crop, (92,20)), cv2.COLOR_BGR2HSV)
    mask = np.uint8((hsv[:,:,1] < 80) & (hsv[:,:,2] > 175))*255
    values = []
    for x in (2,15,34,47,66):
        cell = mask[:,x:x+13]
        n, labels, stats, _ = cv2.connectedComponentsWithStats(cell, 8)
        if n < 2:
            return None
        chosen = 1 + int(np.argmax(stats[1:,cv2.CC_STAT_AREA]))
        left, top, w, h, area = stats[chosen]
        if not (10 <= h <= 19 and 2 <= w <= 13 and 15 <= area <= 180):
            return None
        clean = np.uint8(labels == chosen)*255
        glyph = cv2.resize(clean[top:top+h,left:left+w], (12,18),
                           interpolation=cv2.INTER_AREA)
        scores = [-1.0]*10
        for i, digit in enumerate(EXECUTION_CLOCK_DIGITS):
            score = float(cv2.matchTemplate(glyph,
                EXECUTION_CLOCK_STRIP[:,i*12:(i+1)*12], cv2.TM_CCOEFF_NORMED)[0,0])
            scores[int(digit)] = max(scores[int(digit)], score)
        order = sorted(range(10), key=lambda d: scores[d], reverse=True)
        if scores[order[0]] < .75 or scores[order[0]]-scores[order[1]] < .10:
            return None
        values.append(order[0])
    if values[2] >= 6:
        return None
    return (values[0]*10+values[1])*600+(values[2]*10+values[3])*10+values[4]


class ExecutionClockEvidence:
    """A newly stopped clock on fresh, moving Qingxiao frames.

    Used at F -> ground E (also requires ground E) and the new-target F -> R
    guard. This is composite visual evidence, not a game acknowledgement.
    An already frozen timer, unreadable digits, stale capture or normal
    ticking cannot confirm F.
    """
    def __init__(self):
        self.last_value = None
        self.running_steps = 0
        self.stopped_at = None
        self.frames = 0
        self.last_frame = None
        self.last_at = None
        self.stopped_for = 0.0
        self.value = None

    def observe(self, frame, now, ground):
        self.value = execution_clock_tenths(frame)
        self.stopped_for = 0.0
        if self.value is None:
            # A flash can hide one reading. It supplies no evidence and may
            # bridge at most .20s before a new readable sample is required.
            if self.last_at is None or now-self.last_at > .20:
                self.stopped_at, self.frames, self.last_frame = None, 0, None
            return False
        height, width = frame.shape[:2]
        scene = cv2.resize(frame[height//4:height*3//4,width//4:width*3//4,:3], (48,32))
        fresh = self.last_frame is not None and float(np.abs(
            scene.astype(np.int16)-self.last_frame.astype(np.int16)).mean()) >= 1.0
        gap = self.last_at is not None and now-self.last_at > .20
        delta = None if self.last_value is None else self.last_value-self.value
        if delta is not None and 1 <= delta <= 10:
            self.running_steps += delta
        elif delta is not None and delta != 0:
            self.running_steps = 0
        if delta != 0 or not fresh or gap or not ground:
            self.stopped_at, self.frames = now, 0
        elif self.stopped_at is not None:
            self.frames += 1
            self.stopped_for = now-self.stopped_at
        self.last_value, self.last_frame, self.last_at = self.value, scene, now
        return self.running_steps >= 2 and self.frames >= 3 and self.stopped_for >= .30


class AxisFault(RuntimeError):
    """A bounded, recoverable mismatch; native rotation takes over this battle."""


class AxisDeferred(RuntimeError):
    """Retry a saved boundary on the next perform; never disable the axis."""


# Positive white "wave" caption from the user's 20261017-153801 recording.
# Detect the caption, not a HUD disappearance or an assumed enemy death.
WAVE_TEMPLATE = cv2.imdecode(np.frombuffer(base64.b64decode(
    'iVBORw0KGgoAAAANSUhEUgAAADkAAAAVCAAAAADZHRkUAAAAsUlEQVQ4EZ3BAW4aUQBEMb/7H3r6IWmzC1JUYedT+Q/Lu1yNPEwelmPyJleTh5FjxMib/JgvzZFjZL7lIhdDjEaOaeSYXORiyIgRpsnD5CIXczRyTI7JaHKVizkauRt5kR/zV0z+GXmRm5F5ysPCyIvcjMyRpwkjL3IzX/JtYo7c5cc8NfJlwjRyk4s1YmEyYmLkKjcTFiYTk2PkIjcj5imLydPkInfLMUd+lU/lU/nUHywLSRbICtyFAAAAAElFTkSuQmCC'), np.uint8), cv2.IMREAD_GRAYSCALE)


def wave_banner_visible(frame):
    if frame is None or frame.ndim != 3:
        return False
    h,w=frame.shape[:2]
    if abs(w/h-16/9)>.04:
        return False
    crop=frame[round(h*60/720):round(h*180/720),round(w*.4):round(w*.6),:3]
    if not crop.size:
        return False
    crop=cv2.resize(crop,(256,120))
    low,high=np.min(crop,axis=2),np.max(crop,axis=2)
    white=((low>165)&(high-low<65)).astype(np.uint8)*255
    return cv2.minMaxLoc(cv2.matchTemplate(white,WAVE_TEMPLATE,cv2.TM_CCOEFF_NORMED))[1]>=.84


class AxisState:
    def __init__(self):
        self.phase = 'opener'
        self.round = 0
        self.busy = False
        self.failed = False
        self.denia_form = 'white'
        self.last_mornye_c3_e = -1.0
        self.mornye_c3_clock_anchor = None
        self.mornye_c3_clock_sample = None
        self.mornye_c3_clock_calibration = None
        self.last_denia_r2 = -1.0
        self.target_epoch = 0
        self.executed_epoch = 0
        self.qing_z2_f_epoch = -1
        self.qing_z2_f_checked_epoch = -1
        self.qing_z2_f_attempted_epoch = -1
        self.qing_z2_f_frames = 0
        self.wave_latched = False
        self.wave_frames = 0
        self.wave_absent_since = None
        self.wave_probe_at = -100.0
        self.burst_resume = None
        # A confirmed post-R A4 outro has already brought Mornye on field.
        # Consume once at the next loop entry; never infer it from a manual swap.
        self.loop_intro_ready = False
        self.pre_r_f_pending = False
        self.second_a1_ready = False


# Positive white R1 glyph from the supplied 0.1.21 recording at 54.8s.
# A cooldown ending or a few white pixels in the skill box is not readiness.
DENIA_R1_TEMPLATE = cv2.imdecode(np.frombuffer(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAACIAAAAoCAAAAAC+t3d4AAAAyklEQVQ4EYXBAZKCMADAwOT/j87RFhU4O+7KT3KTQBzkRW5CYpKT3AUIBLLIXcgUsshOyCQ7IZNsJZNsJZNshQyyFTLIVsggWyGDbIUMshUyyEPIEjLIQ8iSTPIQsiSTPIQsySQPIUsyyRL/ySQ3cZAhZJK3WGRKFlliEEimZJElQA4hQ8giQwwyJENyEoiTHJIhOQnxJpAckhfjSk7Ji/FiIEvyZkySSTIlb8ZBhpAl+TDkKeRDvkgu5IvkQr5ILuSL5EJ+kp/kpz/7HEMpgbjJRwAAAABJRU5ErkJggg=='),
    np.uint8), cv2.IMREAD_GRAYSCALE)


def denia_r1_lit(frame):
    """Bright R1 glyph, not an orange ring, CD digits, R2 glyph or a flash."""
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return False
    height, width = frame.shape[:2]
    if not height or not width or abs(width/height-16/9) > .04:
        return False
    crop = frame[round(height*610/720):round(height*676/720),
                 round(width*1175/1280):round(width*1245/1280), :3]
    if crop.size == 0:
        return False
    hsv = cv2.cvtColor(cv2.resize(crop, (70,66)), cv2.COLOR_BGR2HSV)
    mask = np.uint8((hsv[:,:,1] < 80) & (hsv[:,:,2] > 175))*255
    score = cv2.minMaxLoc(cv2.matchTemplate(mask, DENIA_R1_TEMPLATE,
                                          cv2.TM_CCOEFF_NORMED))[1]
    return score >= .78


def denia_conformal_fill(frame):
    """Partial orange R ring, independent of R cooldown digits.

    Default 16:9 HUD; the caller must verify on-field Denia and her form.
    Black form measures conformal production; a positively identified white
    form can use the same arc to confirm an R1 energy deficit. Hidden, full,
    white-coloured or ambiguous rings are unknown, never zero or full.
    The 3-degree samples have about 1% quantization error.
    """
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return None
    height, width = frame.shape[:2]
    if not height or not width or abs(width / height - 16 / 9) > .04:
        return None
    crop = frame[round(height*610/720):round(height*676/720),
                 round(width*1175/1280):round(width*1245/1280), :3]
    if crop.size == 0:
        return None
    hsv = cv2.cvtColor(cv2.resize(crop, (70, 66)), cv2.COLOR_BGR2HSV)
    angles = np.deg2rad(np.arange(6, 360, 3))  # Skip the fixed gap at 12 o'clock.

    def warm_at(radii):
        radii = np.asarray(radii)[:, None]
        xs = np.rint(34.5 - np.sin(angles)[None, :]*radii).astype(int)
        ys = np.rint(34 - np.cos(angles)[None, :]*radii).astype(int)
        h, s, v = np.moveaxis(hsv[ys, xs], -1, 0)
        return ((h < 27) | (h > 165)) & (s > 65) & (v > 110)

    lit = warm_at(np.arange(23.5, 27, .5)).mean(axis=0) >= .28
    if not lit[:5].any():
        return None
    end = next((i for i in range(len(lit)-3) if not lit[i:i+4].any()), len(lit))
    # Require a single arc from the top. Off-ring colour rejects broad flashes;
    # R icon/CD digits are inside the sampled annulus and cannot fill it.
    if (end == len(lit) or end < 2 or lit[end+4:].sum() > 4
            or lit[:end].mean() < .8
            or warm_at((17, 18, 30, 31))[:, :end].mean() > .35):
        return None
    return (end*3 + 6) / 360


def denia_r1_energy_full(frame):
    """Closed orange energy ring, including while old R1 CD covers the glyph.

    Only call for on-field white Denia. Keep this separate from black-form
    conformal production. The entire thin arc must be lit; broad orange
    flashes, partial rings and hidden/unsupported HUD are not full energy.
    """
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return False
    height, width = frame.shape[:2]
    if not height or not width or abs(width/height-16/9) > .04:
        return False
    crop = frame[round(height*610/720):round(height*676/720),
                 round(width*1175/1280):round(width*1245/1280), :3]
    if crop.size == 0:
        return False
    hsv = cv2.cvtColor(cv2.resize(crop, (70,66)), cv2.COLOR_BGR2HSV)
    angles = np.deg2rad(np.arange(9,360,3))  # Exclude the fixed top seam and its edge.

    def warm_at(radii):
        radii = np.asarray(radii)[:,None]
        xs = np.rint(34.5-np.sin(angles)*radii).astype(int)
        ys = np.rint(34-np.cos(angles)*radii).astype(int)
        h,s,v = np.moveaxis(hsv[ys,xs],-1,0)
        return ((h < 27) | (h > 165)) & (s > 65) & (v > 110)

    lit = warm_at(np.arange(23.5,27,.5)).mean(axis=0) >= .28
    return bool(lit.all() and warm_at((17,18,30,31)).mean() <= .35)


def qing_r_energy_fill(frame):
    """Green coverage of Qing's R energy ring, independent of CD OCR.

    0.1.42 replay: the old 1.1/0.9s CD retains a full green ring; a real
    R consumes it. Read the annulus, excluding the white CD/icon inside.
    Only the supported default 16:9 HUD is measurable.
    """
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return None
    height, width = frame.shape[:2]
    if not height or not width or abs(width/height-16/9) > .04:
        return None
    crop = frame[round(height*610/720):round(height*676/720),
                 round(width*1175/1280):round(width*1245/1280), :3]
    if crop.size == 0:
        return None
    hsv = cv2.cvtColor(cv2.resize(crop, (70,66)), cv2.COLOR_BGR2HSV)
    angles = np.deg2rad(np.arange(0,360,5))
    radii = np.arange(24,28,.5)[:,None]
    xs = np.rint(35+np.cos(angles)*radii).astype(int)
    ys = np.rint(33.5+np.sin(angles)*radii).astype(int)
    h,s,v = np.moveaxis(hsv[ys,xs],-1,0)
    green = (h >= 40) & (h <= 95) & (s > 55) & (v > 125)
    return float((green.mean(axis=0) > .28).mean())


def mornye_fill(frame, airborne=False):
    """Read the 34-pip bar at the default 16:9 HUD position (BGR frame).

    Orange pips = static energy; white pips = relative kinetic energy. Return
    None for unsupported framing. This is an auxiliary signal, not a chain
    detector; the mouse-forte template and airborne state remain independent.
    """
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return None
    height, width = frame.shape[:2]
    if abs(width / height - 16 / 9) > .04:
        return None
    # Tutorial layout, adjusted to this reference's first/last pip. Exclude
    # the permanent white baseline below the cells, especially in air mode.
    top, bottom = (666, 670) if airborne else (662, 671)
    strip = frame[round(height * top / 720):round(height * bottom / 720),
                  round(width * 546 / 1280):round(width * 728 / 1280), :3]
    if strip.size == 0 or strip.shape[1] < 68:
        return None
    hsv = cv2.cvtColor(strip, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    if airborne:
        mask = (s < 100) & (v > 165)
    else:
        mask = (h < 25) & (s > 50) & (v > 115)
    # Require contiguous lit cells from the left: a bright effect to the right
    # of an empty cell cannot manufacture additional resource.
    lit = 0
    edges = np.linspace(0, mask.shape[1], 35).astype(int)
    for i in range(34):
        cell = mask[:, edges[i]:edges[i + 1]]
        if float(cell.mean()) < .16:
            break
        lit += 1
    return lit / 34


def qing_circuit_lit(frame):
    """Green occupancy in Qingxiao's left circuit bar, not an attack counter.

    The first post-R A fills green pips beside the central ornament. Exclude
    that ornament, the right-hand decorations and the white HP bar below.
    Normalize to the same default 16:9 HUD coordinates used by the package.
    """
    if frame is None or frame.ndim != 3 or frame.shape[2] < 3:
        return None
    height, width = frame.shape[:2]
    if abs(width / height - 16 / 9) > .04:
        return None
    crop = frame[round(height * 663 / 720):round(height * 670 / 720),
                 round(width * 540 / 1280):round(width * 627 / 1280), :3]
    if crop.size == 0 or crop.shape[1] < 60:
        return None
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    green = (h >= 40) & (h <= 95) & (s > 55) & (v > 125)
    # Use occupied sample cells, not raw overall brightness: white/grey pips
    # and blue R effects cannot by themselves announce resource growth.
    return sum(float(cell.mean()) >= .20 for cell in np.array_split(green, 20, axis=1))




class Denia(NativeDenia):
    qdm_package = PACKAGE_ID

    # Input windows, not an assertion that N clicks produced N attack stages.
    # Resource-gated boundaries below extend these windows when needed.
    TIMING = {
        'qing_opener_A2_at': .48,
        'mornye_A12': .58, 'mornye_A3': .42,
        'denia_R1_A12_buffer': .82,
        'denia_resume_A3_input': .30,
        'denia_resume_A4_from': .58, 'denia_resume_A4_until': .76,
        'denia_A4_handoff_lead': .01,
        # Same-character E can cancel A4; the 10ms swap margin does not apply.
        'opener_denia_A4_E_until': 1.04, 'opener_denia_A4_E_lead': .08,
        'opener_denia_E2_refill_lead': .30,
        'denia_ground_A12': .62, 'denia_air_A12': .58,
        'denia_jump': .18, 'denia_plunge': .48,
        'denia_first_A2_dodge_lead': .05,
        'denia_second_dodge_lead': .005,
        'qing_relay_Q_entry': .02, 'qing_relay_Q_exit': .02,
        'qing_outro_A4_confirm': .02,
        'qing_A4_growth_confirm': .04,
        'qing_A4_baseline_recover': .06,
        'qing_A4_full_confirm': .18,
        'mornye_intro': 1.33,
        'mornye_Z_tail': .28, 'mornye_E_Z2_unseen_min': .65,
        'qing_intro': .85,
        'qing_air_E_start_lead': .04,
        'qing_air_E_entry_recovery': .90,
        'qing_air_E_delay': .15, 'qing_air_E_input': .40, 'qing_air_E_tail': .08,
        'qing_E_tail': .16, 'qing_Z1_tail': 1.05,
        'qing_four_A': 2.0, 'qing_Z2_impact_confirm': .08,
        'qing_tail_A1': .12, 'qing_tail_four_A': 1.80,
        'qing_tail_A34': .60, 'qing_tail_A4': .32,
        'qing_spawn_pause': .50,
        # 0.2.0 opening-only input budgets. Later rounds keep their old keys.
        'opener_qing_A1_E_lead': .06,
        'opener_qing_A4_start_lead': .06,
        'opener_morn_slot_repeat': .03,
        'opener_denia_A2_min': .10,
        'opener_denia_A2_retry': .08,
        'opener_denia_A2_window': .18,
        'opener_denia_A1_recovery': .30,
        'opener_denia_A1_start_lead': .06,
        'opener_f_swap_from_input': 1.90,
        'opener_f_swap_from_ack': 1.55,
        'opener_f_A3_recovery': 2.05,  # F fallback only when the clock cannot be read
        'opener_f_A3_lead': .04,
        'opener_morn_jump_A': .04,
        'opener_qing_intro_A_onset': .54,
        # Opening-only: allow HUD fade on reentry, and jump after Z2's launch
        # rather than immediately when its resource is spent at startup.
        # R-camera slot/F buffering replaces the old post-R Z1 delay.
        # A positive Z2 aiming overlay is a fallback when C3 fills/spends
        # between captured frames; never infer Z2 from a permanently low bar.
        'opener_morn_Z2_aim_tail': .65,
        'opener_morn_Z2_aim_window': .35,
        'opener_morn_ground_grace': .30,
        # 20261019-001616: charge spent ~21.20, shot flash ~22.20.
        # Keep a small launch margin before the scripted jump cancellation.
        'opener_morn_Z2_launch': 1.10,
    }
    LIMIT = {
        'switch': 3.0, 'intro_con': 3.5, 'hud': 8.0,
        'E': 4.0, 'R_ready': 6.0, 'R_start': 2.0, 'R_animation': 8.0,
        'mornye_full': 3.5, 'mornye_heavy': 3.5,
        'qing_Z1': 5.0, 'qing_Z2': 7.0, 'denia_2E': 4.5,
        'qing_Z2_combo_grace': 3.0,
        'F_start': .65, 'F_animation': 4.0,
        'qing_A1_growth': 1.5,
        'qing_A4_start': 4.5, 'qing_air_E_buffer': 3.0,
        'qing_tail_A4': 6.0,
        'denia_second_A12': 3.2,
        'denia_first_A2_extra': .8,
        'opener_morn_air': 5.0,
        'outro_Q': 2.0,
        'pre_R_F': 1.0,
    }
    A_INTERVAL = .12
    KEY_INTERVAL = .10
    MORN_E_INTERVAL = .06
    KEY_DOWN = .04
    FAST_DOWN = .02
    FAST_POLL = .008
    FAST_REPEAT = .06
    POLL = .025
    FRAME_CONFIRM = 2
    # Partial-R-ring checkpoints, not concerto or white cores. A2's already
    # launched tail hits can settle during jump/EE: hand off at 13/41 instead
    # of waiting for the full 30/60. These are NOT claims of full R2 energy.
    # The air checkpoint exceeds ground A12 + air A1, so ground tails alone
    # cannot unlock EE. Keep the independent R2 readiness gate after supports.
    DENIA_A12_ENERGY = {'ground': (.10, .13), 'air': (.40, .41)}
    DENIA_RING_TOLERANCE = .012

    @property
    def qdm_team(self):
        chars = [c for c in self.task.chars if c is not None]
        return (len(chars) == 3 and {c.name for c in chars} == TEAM
                and all(getattr(c, 'qdm_package', None) == PACKAGE_ID for c in chars))

    def axis_state(self):
        state = getattr(self.task, STATE_KEY, None)
        if state is None:
            state = AxisState()
            setattr(self.task, STATE_KEY, state)
        return state

    def reset_axis(self):
        setattr(self.task, STATE_KEY, AxisState())

    def reset_state(self):
        super().reset_state()
        # load_chars can run during combat. A refresh is not a new battle.
        state = getattr(self.task, STATE_KEY, None)
        if not getattr(self.task, '_in_combat', False) and not (state and state.busy):
            self.reset_axis()
        if self.qdm_team:
            install_challenge_entry(self.task)

    def _challenge_entry(self, hook):
        """Enter on confirmed start interaction, or the original new clock."""
        task = self.task
        state = self.axis_state()
        now = time.monotonic()
        eligible = (getattr(task, 'enabled', False)
                    and task.config.get('Auto Target', False)
                    and getattr(task, 'use_liberation', True)
                    and state.phase == 'opener' and not state.failed)
        if not eligible:
            reset_challenge_start(task, hook)
            hook.update(armed=False, absent_since=None, grace_until=0,
                        target_pending=False)
            return False
        if task._in_combat:
            # Let the first A12 finish without sleep_check re-entering the
            # blocking target-acquisition loop we have just bypassed.
            return bool(state.busy and now < hook['grace_until'])
        visible, index, count = task.in_team()
        qing = self.teammate('Qingxiao')
        if state.busy or not visible or count != 3 or index != qing.index:
            reset_challenge_start(task, hook)
            hook.update(armed=False, absent_since=None)
            return False
        clock = self._challenge_clock()
        early = self._challenge_early_start(hook) if not clock else False
        if not clock:
            if hook['absent_since'] is None:
                hook['absent_since'] = now
            elif now - hook['absent_since'] >= .08:
                hook['armed'] = True
            if not early:
                return False
        armed = hook['armed']
        hook.update(armed=False, absent_since=None)
        reset_challenge_start(task, hook)
        if not early and not armed:
            return False  # Mid-challenge enable/import uses the native entry.

        # Verify portraits/slots now, not the party cached before the challenge.
        # This also performs native hotkey/state setup before the first input.
        if not task.load_chars() or not any(c is self for c in task.chars) or not self.qdm_team:
            return False
        visible, index, count = task.in_team()
        if not visible or count != 3 or index != self.teammate('Qingxiao').index:
            return False
        if not self._challenge_clock() and not (early and qing_normal_ready(task.frame)
                                                and not challenge_start_prompt(task.frame)):
            return False
        task.scene.set_in_combat()
        task._in_combat = True
        signal = 'start-interaction' if early else 'new-countdown'
        hook.update(grace_until=time.monotonic()+(.90 if early else .75), target_pending=True,
                    detected_at=now, signal=signal)
        self.logger.info(f'QDM challenge-entry signal={signal} target_wait=bypassed')
        return True

    def _challenge_early_start(self, hook):
        """Prompt + actual user activation + recovered normal icon, before spawn."""
        now = time.monotonic()
        prompt = challenge_start_prompt(self.task.frame)
        if not prompt and hook['start_prompt_at'] is None:
            return False
        focused, pressed = challenge_activation_input(self.task)
        if not focused:
            reset_challenge_start(self.task, hook)
            return False
        if prompt:
            if hook['start_prompt_since'] is None:
                hook['start_prompt_since'] = now  # Drain old input, don't use it.
                interval = getattr(self.task, 'trigger_interval', None)
                if interval is not None and interval > .02:
                    hook['trigger_interval_before'] = interval
                    self.task.trigger_interval = .02
            elif now-hook['start_prompt_since'] >= .08 and pressed:
                hook['start_pressed_at'] = now
            hook['start_prompt_at'] = now
            return False  # A must not be sent while the challenge UI owns input.
        if now-hook['start_prompt_at'] > .60:
            reset_challenge_start(self.task, hook)
            return False
        if pressed and now-hook['start_prompt_since'] >= .08:
            hook['start_pressed_at'] = now
        pressed_at = hook['start_pressed_at']
        return (pressed_at is not None and now-pressed_at <= .60
                and qing_normal_ready(self.task.frame))

    def _challenge_clock(self):
        # The timer slides horizontally as it fades in. The framework's
        # default 0.002 search margin misses that first part of the entrance.
        return bool(self.task.find_one('gray_combat_count_down', threshold=.86,
                                       horizontal_variance=.03, vertical_variance=.006))

    def on_combat_end(self, chars):
        self.reset_axis()

    def teammate(self, name):
        return next(c for c in self.task.chars if c and c.name == name)

    def do_perform(self):
        if self.qdm_team and not self.axis_state().failed:
            return self.run_axis(self)
        return super().do_perform()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self.qdm_team and not self.axis_state().failed:
            return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _mark(self, event, **fields):
        state = self.axis_state()
        values = ' '.join(f'{key}={value}' for key, value in fields.items())
        elapsed = time.monotonic() - self._phase_start
        self.logger.info(f'QDM phase={state.phase} round={state.round} '
                         f't={elapsed:.3f} event={event} {values}')

    def _tick(self):
        self.task.sleep(self.POLL)
        self.task.next_frame()
        self._observe_execution_target()

    def _fast_tick(self):
        # Keep cancellation and a fresh screenshot, without the extra 25ms
        # delay at every input-critical handoff.
        self.task.sleep(self.FAST_POLL)
        self.task.next_frame()
        self._observe_execution_target()

    def _observe_execution_target(self, force=False):
        state=self.axis_state()
        now=time.monotonic()
        if not force and now-state.wave_probe_at<.05:
            return
        state.wave_probe_at=now
        if wave_banner_visible(self.task.frame):
            state.wave_absent_since=None
            state.wave_frames+=1
            if state.wave_frames>=2 and not state.wave_latched:
                state.wave_latched=True
                state.target_epoch+=1
                self._mark('target-wave', epoch=state.target_epoch, pre_R_F='pending')
        else:
            state.wave_frames=0
            if state.wave_latched and not self._hud()[0]:
                # R/F cameras can hide the caption while its display time
                # remains. Its return is not a second new wave.
                state.wave_absent_since=None
            elif state.wave_absent_since is None:
                state.wave_absent_since=now
            elif now-state.wave_absent_since>=.5:
                state.wave_latched=False

    def _hud(self):
        visible, index, count = self.task.in_team()
        return bool(visible), index, count

    def _on_field(self, char=None):
        visible, index, _ = self._hud()
        return visible and index == (char or self.cur).index

    def _label(self, name):
        return bool(self.task.find_one(name, threshold=.78))

    @contextmanager
    def _animation_guard(self):
        # Suppress combat misclassification only inside a bounded, known
        # animation. Task.sleep/next_frame still honor task cancellation.
        previous = self.task.in_liberation
        try:
            self.task.in_liberation = True
            yield
        finally:
            self.task.in_liberation = previous

    def _release(self):
        if getattr(self, '_holding', False):
            try:
                release = getattr(self, '_mouse_release', None) or self.task.mouse_up
                release()
            finally:
                self._holding = False
                self._mouse_release = None

    def _attack(self, fast=False):
        # PostMessage click(move=True) inserts another down_time before the
        # actual press. Combat attacks don't need a cursor move.
        self.task.click(down_time=self.FAST_DOWN if fast else self.KEY_DOWN, move=False)

    def _two_normals_to_swap(self, first, second, second_at):
        """Two onset inputs; the second attack finishes after the quick swap.

        The interval schedules the next stage, not two arbitrary clicks in
        one short spam window. It is a calibrated input budget, not a visual
        assertion of A2/A4 or a wait for its damage/animation to complete.
        """
        self._release()
        if not self._on_field():
            self._hud_back()
        self._mark(first, input='single-press')
        started = time.monotonic()
        self._attack()
        hook = getattr(self.task, ENTRY_HOOK, None)
        if first == 'Qingxiao-opener-A1' and hook and hook['target_pending']:
            hook['target_pending'] = False
            # Submit a single nonblocking lock attempt after A1. Its 20ms
            # input fits inside the existing A1->A2 interval, not before A1.
            self.task.middle_click(down_time=self.FAST_DOWN, move=False)
            self._mark('Qingxiao-first-input', entry=hook.get('signal', 'new-countdown'),
                       entry_ms=round((started-hook['detected_at'])*1000, 1))
        remaining = second_at - (time.monotonic() - started)
        if remaining > 0:
            self._wait(remaining)
        self._mark(second, input='single-press', handoff='onset')
        self._attack()
        # No screenshot, poll tick or action tail here. Caller swaps next.

    def _qing_opener_a12(self):
        # Reference comments give Qing A1's next-stage boundary at 26/60s.
        # .36s ended before that boundary. Leave a small input margin for A2.
        self._two_normals_to_swap('Qingxiao-opener-A1', 'Qingxiao-opener-A2',
                                  self.TIMING['qing_opener_A2_at'])

    def _normal_to_swap(self, tag):
        """A single resumed attack; its animation continues after the swap."""
        self._release()
        if not self._on_field():
            self._hud_back()
        self._mark(tag, input='single-press', handoff='onset')
        self._attack(fast=True)

    def _wait(self, seconds, attack=False):
        start = time.monotonic()
        next_attack = start
        while time.monotonic() - start < seconds:
            now = time.monotonic()
            if attack and now >= next_attack and self._on_field():
                self._attack()
                next_attack = now + self.A_INTERVAL
            self._tick()

    def _until(self, predicate, cap, tag, attack=False, minimum=0, confirmations=None):
        start = time.monotonic()
        next_attack = start
        streak = 0
        confirmations = self.FRAME_CONFIRM if confirmations is None else confirmations
        while time.monotonic() - start < cap:
            now = time.monotonic()
            satisfied = now - start >= minimum and predicate()
            if satisfied:
                streak += 1
                if streak >= confirmations:
                    return
            else:
                streak = 0
            # Never inject a new normal after the condition is already true:
            # that input can occupy the very skill handoff we are waiting for.
            if not satisfied and attack and now >= next_attack and self._on_field():
                self._attack()
                next_attack = now + self.A_INTERVAL
            self._tick()
        raise AxisFault(f'{tag}: condition not confirmed within {cap:.2f}s')

    def _hud_back(self):
        if self._on_field():
            return
        with self._animation_guard():
            self._until(lambda: self._on_field(), self.LIMIT['hud'], 'HUD return')

    def _normal(self, tag, window):
        self._mark(tag, window=window)
        self._wait(window, attack=True)

    def _full_con(self, char):
        # The bottom ring can misclassify a nearly-full Mornye gauge as 1.
        # Only the other two portraits' visible intro halos authorize an outro.
        return self._on_field(char) and portrait_concerto_full(self.task.frame, char.index)

    def _outro_echo(self, source, target, con_full):
        """Q on Denia outros and Mornye -> Qingxiao; Qing Q is relay-only."""
        if con_full and (source.name == 'Denia' or
                         (source.name == 'Mornye' and target.name == 'Qingxiao')):
            return self._buffer_outro_echo(source)
        return {}

    def _buffer_outro_echo(self, source):
        """Shared Q input/CD buffer; hand off on the first new echo CD.

        An initially disabled icon can be R2 recovery, not Q consumption.
        Check actual cooldowns on fresh frames, not echo_available's cache.
        No log, bookkeeping, extra frame or tail separates CD and the slot key.
        """
        start = time.monotonic()
        last_key = -100.0
        presses = 0
        while time.monotonic() - start < self.LIMIT['outro_Q']:
            visible, index, _ = self._hud()
            if visible and index != source.index:
                raise AxisFault(f'{source.name} outro Q lost on-field {source.name}')
            if visible:
                if source.has_cd('echo'):
                    return {'presses': presses, 'gap': 0,
                            'ack': 'new-CD' if presses else 'already-CD',
                            'wait_ms': round((time.monotonic()-start)*1000, 1)}
                now = time.monotonic()
                if now-last_key >= self.FAST_REPEAT:
                    source.send_echo_key(down_time=.01)
                    last_key = now
                    presses += 1
            self._fast_tick()
        raise AxisFault(f'{source.name} outro Q: no confirmed echo CD after {presses} inputs '
                        f'in {self.LIMIT["outro_Q"]:.2f}s')

    def _commit_switch(self, source, target, con_full, start, streak, prehold=False,
                       outro_echo=None):
        source.switch_out(con_full=con_full)
        for char in self.task.chars:
            if char:
                char.is_current_char = char is target
        target.has_intro = con_full
        target.has_sub_dps_intro = con_full and source.is_sub_dps
        target.last_switch_in_time = time.time()
        self.cur = target
        if target.name == 'Qingxiao':
            self._qing_entry_at = time.monotonic()
        if con_full:
            source.last_outro_time = time.time()
            self.task.add_freeze_duration(source.last_outro_time,
                                          target.intro_motion_freeze_duration, -100)
        echo = outro_echo or {}
        if echo.get('ack') == 'new-CD':
            source.record_echo_use()
        self._mark('switch', source=source.name, target=target.name, intro=con_full,
                   con_ack='portrait-halos' if con_full else 'no-halos',
                   outro_q_input=bool(echo.get('presses')), q_presses=echo.get('presses', 0),
                   q_ack=echo.get('ack', 'not-requested'), q_gap_ms=echo.get('gap', 0) * 1000,
                   q_wait_ms=echo.get('wait_ms', 0),
                   switch_ms=round((time.monotonic() - start) * 1000, 1),
                   hud_frames=streak)

    def _switch(self, name, intro=False, fill=True, prehold=False, prepared=None,
                attack_while_waiting=False, echo=True):
        target = self.teammate(name)
        if attack_while_waiting and (self.cur.name != 'Qingxiao' or name != 'Denia'
                                     or intro or prehold or prepared is not None):
            raise AxisFault('Attack/swap buffer requires ordinary Qingxiao -> Denia')
        if prehold and (name != 'Qingxiao' or not intro):
            raise AxisFault('Prehold is only used for the authored Qingxiao intro')
        self._release()
        # The preceding action already sampled the HUD. Only wait for it if
        # hidden; do not add a fresh confirmation delay to every quick swap.
        if prepared is not None and (intro or prehold or prepared[0] is not self.cur
                                     or prepared[1] is not target):
            raise AxisFault('Invalid prepared normal handoff')
        if prepared is None and not self._on_field():
            self._hud_back()
        if self.cur is target:
            if intro:
                raise AxisFault(f'{name}: expected a fresh intro, already current')
            return
        source = self.cur
        if intro:
            self._until(lambda: self._full_con(source), self.LIMIT['intro_con'],
                        f'{source.name} concerto for {name}', attack=fill)
        # Snapshot before Q/slot inputs; afterward the ring may already belong
        # to the destination. Never force an unobserved intro.
        con_full = self._full_con(source) if prepared is None else prepared[2]
        outro_echo = self._outro_echo(source, target, con_full) if echo else {}
        start = time.monotonic()
        last_key = -100.0
        streak = 0
        while time.monotonic() - start < self.LIMIT['switch']:
            now = time.monotonic()
            if now - last_key >= self.FAST_REPEAT:
                if attack_while_waiting and self._on_field(source):
                    # Recheck halos while normals are filling concerto. Send A
                    # BEFORE the slot key: once that key succeeds, no more Qing
                    # inputs may leak into Denia's R1 or resumed A3.
                    con_full = self._full_con(source)
                    self._attack(fast=True)
                self.task.send_key(str(target.index + 1), down_time=self.FAST_DOWN)
                if prehold and not self._holding:
                    # Buffer through the incoming intro, immediately after the
                    # slot key, not after confirmation or an intro sleep.
                    self._holding = True
                    self.task.mouse_down()
                    self._mark('Qingxiao-preinput-A', input='hold', during_intro=True)
                last_key = now
            self._fast_tick()
            visible, index, count = self._hud()
            streak = streak + 1 if visible and index == target.index else 0
            # _fast_tick fetched a new frame AFTER the slot input. With both other
            # slot numbers visible (count=3), the missing target number is an
            # unambiguous full-team result. Partial HUDs still need 3 frames.
            if streak >= (1 if count >= 3 else 3):
                self._commit_switch(source, target, con_full, start, streak, prehold,
                                    outro_echo=outro_echo)
                return
        self._release()
        raise AxisFault(f'switch {source.name}->{name} was not confirmed')

    def _switch_denia_r1(self, source_name='Qingxiao'):
        """Opening slot/R pairs; R may start before Denia has a visible HUD.

        No screenshot or readiness lookup separates the two presses. A key
        submission is not a switch/R acknowledgement: require a new camera,
        then Denia's HUD and the positive black-form R2 icon.
        """
        self._release()
        self._hud_back()
        source = self.cur
        if (source_name not in ('Qingxiao', 'Mornye') or source.name != source_name
                or self.axis_state().denia_form != 'white'):
            raise AxisFault(f'Opening slot/R buffer requires {source_name} -> white Denia')
        con_full = self._full_con(source)
        outro_echo = self._outro_echo(source, self, con_full)
        start = time.monotonic()
        last_pair = -100.0
        hidden = 0
        switched = False
        streak = 0
        with self._animation_guard():
            while time.monotonic() - start < self.LIMIT['switch'] + self.LIMIT['R_start']:
                now = time.monotonic()
                if hidden == 0 and now - last_pair >= self.FAST_REPEAT:
                    if not switched:
                        self.task.send_key(str(self.index + 1), down_time=self.FAST_DOWN)
                    self.send_liberation_key(down_time=self.FAST_DOWN)
                    if last_pair < 0:
                        self._mark('Denia-entry-R1-input', paired_slot=True)
                    last_pair = now
                self._fast_tick()
                visible, index, count = self._hud()
                hidden = 0 if visible else hidden + 1
                streak = streak + 1 if visible and index == self.index else 0
                if not switched and streak >= (1 if count >= 3 else 3):
                    self._commit_switch(source, self, con_full, start, streak,
                                        outro_echo=outro_echo)
                    switched = True
                if hidden >= self.FRAME_CONFIRM:
                    break
            else:
                raise AxisFault('Denia entry R1: no new animation')
            animation_wall = time.time()
            try:
                self._until(lambda: self._on_field(self), self.LIMIT['R_animation'],
                            'Denia entry R1 animation end', confirmations=1)
                self._denia_r1_hud_back_at = time.monotonic()
                if not switched:
                    self._commit_switch(source, self, con_full, start, 1,
                                        outro_echo=outro_echo)
                self._until(lambda: self._on_field(self) and self._label(Labels.denia_end_lib),
                            self.LIMIT['R_ready'], 'Denia entry R1 black form', confirmations=1)
            finally:
                self.task.add_freeze_duration(animation_wall, time.time() - animation_wall)
        self.record_liberation_use()
        self.axis_state().denia_form = 'black'
        self.lib_1_casted = True
        self._mark('R1', char=self.name, entry_buffer=True)

    def _cast_e(self, tail=.1, on_cooldown=None, before_input=None):
        char = self.cur
        self._release()
        self._hud_back()
        self._until(char.resonance_available, self.LIMIT['E'],
                    f'{char.name} E ready', attack=False)
        start = time.monotonic()
        last_key = -100.0
        off_streak = 0
        # Availability was seen above. Only the subsequent cooldown/disabled
        # transition acknowledges a cast; sending a key isn't success.
        while time.monotonic() - start < self.LIMIT['E']:
            now = time.monotonic()
            if now - last_key >= self.KEY_INTERVAL:
                if before_input is not None:
                    before_input()
                char.send_resonance_key(down_time=self.KEY_DOWN)
                last_key = now
            self._tick()
            on_field = self._on_field(char)
            cooldown = on_field and char.has_cd('resonance')
            if on_cooldown is not None:
                # The callback is input-critical: execute on the first actual
                # CD frame, before another confirmation frame, log, tail or
                # resource read. A merely disabled E icon is insufficient.
                if cooldown:
                    on_cooldown()
                    char.record_resonance_use()
                    self._mark('E-CD', char=char.name, immediate_handoff=True)
                    return
                continue
            gone = on_field and (cooldown or not char.resonance_available())
            off_streak = off_streak + 1 if gone else 0
            if off_streak >= self.FRAME_CONFIRM:
                char.record_resonance_use()
                self._mark('E', char=char.name)
                self._wait(tail)
                return
        raise AxisFault(f'{char.name} E input had no confirmed effect')

    def _cast_r(self, form=None, prehold=False, ready_confirmed=False, buffer_onset=False,
                buffer_r1=False, opening_handoff=False):
        if opening_handoff and (self.cur.name != 'Mornye' or not prehold or not buffer_onset):
            raise AxisFault('Opening R handoff requires Mornye R/preheld Z1')
        if buffer_r1:
            if self.cur is not self or form != 'R1' or buffer_onset or ready_confirmed or prehold:
                raise AxisFault('Loop R1 recovery requires Denia R1 from white form')
            return self._denia_loop_r1()
        char = self.cur
        self._release()
        if buffer_onset and (char.name != 'Mornye' or form is not None
                             or char.has_cd('liberation')):
            raise AxisFault('Mornye onset R buffer requires an unused R')
        # Only the immediate E2 callback may reuse its current-frame R2 check.
        # No readiness token is retained across frames or character switches.
        if ready_confirmed and (char is not self or form != 'R2'):
            raise AxisFault('Only the immediate Denia E2 -> R2 handoff can reuse readiness')
        if not ready_confirmed:
            self._hud_back()  # An existing Z2/F animation is never an R success.
        if char is self:
            expected = 'black' if form == 'R2' else 'white'
            if self.axis_state().denia_form != expected:
                raise AxisFault(f'{form}: Denia form is {self.axis_state().denia_form}')

        def ready():
            if form == 'R1' and self._label(Labels.denia_end_lib):
                raise AxisFault('R1 expected white form, but the screen shows the R2 icon')
            return (char.liberation_available()
                    and (form != 'R2' or self._label(Labels.denia_end_lib)))

        if not ready_confirmed and not buffer_onset:
            self._until(ready, self.LIMIT['R_ready'], f'{char.name} {form or "R"} ready',
                        attack=True, confirmations=1)
        if char is self:
            self._mark('Denia-concerto-before-R', form=form,
                       con=round(self.task.get_current_con(), 3))
        start = time.monotonic()
        last_key = -100.0
        last_attack = start
        disappeared = 0
        with self._animation_guard():
            while time.monotonic() - start < self.LIMIT['R_start']:
                now = time.monotonic()
                if (not buffer_onset and now - start > .30 and now - last_attack >= self.A_INTERVAL
                        and self._on_field(char)):
                    # A stable readiness false positive can still be short of
                    # energy. Fill it while retrying, in a separate input tick.
                    self._attack()
                    last_attack = now
                elif disappeared == 0 and now - last_key >= (self.FAST_REPEAT if buffer_onset else self.KEY_INTERVAL):
                    char.send_liberation_key(down_time=self.FAST_DOWN if buffer_onset else self.KEY_DOWN)
                    if last_key < 0:
                        self._mark('R-input', char=char.name, form=form,
                                   immediate_E2_handoff=ready_confirmed, growth_buffer=buffer_onset)
                    last_key = now
                self._fast_tick() if buffer_onset else self._tick()
                disappeared = disappeared + 1 if not self._hud()[0] else 0
                if disappeared >= self.FRAME_CONFIRM:
                    break
            else:
                raise AxisFault(f'{char.name} {form or "R"}: no new animation')
            animation_wall = time.time()
            if prehold:
                self.task.mouse_down()
                self._holding = True
            try:
                if opening_handoff:
                    # Queue the slot while R still owns the camera; F is
                    # submitted only after Qing's foreground is confirmed.
                    # Waiting for Mornye HUD here misses the authored Z1 swap.
                    self._opener_morn_z1_handoff(char)
                else:
                    self._until(lambda: self._on_field(char), self.LIMIT['R_animation'],
                                f'{char.name} R animation end')
                if char is self and form == 'R1':
                    self._denia_r1_hud_back_at = time.monotonic()
                if buffer_onset and not opening_handoff and not char.has_cd('liberation'):
                    raise AxisFault('Mornye onset R: animation ended without a new R cooldown')
            finally:
                # Record only the observed animation interval, including F below.
                self.task.add_freeze_duration(animation_wall, time.time() - animation_wall)
        char.record_liberation_use()
        if char is self:
            self.axis_state().denia_form = 'white' if form == 'R2' else 'black'
            self.lib_1_casted = form == 'R1'  # Keep native fallback state coherent.
            if form == 'R2':
                self.axis_state().last_denia_r2 = time.time()
                self.lib_2 = time.time()
        self._mark(form or 'R', char=char.name)
        if char is self:
            self._mark('Denia-concerto-after-R', form=form,
                       con=round(self.task.get_current_con(), 3))

    def _denia_r1_black(self):
        # R2's glyph is covered by cooldown digits immediately after R1.
        # The native denia_lib2 template is the black E's hands/cube glyph;
        # it remains visible during that R cooldown and is not an R-ready gate.
        return self._on_field(self) and (self._label(Labels.denia_lib2)
                                        or self._label(Labels.denia_end_lib))

    def _denia_loop_r1(self):
        """Buffer white E/A/R together until a confirmed R1 changes form."""
        self._release()
        if self.cur is not self or self.axis_state().denia_form != 'white':
            raise AxisFault('Loop R1 recovery requires on-field white Denia')
        attempts = 0
        while True:
            self._hud_back()
            if self._hud()[1] != self.index:
                raise AxisFault('Loop R1 recovery lost on-field Denia')
            if self._denia_r1_black():
                raise AxisFault('Loop R1 recovery expected white form before R input')
            attempts += 1
            if self._denia_try_loop_r1(attempts):
                self.record_liberation_use()
                self.axis_state().denia_form = 'black'
                self.lib_1_casted = True
                self._denia_r1_hud_back_at = time.monotonic()
                self._mark('R1', char=self.name, attempt=attempts,
                           acknowledgement='white-to-black-and-CD')
                self._mark('Denia-concerto-after-R', form='R1',
                           con=round(self.task.get_current_con(), 3))
                return
            self._mark('Denia-loop-R1-retry', attempt=attempts, action='continue-EAR')
            self._fast_tick()


    def _denia_try_loop_r1(self, attempt):
        """Keep white EAR input and R1 camera confirmation in one guard.

        Retry E/A/R through energy shortage and old cooldowns. Pause on hidden
        HUD and stop all inputs at the first black-form frame, so white inputs
        cannot spill into black E or R2. A ready R1 never waits for white E.
        """
        started = time.monotonic()
        last_key = -100.0
        last_attack = -100.0
        last_e = -100.0
        e_pending = False
        next_f_check = started
        e_cd_before = self.has_cd('resonance')
        energy_was_full = False
        next_recheck = started + self.LIMIT['R_start']
        settle = .40
        draining = None
        black_frames = 0
        black_seen = camera_seen = camera_pending = False
        onset_at = None
        hidden_since = None
        try:
            with self._animation_guard():
                # Normal CD/energy waits keep EAR running with no fixed idle
                # checkpoint. Only possible R energy consumption pauses inputs;
                # a hidden/ambiguous cast still has a bounded camera wait.
                # sleep/next_frame continue honoring cancellation throughout.
                while True:
                    now = time.monotonic()
                    visible, index, _ = self._hud()
                    if visible and index != self.index:
                        raise AxisFault('Loop R1 input lost on-field Denia')
                    if not visible:
                        camera_seen = True
                        camera_pending = True
                        black_frames = 0
                        if onset_at is None:
                            onset_at = now
                        if hidden_since is None:
                            hidden_since = time.time()
                    else:
                        if hidden_since is not None:
                            self.task.add_freeze_duration(hidden_since,time.time()-hidden_since)
                            hidden_since = None
                        black = self._denia_r1_black() if last_key >= 0 else False
                        black_seen = black_seen or black
                        if black and onset_at is None:
                            onset_at = now
                        cd = self.has_cd('liberation')
                        black_frames = black_frames+1 if black else 0
                        if (black_frames >= self.FRAME_CONFIRM and cd
                                and onset_at is not None and now-onset_at >= .40):
                            self._mark('Denia-loop-R1-confirmed', attempt=attempt,
                                       camera_seen=camera_seen,
                                       acknowledgement='white-to-black-and-CD')
                            return True
                        # An unrelated F camera may return white. Require the
                        # positive white E, not merely failure to see black,
                        # before allowing another R input after any camera.
                        if camera_pending and not black_seen and self._label(Labels.denia_e1):
                            camera_pending = False
                            onset_at = None
                        if not black_seen and not camera_pending:
                            full = (denia_r1_energy_full(self.task.frame)
                                    or denia_r1_lit(self.task.frame))
                            if full:
                                energy_was_full = True
                            elif energy_was_full and last_key >= 0 and draining is None:
                                level = denia_conformal_fill(self.task.frame)
                                if level is not None and level < .20:
                                    # R can spend energy before its camera or
                                    # black glyph appears. Pause this possible
                                    # onset, rather than leaking white E/A into
                                    # black form. Ordinary low energy never arms
                                    # this guard without a preceding full read.
                                    draining = 'possible-R1-energy-spend'
                                    self._mark('Denia-loop-R1-settle', reason=draining,
                                               attempt=attempt)
                            if now >= next_recheck:
                                self._mark('Denia-loop-R1-retry', attempt=attempt,
                                           action='recheck-energy-inside-R-buffer')
                                next_recheck = now + self.LIMIT['R_start']
                            # A sudden full-to-empty change may be an accepted
                            # R with a delayed camera. Settle that input before
                            # resuming EAR; an initially short bar never waits.
                            if draining is not None and now-last_key >= settle:
                                return False
                        if not black_seen and not camera_pending and draining is None:
                            e_cd = self.has_cd('resonance')
                            if e_pending and not e_cd_before and e_cd:
                                self.record_resonance_use()
                                e_pending = False
                                self._mark('Denia-white-E-CD', input='EAR-buffer')
                            e_cd_before = e_cd
                            # A landing F can move back into view while E is
                            # already on cooldown. Recheck independently of E,
                            # without delaying EAR when no prompt is present.
                            if now >= next_f_check:
                                next_f_check = now + self.FAST_REPEAT
                                if self._denia_f_ready():
                                    self._denia_late_landing_f()
                                    # Rejected F must not monopolize this loop.
                                    # Resume EAR on a fresh HUD/form frame and
                                    # leave a short input window before retrying.
                                    next_f_check = time.monotonic() + .35
                                    self._fast_tick()
                                    continue
                            direct_r = (last_key < 0 and e_cd and not cd and
                                (denia_r1_energy_full(self.task.frame) or
                                 denia_r1_lit(self.task.frame)))
                            if not direct_r:
                                # Inputs have independent cadences. Send R last
                                # and capture before any further E/A, so a newly
                                # accepted R cannot receive more same-frame input.
                                if now-last_e >= self.FAST_REPEAT:
                                    self.send_resonance_key(down_time=self.FAST_DOWN)
                                    last_e = now
                                    e_pending = e_pending or not e_cd
                                if now-last_attack >= self.FAST_REPEAT:
                                    self._attack(fast=True)
                                    last_attack = now
                        # Never send R2 while waiting for the post-R1 HUD/CD.
                        if (not black_seen and not camera_pending
                                and draining is None
                                and now-last_key >= self.FAST_REPEAT):
                            self.send_liberation_key(down_time=self.FAST_DOWN)
                            if last_key < 0:
                                self._mark('R-input', char=self.name, form='R1',
                                           loop_R1_buffer=True, attempt=attempt)
                            last_key = now
                    if onset_at is not None and now-onset_at >= self.LIMIT['R_animation']:
                        raise AxisFault('Loop R1 post-input character/form remains unreadable')
                    self._fast_tick()
        finally:
            if hidden_since is not None:
                self.task.add_freeze_duration(hidden_since,time.time()-hidden_since)

    def _denia_outro(self, echo=True):
        """R2 is not proof of full concerto, even at C3.

        C3's extra 30 requires the 12-second black entropy buff. Timing,
        misses and incomplete attacks can all leave a deficit; use actual
        concerto, never assume the bonus or overwrite the gauge.
        """
        if self.cur is not self or self.axis_state().denia_form != 'white':
            raise AxisFault('Denia outro recovery requires completed R2/white form')
        self._hud_back()
        if not self._full_con(self):
            self._mark('Denia-R2-concerto-short', con=round(self.task.get_current_con(), 3))
            # The white E has its own cooldown. Only use it when available;
            # otherwise the existing bounded normal-fill gate still applies.
            if self.resonance_available() and not self.has_cd('resonance'):
                self._mark('Denia-outro-recovery-E')
                self._cast_e(.10)
        if echo:
            self._switch('Qingxiao', intro=True, prehold=True)
        else:
            self._switch('Qingxiao', intro=True, prehold=True, echo=False)

    def _f_prompt(self):
        if self.task.find_one(Labels.f_break_full, threshold=.92):
            return not self.task.is_pick_f()
        return self._f_target_prompt()

    def _f_target_prompt(self):
        # The floating F over the enemy is consumed by an execution. The
        # boss-bar f_break_full marker can stay lit THROUGH that execution.
        # Plunge/camera motion can put the enemy prompt above y=.2 or
        # near the right edge (recording: x=1706, y=423 at 1920x1080).
        # Search the combat view; retain the pickup/dialogue exclusion below.
        box = self.task.box_of_screen(.05, .07, .95, .85, hcenter=True, vcenter=True)
        # The recording's wall edges scored .808-.825 with the default .8.
        return (bool(self.task.find_one('f_break', box=box, target_height=720, threshold=.88))
                and not self.task.is_pick_f())

    def _execute(self, prompt_confirmed=False, release_after_input=False,
                 hold_until_ack=False, start_cap=None, on_ack=None,
                 handoff='buffered-E', confirm_grounded_execution=False,
                 confirm_target_execution=False, clock_evidence=None, buffer_entry=False):
        """Optional F at an explicit safe boundary, never inside a normal window."""
        if buffer_entry and (self.cur.name != 'Qingxiao' or not hold_until_ack or not self._holding):
            raise AxisFault('Entry F buffer requires Qingxiao continuous held A')
        if not release_after_input and not hold_until_ack:
            self._release()
        if not buffer_entry and not prompt_confirmed and not self._on_field():
            self._mark('F-unavailable', reason='HUD-hidden')
            return False
        if not buffer_entry and not prompt_confirmed and not self._f_prompt():
            self._release()
            self._mark('F-unavailable')
            return False
        start = time.monotonic()
        wall = time.time()
        last_key = -100.0
        acknowledged = False
        start_cap = self.LIMIT['F_start'] if start_cap is None else start_cap
        missing = 0
        target_prompt_seen = self._f_target_prompt()
        prompt_seen = buffer_entry and (target_prompt_seen or (self._on_field() and self._f_prompt()))
        target_epoch = self.axis_state().target_epoch
        evidence = None
        if confirm_grounded_execution or confirm_target_execution:
            if confirm_grounded_execution and (self.cur.name != 'Qingxiao' or not hold_until_ack or on_ack is None):
                raise AxisFault('Grounded F evidence requires Qingxiao held-A/E handoff')
            if clock_evidence is not None and not confirm_target_execution:
                raise AxisFault('Shared F clock evidence requires target confirmation')
            evidence = clock_evidence if clock_evidence is not None else ExecutionClockEvidence()
            # Seed once for the entire bounded pre-R attempt. Repeated F inputs
            # may already be inside the FIRST successful F's stopped clock.
            # Restarting here discards the prior ticking->stop transition.
            if evidence.last_at is None:
                evidence.observe(self.task.frame, time.monotonic(), False)
        probes = []
        acknowledgement = None
        with self._animation_guard():
            while time.monotonic() - start < start_cap:
                now = time.monotonic()
                if now - last_key >= (self.FAST_REPEAT if buffer_entry else self.KEY_INTERVAL):
                    try:
                        self.task.send_key('f', down_time=self.FAST_DOWN if buffer_entry else self.KEY_DOWN)
                    finally:
                        if release_after_input:
                            self._release()
                    if last_key < 0:
                        self._mark('F-input', held_A=self._holding)
                    last_key = now
                if buffer_entry:
                    self._fast_tick()
                else:
                    self._tick()
                # An early F can be rejected by the incoming animation. Keep
                # A held until two fresh frames acknowledge the execution;
                # releasing on the first rejected F cancelled the buffered A.
                visible, index, _ = self._hud()
                if evidence is not None and visible and index != self.cur.index:
                    raise AxisFault('F confirmation lost on-field character')
                target_prompt = self._f_target_prompt() if visible else False
                target_prompt_seen = target_prompt_seen or target_prompt
                # Once the real target F has been seen, its disappearance
                # acknowledges consumption even if the boss-bar marker stays
                # lit. Never treat an unseen floating prompt as consumed.
                prompt = target_prompt if target_prompt_seen else (visible and self._f_prompt())
                prompt_seen = prompt_seen or prompt
                absent = (visible and not prompt) if confirm_target_execution else (not visible or not prompt)
                missing = missing + 1 if absent else 0
                grounded = False
                clock_ack = False
                if evidence is not None and visible:
                    grounded = (not confirm_grounded_execution or
                                self.cur.enhanced_resonance_available())
                    clock_ack = evidence.observe(self.task.frame, time.monotonic(), grounded)
                # Keep compact per-frame evidence in memory, not synchronous
                # logging in the input loop. Publish only on ack/timeout.
                if evidence is not None:
                    probes.append((round(time.monotonic()-start,3), int(visible),
                                   int(target_prompt), evidence.value, int(grounded),
                                   round(evidence.stopped_for,3)))
                # At the opener E handoff, a briefly occluded floating F is
                # insufficient while Qingxiao still has the airborne E glyph.
                # A visible enhanced ground E is also required before buffering.
                prompt_ack = missing >= 2 and (evidence is None or grounded)
                if buffer_entry:
                    # F is sent before its prompt lights. An absent prompt
                    # that was never seen is not evidence of a successful F.
                    prompt_ack = prompt_ack and prompt_seen
                if confirm_target_execution:
                    # A hidden HUD/old boss marker is not proof the NEW target
                    # received F. Need its observed prompt consumed in view,
                    # or a newly stopped, previously advancing game clock.
                    prompt_ack = prompt_ack and visible and target_prompt_seen
                if prompt_ack or clock_ack:
                    acknowledged = True
                    acknowledgement = (('new-clock-stop-and-ground-E' if confirm_grounded_execution else
                                        'new-clock-stop') if clock_ack else
                                       'target-prompt-consumed' if target_prompt_seen else
                                       'HUD-or-ready-marker-transition')
                    if (self.axis_state().target_epoch == target_epoch and
                            (clock_ack or (visible and target_prompt_seen and not target_prompt))):
                        self.axis_state().executed_epoch = target_epoch
                        self.axis_state().pre_r_f_pending = False
                        self._mark('target-F-confirmed', epoch=target_epoch)
                    if hold_until_ack:
                        self._release()
                    self._mark('F-ack', latency=round(time.monotonic()-start, 3),
                               acknowledgement=acknowledgement)
                    break
            if acknowledged:
                if on_ack is not None:
                    # The prompt may disappear late in F. Buffer follow-up NOW;
                    # waiting another fixed 1.5s double-counted the animation.
                    try:
                        on_ack()
                    finally:
                        if evidence is not None:
                            self._mark('F-evidence', target_seen=target_prompt_seen,
                                       columns='seconds,HUD,target_F,clock_tenths,ground_E,stop_seconds',
                                       samples=probes)
                    self.task.can_break = False
                    self._mark('F', handoff=handoff)
                    return True
                # The HUD may remain visible in F's startup. Protect the
                # observed 1.5s execution window; only after it can E/Z resume.
                self._wait(1.50)
                end_start=time.monotonic()
                while not self._on_field() and time.monotonic()-end_start<self.LIMIT['F_animation']:
                    self._tick()
                if not self._on_field():
                    self._mark('F-unconfirmed', reason='end-HUD-timeout', axis='continue')
                    acknowledged=False
                self.task.add_freeze_duration(wall, time.time() - wall)
        self.task.can_break = False
        if evidence is not None:
            self._mark('F-evidence', target_seen=target_prompt_seen,
                       columns='seconds,HUD,target_F,clock_tenths,ground_E,stop_seconds',
                       samples=probes)
        self._mark('F' if acknowledged else 'F-no-effect')
        return acknowledged

    def _morn_fill(self, mor, airborne):
        if not self._on_field(mor):
            return None
        return mornye_fill(self.task.frame, airborne)

    def _morn_full(self, mor, airborne):
        if not self._on_field(mor):
            return False
        fill = self._morn_fill(mor, airborne)
        return (fill is not None and fill == 1) or bool(mor.is_mouse_forte_full())

    def _morn_normals(self, mor, tag, window, target=None, airborne=False, growth=False):
        if target is None:
            self._normal(tag, window)
            return
        if growth:
            if airborne or target not in (.58, 1):
                raise AxisFault('Growth handoff is only for ground Mornye A12/A3')
            # Ground A1 gives 20%, A2 adds 43%, A3 adds 37%. Do not count
            # A1's slope as the second increase, nor a fading HUD returning
            # to the previous 63% as the start of A3. Two of 34 cells reject
            # single-cell edge noise; the final bar value is not required.
            baseline = self._morn_fill(mor, False)
            floor = .20 if target == .58 else .63
            threshold = min(target, max(floor, baseline or 0) + 2 / 34)
            start = time.monotonic()
            last_attack = -100.0
            while time.monotonic() - start < window + self.LIMIT['mornye_full']:
                fill = self._morn_fill(mor, False)
                # On re-entry the old bar fades in over several frames. Keep
                # pressing A immediately, but collect its peak during the
                # first 80ms before treating a later rise as A3. No idle wait.
                settling = target == 1 and time.monotonic() - start < .08
                if settling and fill is not None:
                    baseline = max(baseline or 0, fill)
                    threshold = min(target, max(floor, baseline) + 2 / 34)
                full = self._morn_full(mor, False)
                if full or (not settling and fill is not None and fill >= threshold):
                    self._mark('Mornye-normal-growth', segment=tag,
                               fill=fill, threshold=round(threshold, 3), target=target,
                               native_full=full)
                    return
                now = time.monotonic()
                if now-last_attack >= self.FAST_REPEAT and self._on_field(mor):
                    self._attack(fast=True)
                    last_attack = now
                self._fast_tick()
            raise AxisFault(f'{tag}: resource growth was not observed')
        self._mark(tag, handoff='resource')
        def enough():
            fill = self._morn_fill(mor, airborne)
            return (fill is not None and fill >= target) or self._morn_full(mor, airborne)
        # Read while attacking, not after a mandatory .58/.42-second window.
        # A2/A3 grant their static energy at onset; no damage tail is required.
        self._until(enough, window + self.LIMIT['mornye_full'], tag + ' resource',
                    attack=True, confirmations=1)
        self._mark('Mornye-normal-resource-ready', target=target)

    def _morn_c3_observe_clock(self, mor):
        """Calibrate estimated C3 time with two consistent HUD clock samples.

        This is not a C3-ready detector. Anchor only soon after an accepted E
        predicted to trigger C3; all Z resource checks remain separate.
        """
        state = self.axis_state()
        now = time.monotonic()
        previous = state.mornye_c3_clock_sample
        if previous is not None and now <= previous[0]:
            return
        value = execution_clock_tenths(self.task.frame)
        if value is None:
            return
        state.mornye_c3_clock_sample = (now, value)
        if previous is None:
            return
        span, drop = now-previous[0], (previous[1]-value)/10
        # A timer reset, isolated OCR jump, or a distant old sample must not
        # grant readiness. The second consistent fresh sample can recover.
        if span > .5 or drop < 0 or drop > span+.15:
            return
        wall_age = time.time()-state.last_mornye_c3_e
        if state.last_mornye_c3_e < 0:
            return
        native_age = max(0.0, mor.time_elapsed_accounting_for_freeze(state.last_mornye_c3_e))
        if state.mornye_c3_clock_anchor is None:
            if not 0 <= wall_age <= 2.0:
                return
            # CD acknowledgement is slightly later than the actual E. Keep
            # that conservative origin; compensate only the short sampling lag.
            state.mornye_c3_clock_anchor = value/10+native_age
        elapsed = state.mornye_c3_clock_anchor-value/10
        if elapsed < 0 or elapsed > wall_age+.15:
            return
        calibration = state.mornye_c3_clock_calibration
        if calibration is not None:
            old_elapsed, _, old_time = calibration
            if elapsed < old_elapsed or elapsed-old_elapsed > now-old_time+.15:
                return
        state.mornye_c3_clock_calibration = (elapsed, native_age, now)

    def _morn_c3_remaining(self, mor):
        state = self.axis_state()
        if state.last_mornye_c3_e < 0:
            return 0.0, 'initial-ready'
        self._morn_c3_observe_clock(mor)
        elapsed = max(0.0, mor.time_elapsed_accounting_for_freeze(state.last_mornye_c3_e))
        source = 'freeze-adjusted'
        calibration = state.mornye_c3_clock_calibration
        if calibration is not None:
            clock_elapsed, native_at_sample, sampled_at = calibration
            if time.monotonic()-sampled_at <= .25:
                # Don't extrapolate through a frozen or briefly unreadable HUD.
                elapsed, source = clock_elapsed, 'HUD-clock'
            else:
                elapsed = clock_elapsed+max(0.0, elapsed-native_at_sample)
                source = 'HUD-calibrated-freeze'
        # The clock reader resolves tenths. A small margin avoids submitting E
        # on the early side of that quantization boundary.
        return max(0.0, 25.1-elapsed), source

    def _morn_c3_ready_for_entry(self, mor):
        remaining, source = self._morn_c3_remaining(mor)
        started = time.monotonic()
        self._mark('Mornye-C3-check', remaining=round(remaining, 3), source=source,
                   estimated=True)
        if not 0 < remaining <= 1.0:
            return remaining == 0
        self._release()
        self._mark('Mornye-C3-near-wait', remaining=round(remaining, 3), input='A')
        last_attack = -100.0
        while time.monotonic()-started < 1.25:
            if not self._on_field(mor) or not mor.on_air():
                raise AxisFault('Mornye C3 wait lost airborne foreground')
            remaining, source = self._morn_c3_remaining(mor)
            if remaining == 0:
                self._mark('Mornye-C3-ready', source=source,
                           wait_ms=round((time.monotonic()-started)*1000), estimated=True)
                return True
            now = time.monotonic()
            if now-last_attack >= self.FAST_REPEAT:
                self._attack(fast=True)
                last_attack = now
            self._fast_tick()
        self._mark('Mornye-C3-wait-fallback', remaining=round(remaining, 3), source=source,
                   wait_ms=round((time.monotonic()-started)*1000))
        return False

    def _morn_c3_record_e(self, mor):
        state = self.axis_state()
        state.last_mornye_c3_e = time.time()
        state.mornye_c3_clock_anchor = None
        state.mornye_c3_clock_calibration = None
        self._morn_c3_observe_clock(mor)
        self._mark('Mornye-C3-E-anchor', acknowledgement='new-E-CD', estimated=True)

    def _morn_heavy(self, mor, ground=False, already_held=False, c3_instant=False,
                    on_air=None, resource_peak=None, tail=None):
        if already_held:
            # Z1 may be preheld through R; Z2 is pressed alongside E's key-down.
            # Never interrupt either handoff with another mouse-down
            # or a new resource-read gate before its input.
            if not self._holding:
                raise AxisFault('invalid preheld Mornye heavy')
        else:
            self._until(lambda: self._morn_full(mor, not ground), self.LIMIT['mornye_full'],
                        'Mornye static full' if ground else 'Mornye relative full', attack=True)
            self.task.mouse_down()
            self._holding = True
        start = time.monotonic()
        empty = 0
        full_seen = not already_held or ground
        try:
            while time.monotonic() - start < self.LIMIT['mornye_heavy']:
                self._tick()
                if not ground:
                    self._morn_c3_observe_clock(mor)
                elapsed = time.monotonic() - start
                if ground:
                    consumed = bool(mor.on_air())
                    if consumed:
                        # The first airborne frame is the Z1 -> Z2/E boundary.
                        # Release Z1 and press again; no minimum hold or second
                        # frame, resource read or E-ready gate belongs here.
                        self._release()
                        self._mark('Mornye-Z1', acknowledgement='first-airborne-frame')
                        if on_air is not None:
                            on_air()
                        return
                else:
                    full = self._morn_full(mor, True)
                    full_seen = full_seen or full
                    fill = self._morn_fill(mor, True)
                    if resource_peak is not None and fill is not None:
                        resource_peak = max(resource_peak, fill)
                    # C3 can fill and consume the whole bar before the next
                    # captured frame when Z2 is preheld alongside E.
                    # Keep holding through a minimum action window in that
                    # case. The second-round prehold can additionally use a
                    # measured resource drop across intro/E below.
                    can_confirm = (full_seen or (c3_instant and elapsed >=
                                   self.TIMING['mornye_E_Z2_unseen_min']))
                    # Second-round intro/E can fill and spend between captures
                    # even while C3 is cooling down. A large observed drop is
                    # evidence; a constantly low or unreadable bar is not.
                    if resource_peak is not None and fill is not None:
                        can_confirm = can_confirm or resource_peak - fill >= .50
                    consumed = (can_confirm and not full and fill is not None and fill < .45)
                empty = empty + 1 if consumed and elapsed >= .30 else 0
                if empty >= self.FRAME_CONFIRM:
                    if not ground:
                        mor.last_heavy = time.time()
                    self._mark('Mornye-Z1' if ground else 'Mornye-Z2',
                               acknowledgement='seen-full' if full_seen else
                               'resource-drop' if resource_peak is not None and fill is not None
                               and resource_peak-fill >= .50 else 'C3-window',
                               resource_peak=resource_peak)
                    # Z1's confirmed airborne state is the E handoff. The
                    # shared .28s tail unnecessarily delayed E/Z2 here.
                    if not ground:
                        self._wait(self.TIMING['mornye_Z_tail'] if tail is None else tail)
                    return
            raise AxisFault('Mornye heavy resource/state transition not observed')
        finally:
            self._release()

    def _morn_intro_z2(self, mor):
        """Keep the intro hold until a post-E charge/spend transition.

        Intro fades and E flashes can make the auxiliary reader report 1.0
        for a frame. Neither that nor the C3 timer proves a Z was cast. E's
        new cooldown is the observation boundary; no pre-E peak is inherited.
        A preheld Z may spend between captures, so observing exactly 1.0 is
        not required, but a sustained charge and near-empty bar are required.
        """
        if not self._holding:
            raise AxisFault('invalid preheld Mornye intro heavy')
        start = time.monotonic()
        charge_since = empty_since = None
        charge_frames = empty_frames = 0
        charge_floor = None
        armed_peak = None
        try:
            while time.monotonic() - start < self.LIMIT['mornye_heavy']:
                self._tick()
                self._morn_c3_observe_clock(mor)
                now = time.monotonic()
                if not self._on_field(mor):
                    raise AxisFault('Mornye intro Z lost foreground before confirmation')
                fill = self._morn_fill(mor, True)
                if fill is not None and fill >= .30:
                    if charge_since is None:
                        charge_since, charge_floor = now, fill
                    charge_frames += 1
                    charge_floor = min(charge_floor, fill)
                    if charge_frames >= self.FRAME_CONFIRM and now-charge_since >= .12:
                        if armed_peak is None:
                            self._mark('Mornye-Z2-post-E-charge', fill=fill,
                                       stable_floor=charge_floor)
                        armed_peak = max(armed_peak or 0, charge_floor)
                else:
                    charge_since = charge_floor = None
                    charge_frames = 0
                # Below 45% was much too permissive: E was still filling the
                # bar in the failed recording. Require an actual near-empty
                # interval following sustained charge, not two low samples.
                spent = (armed_peak is not None and fill is not None
                         and fill <= .08 and armed_peak-fill >= .25
                         and not mor.is_mouse_forte_full())
                if spent and now-start >= .30:
                    if empty_since is None:
                        empty_since = now
                    empty_frames += 1
                    if empty_frames >= self.FRAME_CONFIRM and now-empty_since >= .10:
                        mor.last_heavy = time.time()
                        self._mark('Mornye-Z2', acknowledgement='post-E-stable-charge-spend',
                                   resource_peak=armed_peak, fill=fill)
                        self._wait(self.TIMING['mornye_Z_tail'])
                        return
                else:
                    empty_since = None
                    empty_frames = 0
            raise AxisFault('Mornye intro heavy post-E resource/state transition not observed')
        finally:
            self._release()

    def _morn_pair_inputs(self, e_key):
        """Prepare all work before adjacent Z2/E downs on the active backend.

        On OK-WW's PostMessage backend this avoids activation, coordinate
        conversion and task/UI bookkeeping BETWEEN the two input messages.
        Keep the same HWND/position for release, including on cancellation.
        Other supported backends retain the task API, in Z2 -> E order.
        """
        executor = getattr(self.task, 'executor', None)
        interaction = getattr(executor, 'interaction', None)
        if isinstance(interaction, PostMessageInteraction):
            e_key = self.task.validate_key(e_key)
            executor.reset_scene()  # Includes the framework cancellation check.
            position = interaction.update_mouse_pos(-1, -1)
            hwnd = interaction.hwnd
            vk = interaction.get_key_by_str(e_key)
            key_down = interaction.make_lparam(vk, is_up=False)
            key_up = interaction.make_lparam(vk, is_up=True)
            post = interaction.post
            return (
                lambda: post(win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, position, hwnd=hwnd),
                lambda: post(win32con.WM_KEYDOWN, vk, key_down, hwnd=hwnd),
                lambda: post(win32con.WM_KEYUP, vk, key_up, hwnd=hwnd),
                lambda: post(win32con.WM_LBUTTONUP, 0, position, hwnd=hwnd),
                'PostMessage-adjacent',
            )
        return (self.task.mouse_down, lambda: self.task.send_key_down(e_key),
                lambda: self.task.send_key_up(e_key), self.task.mouse_up, 'task-api')

    def _morn_z1_e_z2(self, mor):
        # Prepare window/key metadata while Z1 is still held. No preparation
        # or readiness polling may separate the observed rise and the regrip.
        try:
            pair = self._morn_pair_inputs(mor.get_resonance_key())
            # Release Z1 through the prepared backend too; no activation or
            # coordinate preparation may delay the new down edge.
            self._mouse_release = pair[3]
            if mor.has_cd('resonance'):
                raise AxisFault('Mornye E was already on cooldown before the Z1 handoff')
            c3_ready = self._morn_c3_remaining(mor)[0] == 0
            self._morn_heavy(mor, ground=True, already_held=True,
                            on_air=lambda: self._morn_e_z2(
                                mor, from_z1=True, prepared_inputs=pair, c3_ready=c3_ready))
        finally:
            self._release()

    def _morn_e_z2(self, mor, from_z1=False, prepared_inputs=None, c3_ready=None,
                   intro_prehold=False, z_tail=None):
        self._release()
        if not from_z1:
            self._hud_back()
            if intro_prehold:
                # An unlit E during intro recovery must not block speculative
                # input. Exclude an existing cooldown so only a NEW CD can
                # acknowledge this E, then retry through the remaining recovery.
                self._until(lambda: not mor.has_cd('resonance'), self.LIMIT['E'],
                            'Mornye E ready', confirmations=1)
                if not self._on_field(mor) or not mor.on_air():
                    raise AxisFault('Mornye second-round intro lost airborne state before E')
            else:
                self._until(mor.resonance_available, self.LIMIT['E'], 'Mornye E ready',
                            confirmations=1)
        pair = prepared_inputs or self._morn_pair_inputs(mor.get_resonance_key())
        z_down, e_down, e_up, z_up, backend = pair
        start = time.monotonic()
        try:
            # Z2 is already held when E's C3 resource arrives. Prepare the
            # backend before this pair; no E-animation-then-Z-cancel sequence.
            mor._resonance_available = False  # same cache invalidation as native send_resonance_key
            try:
                # The caller's snapshot chooses a route, not proof of a proc.
                # Refresh before each input in case HUD calibration changed it.
                c3_ready = self._morn_c3_remaining(mor)[0] == 0
                self._mouse_release = z_up
                self._holding = True
                sent_at = time.monotonic()
                if intro_prehold:
                    # Queue E first so a full entry bar cannot launch Z ahead
                    # of E. Hold immediately, before any capture/CD lookup.
                    e_down()
                    z_down()
                else:
                    z_down()
                    e_down()
                submitted_ms = (time.monotonic() - sent_at) * 1000
                self.task.sleep(self.KEY_DOWN)
            finally:
                e_up()
            self._mark('Mornye-Z2-input', trigger='E-Z2-adjacent' if intro_prehold else 'Z2-E-adjacent', backend=backend,
                       submit_ms=round(submitted_ms, 3), from_Z1_airborne=from_z1)

            # Input is speculative; only an actual CD confirms E. Retry E if
            # it was swallowed, preserving the one uninterrupted Z2 hold.
            last_key = start
            while time.monotonic() - start < self.LIMIT['E']:
                self._tick()
                if self._on_field(mor) and mor.has_cd('resonance'):
                    mor.record_resonance_use()
                    if c3_ready:
                        self._morn_c3_record_e(mor)
                    self._mark('E-CD', char=mor.name, z2_preheld=True)
                    if intro_prehold and not mor.on_air():
                        raise AxisFault('Mornye second-round E lost airborne state before Z')
                    if intro_prehold:
                        self._morn_intro_z2(mor)
                    elif z_tail is not None:
                        self._morn_heavy(mor, already_held=True, c3_instant=c3_ready, tail=z_tail)
                    else:
                        self._morn_heavy(mor, already_held=True, c3_instant=c3_ready)
                    return
                now = time.monotonic()
                if self._on_field(mor) and now - last_key >= self.MORN_E_INTERVAL:
                    # Keep A continuously held and re-use the prepared E pair.
                    # Earlier E inputs can be swallowed during Z1's rise.
                    try:
                        c3_ready = self._morn_c3_remaining(mor)[0] == 0
                        e_down()
                        self.task.sleep(self.KEY_DOWN)
                    finally:
                        e_up()
                    last_key = now
            raise AxisFault('Mornye paired E/Z2 input had no confirmed E cooldown')
        finally:
            self._release()

    def _morn_air_ez(self, mor, second=False):
        if not mor.has_intro:
            raise AxisFault('Mornye air entry requires actual full-concerto intro')
        def airborne_entry():
            self._morn_c3_observe_clock(mor)
            return self._on_field(mor) and mor.on_air()
        if second:
            # Start on the first observed airborne entry. No fixed intro wait
            # or three-normal sequence: E retries and one continuous A hold
            # supply the skill/Z handoff while its recovery finishes.
            self._until(airborne_entry,
                        self.TIMING['mornye_intro']+1.0, 'Mornye intro airborne',
                        confirmations=1)
        else:
            # Begin E/Z retries at an observed airborne entry, instead of an
            # unconditional 1.33s idle. The E cooldown still confirms acceptance.
            self._until(airborne_entry,
                        self.TIMING['mornye_intro']+1.0, 'Mornye loop intro airborne')
        c3_ready = self._morn_c3_ready_for_entry(mor)
        if second:
            self._morn_e_z2(mor, c3_ready=c3_ready, intro_prehold=True)
            return
        if c3_ready:
            self._morn_e_z2(mor, c3_ready=True)
            return
        # Without C3 readiness, preholding Z can consume a full bar before E
        # is acknowledged. Confirm E then a real full bar before pressing Z.
        # E readiness/rejected inputs can outlast the original decision. Track
        # the prediction at each input, not at the later CD observation.
        def before_e():
            nonlocal c3_ready
            c3_ready = self._morn_c3_remaining(mor)[0] == 0
        self._cast_e(tail=0, on_cooldown=lambda: None, before_input=before_e)
        if c3_ready:
            self._morn_c3_record_e(mor)
        self._mark('Mornye-loop-E', c3_ready=c3_ready,
                   acknowledgement='E-CD-before-resource-gated-Z')
        if not mor.on_air():
            raise AxisFault('Mornye loop E lost airborne state before Z')
        self._morn_heavy(mor)

    def _denia_opener_a12(self):
        # Start buffering as soon as R1's HUD is back. The old .47s idle wait
        # followed by two isolated presses delayed Qingxiao's return. Inputs
        # rejected during recovery are retried; no invented combo counter.
        # .82s still covers .47s recovery + .30s A1 derivation and a retry.
        # The buffered keys can start A1 earlier, but this is not A2 vision.
        hud_back = getattr(self, '_denia_r1_hud_back_at', time.monotonic())
        deadline = hud_back + self.TIMING['denia_R1_A12_buffer']
        self._mark('Denia-R1-A12-buffer', acknowledgement='input-window-only')
        self._fast_normals_until(deadline)

    def _fast_normals_until(self, deadline):
        # Repeat through the first capture/input latency, with a final press
        # at the boundary. Do not append an animation tail before switching.
        last = -100.0
        while True:
            now = time.monotonic()
            if now-last >= self.FAST_REPEAT:
                self._attack(fast=True)
                last = now
                if time.monotonic() >= deadline:
                    return
            self._fast_tick()

    def _denia_first_a12_to_dodge(self):
        """Keep the normal input window; extend only for missing A2 production.

        A parry can delay A1/A2 without stopping the challenge clock. Elapsed
        input time therefore cannot prove it is safe to cancel A2 with dodge.
        The opening A12->swap still uses its original independent path.
        """
        self._release()
        if (self.cur is not self or self.axis_state().denia_form != 'black'
                or not self._on_field(self)):
            raise AxisFault('Denia first A12 dodge requires black Denia on field')
        self._denia_opener_a12()
        earliest = time.monotonic() + self.TIMING['denia_first_A2_dodge_lead']
        deadline = earliest + self.LIMIT['denia_first_A2_extra']
        onset, target = self.DENIA_A12_ENERGY['ground']
        ready_frames = 0
        confirmed = extended = False
        last_level = None
        last_attack = -100.0
        try:
            while True:
                self._fast_tick()
                now = time.monotonic()
                visible, index, _ = self._hud()
                if (self.cur is not self or self.axis_state().denia_form != 'black'
                        or (visible and index != self.index)):
                    raise AxisFault('Denia first A12 dodge: current character/form changed')
                if not visible:
                    ready_frames = 0
                    if now >= deadline:
                        raise AxisFault('Denia first A12 dodge: HUD did not return')
                    continue
                level = denia_conformal_fill(self.task.frame)
                if level is not None:
                    last_level = level
                # A1's ~6-7% plateau must not unlock the dodge. Require two
                # fresh samples at 13%, without lowering it by pixel tolerance.
                ready_frames = ready_frames+1 if level is not None and level >= target else 0
                confirmed = confirmed or ready_frames >= self.FRAME_CONFIRM
                if confirmed and now >= earliest:
                    self._mark('Denia-first-A2-dodge-ready', conformal=last_level,
                               extra=round(max(0, now-earliest), 3), extended=extended)
                    return True
                if now >= deadline:
                    # Unreadable/missing production is not an unbounded wait or
                    # a reason to abandon the rotation. Keep the later A2/R2 gates.
                    self._mark('Denia-first-A2-dodge-unconfirmed', conformal=last_level,
                               extra=round(now-earliest, 3), fallback='continue-dodge')
                    return False
                if now >= earliest:
                    if not extended:
                        extended = True
                        self._mark('Denia-first-A2-dodge-extend', conformal=last_level,
                                   target=target, cap=self.LIMIT['denia_first_A2_extra'])
                    # Pause on the first onset sample to avoid queuing A3.
                    # A transient false sample must not permanently stop A2 retries.
                    if (not confirmed and (level is None or level < onset)
                            and now-last_attack >= self.FAST_REPEAT):
                        self._attack(fast=True)
                        last_attack = time.monotonic()
        finally:
            self._release()

    def _denia_resume_a34(self, handoff=False, *, cancel_into_e=False):
        # 0.1.6 sent a single A4 at .55s and left regardless of acceptance.
        # Cover both the incoming A3 and the A4 derivation window. This is
        # explicitly an INPUT window, not pose recognition or damage proof.
        # Give the final A4 input only a 10ms startup margin before handoff.
        self._release()
        if cancel_into_e and (handoff or self.cur is not self or self.axis_state().denia_form != 'black'):
            raise AxisFault('A4 into E requires on-field black Denia without a swap handoff')
        if not self._on_field(self):
            self._hud_back()
        until = self.TIMING['opener_denia_A4_E_until'] if cancel_into_e else self.TIMING['denia_resume_A4_until']
        start = time.monotonic()
        con = self.task.get_current_con()
        self._normal('Denia-resume-A3-input', self.TIMING['denia_resume_A3_input'])
        remaining = self.TIMING['denia_resume_A4_from'] - (time.monotonic() - start)
        if remaining > 0:
            self._wait(remaining)
        last_input = -100.0
        presses = 0
        target = self.teammate('Qingxiao') if handoff else None
        prepared = None
        while True:
            if cancel_into_e:
                visible, index, _ = self._hud()
                if visible and index != self.index:
                    raise AxisFault('A4 into E lost current character')
            # Read source concerto BEFORE the final A4 press. Then place the
            # first slot input after a short startup margin, before logs/HUD
            # work. Keep the proven A4 retry coverage; A3 also consumes the
            # purple bar, so an empty bar is not evidence of A4 acceptance.
            final = time.monotonic() + self.FAST_DOWN - start >= until
            if handoff and final and prepared is None:
                prepared = (self, target, self._full_con(self))
            self._attack(fast=True)
            presses += 1
            last_input = time.monotonic()
            if last_input - start >= until and (not handoff or prepared):
                if handoff:
                    # A small cancellable delay protects a late accepted A4;
                    # no extra A input or screenshot loop extends this margin.
                    self.task.sleep(self.TIMING['denia_A4_handoff_lead'])
                    self._switch('Qingxiao', prepared=prepared)
                break
            # Fixed spacing is a delivery cadence; it does not advance an
            # imaginary combo counter when the game rejects an input.
            # Use denser retries so the first .55s rejection is followed by
            # another edge promptly, without the old .94s coverage tail.
            if handoff and last_input + self.FAST_REPEAT - start >= until:
                # Use the gap before the last retry for the read, so it does
                # not become an equally long wait before that final press.
                prepared = (self, target, self._full_con(self))
            while time.monotonic()-last_input < self.FAST_REPEAT-self.FAST_DOWN:
                self._fast_tick()
        if cancel_into_e:
            # Extend accepted-A4 coverage before E cancellation, rather than
            # assuming that a sent A4 edge was accepted at the old .76s cutoff.
            # This remains a calibrated input window, not a pose/hit detector.
            self.task.sleep(self.TIMING['opener_denia_A4_E_lead'])
        self._mark('Denia-A34-input-complete', A4_presses=presses,
                   elapsed=round(last_input-start, 3), con_before=round(con, 3),
                   handoff_lead=self.TIMING['denia_A4_handoff_lead'] if handoff else 0,
                   next_action='E' if cancel_into_e else 'swap',
                   cancel_guard=self.TIMING['opener_denia_A4_E_lead'] if cancel_into_e else 0,
                   acknowledgement='input-window-only')

    def _denia_double_e(self, release=False, defer_r=False):
        if release and defer_r:
            raise AxisFault('Cannot release and defer Denia R2 together')
        if release:
            return self._denia_e_r_buffer()
        if self.axis_state().denia_form != 'black':
            raise AxisFault('Denia double E requires R1/black form')
        self._hud_back()
        if self.has_cd('resonance'):
            raise AxisFault('Denia double E started with E already on cooldown')
        start = time.monotonic()
        last_key = -100.0
        presses = 0
        e2_cd_seen = False
        last_attack = start
        while time.monotonic() - start < self.LIMIT['denia_2E']:
            now = time.monotonic()
            if not e2_cd_seen and now - last_key >= (self.FAST_REPEAT if defer_r else .10):
                self.send_resonance_key(down_time=self.FAST_DOWN if defer_r else self.KEY_DOWN)
                last_key = now
                presses += 1
            self._fast_tick() if defer_r else self._tick()
            # In black form E1 changes to E2; E2 starts the shared E cooldown.
            # Require that actual transition, not merely two sent keys or an
            # R2 icon already unlocked by normals. Its damage need not land.
            if self._on_field(self):
                e2_cd_seen = e2_cd_seen or (presses >= 2 and self.has_cd('resonance'))
                ready = (e2_cd_seen and (defer_r or (self._label(Labels.denia_end_lib)
                         and self.liberation_available())))
            else:
                ready = False
            if ready:
                self.record_resonance_use()
                self._mark('Denia-E1-E2', presses=presses, R2_unlocked=None if defer_r else True,
                           acknowledgement='E2-CD-R2-deferred' if defer_r else 'E2-CD-and-R2-ready',
                           immediate_R=release)
                return
            # Only the bounded recovery tail adds attacks; the authored two E
            # window stays free of extra normals that could displace E2.
            if (now - start > 2.2 and now - last_attack >= self.A_INTERVAL
                    and self._on_field(self)):
                self._attack()
                last_attack = now
        raise AxisFault('Denia E1/E2 did not produce usable unlocked R2')

    def _denia_e_r_buffer(self, normal_between=False, split_e1=False):
        """Opener-only E/R input buffer, starting on the confirmed switch.

        Black-form R is rejected by the game until it is usable. Keep sending
        both keys instead of serializing R behind OCR/readiness polls. Once
        its camera starts, stop ALL E/R inputs and verify R2 before committing.
        """
        if self.cur is not self or self.axis_state().denia_form != 'black':
            raise AxisFault('E/R buffering requires on-field black Denia')
        if split_e1 and (normal_between or not getattr(self, '_opener_e1_confirmed', False)):
            raise AxisFault('Split E2/R2 requires this opener\'s confirmed E1')
        self._release()
        self._hud_back()
        initial_e_cd = self.has_cd('resonance')
        if (initial_e_cd and not split_e1) or self.has_cd('liberation'):
            raise AxisFault('E/R buffer started with a preexisting cooldown')
        if split_e1:
            self._opener_e1_confirmed = False
        start = time.monotonic()
        last = -100.0
        pairs = 0
        # E1's short CD can still be visible while its follow-up E2 is usable.
        # Only the authored split-E route may reuse that confirmed E1 state.
        # Do not log this already-present CD as a newly accepted E2.
        e_cd_seen = initial_e_cd
        split_e_cd_clear = not initial_e_cd
        split_e2_at = None
        refill_logged = False
        last_attack = -100.0
        ready_retry_at = None
        self._mark('Denia-ER-buffer-start', con=round(self.task.get_current_con(),3),
                   input='EAR' if normal_between else 'ER', split_E1=split_e1,
                   initial_E_CD=initial_e_cd)
        with self._animation_guard():
            while time.monotonic()-start < self.LIMIT['denia_2E']:
                visible,index,_=self._hud()
                if visible and index!=self.index:
                    raise AxisFault('E/R buffer lost on-field Denia')
                if time.monotonic()-last >= self.FAST_REPEAT:
                    last=time.monotonic()
                    # New opener: E -> A -> optional E -> R2. Only the first
                    # pair must submit E. Once R2 is ready, prioritize R and
                    # do not add another E/A. Existing EE/R callers are unchanged.
                    r_ready = (normal_between and pairs > 0 and
                               self._label(Labels.denia_end_lib) and self.liberation_available())
                    if r_ready:
                        if ready_retry_at is None:
                            ready_retry_at = last
                        elif last-ready_retry_at >= self.A_INTERVAL:
                            # A lit-icon false positive/rejected R must not
                            # permanently starve the optional E/A recovery.
                            r_ready = False
                            ready_retry_at = last
                    else:
                        ready_retry_at = None
                    if (not r_ready and (not normal_between or not e_cd_seen)
                            and not (split_e1 and split_e2_at is not None)):
                        self.send_resonance_key(down_time=self.FAST_DOWN)
                    if (normal_between and not r_ready
                            and time.monotonic()-last_attack >= self.A_INTERVAL):
                        self._attack(fast=True)
                        last_attack=time.monotonic()
                    # Adjacent to E, before capture, template/OCR or logging.
                    self.send_liberation_key(down_time=self.FAST_DOWN)
                    pairs+=1
                self._fast_tick()
                if not self._hud()[0]:
                    # Do not resume key spam when a camera hides the HUD.
                    # R2 must end in white form with a NEW R cooldown.
                    self._mark('Denia-ER-camera', pairs=pairs)
                    animation_wall=time.time()
                    try:
                        self._until(lambda:self._on_field(self), self.LIMIT['R_animation'],
                                    'buffered R2 camera return')
                        self._until(lambda:self.has_cd('liberation') and
                                    not self._label(Labels.denia_end_lib), 1.0,
                                    'buffered R2 new cooldown/white form')
                    finally:
                        self.task.add_freeze_duration(animation_wall,time.time()-animation_wall)
                    self.record_liberation_use()
                    self.axis_state().denia_form='white'
                    self.axis_state().last_denia_r2=time.time()
                    self.lib_1_casted=False
                    self.lib_2=time.time()
                    self._mark('R2',char=self.name, acknowledgement='ER-buffer-new-CD-white-form')
                    self._mark('Denia-concerto-after-R',form='R2',con=round(self.task.get_current_con(),3))
                    return
                if self._on_field(self):
                    e_cd = self.has_cd('resonance')
                    split_e_cd_clear = split_e_cd_clear or not e_cd
                    if split_e1 and split_e2_at is None and split_e_cd_clear and e_cd:
                        split_e2_at = time.monotonic()
                        self._mark('Denia-split-E2-confirmed', acknowledgement='new-CD', pairs=pairs)
                    if not e_cd_seen and e_cd:
                        e_cd_seen = True
                        self.record_resonance_use()
                        self._mark('Denia-E2-CD', pairs=pairs)
                    # A lost/cancelled A4 must not leave us sending only E/R at
                    # the same 82% energy for 4.5s. Once this visit's E2 is proven,
                    # stop E, allow its short startup, then fill visible missing
                    # energy with A while maintaining R retries. Old E1 CD alone
                    # cannot unlock this recovery or cancel an unconfirmed E2.
                    if (split_e1 and split_e2_at is not None
                            and time.monotonic()-split_e2_at >= self.TIMING['opener_denia_E2_refill_lead']):
                        level = denia_conformal_fill(self.task.frame)
                        if level is not None and level < 1 and not self.liberation_available():
                            start = time.monotonic()
                            if not refill_logged:
                                self._mark('Denia-opener-R2-fill', conformal=round(level,3), input='A-with-rapid-R')
                                refill_logged = True
                            if time.monotonic()-last_attack >= self.A_INTERVAL:
                                self._attack(fast=True)
                                last_attack = time.monotonic()
            raise AxisFault('E/R buffer did not produce a confirmed R2')

    def _qing_buffer_ground_e(self, optional=False):
        """Called only after F acknowledgement; retries during its recovery."""
        qing=self.cur
        if qing.name!='Qingxiao':
            raise AxisFault('F/E buffer requires Qingxiao')
        self._release()
        start=time.monotonic()
        last=-100.0
        hidden_since=None
        self._mark('Qingxiao-E-buffer-start',trigger='F-ack')
        try:
            while time.monotonic()-start < self.LIMIT['E']:
                if not self._hud()[0]:
                    if hidden_since is None:
                        hidden_since=time.time()
                elif hidden_since is not None:
                    self.task.add_freeze_duration(hidden_since,time.time()-hidden_since)
                    hidden_since=None
                ready = not optional or (self._on_field(qing) and qing.enhanced_resonance_available())
                if ready and time.monotonic()-last>=self.FAST_REPEAT:
                    last=time.monotonic()
                    qing.send_resonance_key(down_time=self.FAST_DOWN)
                self._fast_tick()
                if self._on_field(qing) and qing.has_cd('resonance'):
                    qing.record_resonance_use()
                    self._mark('E',char=qing.name,handoff='first-CD-frame-no-tail')
                    return True
        finally:
            if hidden_since is not None:
                self.task.add_freeze_duration(hidden_since,time.time()-hidden_since)
        if optional:
            self._mark('Qingxiao-entry-E-skipped', reason='F-missed-ground-E-unavailable', axis='continue')
            return False
        raise AxisFault('Qingxiao F/E buffer did not start ground E cooldown')

    def _denia_second_a12(self, airborne=False, *, after_dodge=False):
        """A12 -> jump/E must preserve production, unlike the opener's swap.

        Retry through recovery until A2 starts contributing, then stop sending
        A (avoid queuing A3). Confirm part of its multi-hit production before
        handing off; remaining launched hits may settle during jump/EE. Each
        boundary needs two fresh visible frames, never just elapsed input time.
        """
        self._release()
        variant = 'loop' if self.axis_state().phase == 'loop' else 'second'
        if self.cur is not self or self.axis_state().denia_form != 'black':
            raise AxisFault(f'Denia {variant} A12 requires black form on field')
        stage = 'dodge' if after_dodge else ('air' if airborne else 'ground')
        prefix = 'Denia-'+variant+'-'
        # A reset by dodge is still the SECOND chain: keep its cumulative
        # .40/.41 gate, not the first grounded chain's .10/.13 checkpoint.
        onset, target = self.DENIA_A12_ENERGY['air' if after_dodge or airborne else 'ground']
        # Keep some production beyond onset even when reducing the target:
        # the pixel tolerance must not swallow the entire onset/target gap.
        ready_level = target-min(self.DENIA_RING_TOLERANCE, (target-onset)/2)
        started = time.monotonic()
        last_attack = -100.0
        started_frames = ready_frames = 0
        a2_started = False
        last_level = None
        self._mark(prefix+stage+'-A12',
                   acknowledgement='conformal-ring', target=target, tail_overlap=True)
        try:
            # Queue A immediately after the dodge's short input guard, before
            # the first capture/energy lookup. Rejected recovery inputs are
            # retried below; the second A2 production gate is unchanged.
            if after_dodge and self._on_field(self):
                self._attack(fast=True)
                last_attack = time.monotonic()
            # Fresh frame before the first observation prevents reusing R1's
            # camera frame or the ground checkpoint as an air observation.
            while time.monotonic()-started < self.LIMIT['denia_second_A12']:
                self._fast_tick()
                visible, index, _ = self._hud()
                if visible and index != self.index:
                    raise AxisFault(f'Denia {variant} A12: current character changed')
                if not visible:
                    started_frames = ready_frames = 0
                    continue
                level = denia_conformal_fill(self.task.frame)
                if level is not None:
                    last_level = level
                started_frames = started_frames+1 if level is not None and level >= onset else 0
                ready_frames = (ready_frames+1 if level is not None
                                and level >= ready_level else 0)
                if not a2_started and started_frames >= self.FRAME_CONFIRM:
                    a2_started = True
                    self._mark(prefix+stage+'-A2-production',
                               conformal=round(level, 3))
                if a2_started and ready_frames >= self.FRAME_CONFIRM:
                    self._mark(prefix+stage+'-A12-ready',
                               conformal=round(level, 3),
                               handoff='E' if after_dodge or airborne else 'jump', tail_overlap=True)
                    return
                now = time.monotonic()
                # Pause already on the first positive onset frame; a single
                # false/occluded frame cannot permanently stop the retries.
                if not a2_started and not started_frames and now-last_attack >= self.FAST_REPEAT:
                    last_attack = now
                    self._attack(fast=True)
        finally:
            self._release()
        raise AxisFault(f'Denia {variant} {stage} A12: conformal target {target:.2f} '
                        f'not observed (last={last_level}); refusing early jump/E')

    def _loop_f_then_e(self, boundary, tail=.12, clock_evidence=None):
        """Optional F only at landing/R-end boundaries, never mid Z1->Z2."""
        if self.cur.name == 'Qingxiao' and self.cur.has_cd('resonance'):
            # The fast F/E callback acknowledges a NEW E cooldown. An old CD
            # must instead go through _cast_e's availability/transition gate.
            self._mark('loop-F-skipped', boundary=boundary, reason='E-already-CD')
            return False
        if not self._on_field() or not self._f_prompt():
            self._mark('loop-F-skipped', boundary=boundary, reason='no-prompt')
            return False
        f_started = time.time()
        def resume_e():
            self.task.add_freeze_duration(f_started, time.time()-f_started)
            if self.cur.name == 'Qingxiao':
                self._qing_buffer_ground_e()
            else:
                hidden_at = time.time()
                self._hud_back()
                if time.time() > hidden_at:
                    self.task.add_freeze_duration(hidden_at, time.time()-hidden_at)
                if self.cur is not self:
                    self._cast_e(tail)
                # White Denia resumes through the shared EAR buffer next.
        confirmed = self._execute(prompt_confirmed=True, on_ack=resume_e,
                                  handoff='loop-F-E', start_cap=self.LIMIT['F_start'],
                                  confirm_target_execution=self.cur.name == 'Denia',
                                  clock_evidence=clock_evidence)
        self._mark('loop-F' if confirmed else 'loop-F-skipped', boundary=boundary,
                   reason='confirmed' if confirmed else 'input-rejected')
        return confirmed

    def _denia_f_ready(self):
        state = self.axis_state()
        # Ignore a boss-bar marker left lit after this target already ate F.
        # A fresh floating prompt or an unexecuted wave can still arm it.
        return self._on_field(self) and (self._f_target_prompt() or
            (state.target_epoch > state.executed_epoch and self._f_prompt()))

    def _denia_plunge_f(self):
        """Look for landing F during the existing plunge window, not after it.

        Always send the plunge first. A fresh target prompt can cancel into F;
        missing/rejected F returns to the ordinary E/R1 route without waiting
        for a future prompt. Both second and loop use this preferred boundary.
        """
        self._release()
        start = time.monotonic()
        last_attack = -100.0
        evidence = ExecutionClockEvidence()
        epoch = self.axis_state().target_epoch
        initial_prompt = self._denia_f_ready()
        self._mark('Denia-plunge', window=self.TIMING['denia_plunge'], F='preferred')
        while True:
            if self.axis_state().target_epoch != epoch:
                evidence = ExecutionClockEvidence()
                epoch = self.axis_state().target_epoch
            visible, index, _ = self._hud()
            if visible and index != self.index:
                raise AxisFault('Denia plunge lost on-field Denia')
            now = time.monotonic()
            if visible:
                evidence.observe(self.task.frame, now, False)
                # An already-lit F cannot cancel the very first plunge input.
                # Keep its existing .48s window in that case. For a new prompt
                # after A, allow an earlier F with a small .12s input floor;
                # that floor is not claimed as a hit/landing detector.
                earliest_f = self.TIMING['denia_plunge'] if initial_prompt else .12
                if (last_attack >= start and now-start >= earliest_f
                        and self._denia_f_ready()):
                    return self._loop_f_then_e('Denia-landing', tail=.12,
                                               clock_evidence=evidence)
            if now-start >= self.TIMING['denia_plunge']:
                return False
            if visible and now-last_attack >= self.A_INTERVAL:
                self._attack(fast=True)
                last_attack = now
            self._fast_tick()

    def _denia_late_landing_f(self):
        """Optional visible F during white EAR, independent of E cooldown.

        The target prompt may appear after landing or move into view later.
        F's callback only accounts for its freeze; R1 keeps its input buffer.
        Never repeat E, and never treat a hidden HUD alone as a confirmed F.
        """
        if not self._denia_f_ready():
            return False
        wall = time.time()
        confirmed = self._execute(prompt_confirmed=True,
            confirm_target_execution=True, start_cap=self.LIMIT['F_start'],
            on_ack=lambda:self.task.add_freeze_duration(wall,time.time()-wall),
            handoff='Denia-white-EAR-F-R1')
        self._mark('Denia-late-landing-F', confirmed=confirmed, axis='continue')
        return confirmed



    def _denia_prepare(self, second=False):
        self._denia_plunge_f()
        # Both later rounds stay on white Denia through the A/R1 buffer.
        # Loop Qing visits now belong before the plunge (Q) and before Morn R.
        self._cast_r(form='R1', buffer_r1=True)
        self._denia_weave_normals(weave_qing=second)
        # E2's actual CD is enough for Qing's switch-in A1, then Mornye. R2 stays deferred until
        # after Mornye R and Qingxiao's intro E, with its own readiness gate.
        self._denia_double_e(defer_r=True)

    def _qing_weave_return(self, boundary):
        """One Qing A12 visit before steady-loop white R1, with no extra A."""
        if self.cur is not self:
            raise AxisFault('Qing weave visit must begin on Denia')
        self._switch('Qingxiao')
        self._mark('Qingxiao-white-R1-A12', boundary=boundary)
        self._two_normals_to_swap('Qingxiao-white-R1-A1', 'Qingxiao-white-R1-A2',
                                  self.TIMING['qing_opener_A2_at'])
        self._switch('Denia')

    def _denia_weave_normals(self, weave_qing=True):
        """Black A12/dodge -> optional second-round Qing A12 -> black A12."""
        if self.cur is not self or self.axis_state().denia_form != 'black':
            raise AxisFault('Denia woven A12 requires black Denia after R1')
        self._denia_first_a12_to_dodge()
        # Reset on the ground BEFORE Qing's visit. Switch immediately after
        # the dodge press; never jump or dodge a second time on return.
        self._mark('Denia-weave-dodge', after='Denia-A12', before_Qing=weave_qing)
        self.task.click(key='right', down_time=self.FAST_DOWN if weave_qing else self.KEY_DOWN,
                        move=False)
        if weave_qing:
            self._switch('Qingxiao')
            self._two_normals_to_swap('Qingxiao-weave-A1', 'Qingxiao-weave-A2',
                                      self.TIMING['qing_opener_A2_at'])
            self._switch('Denia')
        else:
            self.task.sleep(self.TIMING['denia_second_dodge_lead'])
        self._denia_second_a12(after_dodge=True)


    def _qing_entry_e(self, execute=False, preinput=False, buffer_intro=False):
        qing = self.cur
        if not qing.has_intro:
            raise AxisFault('Qingxiao entry E requires an observed intro')
        if execute or preinput:
            # First round: preinput A, F lands her, then spend grounded E.
            if preinput:
                if qing.has_cd('resonance'):
                    raise AxisFault('Qingxiao ground E already on cooldown before F')
                if not self._qing_preinput_f(execute=execute, on_ack=self._qing_buffer_ground_e):
                    self._mark('Qingxiao-entry-F-skipped', axis='continue-with-ground-E-if-available')
                    self._qing_buffer_ground_e(optional=True)
                return
            elif execute:
                self._wait(self.TIMING['qing_intro'])
                self._execute()
            self._cast_e(self.TIMING['qing_E_tail'])
            return
        if buffer_intro:
            return self._qing_buffer_air_e()
        # Later rounds: the reference's E remains off cooldown (65.5–66s,
        # 113–114s). It is the airborne A3 replacement, not grounded E.
        # It has no cooldown transition to acknowledge. Send a bounded entry
        # window, reserve ground E for the post-R tail, and defer resource
        # acknowledgement to the mandatory Qingxiao Z1 gate after R2.
        self._wait(self.TIMING['qing_air_E_delay'])
        start = time.monotonic()
        last_key = -100.0
        while time.monotonic() - start < self.TIMING['qing_air_E_input']:
            now = time.monotonic()
            if now - last_key >= self.KEY_INTERVAL:
                qing.send_resonance_key(down_time=self.KEY_DOWN)
                last_key = now
            self._tick()
        self._wait(self.TIMING['qing_air_E_tail'])
        self._mark('Qingxiao-air-E-input', acknowledgement='deferred-to-Z1-resource')


    def _qing_buffer_air_e(self):
        """Prebuffer through intro recovery, then hand off without resource wait.

        No available API proves this airborne E's animation onset. The .90s
        recovery boundary uses the installed native intro duration as an initial
        estimate, followed by one fresh E and .04s startup allowance. This is
        explicitly a TIMING APPROXIMATION, not pose/damage/CD confirmation.
        Resource settles off field and must never gate this handoff.
        """
        self._release()
        if self.cur.name != 'Qingxiao' or not self.cur.has_intro:
            raise AxisFault('Qingxiao entry E requires Qingxiao on field')
        started = time.monotonic()
        entry = getattr(self, '_qing_entry_at', started)
        recover_at = entry + self.TIMING['qing_air_E_entry_recovery']
        ready = 0
        last_key = -100.0
        release_at = None
        prepared = None
        while time.monotonic()-started < self.LIMIT['qing_air_E_buffer']:
            now = time.monotonic()
            visible, index, _ = self._hud()
            if visible and index != self.cur.index:
                raise AxisFault('Qingxiao entry E: current character changed')
            if not visible:
                # Hidden HUD cannot consume the startup allowance. Restart the
                # final input/lead after a visible Qingxiao HUD returns.
                ready = 0
                release_at = None
            elif release_at is not None:
                if now >= release_at:
                    self._mark('Qingxiao-air-E-handoff',
                               detector='intro-recovery-timing-approximation',
                               entry_elapsed=round(now-entry, 3),
                               resource_wait=False)
                    return prepared
            else:
                air_icon = qing_e_icon(self.task.frame) in ('ground', 'air-a3')
                # Reserve ground enhanced E for R -> E -> A4 -> full 4A.
                air_icon = air_icon and not self.cur.enhanced_resonance_available()
                ready = ready+1 if air_icon else 0
                if ready >= 2 and now-last_key >= self.FAST_REPEAT:
                    final_input = now >= recover_at
                    if final_input:
                        # Read concerto before the last E, never between its
                        # startup boundary and the first destination slot key.
                        prepared = (self.cur, self.teammate('Denia'),
                                    self._full_con(self.cur))
                    self.cur.send_resonance_key(down_time=self.FAST_DOWN)
                    if last_key < 0:
                        self._mark('Qingxiao-air-E-buffer', resource_wait=False)
                    last_key = now
                    if final_input:
                        release_at = time.monotonic()+self.TIMING['qing_air_E_start_lead']
                        self._mark('Qingxiao-air-E-startup-input',
                                   detector='intro-recovery-timing-approximation')
            self._fast_tick()
        raise AxisFault('Qingxiao entry E: visible input/startup window unavailable')

    def _qing_preinput_f(self, execute=True, on_ack=None):
        """Continue entry's held A and immediately retry F through the intro."""
        if not self._holding:
            self._holding = True
            self.task.mouse_down()
            self._mark('Qingxiao-preinput-A', input='hold', during_intro=True)
        try:
            if execute:
                return self._execute(hold_until_ack=True, buffer_entry=True,
                                     start_cap=2.2, on_ack=on_ack,
                                     confirm_grounded_execution=on_ack is not None)
            return True
        finally:
            self._release()

    def _qing_enemy_present(self):
        # Camera/occlusion is unknown, not evidence of an empty arena.
        if not self._on_field():
            return None
        return enemy_health_visible(self.task.frame)

    def _qing_spawn_pause(self, tag, resume_hold=False):
        """One fixed half-second pause; never poll until new HP appears."""
        held = self._holding
        self._release()
        self._mark('Qingxiao-spawn-pause', boundary=tag, seconds=self.TIMING['qing_spawn_pause'])
        started = time.monotonic()
        with self._animation_guard():
            while time.monotonic()-started < self.TIMING['qing_spawn_pause']:
                self._fast_tick()
        if resume_hold and held:
            self.task.mouse_down()
            self._holding = True
        self._mark('Qingxiao-spawn-resume', boundary=tag, held_A=self._holding,
                   waited=round(time.monotonic()-started,3))

    def _qing_remember_z2_f(self):
        # The Z2 close-up hides both the team HUD and the target F. Remember
        # a real floating prompt before/during that camera; hiding the HUD
        # cannot erase the pending pre-R execution. Do not latch the persistent
        # boss marker, which may remain lit after an earlier successful F.
        state = self.axis_state()
        if state.pre_r_f_pending:
            return
        if not self._on_field():
            state.qing_z2_f_frames = 0
            return
        state.qing_z2_f_frames = state.qing_z2_f_frames+1 if self._f_target_prompt() else 0
        if state.qing_z2_f_frames >= self.FRAME_CONFIRM:
            state.pre_r_f_pending = True
            self._mark('Qingxiao-Z2-F-latched', epoch=state.target_epoch,
                       source='floating-target-prompt')

    def _qing_z2_ready(self, label, tag, cap, fill, already_held):
        # H2 may only become recognizable after the held A has auto-started Z2.
        # Watch the preceding enhanced normals too, so an empty field releases
        # the buffered A before that point. At most one pause for this Z2;
        # transient HP flashes must not repeatedly extend the half-second.
        start = time.monotonic()
        last_attack = -100.0
        streak = 0
        paused = False
        extended = False
        enhanced_frames = 0
        enhanced_at = None
        while True:
            self._qing_remember_z2_f()
            visible, index, _ = self._hud()
            if visible and index != self.cur.index:
                raise AxisFault(tag+' ready: lost on-field Qingxiao')
            present = self._qing_enemy_present()
            if present is False and not paused:
                before = time.monotonic()
                self._qing_spawn_pause(tag, resume_hold=already_held)
                start += time.monotonic()-before
                paused = True
                streak = 0
            ready = self._label(label)
            streak = streak+1 if ready else 0
            if streak >= (1 if already_held else self.FRAME_CONFIRM):
                return
            # Parry hitstop/slow motion consumes wall time while held A is
            # still advancing the correct combo. Grant one bounded extension
            # only with recent positive enhanced-normal evidence. Do not infer
            # a parry from the game clock or extend repeatedly on a stuck HUD.
            now = time.monotonic()
            enhanced_frames = (enhanced_frames+1 if
                               qing_enhanced_normal_visible(self.task.frame) else 0)
            if enhanced_frames >= self.FRAME_CONFIRM:
                enhanced_at = now
            if now-start >= cap:
                if (not extended and already_held and self._holding
                        and enhanced_at is not None and now-enhanced_at <= .5):
                    extra = self.LIMIT['qing_Z2_combo_grace']
                    cap += extra
                    extended = True
                    self._mark(tag+'-wait-extended', extra=extra,
                               elapsed=round(now-start,3),
                               evidence='enhanced-normal', input='continuous-hold')
                else:
                    raise AxisFault(tag+' ready: condition not confirmed within '+f'{cap:.2f}s')
            if (not ready and fill and not already_held and self._on_field()
                    and time.monotonic()-last_attack >= self.A_INTERVAL):
                self._attack()
                last_attack = time.monotonic()
            self._fast_tick()


    def _qing_heavy(self, label, tag, cap, fill=True, already_held=False,
                    keep_held=False):
        qing = self.cur
        self._hud_back()
        if label == Labels.qingxiao_h2:
            state = self.axis_state()
            state.qing_z2_f_epoch = -1
            state.qing_z2_f_checked_epoch = -1
            state.qing_z2_f_attempted_epoch = -1
            state.qing_z2_f_frames = 0
            state.pre_r_f_pending = False
            # Keep the framework's multi-second target reacquisition out of
            # this bounded held-combo/spawn window; cancellation still works.
            with self._animation_guard():
                self._qing_z2_ready(label, tag, cap, fill, already_held)
        elif already_held and label == Labels.qingxiao_h1:
            if not self._holding:
                raise AxisFault(tag + ': expected continuous held A')
            # A preheld Z1 may start before the first confirmed entry frame.
            # Its positive enhanced-normal or H2 successor also proves progress;
            # missing H1 alone never does. Keep the same hold without A clicks.
            successor = 0
            start = time.monotonic()
            while time.monotonic()-start < cap:
                if self._label(label):
                    break
                h2 = self._label(Labels.qingxiao_h2)
                enhanced = qing_enhanced_normal_visible(self.task.frame)
                successor = successor+1 if h2 or enhanced else 0
                if successor >= self.FRAME_CONFIRM:
                    self._mark(tag, acknowledgement=('preheld-H2-successor' if h2 else
                                                     'preheld-enhanced-normal-successor'))
                    if not keep_held:
                        self._release()
                    return
                self._fast_tick()
            else:
                raise AxisFault(tag+' ready: no H1 or H2/enhanced-normal successor during held entry')
        else:
            self._until(lambda: self._label(label), cap, tag + ' ready',
                        attack=fill and not already_held, confirmations=1 if already_held else None)
        if already_held:
            if not self._holding:
                raise AxisFault(tag + ': expected continuous held A')
        else:
            self.task.mouse_down()
            self._holding = True
        self._mark(tag + '-input')
        start = time.monotonic()
        gone = 0
        normal_since = None
        completed = False
        if label == Labels.qingxiao_h2:
            self._qing_z2_hidden_since = None
            self._qing_z2_impact_confirmed = False
        try:
            with self._animation_guard():
                while time.monotonic() - start < cap:
                    self._tick()
                    if label == Labels.qingxiao_h2:
                        self._qing_remember_z2_f()
                    if (label == Labels.qingxiao_h2 and not self._hud()[0]
                            and self._qing_z2_hidden_since is None):
                        self._qing_z2_hidden_since = time.time()
                    # Require a positive successor, not disappearance alone:
                    # glow/occlusion can hide H1 well before Z1 completes.
                    consumed = not self._label(label)
                    if label == Labels.qingxiao_h1:
                        consumed = consumed and (
                            qing_enhanced_normal_visible(self.task.frame)
                            or self._label(Labels.qingxiao_h2))
                    if label == Labels.qingxiao_h2:
                        # In the user's recording h2 stays visible through the
                        # multi-hit sequence and changes to normal at impact.
                        # Require the positive normal glyph, not disappearance
                        # alone (which can be HUD occlusion or icon glow).
                        consumed = consumed and qing_normal_visible(self.task.frame)
                        if consumed and normal_since is None:
                            normal_since = time.monotonic()
                        elif not consumed:
                            normal_since = None
                    gone = gone + 1 if consumed else 0
                    required = self.FRAME_CONFIRM if label == Labels.qingxiao_h2 else 3
                    # Frame replay: normal glyph at 38.633s, the terminal
                    # damage number starts at ~38.700s. Confirm for .08s from
                    # that positive transition, not 3s after the whole cast.
                    impact_ready = (label != Labels.qingxiao_h2 or
                                    (normal_since is not None and time.monotonic() - normal_since >=
                                     self.TIMING['qing_Z2_impact_confirm']))
                    if gone >= required and impact_ready and time.monotonic() - start >= .30:
                        if label == Labels.qingxiao_h2:
                            self._qing_z2_impact_confirmed = True
                        self._mark(tag)
                        completed = True
                        return
                raise AxisFault(tag + ' did not consume its ready state')
        finally:
            if not (completed and keep_held):
                self._release()

    def _qing_pre_r_execution(self):
        """Prefer F, but missing/rejected F must always release the R boundary.

        A Z2/target gets one bounded F input window. A discarded hint cannot
        rearm itself on each rapid R retry; a later real floating prompt can
        still get that window if no F input was attempted yet.
        """
        state=self.axis_state()
        self._observe_execution_target(force=True)
        if state.qing_z2_f_attempted_epoch == state.target_epoch:
            return True
        visible=self._on_field()
        fresh_prompt=visible and self._f_target_prompt()
        unchecked=state.qing_z2_f_checked_epoch != state.target_epoch
        pending=fresh_prompt or (unchecked and (
            state.target_epoch>state.executed_epoch or state.pre_r_f_pending or
            (visible and state.qing_z2_f_epoch != state.target_epoch and self._f_prompt())))
        if not pending:
            return True
        state.pre_r_f_pending=True
        self._release()
        start=time.monotonic()
        last_attack=-100.0
        locked=False
        missing_since=None
        # One chronological observation stream across retries for this target.
        # Do not carry it across a deferred call or a changed target epoch.
        evidence = ExecutionClockEvidence()
        evidence_epoch = state.target_epoch
        self._mark('Qingxiao-pre-R-F', epoch=state.target_epoch, status='pending')
        while time.monotonic()-start<self.LIMIT['pre_R_F']:
            if state.target_epoch != evidence_epoch:
                evidence = ExecutionClockEvidence()
                evidence_epoch = state.target_epoch
                missing_since=None
            visible,index,_=self._hud()
            if visible and index!=self.cur.index:
                raise AxisFault('Qingxiao pre-R F lost on-field Qingxiao')
            hidden_since=getattr(self,'_qing_z2_hidden_since',None)
            if visible and hidden_since is not None:
                # Close the preceding Z2 camera interval before accounting
                # for F; do not charge the same freeze interval twice.
                self.task.add_freeze_duration(hidden_since,time.time()-hidden_since)
                self._qing_z2_hidden_since=None
            if visible and self._f_prompt():
                missing_since=None
                wall=time.time()
                state.qing_z2_f_attempted_epoch=state.target_epoch
                remaining=self.LIMIT['pre_R_F']-(time.monotonic()-start)
                if remaining <= 0:
                    break
                confirmed=self._execute(prompt_confirmed=True,
                    start_cap=min(self.LIMIT['F_start'],remaining), confirm_target_execution=True,
                    clock_evidence=evidence,
                    on_ack=lambda:self.task.add_freeze_duration(wall,time.time()-wall),
                    handoff='pre-R')
                if confirmed and state.executed_epoch==state.target_epoch:
                    state.pre_r_f_pending=False
                    state.qing_z2_f_epoch=state.target_epoch
                    state.qing_z2_f_checked_epoch=state.target_epoch
                    self._mark('Qingxiao-pre-R-F-ready', epoch=state.target_epoch)
                    return True
            elif visible:
                if missing_since is None:
                    missing_since=time.monotonic()
                new_target=state.target_epoch>state.executed_epoch
                if time.monotonic()-missing_since >= (.35 if new_target else .12):
                    break
                if new_target and time.monotonic()-last_attack>=self.A_INTERVAL:
                    # Give a new target a brief hit window to expose Denia C2's
                    # F, without forcing an indefinitely missing F to appear.
                    if not locked and callable(getattr(self.task,'middle_click',None)):
                        self.task.middle_click(down_time=self.FAST_DOWN,move=False)
                        locked=True
                    self._attack(fast=True)
                    last_attack=time.monotonic()
            else:
                missing_since=None
            self._tick()
        state.pre_r_f_pending=False
        state.qing_z2_f_checked_epoch=state.target_epoch
        self._mark('Qingxiao-pre-R-F-continue', epoch=state.target_epoch,
                   reason='unconfirmed' if state.qing_z2_f_attempted_epoch==state.target_epoch
                          else 'prompt-missing', axis='continue-R')
        # Do not mark an unconfirmed F as executed; only release the R guard.
        return True

    def _qing_r_after_z2(self, on_recovery=None):
        """Send R at the observed impact boundary, even during the Z2 camera.

        Old CD can reappear after Z2/F or an OCR miss. R acceptance requires
        a long numerical cooldown AND consumed energy, on two fresh frames.
        A boolean CD or a hidden/returned team HUD cannot prove a new cast.
        """
        if self.cur.name != 'Qingxiao' or not getattr(self, '_qing_z2_impact_confirmed', False):
            raise AxisFault('Qingxiao R requires the Z2 impact/normal-icon transition')
        gap_paused = self._qing_enemy_present() is False
        if gap_paused:
            self._qing_spawn_pause('R')
        if not self._qing_pre_r_execution():
            raise AxisDeferred('Qingxiao R pending new-target F')
        self._release()
        qing = self.cur
        start = time.monotonic()
        hidden_since = getattr(self, '_qing_z2_hidden_since', None)
        last_key = -100.0
        last_attack = -100.0
        refill_logged = False
        pre_cast_energy = False
        input_started = None
        cooldown_frames = 0
        cast_frames = 0
        hidden_after_input = False
        recovery_armed = False
        deferred = False
        try:
            with self._animation_guard():
                # Keep trying R while filling A instead of waiting at the old
                # six-second readiness gate. Full-looking ring pixels alone
                # cannot prove readiness: the replay's last energy sliver
                # still leaves the R glyph dark.
                pre_cast_energy = (qing.liberation_available() or
                    (self._on_field(qing) and (qing_r_energy_fill(self.task.frame) or 0) >= .75))
                while time.monotonic() - start < self.LIMIT['R_start'] + self.LIMIT['R_animation']:
                    now = time.monotonic()
                    if now - last_key >= self.FAST_REPEAT and not cast_frames and not recovery_armed:
                        # Readiness can take seconds. Recheck a wave/target
                        # arriving during that wait or a rejected R input.
                        if (last_key<0 or (self._on_field(qing) and not qing.has_cd('liberation'))):
                            guard_start=time.monotonic()
                            present = self._qing_enemy_present()
                            if present is False and not gap_paused:
                                self._qing_spawn_pause('R')
                                gap_paused = True
                            if not self._qing_pre_r_execution():
                                deferred=True
                                raise AxisDeferred('Qingxiao R pending new-target F')
                            # F recovery is not a rejected-R timeout.
                            start+=time.monotonic()-guard_start
                            now=time.monotonic()
                        pre_cast_energy = pre_cast_energy or qing.liberation_available()
                        qing.send_liberation_key(down_time=self.FAST_DOWN)
                        if last_key < 0:
                            input_started = now
                            self._mark('R-input', char=qing.name, trigger='Z2-impact')
                        last_key = now
                    if on_recovery is None:
                        self._tick()
                    else:
                        self._fast_tick()
                    visible, index, _ = self._hud()
                    if visible and index != qing.index:
                        raise AxisFault('Qingxiao R lost on-field Qingxiao')
                    # The supplied replay's old CD was 1.1 -> .9 -> .4, with
                    # full energy throughout. A real R starts near 25s and
                    # spends that energy. Both signals must agree; never
                    # replace missing numerical evidence with has_cd(True).
                    cd = self.task.get_cd('liberation') if visible else None
                    energy = qing_r_energy_fill(self.task.frame) if visible else None
                    available = visible and qing.liberation_available()
                    pre_cast_energy = pre_cast_energy or available or (energy is not None and energy >= .75)
                    new_cast = (pre_cast_energy and isinstance(cd, (int,float)) and 10 <= cd <= 35
                                and energy is not None and energy <= .35)
                    cast_frames = cast_frames+1 if new_cast else 0
                    if not recovery_armed and energy is not None and energy >= .75:
                        # Returning from Z2/F with energy intact cannot supply
                        # the later R's completed-camera evidence. A genuine
                        # R first spends energy, then supplies its own camera.
                        hidden_after_input = False
                    if not recovery_armed and cast_frames >= self.FRAME_CONFIRM:
                        recovery_armed = True
                        self._mark('Qingxiao-R-cast-confirmed', CD=round(cd,2),
                                   energy=round(energy,3), acknowledgement='long-CD-and-energy-spent')
                    if recovery_armed and on_recovery is not None:
                        on_recovery()
                    hidden_after_input = hidden_after_input or not visible
                    if not visible and hidden_since is None:
                        hidden_since = time.time()
                    elif visible and hidden_since is not None:
                        self.task.add_freeze_duration(hidden_since, time.time() - hidden_since)
                        hidden_since = None
                    # A CD can appear during startup before the camera hides.
                    # Do not commit the phase on those early visible frames.
                    cooled = (recovery_armed and hidden_after_input and now - start >= .40
                              and new_cast)
                    cooldown_frames = cooldown_frames + 1 if cooled else 0
                    if cooldown_frames >= self.FRAME_CONFIRM:
                        qing.record_liberation_use()
                        self._mark('R', char=qing.name,
                                   acknowledgement='long-CD-energy-spent-and-HUD-return',
                                   CD=round(cd,2), energy=round(energy,3))
                        return
                    # No fixed timeout for a visible, actionable energy/CD
                    # wait. Preserve the normal R animation timeout once R
                    # consumes energy; never mix filler A into its recovery.
                    filling = (visible and not recovery_armed and not cast_frames
                               and qing_normal_visible(self.task.frame)
                               and energy is not None
                               and (energy > .35 or not pre_cast_energy)
                               and (not available or energy < .99
                                    or (input_started is not None
                                        and time.monotonic()-input_started >= .20)))
                    if filling:
                        start = time.monotonic()
                        if not refill_logged:
                            self._mark('Qingxiao-R-fill', input='A-with-rapid-R',
                                       energy=round(energy,3), CD=cd)
                            refill_logged = True
                        if time.monotonic()-last_attack >= self.A_INTERVAL:
                            self._attack(fast=True)
                            last_attack = time.monotonic()
                raise AxisFault('Qingxiao R after Z2 did not produce a confirmed cooldown')
        finally:
            if hidden_since is not None:
                self.task.add_freeze_duration(hidden_since, time.time() - hidden_since)
            self._qing_z2_hidden_since = None
            if not deferred:
                self._qing_z2_impact_confirmed = False

    def _second_f(self, tag, resume_hold=False):
        """Optional F at this boundary; absence/rejection never abandons Z2."""
        if not self._on_field() or not self._f_prompt():
            self._mark(tag+'-skipped', reason='no-prompt', axis='continue')
            return False
        f_started = time.time()
        def resume():
            self._holding = True
            self.task.mouse_down()
            # This callback skips _execute's default completion branch, so
            # retain its observed input-to-ack interval for freeze accounting.
            self.task.add_freeze_duration(f_started, time.time() - f_started)
            self._mark('Qingxiao-after-F-A', input='continuous-hold')
        confirmed=self._execute(prompt_confirmed=True, start_cap=2.2,
                                hold_until_ack=resume_hold,
                                on_ack=resume if resume_hold else None)
        if resume_hold and not self._holding:
            self._holding=True
            self.task.mouse_down()
        self._mark(tag if confirmed else tag+'-skipped',
                   acknowledgement='confirmed' if confirmed else 'not-confirmed', axis='continue')
        return confirmed

    def _qing_burst(self, first=False, second=False):
        if first or not second:
            # The reference package and video use one uninterrupted hold for
            # Z1 -> enhanced normals -> Z2. Keep the input buffered through
            # Z1's animation; h2 must actually appear, then reach its positive
            # impact marker. No 1.05s idle tail or click window in between.
            try:
                self._qing_heavy(Labels.qingxiao_h1, 'Qingxiao-Z1',
                                 self.LIMIT['qing_Z1'], already_held=self._holding, keep_held=True)
                self._mark('Qingxiao-enhanced-A', input='continuous-hold')
                self._qing_heavy(Labels.qingxiao_h2, 'Qingxiao-Z2',
                                 self.LIMIT['qing_Z2'], already_held=True)
            finally:
                self._release()
        elif second:
            # Keep the confirmed opener's continuous input, with this round's
            # authored F between Z1 and Z2. Resource gates, rather than a
            # 1.05s idle tail plus a blind 2s click window, control progress.
            try:
                self._qing_heavy(Labels.qingxiao_h1, 'Qingxiao-Z1',
                                 self.LIMIT['qing_Z1'], already_held=self._holding, keep_held=True)
                self._second_f('Qingxiao-second-burst-F', resume_hold=True)
                self._qing_heavy(Labels.qingxiao_h2, 'Qingxiao-Z2',
                                 self.LIMIT['qing_Z2'], already_held=True)
            finally:
                self._release()
        self.axis_state().burst_resume=(first,second)
        self._qing_finish_burst(first=first,second=second)

    def _qing_recovery_input(self, buffer):
        """Fast post-R A/E input; input submission never counts as a hit/cast."""
        buffer['observed'] = True
        visible, index, _ = self._hud()
        if visible and index != self.cur.index:
            raise AxisFault('Qingxiao R recovery lost on-field Qingxiao')
        now = time.monotonic()
        if buffer['kind'] == 'A':
            if not visible:
                # The R camera can precede its circuit reset. A pre-camera
                # value cannot become the post-R A1 baseline.
                buffer['baseline'] = None
                buffer['grown'] = 0
                buffer['ready'] = False
            else:
                level = qing_circuit_lit(self.task.frame)
                baseline = buffer['baseline']
                if level is not None and (baseline is None or level < baseline):
                    buffer['baseline'] = baseline = level
                    buffer['grown'] = 0
                grew = (buffer['presses'] > 0 and level is not None and
                        baseline is not None and level >= baseline+1)
                buffer['grown'] = buffer['grown']+1 if grew else 0
            if buffer['grown'] >= self.FRAME_CONFIRM:
                buffer['ready'] = True
            if not buffer['ready'] and buffer['grown'] == 0 and now-buffer['last'] >= self.FAST_REPEAT:
                self._attack(fast=True)
                buffer['last'] = now
                buffer['presses'] += 1
                if buffer['presses'] == 1:
                    self._mark('Qingxiao-post-R-buffer', input='rapid-A', trigger='new-R-CD')
        else:
            if visible:
                cd = self.cur.has_cd('resonance')
                if not cd:
                    buffer['E_clear'] = True
                elif buffer['E_clear'] and buffer['presses']:
                    # First actual NEW E CD: hold immediately, before logging,
                    # another screenshot, confirmation frame or the old .16s tail.
                    if not buffer['ready']:
                        # Keep this cast's evidence in the local recovery
                        # buffer. mouse_down can invalidate the OCR scene;
                        # its next result must not revoke an accepted E.
                        buffer['E_started'] = self.cur
                    if not self._holding:
                        self._holding = True
                        self.task.mouse_down()
                    if not buffer['ready']:
                        self.cur.record_resonance_use()
                        self._mark('Qingxiao-post-R-E-start', acknowledgement='new-CD',
                                   next_input='continuous-hold-A', tail_ms=0)
                    buffer['ready'] = True
            if not buffer['ready'] and now-buffer['last'] >= self.FAST_REPEAT:
                self.cur.send_resonance_key(down_time=self.FAST_DOWN)
                buffer['last'] = now
                buffer['presses'] += 1
                if buffer['presses'] == 1:
                    self._mark('Qingxiao-post-R-buffer', input='rapid-E', trigger='new-R-CD')

    def _qing_finish_recovery(self, buffer):
        start = time.monotonic()
        cap = self.LIMIT['qing_A1_growth' if buffer['kind']=='A' else 'E']
        while not buffer['ready'] and time.monotonic()-start < cap:
            # The R loop may just have sampled this frame. Growth confirmation
            # must use another capture, not count that same sample twice.
            if buffer.get('observed'):
                self._fast_tick()
            self._qing_recovery_input(buffer)
        if not buffer['ready']:
            raise AxisFault('Qingxiao post-R '+buffer['kind']+' recovery not confirmed')
        if buffer['kind'] == 'A':
            self.task.click(key='right', down_time=self.KEY_DOWN)
            self.axis_state().second_a1_ready = True
            self._mark('Qingxiao-second-A1-dodge', acknowledgement='buffered-circuit-growth',
                       circuit_before=buffer['baseline'], A_presses=buffer['presses'])
        else:
            self._qing_tail_normals(preheld=True, e_started=buffer.get('E_started'))

    def _qing_finish_burst(self, first=False, second=False):
        buffer = dict(kind='A' if first else 'E', last=-100., presses=0,
                      baseline=None, grown=0, E_clear=False, ready=False)
        try:
            self._qing_r_after_z2(on_recovery=lambda:self._qing_recovery_input(buffer))
            self._qing_finish_recovery(buffer)
        finally:
            self._release()
        self._mark('Qingxiao-burst-end', variant='first' if first else ('second' if second else 'loop'))
        self.axis_state().burst_resume=None

    def _opener_qing_e(self):
        """One immediate A1, a short onset lead, then E's first new CD."""
        self._release()
        qing = self.cur
        if qing.name != 'Qingxiao' or not self._on_field(qing):
            raise AxisFault('Opening E requires on-field Qingxiao')
        if qing.has_cd('resonance'):
            raise AxisFault('Opening Qingxiao E already on cooldown')
        self._attack(fast=True)
        self._mark('Qingxiao-first-input', input='A1', next='E', pose_confirmed=False)
        # Let the detached A1 start without waiting for its hit/resource gain.
        # This is an input margin, not a pose detector; retry E, never A1.
        self.task.sleep(self.TIMING['opener_qing_A1_E_lead'])
        started = time.monotonic()
        last = -100.0
        while time.monotonic()-started < self.LIMIT['E']:
            visible, index, _ = self._hud()
            if visible and index != qing.index:
                raise AxisFault('Opening Qingxiao E lost current character')
            now = time.monotonic()
            if visible and now-last >= self.FAST_REPEAT:
                qing.send_resonance_key(down_time=self.FAST_DOWN)
                if last < 0:
                    hook = getattr(self.task, ENTRY_HOOK, None)
                    if hook and hook['target_pending']:
                        hook['target_pending'] = False
                        # Retain the early challenge hook; lock AFTER the first
                        # action rather than waiting for a spawned health bar.
                        self.task.middle_click(down_time=self.FAST_DOWN, move=False)
                last = now
            self._fast_tick()
            if self._on_field(qing) and qing.has_cd('resonance'):
                qing.record_resonance_use()
                self._mark('Qingxiao-opener-E', acknowledgement='new-CD')
                return
        raise AxisFault('Opening Qingxiao E had no new cooldown')

    def _opener_denia_tap_to(self, target_name, tag):
        """One black normal input, with prepared metadata for the next slot.

        The caller owns R1 recovery and the short A1/A2 onset window. Do not
        keep clicking while waiting for damage/energy: that queues A2 early.
        Snapshot switching metadata BEFORE A so no lookup separates A/slot.
        """
        if (self.cur is not self or self.axis_state().denia_form != 'black'
                or not self._on_field(self)):
            raise AxisFault('Opening single normal requires on-field black Denia')
        if target_name not in ('Qingxiao', 'Mornye'):
            raise AxisFault('Opening normal handoff requires Qingxiao or Mornye')
        self._release()
        prepared = (self, self.teammate(target_name), self._full_con(self))
        self._mark(tag, input='single-press',
                   handoff='caller-onset-window',
                   target=target_name, pose_confirmed=False)
        self._attack(fast=True)
        return prepared

    def _opener_denia_a1(self):
        # A restored HUD is earlier than the end of R1's input lock. Keep one
        # A edge, but place it after a short R1 recovery budget and give its
        # onset a small lead before swapping. Never fill this wait with A spam.
        if self.cur is not self or self.axis_state().denia_form != 'black':
            raise AxisFault('Opening A1 recovery requires black Denia')
        entry = getattr(self, '_denia_r1_hud_back_at', time.monotonic())
        deadline = entry+self.TIMING['opener_denia_A1_recovery']
        while time.monotonic() < deadline:
            visible, index, _ = self._hud()
            if visible and index != self.index:
                raise AxisFault('Opening A1 recovery lost current character')
            self._fast_tick()
        prepared = self._opener_denia_tap_to('Qingxiao', 'Denia-opener-A1')
        self.task.sleep(self.TIMING['opener_denia_A1_start_lead'])
        self._mark('Denia-opener-A1-handoff', acknowledgement='R1-recovery-plus-onset-window',
                   recovery_ms=self.TIMING['opener_denia_A1_recovery']*1000,
                   onset_ms=self.TIMING['opener_denia_A1_start_lead']*1000,
                   pose_confirmed=False)
        return prepared

    def _opener_denia_a2(self):
        """Cover reentry acceptance without waiting for A2's full damage.

        A single immediate click/slot pair can switch away before A2 begins.
        Keep a short onset window and at most one retry for a swallowed input.
        Fresh production can close the window early; absent energy is not an
        unbounded wait while Mornye's airborne window is expiring.
        """
        if (self.cur is not self or self.axis_state().denia_form != 'black'
                or not self._on_field(self)):
            raise AxisFault('Opening resumed A2 requires on-field black Denia')
        baseline = denia_conformal_fill(self.task.frame)
        prepared = self._opener_denia_tap_to('Mornye', 'Denia-opener-resume-A2')
        start = time.monotonic()
        presses = 1
        frames = 0
        level = None
        threshold = max(.09, baseline+.0167) if baseline is not None else .09
        while True:
            self._fast_tick()
            visible, index, _ = self._hud()
            if visible and index != self.index:
                raise AxisFault('Opening resumed A2 lost current character')
            elapsed = time.monotonic()-start
            level = denia_conformal_fill(self.task.frame) if visible else None
            growing = level is not None and level >= threshold
            frames = frames+1 if growing else 0
            confirmed = frames >= self.FRAME_CONFIRM
            if (visible and elapsed >= self.TIMING['opener_denia_A2_min'] and confirmed):
                break
            if elapsed >= self.TIMING['opener_denia_A2_window']:
                if not visible:
                    raise AxisFault('Opening resumed A2 HUD did not return')
                break
            if (visible and not growing and presses == 1
                    and elapsed >= self.TIMING['opener_denia_A2_retry']):
                self._attack(fast=True)
                presses += 1
        self._mark('Denia-opener-A2-handoff', presses=presses,
                   elapsed_ms=round(elapsed*1000), conformal_before=baseline, conformal=level,
                   acknowledgement='new-production' if confirmed else 'bounded-onset-window',
                   pose_confirmed=False)
        return prepared

    def _opener_qing_f_a3(self):
        """Keep A inputs through F, then hand off at its recovery boundary.

        No available pose template identifies A3. After an acknowledged F,
        open a calibrated tail window for A/slot retries; keep A going until
        the engine accepts the switch. Clock resume is an earlier exit when
        observed. Every exit keeps A buffered in the following switch loop;
        a resumed clock need not mean the engine already accepts the slot.
        Missing F remains nonfatal.
        """
        if self.cur.name != 'Qingxiao' or not self._on_field():
            raise AxisFault('Opening F/A3 requires Qingxiao')
        self._release()
        started = time.monotonic()
        wall = time.time()
        context = getattr(self, '_opener_f_buffer', None) or {}
        self._opener_f_buffer = None
        target_seen = bool(context.get('target_seen'))
        epoch = context.get('epoch', self.axis_state().target_epoch)
        evidence = context.get('clock') or ExecutionClockEvidence()
        last_f = context.get('last_f')
        first_f = started if last_f is None else last_f
        last_f = -100.0 if last_f is None else last_f
        last_a = -100.0
        missing = 0
        ack = False
        ack_at = None
        stopped_value = None
        same_since = None
        last_value = None
        resume_frames = 0
        with self._animation_guard():
            while time.monotonic()-started < self.LIMIT['F_animation']:
                visible, index, _ = self._hud()
                if visible and index != self.cur.index:
                    raise AxisFault('Opening F/A3 lost current character')
                now = time.monotonic()
                # Buffer A before recognition work, including during F.
                if now-last_a >= self.FAST_REPEAT:
                    self._attack(fast=True)
                    last_a = now
                if not ack:
                    prompt = self._f_target_prompt() if visible else False
                    target_seen |= prompt
                    missing = missing+1 if visible and target_seen and not prompt else 0
                    clock_ack = evidence.observe(self.task.frame, now, True) if visible else False
                    value = evidence.value if visible else None
                    if missing >= self.FRAME_CONFIRM or clock_ack:
                        ack = True
                        ack_at = now
                        if self.axis_state().target_epoch == epoch:
                            self.axis_state().executed_epoch = epoch
                            self.axis_state().pre_r_f_pending = False
                        self._mark('F-ack', acknowledgement='target-prompt-consumed' if missing >= 2 else 'new-clock-stop',
                                   latency=round(now-started, 3), opening_buffer=True)
                else:
                    # F is already acknowledged. Re-searching its large target
                    # prompt every frame delayed both A inputs and the handoff.
                    value = execution_clock_tenths(self.task.frame) if visible else None
                if value is not None:
                    if last_value != value:
                        same_since = now
                        last_value = value
                    elif same_since is not None and now-same_since >= .25:
                        stopped_value = value
                    resumed = stopped_value is not None and 0 < stopped_value-value <= 3
                    resume_frames = resume_frames+1 if resumed else 0
                if not ack and now-started < self.LIMIT['F_start'] and now-last_f >= self.FAST_REPEAT:
                    self.task.send_key('f', down_time=self.FAST_DOWN)
                    last_f = time.monotonic()
                if ack and resume_frames >= 1:
                    # Use the first positively decoded change after the stable
                    # F clock. A has been buffered throughout; no extra click,
                    # confirmation frame or 40ms tail delays the slot input.
                    self.task.add_freeze_duration(wall, time.time()-wall)
                    self._mark('Qingxiao-opener-F-A3', acknowledgement='first-clock-resume-with-buffered-A',
                               pose_confirmed=False)
                    return True
                if (ack and visible and ack_at is not None and
                        now-first_f >= self.TIMING['opener_f_swap_from_input'] and
                        now-ack_at >= self.TIMING['opener_f_swap_from_ack']):
                    # This is an input window, not proof of an A3 pose. The
                    # following switch loop keeps A BEFORE each slot attempt
                    # while Qing remains current; it stops A on confirmed Denia.
                    self.task.add_freeze_duration(wall, time.time()-wall)
                    self._mark('Qingxiao-opener-F-A3', acknowledgement='F-tail-A-slot-buffer',
                               pose_confirmed=False, since_F_ms=round((now-first_f)*1000),
                               since_ack_ms=round((now-ack_at)*1000))
                    return True
                if not ack and now-started >= self.LIMIT['F_start']:
                    self.task.sleep(self.TIMING['opener_f_A3_lead'])
                    self._mark('Qingxiao-opener-F-skipped', axis='continue', input='A-buffered')
                    return True
                if (ack and stopped_value is None and
                        now-started >= self.TIMING['opener_f_A3_recovery']):
                    self.task.sleep(self.TIMING['opener_f_A3_lead'])
                    self.task.add_freeze_duration(wall, time.time()-wall)
                    self._mark('Qingxiao-opener-F-A3', acknowledgement='clock-unreadable-input-window',
                               pose_confirmed=False)
                    return True
                self._fast_tick()
        # A lost clock/F observation must not terminate the whole rotation.
        self._mark('Qingxiao-opener-F-A3', acknowledgement='bounded-F-observation-fallback',
                   pose_confirmed=False)
        return True

    def _opener_morn_z1_handoff(self, mor):
        """R camera: hold Z1 and retry Qing's slot; F only on confirmed Qing."""
        target = self.teammate('Qingxiao')
        start = time.monotonic()
        last_key = -100.0
        streak = 0
        context = {'target_seen': False, 'epoch': self.axis_state().target_epoch,
                   'last_f': None, 'clock': ExecutionClockEvidence()}
        self._opener_f_buffer = context
        # Before the R camera the authored ordinary switch has no full halo.
        # Refresh if Mornye becomes visible before the slot is accepted.
        con_full = getattr(self, '_opener_morn_r_con', False)
        try:
            if self.cur is not mor or not self._holding:
                raise AxisFault('Opening Mornye Z1 handoff requires R prehold on Mornye')
            self._mark('Mornye-opener-Z1-handoff', acknowledgement='R-camera-input-buffer',
                       hud_hidden=not self._hud()[0], inputs='held-A/slot-Qing',
                       F_gate='confirmed-Qing-foreground')
            while time.monotonic()-start < self.LIMIT['R_animation']+self.LIMIT['switch']:
                visible, index, count = self._hud()
                if visible and index not in (mor.index, target.index):
                    raise AxisFault('Opening Mornye Z1 handoff lost current character')
                if visible and index == target.index:
                    streak += 1
                    if streak >= (1 if count >= 3 else 3):
                        self._release()
                        self._commit_switch(mor, target, con_full, start, streak)
                        # A sent slot key is not an accepted switch. Submit
                        # the first F only at this observed Qing boundary,
                        # with no extra frame, sleep or animation wait.
                        self.task.send_key('f', down_time=self.FAST_DOWN)
                        context['last_f'] = time.monotonic()
                        self._mark('F-input', char=target.name, held_A=False,
                                   acknowledgement='confirmed-Qing-foreground')
                        # Capture F evidence only AFTER its first input. The
                        # camera/slot loop must not spend each tick searching
                        # the combat view for F or decoding a hidden clock.
                        context['target_seen'] = self._f_target_prompt()
                        context['clock'].observe(self.task.frame, time.monotonic(), False)
                        return
                else:
                    streak = 0
                if visible and index == mor.index:
                    con_full = self._full_con(mor)
                now = time.monotonic()
                if now-last_key >= self.TIMING['opener_morn_slot_repeat']:
                    # Retry the slot during R, including a hidden HUD. Never
                    # pair it with F: Mornye may still own the foreground.
                    self.task.send_key(str(target.index+1), down_time=self.FAST_DOWN)
                    last_key = now
                self._fast_tick()
            raise AxisFault('Opening Mornye Z1 -> Qingxiao switch was not confirmed')
        finally:
            self._release()

    def _opener_morn_air_ready(self, mor):
        """Allow the return HUD/state to settle before any recovery A input."""
        self._release()
        start = time.monotonic()
        last_attack = -100.0
        air_since = None
        air_frames = ground_full_frames = 0
        recovering = False
        try:
            while time.monotonic()-start < self.LIMIT['opener_morn_air']:
                visible, index, _ = self._hud()
                if self.cur is not mor or (visible and index != mor.index):
                    raise AxisFault('Opening Mornye air recovery lost current character')
                now = time.monotonic()
                airborne = visible and bool(mor.on_air())
                if airborne:
                    air_since = now if air_since is None else air_since
                    air_frames += 1
                    if air_frames >= self.FRAME_CONFIRM and now-air_since >= .025:
                        self._mark('Mornye-opener-air-ready', recovered=recovering,
                                   wait_ms=round((now-start)*1000))
                        return
                else:
                    air_since = None
                    air_frames = 0
                    if visible and now-start >= self.TIMING['opener_morn_ground_grace']:
                        if not recovering:
                            self._mark('Mornye-opener-air-recovery',
                                       ground_fill=self._morn_fill(mor, False),
                                       action='A-to-static-full-then-Z1', E='withheld')
                            recovering = True
                        if not self._holding:
                            full = self._morn_full(mor, False)
                            ground_full_frames = ground_full_frames+1 if full else 0
                            if ground_full_frames >= self.FRAME_CONFIRM:
                                self._holding = True
                                self.task.mouse_down()
                            elif not full and now-last_attack >= self.FAST_REPEAT:
                                self._attack(fast=True)
                                last_attack = now
                self._fast_tick()
            raise AxisFault('Opening Mornye did not recover airborne state; ground E withheld')
        finally:
            self._release()

    def _opener_morn_e_z2(self, mor):
        """Submit E and Z together on return; observe the result afterwards."""
        self._release()
        if self.cur is not mor or not self._on_field(mor):
            raise AxisFault('Opening Mornye paired E/Z requires current character')
        if mor.has_cd('resonance'):
            raise AxisFault('Opening Mornye E already on cooldown before paired input')
        z_down, e_down, e_up, z_up, backend = self._morn_pair_inputs(mor.get_resonance_key())
        started = time.monotonic()
        last_e = started
        e_confirmed = False
        full_frames = empty_frames = aim_frames = 0
        full_seen = False
        spent_at = aim_at = None
        aim_first_at = None
        spent_confirmed = False
        charge_deadline = None
        c3_ready = self._morn_c3_remaining(mor)[0] == 0
        try:
            mor._resonance_available = False
            self._mouse_release = z_up
            self._holding = True
            try:
                # Adjacent downs: no capture, cooldown poll or sleep in between.
                e_down()
                z_down()
                self.task.sleep(self.FAST_DOWN)
            finally:
                e_up()
            self._mark('Mornye-Z2-input', trigger='opening-E-Z-adjacent', backend=backend)
            while True:
                self._fast_tick()
                visible, index, _ = self._hud()
                if visible and index != mor.index:
                    raise AxisFault('Opening Mornye paired E/Z lost current character')
                now = time.monotonic()
                if now-started >= self.LIMIT['E']+self.LIMIT['mornye_heavy']+self.TIMING['opener_morn_Z2_launch']:
                    raise AxisFault('Opening Mornye E/Z observation deadline exceeded')
                air = visible and bool(mor.on_air())
                if not e_confirmed:
                    if visible and mor.has_cd('resonance'):
                        if not air:
                            raise AxisFault('Opening Mornye E cooldown without confirmed air cast')
                        e_confirmed = True
                        charge_deadline = now+self.LIMIT['mornye_heavy']
                        mor.record_resonance_use()
                        if c3_ready:
                            self._morn_c3_record_e(mor)
                        self._mark('E-CD', char=mor.name, airborne=True, z2_preheld=True,
                                   acknowledgement='opening-paired-air-E')
                    elif now-started >= self.LIMIT['E']:
                        raise AxisFault('Opening Mornye paired E/Z had no new E cooldown')
                    elif visible and now-last_e >= self.FAST_REPEAT:
                        try:
                            c3_ready = self._morn_c3_remaining(mor)[0] == 0
                            e_down()
                            self.task.sleep(self.FAST_DOWN)
                        finally:
                            e_up()
                        last_e = now
                if not e_confirmed or not visible:
                    continue
                if not spent_confirmed:
                    full = air and self._morn_full(mor, True)
                    full_frames = full_frames+1 if full else 0
                    full_seen |= full_frames >= self.FRAME_CONFIRM
                    fill = self._morn_fill(mor, True) if air else None
                    empty = (full_seen and fill is not None and fill <= .08
                             and not mor.is_mouse_forte_full())
                    if empty:
                        spent_at = now if spent_at is None else spent_at
                        empty_frames += 1
                        if empty_frames >= self.FRAME_CONFIRM and now-spent_at >= .025:
                            spent_confirmed = True
                            self._mark('Mornye-opener-Z2-spent', acknowledgement='latched-air-full-spend')
                    else:
                        spent_at = None
                        empty_frames = 0
                # A preheld Z may consume the C3 fill between captures. Require
                # the distinctive aiming overlay instead of guessing from time.
                if aim_at is None:
                    # The aiming icon pulses to white and can disappear into
                    # bloom for a capture. Require two positive observations
                    # in a short window; a single flash still proves nothing.
                    if (aim_first_at is not None and
                            now-aim_first_at > self.TIMING['opener_morn_Z2_aim_window']):
                        aim_first_at = None
                        aim_frames = 0
                    if mornye_z2_aim(self.task.frame):
                        aim_first_at = now if aim_first_at is None else aim_first_at
                        aim_frames += 1
                    if aim_frames >= self.FRAME_CONFIRM:
                        aim_at = now
                        self._mark('Mornye-opener-Z2-aim', acknowledgement='aim-overlay',
                                   evidence_span_ms=round((now-aim_first_at)*1000))
                spend_done = spent_confirmed and now-spent_at >= self.TIMING['opener_morn_Z2_launch']
                aim_done = aim_at is not None and now-aim_at >= self.TIMING['opener_morn_Z2_aim_tail']
                if spend_done or aim_done:
                    mor.last_heavy = time.time()
                    self._mark('Mornye-Z2', acknowledgement='observed-air-full-spend' if spend_done else 'aim-overlay',
                               spend_latched=spent_confirmed, launch_guard='reference-window')
                    return
                if not spent_confirmed and aim_at is None and now >= charge_deadline:
                    raise AxisFault('Opening Mornye Z2 has no observed charge spend or aiming overlay')
        finally:
            self._release()

    def _opener_morn_jump_a(self, mor):
        """Only after confirmed Z2: jump cancel, A, then the ordinary Qing visit."""
        self._release()
        if self.cur is not mor or not self._on_field(mor):
            raise AxisFault('Opening jump/A requires Mornye')
        self.task.send_key(self.task.key_config.get('Jump Key', 'space'), down_time=self.FAST_DOWN)
        self.task.sleep(self.TIMING['opener_morn_jump_A'])
        self._attack(fast=True)
        self._mark('Mornye-opener-jump-A', acknowledgement='input-window-only')

    def _opener_qing_intro_e(self, recovery_origin=None):
        """Intro E while the opening ground E is still on CD.

        The old ground-E CD is neither a reason to wait nor evidence of this
        airborne action. Reuse only the calibrated intro recovery/startup
        budgets; later rounds retain their existing glyph checks unchanged.
        """
        self._release()
        qing = self.cur
        if qing.name != 'Qingxiao' or not qing.has_intro:
            raise AxisFault('Opening intro E requires confirmed Qingxiao intro')
        started = time.monotonic()
        entry = getattr(self, '_qing_entry_at', started)
        if recovery_origin is not None:
            entry = max(entry, recovery_origin)
        recover_at = entry+self.TIMING['qing_air_E_entry_recovery']
        last = -100.0
        while time.monotonic()-started < self.LIMIT['qing_air_E_buffer']:
            visible, index, _ = self._hud()
            if visible and index != qing.index:
                raise AxisFault('Opening intro E lost current character')
            now = time.monotonic()
            if visible and now-last >= self.FAST_REPEAT:
                final = now >= recover_at
                prepared = (qing, self, self._full_con(qing)) if final else None
                qing.send_resonance_key(down_time=self.FAST_DOWN)
                last = now
                if final:
                    self.task.sleep(self.TIMING['qing_air_E_start_lead'])
                    self._mark('Qingxiao-opener-intro-E', acknowledgement='intro-recovery-input-window',
                               ground_CD_ignored=True)
                    return prepared
            self._fast_tick()
        raise AxisFault('Opening intro E never obtained a visible input window')

    def _opener_qing_intro_a_e(self):
        """New opener: hold A through Qing's intro, then overlap E recovery.

        The A boundary is a calibrated input window, not a pose detector.
        E's .90s recovery overlaps this .54s hold rather than adding .90s.
        This airborne E may be used while the opening ground E is on CD.
        """
        if self.cur.name != 'Qingxiao' or not self.cur.has_intro:
            self._release()
            raise AxisFault('Opening Qing A1/E requires a confirmed intro')
        started = time.monotonic()
        held_at = getattr(self, '_qing_entry_at', started) if self._holding else None
        try:
            while time.monotonic()-started < self.LIMIT['qing_air_E_buffer']:
                visible, index, _ = self._hud()
                if visible and index != self.cur.index:
                    raise AxisFault('Opening Qing A1/E lost current character')
                now = time.monotonic()
                if not visible:
                    self._release()
                    held_at = None
                else:
                    if held_at is None:
                        self.task.mouse_down()
                        self._holding = True
                        held_at = now
                        self._mark('Qingxiao-opener-intro-A1', input='hold', pose_confirmed=False)
                    if now-held_at >= self.TIMING['opener_qing_intro_A_onset']:
                        self._mark('Qingxiao-opener-intro-A1-E',
                                   acknowledgement='intro-A-input-window', pose_confirmed=False)
                        break
                self._fast_tick()
            else:
                raise AxisFault('Opening Qing A1/E had no visible A input window')
        finally:
            self._release()
        return self._opener_qing_intro_e(recovery_origin=held_at)

    def _opener_denia_e1_to_qing(self):
        """After the resumed A3/A4, send only E1 and hand off to Qing.

        E1 briefly shows cooldown digits before the follow-up E2 glyph. Either
        a new CD or two fresh E2-glyph frames acknowledge the first E. Pause
        E repeats at the first glyph candidate so they cannot consume E2 here.
        """
        self._opener_e1_confirmed = False
        self._release()
        if self.cur is not self or self.axis_state().denia_form != 'black' or not self._on_field(self):
            raise AxisFault('Opening split E1 requires on-field black Denia')
        if self.has_cd('resonance'):
            raise AxisFault('Opening split E1 started with an existing E cooldown')
        # This glyph also appears briefly during an earlier black-form normal.
        # An unchanged entry glyph cannot acknowledge the E we are about to send.
        followup_armed = not denia_followup_e_visible(self.task.frame)
        started = time.monotonic()
        last = -100.0
        followup_frames = 0
        presses = 0
        while time.monotonic()-started < self.LIMIT['E']:
            visible, index, _ = self._hud()
            if visible and index != self.index:
                raise AxisFault('Opening split E1 lost current character')
            now = time.monotonic()
            if visible and not followup_frames and now-last >= self.FAST_REPEAT:
                self.send_resonance_key(down_time=self.FAST_DOWN)
                last = now
                presses += 1
            self._fast_tick()
            visible, index, _ = self._hud()
            if visible and index != self.index:
                raise AxisFault('Opening split E1 lost current character')
            on_field = visible and index == self.index
            cd = on_field and presses > 0 and self.has_cd('resonance')
            glyph = on_field and denia_followup_e_visible(self.task.frame)
            if on_field and not glyph:
                followup_armed = True
            followup = followup_armed and presses > 0 and glyph
            followup_frames = followup_frames+1 if followup else 0
            if cd or followup_frames >= self.FRAME_CONFIRM:
                self._opener_e1_confirmed = True
                self.record_resonance_use()
                self._mark('Denia-opener-E1', acknowledgement='new-CD' if cd else 'follow-up-E2-glyph',
                           presses=presses, next='Qingxiao-A3A4')
                self._switch('Qingxiao', echo=False)
                return
        raise AxisFault('Opening split E1 had no new CD or follow-up E2 glyph')

    def _opener_qing_resume_a34(self):
        """Resume A3/A4; hand off on A4 onset without waiting for damage."""
        self._release()
        if self.cur.name != 'Qingxiao' or not self._on_field():
            raise AxisFault('Opening resumed A3/A4 requires Qingxiao')
        self._qing_wait_a4('Qingxiao-opener-split-A34', attack=True,
                          onset_confirm=self.TIMING['qing_outro_A4_confirm'], allow_enhanced=True)

    def _opener(self):
        self._opener_e1_confirmed = False
        mor = self.teammate('Mornye')
        self._switch('Qingxiao')
        self._opener_qing_e()
        self._switch('Mornye')
        self._morn_normals(mor, 'Mornye-A12', self.TIMING['mornye_A12'], target=.58, growth=True)
        self._switch_denia_r1(source_name='Mornye')
        prepared = self._opener_denia_a1()
        self._switch('Qingxiao', prepared=prepared, echo=False)
        self._normal_to_swap('Qingxiao-opener-E-derived-A4')
        # This entry can still be recovering when the single A4 is submitted.
        # Give its onset a small lead before the slot; do not wait for damage
        # or circuit gain. This precedes Mornye R/Z1's airborne window.
        self.task.sleep(self.TIMING['opener_qing_A4_start_lead'])
        self._mark('Qingxiao-opener-A4-handoff',
                   onset_ms=self.TIMING['opener_qing_A4_start_lead']*1000,
                   acknowledgement='input-onset-window', pose_confirmed=False)
        self._switch('Mornye')
        self._morn_normals(mor, 'Mornye-resume-A3', self.TIMING['mornye_A3'], target=1, growth=True)
        self._opener_morn_r_con = self._full_con(mor)
        self._cast_r(prehold=True, buffer_onset=True, opening_handoff=True)
        # Z1 and E/Z2 are deliberately split by Qing F/A3 and Denia A2.
        buffer_f_tail = self._opener_qing_f_a3()
        self._switch('Denia', attack_while_waiting=bool(buffer_f_tail), echo=False)
        prepared = self._opener_denia_a2()
        self._switch('Mornye', prepared=prepared, echo=False)
        self._opener_morn_e_z2(mor)
        # The user's weapon fills Mornye concerto at EZ. This is an observed
        # intro, not the old jump/A -> ordinary Qing A4 -> Mornye A3 route.
        self._switch('Qingxiao', intro=True, prehold=True, echo=False)
        prepared = self._opener_qing_intro_a_e()
        self._switch('Denia', prepared=prepared, echo=False)
        # Denia already performed A1 and A2 in the opening cross-character
        # sequence. These two resumed normals are A3/A4 before the first E.
        self._denia_resume_a34(cancel_into_e=True)
        self._opener_denia_e1_to_qing()
        self._opener_qing_resume_a34()
        self._switch('Denia', echo=False)
        self._denia_e_r_buffer(split_e1=True)
        self._denia_outro(echo=False)
        self._qing_burst(first=True)

    def _qing_echo_relay(self):
        """Mornye EZ -> ordinary Qingxiao Q visit -> Denia's original plunge.

        No A/E or concerto filling on this visit. Add only 20ms on either side
        of a new Q. Preserve the actual-CD gate and immediate already-CD skip;
        these small guards do not wait for Q's animation or damage.
        """
        self._switch('Qingxiao')
        qing = self.cur
        prepared = (qing, self.teammate('Denia'), self._full_con(qing))
        entry_guard = 0 if qing.has_cd('echo') else self.TIMING['qing_relay_Q_entry']
        if entry_guard:
            self.task.sleep(entry_guard)
        echo = self._buffer_outro_echo(qing)
        if echo.get('ack') == 'new-CD':
            self.task.sleep(self.TIMING['qing_relay_Q_exit'])
        # No resource read/log between the short exit guard and the slot key.
        self._switch('Denia', prepared=prepared)
        if echo.get('ack') == 'new-CD':
            qing.record_echo_use()
        self._mark('Qingxiao-EZ-relay-Q', presses=echo['presses'],
                   acknowledgement=echo['ack'], wait_ms=echo['wait_ms'],
                   handoff='Denia-plunge',
                   entry_guard_ms=entry_guard*1000,
                   exit_guard_ms=self.TIMING['qing_relay_Q_exit']*1000 if echo.get('ack')=='new-CD' else 0)

    def _supports(self, second=False):
        mor = self.teammate('Mornye')
        state = self.axis_state()
        if state.loop_intro_ready:
            visible, index, _ = self._hud()
            if (second or self.cur is not mor or not mor.has_intro or
                    (visible and index != mor.index)):
                raise AxisFault('Pending loop entry requires the confirmed Mornye intro')
            # A transiently hidden intro HUD is not a manual field change.
            self._hud_back()
            state.loop_intro_ready = False
        else:
            self._switch('Mornye', intro=True)
        self._morn_air_ez(mor, second=second)
        if second:
            self._switch('Denia')
        else:
            self._qing_echo_relay()
        self._denia_prepare(second=second)
        self._switch('Qingxiao')
        # Per the authored route, Qing's switch-in supplies A1 automatically.
        # Do not add A, Q, or an action tail that could cancel/delay it.
        self._switch('Mornye')
        self._cast_r()
        self._switch('Qingxiao', intro=True)
        handoff = self._qing_entry_e(buffer_intro=True)
        self._switch('Denia', prepared=handoff)
        self._cast_r(form='R2')
        self._denia_outro()
        self._qing_burst(second=second)

    def _qing_second_a1_dodge(self):
        self._release()
        if self.cur.name != 'Qingxiao':
            raise AxisFault('Second-round A1/dodge requires Qingxiao')
        self._hud_back()
        baseline = qing_circuit_lit(self.task.frame)
        if baseline is None:
            raise AxisFault('Qingxiao A1 circuit framing is unsupported')
        start = time.monotonic()
        last_attack = -100.0
        grown = 0
        self._mark('Qingxiao-second-A1-input', circuit_before=baseline)
        while time.monotonic() - start < self.LIMIT['qing_A1_growth']:
            now = time.monotonic()
            if grown == 0 and now-last_attack >= self.A_INTERVAL and self._on_field():
                self._attack()
                last_attack = now
            self._fast_tick()
            level = qing_circuit_lit(self.task.frame) if self._on_field() else None
            grown = grown + 1 if level is not None and level >= baseline + 1 else 0
            if grown >= 2:
                # Two fresh frames show growth AFTER A input. Dodge at that
                # boundary, not at the old fixed .12s input deadline.
                self.task.click(key='right', down_time=self.KEY_DOWN)
                self._mark('Qingxiao-second-A1-dodge', circuit_before=baseline,
                           circuit_after=level, acknowledgement='circuit-growth',
                           elapsed=round(time.monotonic()-start, 3))
                return
        raise AxisFault('Qingxiao A1 circuit growth was not observed before dodge')

    def _qing_wait_a4(self, tag, attack=False, growth=False, cap=None, onset_confirm=0,
                      allow_enhanced=False):
        """A3 air-E glyph -> restored ground E marks the A4 handoff boundary.

        This is a HUD state proxy observed alongside A4's onset in the supplied
        video, not an arm-pose model. No elapsed input window counts as success.
        Before F, require sustained new green growth beyond the recent A3
        plateau. A saturated bar instead needs a stable full reading after
        confirmed A4 onset; it cannot produce an extra sample cell.
        """
        started = time.monotonic()
        if cap is None:
            cap = self.LIMIT['qing_A4_start'] + (self.LIMIT['F_animation'] if attack else 0)
        air_frames = ground_frames = grown = 0
        ground_since = None
        air_seen = False
        boundary = False
        baseline = previous = None
        grown_since = full_since = lower_since = None
        lower_level = None
        lower_frames = full_frames = 0
        hidden_since = None
        last = -100.0
        try:
            while time.monotonic()-started < cap:
                now = time.monotonic()
                if attack and now-last >= self.FAST_REPEAT:
                    self._attack(fast=True)
                    if last < 0:
                        self._mark(tag, input='buffered-clicks', acknowledgement='pending-A4-state')
                    last = now
                if self._on_field():
                    if hidden_since is not None:
                        self.task.add_freeze_duration(hidden_since, time.time()-hidden_since)
                        hidden_since = None
                    level = qing_circuit_lit(self.task.frame) if growth else None
                    if growth and not boundary:
                        # Use the latest consistent pair, not a lifetime peak.
                        # The 13:46 recording briefly paints the entire bar
                        # green, then returns to 9 cells before A4 starts.
                        if (level is not None and previous is not None
                                and abs(previous-level) <= 1):
                            baseline = max(previous, level)
                        previous = level
                    icon = qing_e_icon(self.task.frame)
                    air_frames = air_frames+1 if icon == 'air-a3' else 0
                    if air_frames >= 2 and not air_seen:
                        air_seen = True
                        self._mark(tag+'-A3-state', acknowledgement='air-E-glyph')
                    ground = air_seen and icon != 'air-a3' and (
                        icon == 'ground' or self.cur.has_cd('resonance') or
                        (allow_enhanced and self.cur.enhanced_resonance_available()))
                    ground_frames = ground_frames+1 if ground else 0
                    ground_since = (ground_since if ground_since is not None else now) if ground else None
                    if (not boundary and ground_frames >= 2 and ground_since is not None
                            and now-ground_since >= onset_confirm):
                        boundary = True
                        self._mark(tag+'-A4-onset', acknowledgement='air-E-to-ground-E',
                                   circuit_before=baseline)
                    if boundary and not growth:
                        return
                    # If the flash straddled A4 onset, recover the baseline
                    # only after a sustained lower plateau. A single dark
                    # frame must not manufacture a subsequent "increase".
                    lower = (boundary and level is not None
                             and (baseline is None or level < baseline))
                    if lower:
                        if lower_level is None or abs(level-lower_level) > 1:
                            lower_since, lower_frames = now, 0
                            lower_level = level
                        lower_frames += 1
                        lower_level = max(lower_level, level)
                        if (lower_frames >= 3 and
                                now-lower_since >= self.TIMING['qing_A4_baseline_recover']):
                            self._mark(tag+'-A4-baseline-recovered', circuit_before=baseline,
                                       circuit_after=lower_level)
                            baseline = lower_level
                            lower_since = lower_level = None
                            lower_frames = 0
                    else:
                        lower_since = lower_level = None
                        lower_frames = 0
                    increasing = (boundary and ground and baseline is not None and baseline < 19
                                  and level is not None and level >= baseline+1)
                    grown = grown+1 if increasing else 0
                    grown_since = (grown_since if grown_since is not None else now) if increasing else None
                    if (grown >= 3 and grown_since is not None and
                            now-grown_since >= self.TIMING['qing_A4_growth_confirm']):
                        self._mark(tag+'-A4-growth', circuit_before=baseline, circuit_after=level)
                        return
                    # A full visible bar occupies 19 or 20 of the sampled
                    # cells (the outer cell varies with resolution). This
                    # branch still needs A3->A4 and a post-onset full hold;
                    # full concerto/resource alone never proves an A4.
                    full = (boundary and ground and baseline is not None and baseline >= 19
                            and level is not None and level >= 19)
                    full_frames = full_frames+1 if full else 0
                    full_since = (full_since if full_since is not None else now) if full else None
                    if (full_frames >= 3 and full_since is not None and
                            now-full_since >= self.TIMING['qing_A4_full_confirm']):
                        self._mark(tag+'-A4-saturated', circuit_before=baseline, circuit_after=level,
                                   acknowledgement='A4-onset-and-stable-full-circuit')
                        return
                else:
                    air_frames = ground_frames = grown = 0
                    ground_since = None
                    previous = None
                    grown_since = full_since = lower_since = lower_level = None
                    lower_frames = full_frames = 0
                    if hidden_since is None:
                        hidden_since = time.time()
                self._fast_tick()
            raise AxisFault(tag+': A4 '+('circuit growth' if growth else 'onset state')+' not observed')
        finally:
            if hidden_since is not None:
                self.task.add_freeze_duration(hidden_since, time.time()-hidden_since)

    def _qing_tail_normals(self, preheld=False, e_started=None):
        """After ground E, hold its derived A4 and then a full A1234.

        E's derived A4 has no air-A3 glyph. The following full chain's
        A3->A4 transition is the handoff, not full concerto or circuit alone.
        Preserve the immediate Mornye outro at that last A4 onset.
        """
        if not preheld:
            self._release()
        elif not self._holding:
            raise AxisFault('Qingxiao post-R E must retain its continuous A hold')
        if self.cur.name != 'Qingxiao':
            raise AxisFault('Qingxiao post-R 4A requires Qingxiao on field')
        if e_started is not None and (not preheld or e_started is not self.cur):
            raise AxisFault('Qingxiao tail E evidence does not match the held recovery')
        self._hud_back()
        # The post-R buffer has already observed clear -> input -> new CD.
        # Re-reading OCR here can lose one transient digit frame and abort
        # 37 ms after accepting E (0.1.46 recording). Carry that local proof
        # through this handoff, without a new wait, E press or A release.
        # Direct callers without that proof still require a current cooldown.
        if e_started is None and not self.cur.has_cd('resonance'):
            raise AxisFault('Qingxiao tail requires a confirmed ground E cooldown')
        try:
            if not self._holding:
                self._holding = True
                self.task.mouse_down()
            self._mark('Qingxiao-tail-A4-4A', input='continuous-hold',
                       acknowledgement='pending-final-A4-state', E='restored',
                       E_ack='buffered-new-CD' if e_started is not None else 'current-CD')
            self._qing_wait_a4('Qingxiao-tail-4A', cap=self.LIMIT['qing_tail_A4'],
                               onset_confirm=self.TIMING['qing_outro_A4_confirm'])
            # Release before the slot key so we cannot queue a second A1.
            # Qingxiao has no outro Q; A4 may finish off field. Never inject
            # extra normals here to fill concerto and interrupt that A4.
            self._release()
            self._switch('Mornye', intro=True, fill=False)
            self.axis_state().loop_intro_ready = True
            self._mark('Qingxiao-tail-complete', acknowledgement='derived-A4-then-full-4A-outro', E='restored')
        finally:
            self._release()

    def _qing_second_after_f_a34(self, f_started):
        acknowledged = time.time()
        try:
            # Q is disabled, so A4 can finish off field. Only debounce the
            # E-state transition: a two-frame A3 glyph dropout in 0.1.29's
            # recording must not become a premature A4/swap acknowledgement.
            # The 0.2 opener spends ground E earlier; its CD can finish during
            # this F. A4 then restores enhanced E, not the normal ground glyph.
            self._qing_wait_a4('Qingxiao-second-A34', attack=True,
                               onset_confirm=self.TIMING['qing_outro_A4_confirm'], allow_enhanced=True)
        finally:
            self.task.add_freeze_duration(f_started, acknowledged-f_started)

    def _qing_second_hold4a(self):
        """Hold through A4's new green growth, then check F once at that boundary."""
        self._release()
        if self.cur.name != 'Qingxiao':
            raise AxisFault('Second-round held 4A requires Qingxiao')
        self._hud_back()
        try:
            self._holding = True
            self.task.mouse_down()
            self._mark('Qingxiao-second-4A', input='continuous-hold',
                       acknowledgement='pending-A4-growth')
            self._qing_wait_a4('Qingxiao-second-4A', growth=True, allow_enhanced=True)
            # Do not poll for a future prompt, or run F-dependent A34 if the
            # prompt is absent. Keep the hold through an actual F attempt.
            if not self._on_field() or not self._f_prompt():
                self._mark('Qingxiao-second-prep-F-skipped', reason='no-prompt')
                return False
            f_started = time.time()
            if not self._execute(prompt_confirmed=True, hold_until_ack=True, start_cap=2.2,
                                 on_ack=lambda: self._qing_second_after_f_a34(f_started),
                                 handoff='buffered-A34'):
                self._mark('Qingxiao-second-prep-F-skipped', reason='not-confirmed')
                return False
            self._mark('Qingxiao-second-prep-F', acknowledgement='confirmed')
            return True
        finally:
            self._release()

    def _second(self):
        state = self.axis_state()
        if state.second_a1_ready:
            if self.cur.name != 'Qingxiao' or not self._on_field():
                raise AxisFault('Buffered second-round A1/dodge requires Qingxiao')
            state.second_a1_ready = False
            self._mark('Qingxiao-second-A1-consumed', source='opener-R-recovery')
        else:
            self._qing_second_a1_dodge()
        self._qing_second_hold4a()
        # No-F branch goes directly to the observed full-concerto handoff;
        # it neither waits for F nor pretends that a normal swap is an intro.
        self._supports(second=True)

    def _loop(self):
        self._supports(second=False)

    def _reconcile(self):
        visible, index, _ = self._hud()
        if not visible:
            return
        for char in self.task.chars:
            if char:
                char.is_current_char = char.index == index
                if char.is_current_char:
                    self.cur = char

    def run_axis(self, entry):
        state = self.axis_state()
        if state.busy:
            raise AxisFault('reentrant coordinator call')
        if not self.qdm_team or state.failed:
            return
        self.cur = entry
        self._holding = False
        self._phase_start = time.monotonic()
        saved_flags = [(c, c.check_f_on_switch) for c in self.task.chars if c]
        state.busy = True
        completed = False
        deferred = False
        try:
            for char, _ in saved_flags:
                char.check_f_on_switch = False
            if not getattr(self.task, 'use_liberation', True):
                raise AxisFault('this axis requires Use Liberation')
            self._mark('phase-start')
            if state.burst_resume is not None:
                if entry.name!='Qingxiao':
                    raise AxisFault('Pending Qingxiao R requires Qingxiao on field')
                first,second=state.burst_resume
                self._qing_finish_burst(first=first,second=second)
                state.phase='second' if first else 'loop'
            elif state.phase == 'opener':
                self._opener()
                state.phase = 'second'
            else:
                # The post-R tail now commits its Mornye outro immediately.
                # Only that observed handoff authorizes a Mornye loop entry.
                expected = 'Mornye' if state.phase == 'loop' and state.loop_intro_ready else 'Qingxiao'
                if entry.name != expected:
                    raise AxisFault(f'phase boundary requires {expected} on field')
                if state.phase == 'second':
                    self._second()
                else:
                    self._loop()
                state.phase = 'loop'
            state.round += 1
            completed = True
            self._mark('phase-complete')
        except AxisDeferred as exc:
            deferred=True
            self._mark('axis-deferred', reason=str(exc), resume='Qingxiao-pre-R', failed=False)
        except AxisFault as exc:
            state.failed = True
            self._mark('axis-aborted', reason=str(exc))
            self.logger.warning(f'QDM: {exc}; native rotation for the rest of this battle')
            self._reconcile()
        finally:
            # A cancellation/foreign exception may stop in the middle of a
            # segment. Resuming that phase would re-run already spent resources.
            if not completed and not deferred:
                state.failed = True
            try:
                self._release()
            finally:
                for char, flag in saved_flags:
                    char.check_f_on_switch = flag
                state.busy = False
