from src.char.BaseChar import SwitchPriority
from src.char.Qingxiao import Qingxiao as NativeQingxiao


class Qingxiao(NativeQingxiao):
    qdm_package = 'qdm-c3-full-cycle-v1'

    def coordinator(self):
        for char in self.task.chars:
            if char and callable(getattr(char, 'run_axis', None)) and char.qdm_team:
                return char
        return None

    def do_perform(self):
        axis = self.coordinator()
        if axis is not None and not axis.axis_state().failed:
            return axis.run_axis(self)
        return super().do_perform()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        axis = self.coordinator()
        if axis is not None and not axis.axis_state().failed:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        axis = self.coordinator()
        if axis is not None:
            axis.reset_axis()
