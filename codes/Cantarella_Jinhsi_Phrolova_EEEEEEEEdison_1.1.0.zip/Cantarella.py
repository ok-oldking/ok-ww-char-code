"""ok-ww workshop axis code: Cantarella / Jinhsi / Phrolova, 25 s advanced axis (Cantarella)."""
import logging
import time

import numpy as np
from src.char.BaseChar import BaseChar, SwitchPriority

# ---------------- 模块级日志部件（三个文件各带一份，内容保持一致） ----------------
_RATIO_FIELDS = ('con', 'res_pct', 'ring', 'ring_min', 'outer', 'inner', 'arms', 'miss_inner', 'miss_arms')
_FILTERED_SWITCH_LINES = (
    'BaseCombatTask:switch selection result',
    'BaseCombatTask:switch_next_char end',
)


def _fmt_value(key, v):
    if isinstance(v, float):
        return f'{v:.3f}' if key in _RATIO_FIELDS else f'{v:.2f}'
    return str(v)


class _InfoAsDebug:
    """Per-instance logger: framework info lines become debug; everything else passes through."""

    def __init__(self, inner):
        self._inner = inner

    def info(self, message):
        self._inner.debug(message)

    def __getattr__(self, name):
        return getattr(self._inner, name)


class _AxisSwitchFilter(logging.Filter):
    """Drops the task-level switch info lines while the running task's team has an axis char."""

    okww_axis_switch_filter = True

    def __init__(self, executor):
        super().__init__()
        self._executor = executor

    def filter(self, record):
        try:
            if record.levelno != logging.INFO or not record.getMessage().startswith(_FILTERED_SWITCH_LINES):
                return True
            chars = getattr(self._executor.current_task, 'chars', None) or []
            return not any(getattr(char, '_axis_char', False) for char in chars)
        except Exception:
            return True


def _install_axis_switch_filter(task):
    try:
        ok_logger = logging.getLogger('ok')
        if not any(getattr(f, 'okww_axis_switch_filter', False) for f in ok_logger.filters):
            ok_logger.addFilter(_AxisSwitchFilter(task.executor))
    except Exception:
        pass


class Cantarella(BaseChar):
    """Workshop axis team Cantarella / Jinhsi / Phrolova, 25 s advanced axis: Cantarella opens the startup axis.

    Node comments: axis row, axis text, video interval (s) and the timeline.json node id.
    """

    E_TIMEOUT = 1.5  # 普通 E 到出冷却数字的上限，卡坎 56
    OPEN_R_WAIT = 3.0  # 开局等 R 就绪的上限，Cantarella.f1#1
    WET_HOLD_MAX = 2.1  # 按住普攻进湿身的上限，卡坎 42
    WET_OUTLINE_GONE = 0.1  # 鼠标外框连续消失 0.1 s 判进湿身，卡坎 42
    VORTEX_WAIT = 3.0  # 等粉圈图标的上限，卡坎 52；湿身后点普攻到出粉圈实测 1.42–2.42 s，v2.0.5 有 1 次超过 2.5 s（I37）
    VORTEX_PAUSE = 0.3  # 粉圈E按下后停 0.3 s 再按水母E，卡坎 53
    VORTEX_KNOWN_WET = 7.0  # 上一节点已认到粉圈、湿身后不超过 7.0 s：入场即按粉圈E；实测 5.38–6.75 s 为粉圈，9.95 s 已变伞（I47）
    JELLY_WAIT = 2.5  # 水母E补按到出冷却数字的上限，Cantarella.f3#1；实测 1.23–1.92 s
    INTRO_LOCK = 1.5  # 变奏入场时粉圈E 等锁定期结束才放出，v2.0.5 实测晚约 1.3 s；水母E 上限按此延长（I35）
    FINALE_ECHO_READY = 1.0  # 第 13 行等 Q 就绪的上限：入场时切人过渡帧上 Q 格可能还是今汐的冷却（I49）
    FINALE_R_WAIT = 6.0  # 第 13 行等 R 冷却的上限，期间点普攻，Cantarella.f4#1、I6
    R_GATE = 12.5  # 进湿身前等 R 冷却剩余降到 12.5 s，I22
    R_GATE_MAX = 4.0  # 上述等待的上限，I22
    R_GATE_READ = 0.3  # 读 R 冷却数字的上限，I22

    _axis_char = True
    _in_force_switch = False  # 强切期间为真，见 liberation_available（I46）、get_current_con（I48）

    # A property, not an __init__ assignment: CharFactory copies the built-in instance's __dict__
    # over this one on team load, and a data descriptor wins over the instance __dict__.
    @property
    def logger(self):
        return self._quiet_logger

    @logger.setter
    def logger(self, value):
        self._raw_logger = value
        self._quiet_logger = _InfoAsDebug(value)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _install_axis_switch_filter(self.task)
        self._force_switch_me = False
        self._entry_mode = None
        self._node = None
        self.started = False
        self._startup_done = False
        self._reset_char_state()

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None
        self._reset_char_state()

    # ---------------- 强切协议（队里每个类都带同一份） ----------------
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        # Workshop classes are loaded standalone, so isinstance() against src.char.* never matches.
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode):
        if target is None:
            self._raw_logger.warning(f'[{self._node.upper()}] fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        self._in_force_switch = True
        try:
            return self.switch_next_char()
        finally:
            self._in_force_switch = False
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    def liberation_available(self, check_color=True):
        # I46：BaseChar.switch_next_char 切人前读一次 R，只缓存给框架选人；强切用不上，有冷却数字时这次读要 OCR，约 0.13 s
        if self._in_force_switch:
            return False
        return super().liberation_available(check_color=check_color)

    def get_current_con(self):
        # I48：框架切人前读到 0.8–1 会停 0.05 s 再读一次，约 0.1 s；强切目标已定，切人循环里仍用 is_con_full 补认变奏
        con = super().get_current_con()
        if self._in_force_switch and 0.8 < con < 1:
            return 0.8
        return con

    # ---------------- 分发器 ----------------
    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        if mode is None:
            if not self.started:
                mode = 'f1'
            elif self._startup_done:
                mode = 's1'
            else:
                self._trace(None, 'interrupt', reason='startup_in_progress', next='framework')
                return self.switch_next_char()
            entry = 'intro' if self.has_intro else 'natural'
        else:
            entry = 'forced'
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, f'perform_{mode}', None)
        if func is None:
            self._trace(mode, 'interrupt', reason='unknown_mode', next='framework')
            return self.switch_next_char()
        self._node = mode
        self._trace(mode, 'enter', mode=entry)
        return func()

    # ---------------- 日志 ----------------
    def _trace(self, tag, event, ok=None, reason=None, **data):
        """Write one template line: [TAG] event[: ok|fail] [reason=code] [key=value ...]."""
        try:
            line = f'[{tag.upper()}] {event}' if tag else event
            if ok is not None:
                line += ': ok' if ok else ': fail'
            if reason:
                line += f' reason={reason}'
            for key, value in data.items():
                line += f' {key}={_fmt_value(key, value)}'
            self._raw_logger.info(line)
        except Exception:
            pass

    # ---------------- 共用动作 helper（三个文件各带一份，内容保持一致） ----------------
    def _cast_echo(self, tag, ready_timeout=0.0):
        """Q: optionally wait briefly for ready (I13), then click_echo; ok means the Q cooldown showed up."""
        ready = self.echo_available()
        if not ready and ready_timeout > 0:
            ready = bool(self.task.wait_until(self.echo_available, time_out=ready_timeout))
        if not ready:
            self._trace(tag, 'cast echo', ok=False, reason='not_ready')
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_echo')
            return False
        start = time.time()
        # Loop mode: presses every 0.1 s until echo_available() turns False, i.e. the cooldown digits appear.
        ok = self.click_echo(time_out=1)
        self._trace(tag, 'cast echo', ok=ok, reason=None if ok else 'icon_still_lit', cd_s=time.time() - start)
        if not ok:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_echo')
        return ok

    def _cast_r(self, tag, ready_timeout, attack=False, click_f=True, confirm=False):
        """R: wait for ready (normal attacks only where the model allows), cast, wait the animation out.

        A press without animation waits again within ready_timeout: a one-frame cooldown OCR miss
        reads as ready while R still has about 1.5 s of cooldown (I38).
        confirm: press only if the next frame still reads ready (I58).
        """
        start = time.time()
        while True:
            ready = self.liberation_available()
            remaining = ready_timeout - (time.time() - start)
            if not ready and remaining > 0:
                if remaining >= 2:
                    self._trace(tag, 'wait: r_ready', timeout=remaining)
                ready = bool(self.task.wait_until(self.liberation_available, time_out=remaining,
                                                  pre_action=self.check_combat,
                                                  post_action=self.click_with_interval if attack else None))
            ready_s = time.time() - start
            if not ready:
                self._trace(tag, 'cast R', ok=False, reason='not_ready', ready_s=ready_s)
                break
            if confirm:
                # I58：冷却数字漏读的那一帧 R 读成就绪；下一帧仍就绪才按，否则回到上面重等
                self.task.next_frame()
                if not self.liberation_available():
                    continue
            ok = self.click_liberation(click_f=click_f) or self._finish_late_liberation(tag)
            self._trace(tag, 'cast R', ok=ok, reason=None if ok else 'no_animation', ready_s=ready_s)
            if ok:
                return True
            if time.time() - start >= ready_timeout:
                break
        self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_r')
        return False

    def _finish_late_liberation(self, tag):
        """click_liberation gives the animation 0.4 s to start; finish a later one here.

        R lit again means the press was refused: return at once so _cast_r presses again (I38).
        """
        state = self.task.wait_until(
            lambda: 'animation' if not self.task.in_team()[0] else 'lit' if self.liberation_available() else None,
            time_out=0.6)
        if state != 'animation':
            return False
        self._wait_animation_end(tag)
        self.record_liberation_use()
        return True

    def _wait_animation_end(self, tag):
        """HUD hidden by an animation: keep combat checks quiet, wait for the team HUD, book the freeze."""
        start = time.time()
        self.task.in_liberation = True
        try:
            self._trace(tag, 'wait: hud_back', timeout=7.0)
            back = self.task.wait_until(lambda: self.task.in_team()[0], time_out=7.0, settle_time=0.1,
                                        pre_action=self.check_combat)
        finally:
            self.task.in_liberation = False
        self.add_freeze_duration(start)
        return bool(back)

    # ---------------- 坎特蕾拉：状态与击破 ----------------
    def _reset_char_state(self):
        self._wet_time = -1  # 最近一次确认进湿身的时刻，供 I47 使用
        self._vortex_seen = False  # 湿身节点已认到粉圈图标，下一个 [EE] 节点用后清除（I47）

    def f_break(self, check_f_on_switch=False, force=False):
        # D15：切人时坎特蕾拉不按 F；处决只在 QR↓ 的 Q 后、R 前（_try_break，I34）
        return False

    def _try_break(self, tag):
        """Execution: one check after Q; press F while the break prompt shows (same spot as the baseline code)."""
        # 框架 f_break 至少按 0.5 s F 和普攻，提示不消失最多 5 s；处决演出全局时停
        if not self.task.check_f_break():
            self._trace(tag, 'decide: no_break')
            return
        self._trace(tag, 'decide: break')
        start = time.time()
        self.task.f_break()
        self._trace(tag, 'send F', done_s=time.time() - start)

    # ---------------- 节点：f = 启动轴，s = 循环轴（薄包装，最后一句保持字面写法） ----------------
    def perform_f1(self):
        # 启动第 1 行 坎 ER；视频 104.6–109.7；Cantarella.f1
        self._action_open('f1', 'Phrolova.f1')
        self._force_switch_to(self._find_teammate('Phrolova'), 'f1')

    def perform_f2(self):
        # 启动第 8 行 坎 ZAAA（变奏入场）；视频 126.6–131.2；Cantarella.f2
        self._action_wet('f2', 'Phrolova.f4')
        self._force_switch_to(self._find_teammate('Phrolova'), 'f4')

    def perform_f3(self):
        # 启动第 11 行 坎 [EE]；视频 137.3–139.5；Cantarella.f3
        self._action_vortex('f3', 'Jinhsi.f5')
        self._force_switch_to(self._find_teammate('Jinhsi'), 'f5')

    def perform_f4(self):
        # 启动第 13 行 坎 QR↓；视频 141.1–147.8；Cantarella.f4
        self._action_finale('f4', 'Jinhsi.f6', confirm_r=True)  # I58：R 读错集中在开局这一处；C.s3 在 20 局中只有 1 次，晚约 0.1 s，不加确认
        self._force_switch_to(self._find_teammate('Jinhsi'), 'f6')

    def perform_s1(self):
        # 循环第 7 行 坎 ZAAA（变奏入场）；视频 170.5–174.4；Cantarella.s1
        self._action_wet('s1', 'Phrolova.s4')
        self._force_switch_to(self._find_teammate('Phrolova'), 's4')

    def perform_s2(self):
        # 循环第 10 行 坎 [EE]；视频 180.8–182.6；Cantarella.s2
        self._action_vortex('s2', 'Jinhsi.s5')
        self._force_switch_to(self._find_teammate('Jinhsi'), 's5')

    def perform_s3(self):
        # 循环第 12 行 坎 QR↓；视频 184.2 起；Cantarella.s3
        self._action_finale('s3', 'Jinhsi.s6')
        self._force_switch_to(self._find_teammate('Jinhsi'), 's6')

    # ---------------- 坎特蕾拉：动作体 ----------------
    def _action_open(self, tag, nxt):
        # E：普通 E（伞），出冷却数字即完成（卡坎 56）；R：不按 F（D15）
        start = time.time()
        ok = self.click_resonance(send_click=False, time_out=self.E_TIMEOUT)[0] and not self.resonance_available()
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'timeout', skill='umbrella',
                    cd_s=time.time() - start)
        if not ok:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_e')
        self._cast_r(tag, self.OPEN_R_WAIT, attack=False, click_f=False)
        self._trace(tag, 'exit', next=nxt)

    def _action_wet(self, tag, nxt):
        # 进湿身前对齐 R 冷却：第 10 行今汐 E2 起算的凌霄要覆盖到第 14 行 E4（I22）
        self._wait_r_gate(tag)
        # Z：按住普攻进湿身即松手，防止结晶提前满（卡坎 11、42）
        wet = self._hold_into_wet(tag)
        release = time.time()
        if not wet:
            # 外框判据会漏判：v2.0.3 两次超时前 E 格已变水母（I29）。照常点普攻，出粉圈即说明进过湿身
            self._raw_logger.warning(f'[{tag.upper()}] fallback: attack_without_wet')
        # A×3：点普攻到 E 格出现粉圈漩涡，出现即停，不放水母E、粉圈E（卡坎 10、51–52）
        start = time.time()
        self._trace(tag, 'wait: vortex', timeout=self.VORTEX_WAIT)
        icon = self._wait_e_icon(self.VORTEX_WAIT, attack=True)
        self._trace(tag, 'attack', ended='vortex' if icon == 'vortex' else 'timeout', attack_s=time.time() - start)
        self._vortex_seen = icon == 'vortex'
        if icon != 'vortex':
            self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_vortex')
        elif not wet:
            self._wet_time = release  # 进湿身不晚于松手
        self._trace(tag, 'exit', next=nxt)

    def _wait_r_gate(self, tag):
        """Stand still until the R cooldown digits read <= R_GATE; no digits read means no wait (I22).

        Cantarella R gates row 13, so Jinhsi's row 10 E2 must not come earlier than about 8 s before R is ready.
        Waiting before the wet entry keeps the wet window (rows 8-11) and the rows 3-7 Lingxiao window unchanged.
        """
        start = time.time()
        cd = 0.0
        while True:
            cd = max(cd, self.task.get_cd('liberation'))
            if cd > 0 or time.time() - start >= self.R_GATE_READ:
                break
            self.task.next_frame()
        wait = min(cd - self.R_GATE, self.R_GATE_MAX)
        if wait > 0:
            self._trace(tag, 'wait: r_cd', timeout=wait)
            # I51：切人过渡帧上 R 格可能还是今汐的冷却，读数偏大约 5 s；逐帧重读，降到 R_GATE 即走
            self.task.wait_until(lambda: self.task.get_cd('liberation') <= self.R_GATE, time_out=wait,
                                 pre_action=self.check_combat)

    def _hold_into_wet(self, tag):
        """Hold attack until the mouse forte outline lights, then stays gone for 0.1 s; release in finally."""
        start = time.time()
        gone = None
        self.task.mouse_down()
        try:
            self._trace(tag, 'wait: wet', timeout=self.WET_HOLD_MAX)
            lit = self.task.wait_until(self.is_mouse_forte_full, time_out=self.WET_HOLD_MAX,
                                       pre_action=self.check_combat)
            if lit:
                gone = self.task.wait_until(lambda: not self.is_mouse_forte_full(),
                                            time_out=max(0.0, self.WET_HOLD_MAX - (time.time() - start)),
                                            settle_time=self.WET_OUTLINE_GONE, pre_action=self.check_combat)
        finally:
            self.task.mouse_up()
        if gone:
            self._wet_time = time.time()
            self._trace(tag, 'cast heavy', ok=True, done_s=self._wet_time - start)
            return True
        self._trace(tag, 'cast heavy', ok=False, reason='timeout', held_s=time.time() - start)
        return False

    def _action_vortex(self, tag, nxt):
        # [EE]：粉圈E 后停 0.3 s 再按水母E，水母E 出冷却数字即完成；不按 Q（卡坎 52–53）
        wet_s = self.time_elapsed_accounting_for_freeze(self._wet_time) if self._wet_time > 0 else -1.0
        known = self._vortex_seen and not self.has_intro and 0 <= wet_s <= self.VORTEX_KNOWN_WET
        self._vortex_seen = False
        if known:
            # I47：入场后 E 格图标要 0.11–0.59 s 才认得出，粉圈已在上一节点认到，不再等图标
            self._trace(tag, 'decide: vortex_known')
        else:
            self._trace(tag, 'wait: vortex', timeout=self.VORTEX_WAIT)
            icon = self._wait_e_icon(self.VORTEX_WAIT)
            if icon != 'vortex':
                self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_vortex')
                self._trace(tag, 'exit', next=nxt)
                return
        self.send_resonance_key()
        self._trace(tag, 'send E', skill='vortex')
        self.sleep(self.VORTEX_PAUSE)
        start = time.time()
        jelly_wait = self.JELLY_WAIT + (self.INTRO_LOCK if self.has_intro else 0.0)
        # I47：入场即按时可能还在切人过渡帧，冷却数字或是上一个角色的；先读到一次 E 无冷却，再认冷却
        armed = [not known]

        def jelly_cd():
            if self.resonance_available():
                armed[0] = True
                return False
            return armed[0]

        self._trace(tag, 'wait: e_cd', timeout=jelly_wait)
        ok = bool(self.task.wait_until(jelly_cd, time_out=jelly_wait,
                                       pre_action=self.check_combat,
                                       post_action=lambda: self.send_resonance_key(interval=0.1)))
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'timeout', skill='jellyfish',
                    cd_s=time.time() - start)
        if not ok:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_jellyfish')
        self._trace(tag, 'exit', next=nxt)

    def _action_finale(self, tag, nxt, confirm_r=False):
        # Q；处决（I34）；R：等冷却期间点普攻，R 演出结束即延奏（I6）
        self._cast_echo(tag, ready_timeout=self.FINALE_ECHO_READY)
        self._try_break(tag)
        self._cast_r(tag, self.FINALE_R_WAIT, attack=True, click_f=False, confirm=confirm_r)
        self._trace(tag, 'exit', next=nxt)

    # ---------------- 坎特蕾拉：E 格图标识别（卡坎 51） ----------------
    def _e_icon(self):
        """Return 'vortex' (pink swirl), 'umbrella' (normal E, ready) or None, from white pixels in two rings."""
        box = self.task.get_box_by_name('box_resonance')
        cx, cy = box.x + 0.456 * box.width, box.y + 0.4975 * box.height
        r = 0.903 * box.height
        x0, y0 = max(int(cx - r), 0), max(int(cy - r), 0)
        img = self.task.frame[y0:int(cy + r) + 1, x0:int(cx + r) + 1].astype(np.int16)
        if img.size == 0:
            return None
        hi, lo = img.max(axis=2), img.min(axis=2)
        white = (hi >= 200) & (hi - lo <= 50)
        yy, xx = np.ogrid[y0:y0 + img.shape[0], x0:x0 + img.shape[1]]
        d = np.hypot(xx - cx, yy - cy) / r
        inner = float(white[(d >= 0.08) & (d < 0.30)].mean())
        arms = float(white[(d >= 0.32) & (d < 0.58)].mean())
        if inner <= 0.08 and arms >= 0.28:
            return 'vortex'
        # I50：粉圈帧内圈偶有白点，原画 inner 0.084–0.125、arms 0.368–0.390；inner ≤ 0.15 的非粉圈帧 arms 不超过 0.285
        if inner <= 0.13 and arms >= 0.36:
            return 'vortex'
        if inner >= 0.30 and self.resonance_available():
            return 'umbrella'
        return None

    def _wait_e_icon(self, time_out, attack=False):
        """Wait for a stable icon: vortex held 0.05 s or umbrella held 0.3 s; None on timeout."""
        seen = {'icon': None, 'since': 0.0}

        def stable():
            icon = self._e_icon()
            now = time.time()
            if icon != seen['icon']:
                seen['icon'], seen['since'] = icon, now
            hold = 0.05 if icon == 'vortex' else 0.3
            return icon if icon and now - seen['since'] >= hold else None

        return self.task.wait_until(stable, time_out=time_out, pre_action=self.check_combat,
                                    post_action=self.click_with_interval if attack else None)
