"""ok-ww workshop axis code: Cantarella / Jinhsi / Phrolova, 25 s advanced axis (Jinhsi)."""
import logging
import time

import cv2
import numpy as np
from src.char.BaseChar import BaseChar, SwitchPriority

# ---------------- 模块级日志部件（三个文件各带一份，内容保持一致） ----------------
_RATIO_FIELDS = ('con', 'res_pct', 'ring', 'ring_min', 'outer', 'inner', 'arms', 'miss_inner', 'miss_arms')
_FILTERED_SWITCH_LINES = (
    'BaseCombatTask:switch selection result',
    'BaseCombatTask:switch_next_char end',
)


def _fmt_value(key, v):
    if isinstance(v, float):
        return f'{v:.3f}' if key in _RATIO_FIELDS else f'{v:.2f}'
    return str(v)


class _InfoAsDebug:
    """Per-instance logger: framework info lines become debug; everything else passes through."""

    def __init__(self, inner):
        self._inner = inner

    def info(self, message):
        self._inner.debug(message)

    def __getattr__(self, name):
        return getattr(self._inner, name)


class _AxisSwitchFilter(logging.Filter):
    """Drops the task-level switch info lines while the running task's team has an axis char."""

    okww_axis_switch_filter = True

    def __init__(self, executor):
        super().__init__()
        self._executor = executor

    def filter(self, record):
        try:
            if record.levelno != logging.INFO or not record.getMessage().startswith(_FILTERED_SWITCH_LINES):
                return True
            chars = getattr(self._executor.current_task, 'chars', None) or []
            return not any(getattr(char, '_axis_char', False) for char in chars)
        except Exception:
            return True


def _install_axis_switch_filter(task):
    try:
        ok_logger = logging.getLogger('ok')
        if not any(getattr(f, 'okww_axis_switch_filter', False) for f in ok_logger.filters):
            ok_logger.addFilter(_AxisSwitchFilter(task.executor))
    except Exception:
        pass


class Jinhsi(BaseChar):
    """Workshop axis team Cantarella / Jinhsi / Phrolova, 25 s advanced axis: Jinhsi holds the Lingxiao air stage.

    Node comments: axis row, axis text, video interval (s) and the timeline.json node id.
    """

    E2_RING = 0.27  # E2 激活：E 格外圈淡金光环占比阈值；E1 ≤0.07、E3 ≤0.01、E2 ≥0.34（scout_e2 标定，I19）
    E2_FLASH = 0.5  # 圆盘黄色占比 ≥0.5 为图标切换闪光，不算激活（I19）
    E2_BG = 0.15  # 环外 0.78h–0.98h 黄色占比 ≥0.15 为黄色背景，不算激活；真亮 ≤0.047、背景误判 0.26–0.32（I40）
    E2_WAIT = 3.0  # 点普攻等 E2 激活的上限，超时直接按 E，Jinhsi.f1#1
    E2_FIRE = 1.5  # E2 亮起后连按 E 到 E 格变 E3 图标的上限；变奏入场锁定 E 约 0.6–0.9 s，实测亮→E3 图标 0.9 s，I27
    E2_GONE = 2  # E 格连续几帧无金环、无闪光才算 E2 已放出；切人闪光帧圆盘黄色 ≥0.73，I27
    E2_READY = 2.0  # 第 10 行等 E 冷却结束的上限，Jinhsi.f4#0
    E2_INTRO = 0.6  # 第 10 行：这么久金环一帧都没达标即判无变奏入场；142 次判亮里晚于 0.6 s 的 7 次，金环早已达标，只被闪光或冷却拒绝（I55）
    ECHO_READY = 1.0  # 等 Q 就绪的上限，Jinhsi.f1#0
    R_WAIT = 1.0  # 等 R 就绪的上限，Jinhsi.f1#3；就绪时 0.12 s 内放出（15/15），未就绪的 1 次 3 s 内图标一直暗（I36）
    E3_WAIT = 1.5  # 连按 E 到 E3 白龙图标变暗的上限，Jinhsi.f1#4
    E3_ICON = 0.05  # E3 可用时白龙图标白像素占比 ≥0.058（多为 0.09–0.13），I26
    E3_DIM = 0.04  # E3 放出后同一格降到 0.010–0.030；比冷却数字 OCR 早 0.17–0.34 s，I26
    AIR_A_TIME = 1.2  # 空中 A1–A3：间隔 0.5 s 点 3 下（0、0.5、1.0 s），约 1.5 s 离场，I14
    AIR_A_GAP = 0.5
    PRESS_GAP = 0.1  # A[E]：A 与 E 交替，每 0.1 s 只发一个输入（框架点击与按键共用一个节流时间戳），I28
    E4_WAIT = 2.0  # A/E 交替到 E4 演出开始（HUD 隐藏）的上限；覆盖变奏入场锁定，实测非锁定 0.08–0.10 s，I28
    FILL_WAIT = 2.0  # 补普攻到协奏满的上限：E4 未放出时（I24）、QA[E]A↓ 的 E4 演出后协奏未满时（I33）

    _axis_char = True
    _in_force_switch = False  # 强切期间为真，见 liberation_available（I46）、get_current_con（I48）

    # A property, not an __init__ assignment: CharFactory copies the built-in instance's __dict__
    # over this one on team load, and a data descriptor wins over the instance __dict__.
    @property
    def logger(self):
        return self._quiet_logger

    @logger.setter
    def logger(self, value):
        self._raw_logger = value
        self._quiet_logger = _InfoAsDebug(value)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _install_axis_switch_filter(self.task)
        self._force_switch_me = False
        self._entry_mode = None
        self._node = None
        self.started = False
        self._startup_done = False
        self._reset_char_state()

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None
        self._reset_char_state()

    # ---------------- 强切协议（队里每个类都带同一份） ----------------
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        # Workshop classes are loaded standalone, so isinstance() against src.char.* never matches.
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode):
        if target is None:
            self._raw_logger.warning(f'[{self._node.upper()}] fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        self._in_force_switch = True
        try:
            return self.switch_next_char()
        finally:
            self._in_force_switch = False
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    def liberation_available(self, check_color=True):
        # I46：BaseChar.switch_next_char 切人前读一次 R，只缓存给框架选人；强切用不上，有冷却数字时这次读要 OCR，约 0.13 s
        if self._in_force_switch:
            return False
        return super().liberation_available(check_color=check_color)

    def get_current_con(self):
        # I48：框架切人前读到 0.8–1 会停 0.05 s 再读一次，约 0.1 s；强切目标已定，切人循环里仍用 is_con_full 补认变奏
        con = super().get_current_con()
        if self._in_force_switch and 0.8 < con < 1:
            return 0.8
        return con

    # ---------------- 分发器 ----------------
    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        if mode is None:
            if not self.started:
                mode = 'f1'
            elif self._startup_done:
                mode = 's1'
            else:
                self._trace(None, 'interrupt', reason='startup_in_progress', next='framework')
                return self.switch_next_char()
            entry = 'intro' if self.has_intro else 'natural'
        else:
            entry = 'forced'
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, f'perform_{mode}', None)
        if func is None:
            self._trace(mode, 'interrupt', reason='unknown_mode', next='framework')
            return self.switch_next_char()
        self._node = mode
        self._trace(mode, 'enter', mode=entry)
        return func()

    # ---------------- 日志 ----------------
    def _trace(self, tag, event, ok=None, reason=None, **data):
        """Write one template line: [TAG] event[: ok|fail] [reason=code] [key=value ...]."""
        try:
            line = f'[{tag.upper()}] {event}' if tag else event
            if ok is not None:
                line += ': ok' if ok else ': fail'
            if reason:
                line += f' reason={reason}'
            for key, value in data.items():
                line += f' {key}={_fmt_value(key, value)}'
            self._raw_logger.info(line)
        except Exception:
            pass

    # ---------------- 共用动作 helper（三个文件各带一份，内容保持一致） ----------------
    def _cast_echo(self, tag, ready_timeout=0.0):
        """Q: optionally wait briefly for ready (I13), then click_echo; ok means the Q cooldown showed up."""
        ready = self.echo_available()
        if not ready and ready_timeout > 0:
            ready = bool(self.task.wait_until(self.echo_available, time_out=ready_timeout))
        if not ready:
            self._trace(tag, 'cast echo', ok=False, reason='not_ready')
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_echo')
            return False
        start = time.time()
        # Loop mode: presses every 0.1 s until echo_available() turns False, i.e. the cooldown digits appear.
        ok = self.click_echo(time_out=1)
        self._trace(tag, 'cast echo', ok=ok, reason=None if ok else 'icon_still_lit', cd_s=time.time() - start)
        if not ok:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_echo')
        return ok

    def _cast_r(self, tag, ready_timeout, attack=False, click_f=True, confirm=False):
        """R: wait for ready (normal attacks only where the model allows), cast, wait the animation out.

        A press without animation waits again within ready_timeout: a one-frame cooldown OCR miss
        reads as ready while R still has about 1.5 s of cooldown (I38).
        confirm: press only if the next frame still reads ready (I58).
        """
        start = time.time()
        while True:
            ready = self.liberation_available()
            remaining = ready_timeout - (time.time() - start)
            if not ready and remaining > 0:
                if remaining >= 2:
                    self._trace(tag, 'wait: r_ready', timeout=remaining)
                ready = bool(self.task.wait_until(self.liberation_available, time_out=remaining,
                                                  pre_action=self.check_combat,
                                                  post_action=self.click_with_interval if attack else None))
            ready_s = time.time() - start
            if not ready:
                self._trace(tag, 'cast R', ok=False, reason='not_ready', ready_s=ready_s)
                break
            if confirm:
                # I58：冷却数字漏读的那一帧 R 读成就绪；下一帧仍就绪才按，否则回到上面重等
                self.task.next_frame()
                if not self.liberation_available():
                    continue
            ok = self.click_liberation(click_f=click_f) or self._finish_late_liberation(tag)
            self._trace(tag, 'cast R', ok=ok, reason=None if ok else 'no_animation', ready_s=ready_s)
            if ok:
                return True
            if time.time() - start >= ready_timeout:
                break
        self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_r')
        return False

    def _finish_late_liberation(self, tag):
        """click_liberation gives the animation 0.4 s to start; finish a later one here.

        R lit again means the press was refused: return at once so _cast_r presses again (I38).
        """
        state = self.task.wait_until(
            lambda: 'animation' if not self.task.in_team()[0] else 'lit' if self.liberation_available() else None,
            time_out=0.6)
        if state != 'animation':
            return False
        self._wait_animation_end(tag)
        self.record_liberation_use()
        return True

    def _wait_animation_end(self, tag):
        """HUD hidden by an animation: keep combat checks quiet, wait for the team HUD, book the freeze."""
        start = time.time()
        self.task.in_liberation = True
        try:
            self._trace(tag, 'wait: hud_back', timeout=7.0)
            back = self.task.wait_until(lambda: self.task.in_team()[0], time_out=7.0, settle_time=0.1,
                                        pre_action=self.check_combat)
        finally:
            self.task.in_liberation = False
        self.add_freeze_duration(start)
        return bool(back)

    # ---------------- 今汐：状态与切人 ----------------
    def _reset_char_state(self):
        self._free_intro = False  # E4 演出已确认：下一次切人按满协奏（同奏，卡汐 20）

    def f_break(self, check_f_on_switch=False, force=False):
        # I34：切人时不按 F；处决只在坎特蕾拉 QR↓ 的 Q 后、R 前，与基线代码同位置
        return False

    def switch_next_char(self, post_action=None, free_intro=False, target_low_con=False):
        free_intro = free_intro or self._free_intro
        self._free_intro = False
        return super().switch_next_char(post_action=post_action, free_intro=free_intro,
                                        target_low_con=target_low_con)

    # ---------------- 节点：f = 启动轴，s = 循环轴（薄包装，最后一句保持字面写法） ----------------
    def perform_f1(self):
        # 启动第 3 行 汐 QAAAERE；视频 112.5–118.3；Jinhsi.f1
        self._action_open('f1', 'Phrolova.f2', echo=True)
        self._force_switch_to(self._find_teammate('Phrolova'), 'f2')

    def perform_f2(self):
        # 启动第 5 行 汐 AAA；视频 120.2–121.9；Jinhsi.f2
        self._action_air('f2', 'Phrolova.f3')
        self._force_switch_to(self._find_teammate('Phrolova'), 'f3')

    def perform_f3(self):
        # 启动第 7 行 汐 A[E]↓；视频 123.3–126.6；Jinhsi.f3
        self._action_e4('f3', 'Cantarella.f2')
        self._force_switch_to(self._find_teammate('Cantarella'), 'f2')

    def perform_f4(self):
        # 启动第 10 行 汐 E闪E（变奏入场）；视频 135.5–137.3；Jinhsi.f4
        self._action_dodge('f4', 'Cantarella.f3')
        self._force_switch_to(self._find_teammate('Cantarella'), 'f3')

    def perform_f5(self):
        # 启动第 12 行 汐 AAA；视频 139.5–141.1；Jinhsi.f5
        self._action_air('f5', 'Cantarella.f4')
        self._force_switch_to(self._find_teammate('Cantarella'), 'f4')

    def perform_f6(self):
        # 启动第 14 行 汐 QA[E]A↓（变奏入场）；视频 147.8–153.1；Jinhsi.f6
        self._action_outro('f6', 'Phrolova.s1')
        self._force_switch_to(self._find_teammate('Phrolova'), 's1')

    def perform_s1(self):
        # 循环第 2 行 汐 AAAERE；视频 156.7–162.7；Jinhsi.s1
        self._action_open('s1', 'Phrolova.s2', echo=False)
        self._force_switch_to(self._find_teammate('Phrolova'), 's2')

    def perform_s2(self):
        # 循环第 4 行 汐 AAA；视频 164.3–165.9；Jinhsi.s2
        self._action_air('s2', 'Phrolova.s3')
        self._force_switch_to(self._find_teammate('Phrolova'), 's3')

    def perform_s3(self):
        # 循环第 6 行 汐 A[E]↓；视频 167.2–170.5；Jinhsi.s3
        self._action_e4('s3', 'Cantarella.s1')
        self._force_switch_to(self._find_teammate('Cantarella'), 's1')

    def perform_s4(self):
        # 循环第 9 行 汐 E闪E（变奏入场）；视频 178.8–180.8；Jinhsi.s4
        self._action_dodge('s4', 'Cantarella.s2')
        self._force_switch_to(self._find_teammate('Cantarella'), 's2')

    def perform_s5(self):
        # 循环第 11 行 汐 AAA；视频 182.6–184.2；Jinhsi.s5
        self._action_air('s5', 'Cantarella.s3')
        self._force_switch_to(self._find_teammate('Cantarella'), 's3')

    def perform_s6(self):
        # 循环第 13 行 汐 QA[E]A↓（变奏入场）；视频未录到，同 Jinhsi.f6；Jinhsi.s6
        self._action_outro('s6', 'Phrolova.s1')
        self._force_switch_to(self._find_teammate('Phrolova'), 's1')

    # ---------------- 今汐：E 格识别与技能 helper ----------------
    def _e_yellow(self):
        """E cell yellow share: (glow band 0.54h–0.70h, inner disc < 0.51h, outer band 0.78h–0.98h),
        h = box height; (0, 0, 0) off-frame."""
        box = self.task.get_box_by_name('box_resonance')
        cx, cy = box.x + 0.456 * box.width, box.y + 0.4975 * box.height
        r = 0.98 * box.height
        x0, y0 = max(int(cx - r), 0), max(int(cy - r), 0)
        img = self.task.frame[y0:int(cy + r) + 1, x0:int(cx + r) + 1]
        if img.size == 0:
            return 0.0, 0.0, 0.0
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        yellow = (hsv[..., 0] >= 15) & (hsv[..., 0] <= 40) & (hsv[..., 1] >= 20) & (hsv[..., 2] >= 120)
        yy, xx = np.ogrid[y0:y0 + img.shape[0], x0:x0 + img.shape[1]]
        d = np.hypot(xx - cx, yy - cy) / box.height
        return (float(yellow[(d >= 0.54) & (d < 0.70)].mean()), float(yellow[d < 0.51].mean()),
                float(yellow[(d >= 0.78) & (d < 0.98)].mean()))

    def _e2_lit(self):
        """E2 active: pale-gold glow, no switch flash, no yellow background, no cooldown digits."""
        # 黄色背景铺满 E 格时环带也达标，环外同样泛黄（I40）
        ring, inner, outer = self._e_yellow()
        st = self._e2_stats  # 只供 I44 的 probe 行使用：每个被拒条件各拒了几帧
        st['frames'] += 1
        st['ring'] = max(st['ring'], ring)
        if ring < self.E2_RING:
            return False
        if inner >= self.E2_FLASH:
            st['flash'] += 1
            return False
        if outer >= self.E2_BG:
            st['bg'] += 1
            st['outer'] = max(st['outer'], outer)
            return False
        if not self.resonance_available():
            st['cd'] += 1
            return False
        return True

    def _wait_e2(self, tag, time_out, attack, intro_s=None):
        """Wait for E2. With intro_s, stop early once intro_s passes without any ring frame (no intro, I55)."""
        self._trace(tag, 'wait: e2', timeout=time_out)
        self._e2_stats = {'frames': 0, 'ring': 0.0, 'flash': 0, 'bg': 0, 'outer': 0.0, 'cd': 0}
        start = time.time()
        lit = [False]

        def done():
            lit[0] = self._e2_lit()
            # 金环达标过的帧（含被闪光、冷却拒绝的）都记在 ring 最大值里；一帧都没有才判无变奏（I55）
            return lit[0] or (intro_s is not None and time.time() - start >= intro_s
                              and self._e2_stats['ring'] < self.E2_RING)

        self.task.wait_until(done, time_out=time_out, pre_action=self.check_combat,
                             post_action=self.click_with_interval if attack else None)
        self._trace(tag, 'probe e2', lit=lit[0], wait_s=time.time() - start, **self._e2_stats)  # I44：判不亮时卡在哪个条件
        return lit[0]

    def _cast_e2(self, tag, lit):
        """E2: press E every 0.1 s until the cell shows the E3 icon (enter Lingxiao). Without a seen glow, press once."""
        # 变奏入场锁定期内 E 被吞，切人闪光又会盖掉金环；"金环消失"一帧不算数，要连续 E2_GONE 帧（I27）
        start = time.time()
        if not lit:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: e2_unconfirmed')
            self.send_resonance_key()
            self._trace(tag, 'send E', skill='e2')
            return
        gone = [0]

        def fired():
            ring, inner, _ = self._e_yellow()
            low = ring < self.E2_RING and inner < self.E2_FLASH and self.task.in_team()[0]
            gone[0] = gone[0] + 1 if low else 0
            return gone[0] >= self.E2_GONE

        ok = bool(self.task.wait_until(fired, time_out=self.E2_FIRE,
                                       post_action=lambda: self.send_resonance_key(interval=0.1)))
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'icon_still_lit', skill='e2',
                    fire_s=time.time() - start)
        if not ok:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: continue_without_e2')

    def _cast_e3(self, tag):
        """E3: press E every 0.1 s until the white dragon icon dims, then leave at once."""
        # E3 突进约在图标变暗后 0.24 s 打到 boss；晚于突进切人，下一位在 boss 顶上出场，第一下普攻变成下落攻击（I26）。
        # 不调 check_combat：突进期间丢目标会重新锁定，推迟切人。
        start = time.time()
        seen = [False]

        def dimmed():
            if not self.task.in_team()[0]:
                return False
            white = self.current_resonance()
            if white > self.E3_ICON and self._e_yellow()[0] < self.E2_RING:
                seen[0] = True
            return seen[0] and white < self.E3_DIM

        ok = bool(self.task.wait_until(dimmed, time_out=self.E3_WAIT,
                                       post_action=lambda: self.send_resonance_key(interval=0.1)))
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'icon_still_lit', skill='e3',
                    fire_s=time.time() - start)
        if not ok:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_e3')

    def _cast_e4(self, tag):
        """A[E]: alternate A and E until the E4 animation hides the HUD, wait it out, switch as full con."""
        # A4 解锁 E4（卡汐 29）；A4 前凌霄内 E3 已在冷却，按 E 无效。变奏入场锁定期内 A 被吞，所以 A 一直补到 E4 放出。
        # 不调 check_combat：演出开始时判 target lost，重新锁定阻塞 3 s，演出结束才回来（第 4 段 J.f3，I28）
        start = time.time()
        presses = [0]

        def press():
            if not self.task.check_interval(self.PRESS_GAP):
                return
            if presses[0] % 2 == 0:
                self.click()
            else:
                self.send_resonance_key()
            presses[0] += 1

        self._trace(tag, 'wait: e4', timeout=self.E4_WAIT)
        fired = bool(self.task.wait_until(lambda: not self.task.in_team()[0], time_out=self.E4_WAIT,
                                          post_action=press))
        fire_s = time.time() - start
        if not fired:
            self._trace(tag, 'cast E', ok=False, reason='no_animation', skill='e4', attacks=(presses[0] + 1) // 2,
                        fire_s=fire_s)
            self._fill_con(tag)
            return False
        self._wait_animation_end(tag)
        self._free_intro = True
        self._trace(tag, 'cast E', ok=True, skill='e4', attacks=(presses[0] + 1) // 2, fire_s=fire_s)
        return True

    def _fill_con(self, tag):
        """E4 missed: attack until concerto is full so the next node still enters by intro."""
        self._raw_logger.warning(f'[{tag.upper()}] fallback: fill_con')
        self._attack_to_full(tag)

    def _attack_to_full(self, tag):
        """Click normal attacks until concerto is full, at most FILL_WAIT."""
        start = time.time()
        self._trace(tag, 'wait: con_full', timeout=self.FILL_WAIT)
        full = bool(self.task.wait_until(self._con_ready, time_out=self.FILL_WAIT, pre_action=self.check_combat,
                                         post_action=self.click_with_interval))
        self._trace(tag, 'attack', con_full=full, attack_s=time.time() - start)
        return full

    def _con_ready(self, con=None):
        # 框架把面积已满、形状未判满的协奏环记作 0.99，is_con_full 为 False；这里算满（I33）
        return (self.get_current_con() if con is None else con) >= 0.99

    # ---------------- 今汐：动作体 ----------------
    def _action_open(self, tag, nxt, echo):
        # [Q]AAAERE：Q；点普攻到 E2 激活（A4 出手）；E2 进凌霄；R 打断 E2 后摇（卡汐 9）；E3
        if echo:
            self._cast_echo(tag, ready_timeout=self.ECHO_READY)
        lit = self._wait_e2(tag, self.E2_WAIT, attack=True)
        self._cast_e2(tag, lit)
        self._cast_r(tag, self.R_WAIT, click_f=False)
        self._cast_e3(tag)
        self._trace(tag, 'exit', next=nxt)

    def _action_air(self, tag, nxt):
        # AAA：凌霄内空中 A1–A3，固定点 3 下，不得打出 A4（D16、I14）
        start = time.time()
        self.continues_normal_attack(self.AIR_A_TIME, interval=self.AIR_A_GAP)
        self._trace(tag, 'attack', ended='fixed', attack_s=time.time() - start)
        self._trace(tag, 'exit', next=nxt)

    def _action_e4(self, tag, nxt):
        # A[E]↓：空中 A4 解锁 E4；E4 演出结束即延奏
        self._cast_e4(tag)
        self._trace(tag, 'exit', next=nxt)

    def _action_dodge(self, tag, nxt):
        # E闪E：E2 亮起即连按 E 到 E 格变 E3 图标（变奏入场锁定，I27）；闪避打断 E2 后摇（卡汐 9）；E3 图标变暗即切人（I26）
        lit = self._wait_e2(tag, self.E2_READY, attack=False, intro_s=self.E2_INTRO)
        if not lit and self._e2_stats['ring'] < self.E2_RING and self.resonance_available():
            # 无变奏入场（I42）：此时按 E 放出的是 E1，进不了凌霄，连锁丢 3 次龙喷。
            # 非变奏入场的出场攻击算第 2 段，点普攻到 A4 出手即激活 E2（卡汐 6、10），同循环第 2 行（I55）
            self._raw_logger.warning(f'[{tag.upper()}] fallback: e2_by_attack')
            lit = self._wait_e2(tag, self.E2_WAIT, attack=True)
        if not lit and not self.resonance_available():
            self._trace(tag, 'cast E', ok=False, reason='not_ready', skill='e2')
            self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_e2')
            self._trace(tag, 'exit', next=nxt)
            return
        self._cast_e2(tag, lit)
        self.task.send_key(self.task.key_config.get('Dodge Key'))
        self._trace(tag, 'send dodge')
        self._cast_e3(tag)
        self._trace(tag, 'exit', next=nxt)

    def _action_outro(self, tag, nxt):
        # QA[E]A↓：Q（锁定期内也接受）；A/E 交替到 E4 放出（I28）；E4 演出后协奏已满即延奏，未满点普攻到满再延奏（I33）
        # 用户 2026-10-24 定：去掉固定的下落攻击与 1.0 s 等待，不再等赫卡忒强化攻击二段（I7）
        self._cast_echo(tag, ready_timeout=self.ECHO_READY)
        if self._cast_e4(tag):
            con = self.get_current_con()
            full = self._con_ready(con)
            self._trace(tag, 'decide: outro' if full else 'decide: fill_con', con=con, con_full=full)
            if not full and not self._attack_to_full(tag):
                self._raw_logger.warning(f'[{tag.upper()}] fallback: outro_without_con')
        self._trace(tag, 'exit', next=nxt)
