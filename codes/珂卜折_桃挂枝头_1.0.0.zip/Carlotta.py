import time
import numpy as np

from src.char.BaseChar import SwitchPriority
from src.char.Carlotta import Carlotta as NativeCarlotta


class Carlotta(NativeCarlotta):
    MATRIX_PROTOCOL = 12
    MATRIX_PREPARE_CAP = 7.0
    MATRIX_READY_GRACE = 3.0
    MATRIX_ENERGY_CAP = 12.0
    MATRIX_BURST_CAP = 10.0
    MATRIX_MAX_LIBERATION_INPUTS = 80
    MATRIX_SKILL_CAP = 2.8
    MATRIX_LIBERATION_INTERVAL = 0.18
    MATRIX_SHOT_GAP_CAP = 0.65

    def matrix_controller(self):
        for char in self.task.chars:
            if char is not None and char.name == 'Douling':
                if getattr(char, 'MATRIX_PROTOCOL', None) == self.MATRIX_PROTOCOL and char.matrix_team():
                    return char
        return None

    def do_perform(self):
        controller = self.matrix_controller()
        if controller is None:
            return super().do_perform()
        if controller.matrix_target() != self.name:
            return self.switch_next_char()
        if controller.matrix_phase == 'carlotta_seed':
            self.wait_intro()
            self.matrix_seed()
            controller.matrix_seeded = True
            controller.matrix_advance('douling_finish')
        elif controller.matrix_phase == 'carlotta_prepare':
            self.matrix_prepare()
            controller.matrix_advance('zhezhi_prepare')
        else:
            self.matrix_burst()
            controller.matrix_advance('douling_prepare')
        self.wait_switch_cd()
        return self.switch_next_char()

    def matrix_seed(self):
        """零链预留一段回路；按实读结果记录，不把E发键次数当作能量。"""
        self.task.next_frame()
        before = self.get_forte()
        if before >= 1:
            self.logger.info(f'CZB-FIX5: seed already present; segments={before}')
            return True
        if not self.resonance_available() or self.has_cd('resonance'):
            self.logger.warning('CZB-FIX5: seed E on cooldown; no extra wait')
            return False
        self.matrix_cast_skill()
        start = time.time()
        while time.time() - start < 0.6:
            self.task.next_frame()
            if self.get_forte() >= 1:
                self.logger.info('CZB-FIX5: seed confirmed; next intro will not start from empty')
                return True
            self.click()
            self.task.sleep(0.05)
        self.logger.warning('CZB-FIX5: seed attempt unconfirmed; keeping normal cycle')
        return False

    def matrix_prepare(self):
        # 本轮重新确认，不能用上一轮留下的liberation_ready跳过满回路重击。
        self.liberation_ready = False
        start = time.time()
        full_frames = 0
        last_skill = start - 1.0
        extended = False
        while time.time() - start < self.MATRIX_PREPARE_CAP + self.MATRIX_READY_GRACE:
            self.cycle_start()
            self.check_combat()
            self.task.next_frame()
            full_frames = full_frames + 1 if self.matrix_forte_full() else 0
            if full_frames >= 2:
                self.logger.info(
                    f'CZB-FIX4: full gauge detected by {getattr(self, "_matrix_forte_source", "test")}; '
                    'landing before heavy'
                )
                self._matrix_heavy_confirmed = bool(self.matrix_heavy())
                if self._matrix_heavy_confirmed:
                    self.liberation_ready = True
                    self.forte = 0
                    self.logger.info('CZB-FIX4: full forte heavy confirmed; entering R')
                else:
                    self.logger.warning(
                        'CZB-FIX4: full gauge seen and grounded heavy attempted, '
                        'consumption unconfirmed; allowing R fallback, not claiming heavy success'
                    )
                    combat = getattr(self.task, 'combat_start', None)
                    if getattr(self, '_matrix_diag_combat', object()) != combat:
                        self._matrix_diag_combat = combat
                        if hasattr(self.task, 'screenshot'):
                            self.task.screenshot('CZB_FIX4_heavy_unconfirmed')
                return True
            if time.time() - start >= self.MATRIX_PREPARE_CAP and not extended:
                if self.get_forte() < 3:
                    break
                extended = True
                self.logger.info('CZB-FIX9: near-full blue gauge; waiting up to 3s for white heavy readiness')
            if self.resonance_available() and time.time() - last_skill >= 1.0:
                self.matrix_cast_skill()
                last_skill = time.time()
            else:
                self.click()
            self.cycle_sleep()
        self.logger.warning('CZB-FIX3: forte fill timed out; refusing to skip heavy and open R')
        return False

    def matrix_forte_full(self):
        if self.is_mouse_forte_full():
            self._matrix_forte_source = 'mouse_prompt'
            return True
        # 录像里的蓝色4格仍不能触发强化重击；不能把FFT段数当作就绪提示。
        ready = self.matrix_white_forte_ready()
        self._matrix_forte_source = 'white_gauge' if ready else 'not_ready'
        return ready

    def matrix_white_forte_ready(self):
        box = self.task.box_of_screen_scaled(
            5120, 2880, 2164, 2670, 2900, 2680,
            name='matrix_carlotta_white_forte', hcenter=True,
        )
        cropped = box.crop_frame(self.task.frame)
        if cropped.ndim != 3 or cropped.shape[2] < 3 or cropped.shape[0] < 1 or cropped.shape[1] < 16:
            return False
        # OpenCV帧为BGR；转有符号整数后比较，避免uint8相减回绕。
        pixels = cropped[:, :, :3].astype(np.int16)
        blue, green, red = pixels[:, :, 0], pixels[:, :, 1], pixels[:, :, 2]
        white = (
            (red >= 190) & (green >= 210) & (blue >= 220)
            & (pixels.max(axis=2) - pixels.min(axis=2) <= 55)
        )
        quarters = np.array_split(white, 4, axis=1)
        return bool(white.mean() >= 0.22 and all(part.mean() >= 0.12 for part in quarters))

    def judge_frequncy_and_amplitude(self, gray, min_freq, max_freq, min_amp):
        # 1280x720下单段只有46像素、约2像素高，原生width<64直接判0。
        # 最近邻整数放大仍保持二值纹理；沿用原生频率/振幅判断。
        if gray.ndim != 2 or gray.shape[0] == 0 or gray.shape[1] < 8:
            return 0
        scale = max(1, int(np.ceil(64 / gray.shape[1])), int(np.ceil(4 / gray.shape[0])))
        if scale > 1:
            gray = np.repeat(np.repeat(gray, scale, axis=0), scale, axis=1)
        return super().judge_frequncy_and_amplitude(gray, min_freq, max_freq, min_amp)

    def matrix_heavy_consumed(self):
        # 4格抖成3格不算消耗；要求提示消失且实读回路降至0或1格。
        return not self.is_mouse_forte_full() and self.get_forte() <= 1

    def matrix_heavy(self):
        for attempt in range(2):
            # 二段E后可能仍在空中。先用普攻下落，并给落地后一次新的按下沿。
            self.task.mouse_up()
            self.continues_normal_attack(0.9 if attempt == 0 else 0.25)
            if self.flying():
                self.wait_down()
            self.task.mouse_up()
            self.sleep(0.03)
            start = time.time()
            empty_frames = 0
            consumed = False
            self.task.mouse_down()
            try:
                while time.time() - start < 1.2:
                    self.task.next_frame()
                    self.check_combat()
                    empty_frames = empty_frames + 1 if self.matrix_heavy_consumed() else 0
                    if time.time() - start >= 0.7 and empty_frames >= 2:
                        consumed = True
                        break
                    self.sleep(0.06)
            finally:
                self.task.mouse_up()
            # 松键后继续观察，不能把“按住时还没消耗”直接当作动作失败。
            release_start = time.time()
            while not consumed and time.time() - release_start < 0.65:
                self.task.next_frame()
                self.check_combat()
                empty_frames = empty_frames + 1 if self.matrix_heavy_consumed() else 0
                if empty_frames >= 2:
                    consumed = True
                    break
                self.sleep(0.05)
            self.logger.info(
                f'CZB-FIX4: grounded heavy attempt={attempt + 1}, consumed={consumed}, '
                f'elapsed={time.time() - start:.2f}s'
            )
            if consumed:
                self.sleep(0.15)
                return True
        return False

    def matrix_burst(self):
        self.wait_intro()
        if not self.has_intro:
            self.logger.warning('CZB: Carlotta burst without intro; verify Zhezhi concerto in logs')
        if not self.matrix_prepare():
            return False
        if not self.matrix_wait_energy():
            self.switch_lock = -1
            return False
        previous_skip = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        try:
            return self.matrix_burst_combo()
        finally:
            self.task.skip_combat_check = previous_skip
            self.task.mouse_up()

    def matrix_wait_energy(self):
        # 补能独立计时：录像中的E仍有8秒冷却，旧5秒上限会漏掉整轮R。
        if not self.task.use_liberation:
            return False
        start = time.time()
        last_skill = start - 1.0
        try:
            while time.time() - start < self.MATRIX_ENERGY_CAP:
                self.cycle_start()
                self.check_combat()
                self.task.next_frame()
                if self.liberation_available():
                    self.logger.info(
                        f'CZB-FIX7: energy ready; build_wall={time.time() - start:.2f}s'
                    )
                    return True
                if not self.matrix_skill_cooling() and self.resonance_available() and time.time() - last_skill >= 1.0:
                    remaining = self.MATRIX_ENERGY_CAP - (time.time() - start)
                    self.matrix_cast_skill(time_cap=max(0.0, remaining))
                    last_skill = time.time()
                else:
                    self.click()
                self.task.sleep(0.05)
            # 边界刷新一次；不能在最后一帧刚充满时直接放弃。
            self.task.next_frame()
            if self.liberation_available():
                return True
            self.logger.warning(
                f'CZB-FIX7: energy build capped at {time.time() - start:.2f}s; '
                'R still unavailable; no R inputs sent'
            )
            return False
        finally:
            self.task.mouse_up()

    def matrix_skill_cooling(self):
        # 只缓存实际OCR读到的正冷却；避免下一帧漏字变成0后反复空按E。
        combat = getattr(self.task, 'combat_start', None)
        if getattr(self, '_matrix_cd_combat', object()) != combat:
            self._matrix_cd_combat = combat
            self._matrix_cd_started = time.time()
            self._matrix_cd_duration = 0.0
        cd = self.task.get_cd('resonance')
        cached = self._matrix_cd_duration - self.time_elapsed_accounting_for_freeze(self._matrix_cd_started)
        if isinstance(cd, (int, float)) and 0.25 <= cd <= 15.0 and cd > cached:
            self._matrix_cd_started = time.time()
            self._matrix_cd_duration = cd
            cached = cd
        return cached > 0.15 or self.has_cd('resonance')

    def matrix_burst_combo(self):
        # 限时连射段内保留任务停止检查，但避免演出期间反复锁敌打断输入节奏。
        start = time.time()
        presses = 0
        animations = 0
        last_r = start - self.MATRIX_LIBERATION_INTERVAL
        no_r_since = None
        while (
            time.time() - start < self.MATRIX_BURST_CAP * 2
            and self.time_elapsed_accounting_for_freeze(start) < self.MATRIX_BURST_CAP
        ):
            self.cycle_start()
            self.check_combat()
            self.task.next_frame()
            if not self.task.in_team()[0]:
                if not self.matrix_wait_animation():
                    break
                animations += 1
                no_r_since = None
                continue
            ready = self.task.use_liberation and self.liberation_available()
            if ready and presses < self.MATRIX_MAX_LIBERATION_INPUTS:
                no_r_since = None
                if time.time() - last_r >= self.MATRIX_LIBERATION_INTERVAL:
                    # 中间的枪击可能没有隐藏HUD；不再用“必须出现演出”判断每一枪。
                    self.send_liberation_key()
                    presses += 1
                    last_r = time.time()
            else:
                if no_r_since is None:
                    no_r_since = time.time()
                quiet = time.time() - no_r_since
                # 枪击间隙先等技能位恢复，避免普通E打断大招流程。
                if presses and quiet < self.MATRIX_SHOT_GAP_CAP:
                    self.task.sleep(0.05)
                    continue
                if presses:
                    # 最后一枪后不补E、不重新攒能量，直接结束输出回合。
                    self.logger.info('CZB-FIX3: R chain unavailable; leaving without E tail')
                    break
                # 补能已经在连射前完成。首枪瞬间识别抖动时短等，不在此补E。
                if quiet >= 0.8:
                    self.logger.warning('CZB-FIX7: R readiness lost before first input; ending burst')
                    break
            self.task.sleep(0.05)
        # 大招链结束后仅补一次下轮备弹，不重复E或在R形态内攒回路。
        if presses and not self.liberation_available():
            self.matrix_seed()
        # 本轮录像中收尾Q进入变身，切卜灵耗时约5秒；本轴优先立即交回辅助。
        self.logger.info('CZB-FIX9: skipping Carlotta echo tail; switching after R')
        self.switch_lock = -1
        self.continue_liberation = animations == 0
        if animations:
            self.liberation_ready = False
        self.logger.info(
            f'CZB-FIX3: Carlotta burst R_inputs={presses}, '
            f'HUD_animations={animations}, wall={time.time() - start:.2f}s'
        )

    def matrix_cast_skill(self, time_cap=None):
        """等待两段E进入冷却；短尝试超时记录具体状态，不套用原生键位错误提示。"""
        if self.matrix_skill_cooling() or not self.resonance_available():
            return False
        start = time.time()
        cap = self.MATRIX_SKILL_CAP if time_cap is None else min(self.MATRIX_SKILL_CAP, time_cap)
        presses = 0
        cd_frames = 0
        next_key = start
        while time.time() - start < cap:
            self.check_combat()
            self.task.next_frame()
            cd_frames = cd_frames + 1 if self.has_cd('resonance') else 0
            if presses and cd_frames >= 2:
                self.matrix_skill_cooling()
                self.record_resonance_use()
                self.logger.info(f'CZB-FIX7: Carlotta E cooldown observed after inputs={presses}')
                return True
            if time.time() >= next_key and not self.has_cd('resonance'):
                self.send_resonance_key()
                presses += 1
                self.click()
                next_key = time.time() + 0.12
            self.task.sleep(0.03)
        self.logger.warning(
            f'CZB-FIX: Carlotta E unconfirmed after {time.time() - start:.2f}s, '
            f'inputs={presses}, cd={self.has_cd("resonance")}; '
            'check animation, recognition and energy in recording'
        )
        return False

    def matrix_wait_animation(self):
        start = time.time()
        self.task.in_liberation = True
        try:
            while time.time() - start < 7.0:
                self.task.next_frame()
                if self.task.in_team()[0]:
                    self.add_freeze_duration(start, time.time() - start)
                    self.record_liberation_use()
                    return True
                self.task.sleep(0.05)
        finally:
            self.task.in_liberation = False
        self.logger.warning('CZB-FIX: Carlotta HUD did not return; leaving burst')
        return False

    def switch_next_char(self, *args, **kwargs):
        if getattr(self, '_matrix_capture_switch', False):
            return None
        native_switch = super().switch_next_char
        controller = self.matrix_controller()
        if controller is None:
            return native_switch(*args, **kwargs)
        return controller.matrix_switch_hud_guard(lambda: native_switch(*args, **kwargs))

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        controller = self.matrix_controller()
        if controller is None:
            return super().get_switch_priority(current_char, has_intro, target_low_con)
        return SwitchPriority.MUST if controller.matrix_target() == self.name else SwitchPriority.NO
