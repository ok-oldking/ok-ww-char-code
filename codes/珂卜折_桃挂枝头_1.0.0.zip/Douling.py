import time

from src.char.BaseChar import SwitchPriority
from src.char.Douling import Douling as NativeDouling


class Douling(NativeDouling):
    """珂折卜矩阵候选轴。持有队伍阶段，切人和变奏记账仍由框架完成。"""

    MATRIX_TARGETS = {
        'douling_prepare': 'Douling',
        'carlotta_prepare': 'Carlotta',
        'zhezhi_prepare': 'Zhezhi',
        'douling_finish': 'Douling',
        'zhezhi_finish': 'Zhezhi',
        'carlotta_burst': 'Carlotta',
        'carlotta_seed': 'Carlotta',
    }
    MATRIX_PROTOCOL = 12
    MATRIX_PROFILE = {
        'Carlotta': {'chain': 0, 'weapon': '死与舞', 'refinement': 1, 'er': 119.2},
        'Zhezhi': {'chain': 0, 'weapon': '漪澜浮录', 'refinement': None, 'er': 131.2},
        'Douling': {'chain': 5, 'weapon': '渊海回声', 'refinement': None, 'er': 215.8},
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.matrix_phase = 'douling_prepare'
        self.matrix_round = 1
        self.matrix_combat = None
        self._matrix_capture_switch = False
        self.matrix_seeded = False

    def matrix_team(self):
        chars = {
            char.name: char for char in self.task.chars if char is not None
        }
        if not all(name in chars for name in ('Carlotta', 'Zhezhi', 'Douling')):
            return None
        if not all(getattr(chars[name], 'MATRIX_PROTOCOL', None) == self.MATRIX_PROTOCOL for name in chars):
            return None
        combat = getattr(self.task, 'combat_start', None)
        if combat != self.matrix_combat:
            self.matrix_combat = combat
            self.matrix_phase = 'douling_prepare'
            self.matrix_round = 1
            self._segment = 1
            self.matrix_seeded = False
        chars['Carlotta'].char_zhezhi = chars['Zhezhi']
        chars['Carlotta'].press_w = 0
        chars['Zhezhi'].char_carlotta = chars['Carlotta']
        return chars

    def matrix_target(self):
        return self.MATRIX_TARGETS[self.matrix_phase]

    def matrix_advance(self, phase):
        previous = self.matrix_phase
        if phase == 'douling_prepare' and previous == 'carlotta_burst':
            self.matrix_round += 1
        self.matrix_phase = phase
        self.logger.info(
            f'CZB round {self.matrix_round}: {previous} -> {phase}'
        )

    def matrix_capture(self, char, action):
        """执行原生单角色动作，但延后其内部切人，阶段更新后只切一次。"""
        char._matrix_capture_switch = True
        try:
            return action()
        finally:
            char._matrix_capture_switch = False
            char.task.mouse_up()

    def do_perform(self):
        team = self.matrix_team()
        if team is None:
            return super().do_perform()
        if self.matrix_target() != self.name:
            return self.switch_next_char()
        self.wait_intro()
        if self.matrix_phase == 'douling_prepare':
            self._segment = 1
            self.matrix_capture(self, self._do_segment1)
            if not self.matrix_seeded:
                self.matrix_advance('carlotta_seed')
                self.wait_switch_cd()
                return self.switch_next_char()
            # 两段在本次入场连续完成，不再绕一圈把满协奏交给错误的角色。
            if self._segment == 2:
                self.matrix_capture(self, self._do_segment2)
            self.matrix_finish_concerto()
            self.matrix_advance('zhezhi_finish')
        else:
            self._segment = 2
            self.matrix_capture(self, self._do_segment2)
            self.matrix_finish_concerto()
            self.matrix_advance('zhezhi_finish')
        self.wait_switch_cd()
        return self.switch_next_char()

    def matrix_finish_concerto(self):
        """只对已经接近满的协奏补普攻，不为低协奏额外等一整轮。"""
        self.task.next_frame()
        con = float(self.task.get_current_con())
        if con < 0.8:
            return False
        start = time.time()
        while time.time() - start < 2.4:
            self.task.next_frame()
            if self.task.is_con_full():
                self.logger.info('CZB-FIX8: Douling concerto confirmed before Zhezhi handoff')
                return True
            self.check_combat()
            self.click()
            self.sleep(0.1)
        self.logger.warning('CZB-FIX8: Douling concerto top-up timed out; no forced intro')
        return False

    def matrix_switch_hud_guard(self, action):
        """仅在原生切人调用内为短暂HUD失读保留最后确认的角色索引。"""
        original = self.task.in_team
        last_visible = original()
        # 进入切人时本就没有HUD，交还框架原有错误处理。
        if not last_visible[0]:
            return action()
        first_missing = None
        bridged = 0
        own_value = vars(self.task).get('in_team')
        had_own_value = 'in_team' in vars(self.task)

        def guarded_in_team(*args, **kwargs):
            nonlocal last_visible, first_missing, bridged
            result = original(*args, **kwargs)
            if result[0]:
                last_visible = result
                first_missing = None
                return result
            if first_missing is None:
                first_missing = time.time()
            if time.time() - first_missing < 0.35:
                # 只返回旧的已确认索引，不猜测切人成功，不制造变奏。
                bridged += 1
                return last_visible
            return result

        self.task.in_team = guarded_in_team
        try:
            return action()
        finally:
            if had_own_value:
                self.task.in_team = own_value
            else:
                del self.task.in_team
            if bridged:
                self.logger.info(f'CZB-FIX10: switch HUD gap bridged; reads={bridged}, max_gap=0.35s')

    def switch_next_char(self, *args, **kwargs):
        if getattr(self, '_matrix_capture_switch', False):
            return None
        native_switch = super().switch_next_char
        if self.matrix_team() is None:
            return native_switch(*args, **kwargs)
        return self.matrix_switch_hud_guard(lambda: native_switch(*args, **kwargs))

    def _heavy_attack_hold(self, duration):
        # 保留原版被击飞后的重试，同时保证异常退出也松开鼠标。
        for _ in range(3):
            self.check_combat()
            interrupted = False
            start = time.time()
            self.task.mouse_down()
            try:
                while time.time() - start < duration:
                    if self.flying():
                        interrupted = True
                        break
                    self.sleep(0.1)
            finally:
                self.task.mouse_up()
            if not interrupted:
                return
            self.wait_down()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self.matrix_team() is None:
            return super().get_switch_priority(current_char, has_intro, target_low_con)
        return SwitchPriority.MUST if self.matrix_target() == self.name else SwitchPriority.NO

    def healer_full_con_switch_locked(self):
        # 本轴需要卜灵短时间内二次进场；框架会在读取优先级之前应用此锁。
        if self.matrix_team() is not None:
            return False
        return super().healer_full_con_switch_locked()

    def on_combat_end(self, chars):
        self.matrix_seeded = False
        self.matrix_phase = 'douling_prepare'
        self.matrix_round = 1
        self.matrix_combat = None
        self._segment = 1
        return super().on_combat_end(chars)
