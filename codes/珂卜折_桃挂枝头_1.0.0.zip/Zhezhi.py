import time
import numpy as np

from src.char.BaseChar import SwitchPriority
from src.char.Zhezhi import Zhezhi as NativeZhezhi


class Zhezhi(NativeZhezhi):
    MATRIX_PROTOCOL = 12
    MATRIX_PREPARE_CAP = 3.0
    MATRIX_FINISH_CAP = 9.0
    MATRIX_CON_FILL_CAP = 2.0

    def matrix_controller(self):
        for char in self.task.chars:
            if char is not None and char.name == 'Douling':
                if getattr(char, 'MATRIX_PROTOCOL', None) == self.MATRIX_PROTOCOL and char.matrix_team():
                    return char
        return None

    def judge_frequncy_and_amplitude(self, gray, min_freq, max_freq, min_amp):
        if gray.ndim != 2 or gray.shape[0] == 0 or gray.shape[1] < 8:
            return 0
        scale = max(1, int(np.ceil(64 / gray.shape[1])), int(np.ceil(4 / gray.shape[0])))
        if scale > 1:
            gray = np.repeat(np.repeat(gray, scale, axis=0), scale, axis=1)
        return super().judge_frequncy_and_amplitude(gray, min_freq, max_freq, min_amp)

    def do_perform(self):
        controller = self.matrix_controller()
        if controller is None:
            return super().do_perform()
        if controller.matrix_target() != self.name:
            return self.switch_next_char()
        if controller.matrix_phase == 'zhezhi_prepare':
            self.matrix_prepare()
            controller.matrix_advance('douling_finish')
        else:
            ready = self.matrix_finish()
            if ready:
                controller.matrix_advance('carlotta_burst')
            else:
                # 这是降级输出，不假定有变奏；绝不重新跑整套辅助消耗几十秒。
                self.logger.warning('CZB-FIX2: concerto incomplete; taking one unbuffed carry turn')
                controller.matrix_advance('carlotta_burst')
        self.wait_switch_cd()
        return self.switch_next_char()

    def matrix_prepare(self):
        self.wait_intro()
        start = time.time()
        while time.time() - start < self.MATRIX_PREPARE_CAP:
            self.cycle_start()
            self.check_combat()
            if self.resonance_blue() or self.judge_forte() >= 3:
                break
            self.click()
            self.cycle_sleep()
        # 日志中judge_forte持续返回0，不能再将它作为释放技能的唯一前提。
        if not self.resonance_blue() and self.resonance_available():
            if self.click_resonance(time_out=1.2)[0]:
                self.continues_normal_attack(0.8)

    def matrix_finish(self):
        self.wait_intro()
        if not self.resonance_blue():
            self.continues_normal_attack(0.7 if self.has_intro else 1.4)
        start = time.time()
        last_skill = start - 2.0
        last_ultimate_attempt = start - 2.0
        last_echo_attempt = start - 2.0
        ultimate_used = False
        while (
            time.time() - start < self.MATRIX_FINISH_CAP * 2
            and self.time_elapsed_accounting_for_freeze(start) < self.MATRIX_FINISH_CAP
        ):
            self.cycle_start()
            self.check_combat()
            self.task.next_frame()
            # 优先释放折枝大招；不再受珂莱塔get_ready/回路识别为0的门控。
            if (
                not ultimate_used and self.task.use_liberation
                and time.time() - last_ultimate_attempt >= 1.0
                and self.liberation_available()
            ):
                last_ultimate_attempt = time.time()
                ultimate_used = bool(self.click_liberation(wait_if_cd_ready=0))
            if self.task.is_con_full():
                self.logger.info(f'CZB-FIX: Zhezhi ready; ultimate={ultimate_used}')
                return True
            if self.resonance_blue() and self.resonance_available():
                self.resonance_until_not_blue()
                last_skill = time.time()
            elif self.resonance_available() and time.time() - last_skill >= 1.0:
                # 仍检查技能可用；段数失读时用预铺普攻后的技能尝试作为兜底。
                skill_result = self.click_resonance(time_out=1.2)
                if skill_result[0]:
                    # 这里只表示原生方法发出了技能，不把发键次数当作命中。
                    self.logger.info('CZB-FIX11: Zhezhi E input accepted; entering heavy/followups')
                    self.task.mouse_down()
                    try:
                        self.sleep(0.65)
                    finally:
                        self.task.mouse_up()
                    self.matrix_feather_followups()
                else:
                    # 原流程即使E返回False也强制重击+派生约2.25秒。
                    self.logger.info('CZB-FIX11: Zhezhi E returned false; normal attack instead of forced followups')
                    self.click()
                last_skill = time.time()
            else:
                self.click()
            if time.time() - last_echo_attempt >= 2.0:
                self.click_echo(time_out=0)
                last_echo_attempt = time.time()
            self.cycle_sleep()
        return self.matrix_fill_concerto()

    def matrix_feather_followups(self):
        """初始E和重击后衔接派生E，避免蓝色提示失读时只剩普攻补协奏。"""
        start = time.time()
        presses = 0
        next_jump = start + 0.4
        previous_skip = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        try:
            self.task.mouse_down()
            while time.time() - start < 1.6:
                self.task.next_frame()
                if self.task.is_con_full():
                    break
                # 仅用于刚完成本角色E+重击的短窗口，不依赖普通E的冷却读数。
                self.send_resonance_key()
                presses += 1
                if time.time() >= next_jump:
                    self.task.jump(after_sleep=0.01)
                    next_jump = time.time() + 0.4
                self.task.sleep(0.12)
        finally:
            self.task.mouse_up()
            self.task.skip_combat_check = previous_skip
        self.logger.info(
            f'CZB-FIX6: Zhezhi feather followups E_inputs={presses}, '
            f'wall={time.time() - start:.2f}s'
        )

    def matrix_fill_concerto(self):
        start = time.time()
        extended = False
        while time.time() - start < self.MATRIX_CON_FILL_CAP + 2.0:
            self.task.next_frame()
            if self.task.is_con_full():
                self.logger.info(
                    f'CZB-FIX8: Zhezhi concerto tail confirmed; wall={time.time() - start:.2f}s'
                )
                return True
            elapsed = time.time() - start
            if elapsed >= self.MATRIX_CON_FILL_CAP:
                # 99%不等于满协奏。只在近满时给予一次额外普攻窗口。
                if not extended:
                    if float(self.task.get_current_con()) < 0.95:
                        break
                    extended = True
                    self.logger.info('CZB-FIX8: Zhezhi near-full concerto; extending tail by up to 2s')
            self.check_combat()
            self.click()
            self.sleep(0.1)
        self.task.next_frame()
        if self.task.is_con_full():
            return True
        self.logger.warning('CZB-FIX8: concerto tail capped; no intro will be fabricated')
        return False

    def resonance_until_not_blue(self):
        start = time.time()
        next_jump = start + 0.4
        self.task.mouse_down()
        try:
            while time.time() - start < 4.0:
                self.check_combat()
                self.task.next_frame()
                if not self.resonance_blue() or not self.resonance_available():
                    break
                self.send_resonance_key()
                if self.task.is_con_full():
                    break
                if time.time() >= next_jump:
                    self.task.jump(after_sleep=0.01)
                    next_jump = time.time() + 0.4
                self.sleep(0.1)
        finally:
            self.task.mouse_up()

    def switch_next_char(self, *args, **kwargs):
        if getattr(self, '_matrix_capture_switch', False):
            return None
        native_switch = super().switch_next_char
        controller = self.matrix_controller()
        if controller is None:
            return native_switch(*args, **kwargs)
        return controller.matrix_switch_hud_guard(lambda: native_switch(*args, **kwargs))

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        controller = self.matrix_controller()
        if controller is None:
            return super().get_switch_priority(current_char, has_intro, target_low_con)
        return SwitchPriority.MUST if controller.matrix_target() == self.name else SwitchPriority.NO
