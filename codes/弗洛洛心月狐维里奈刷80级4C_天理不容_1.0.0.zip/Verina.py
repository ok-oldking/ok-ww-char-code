from src.char.BaseChar import SwitchPriority
from src.char.Verina import Verina as NativeVerina


class Verina(NativeVerina):
    """弗心维(弗洛洛 / 心月狐 / 维里奈)里的维里奈。非本队时整套走原版。

    【她不驱动任何一段轴】: 宏体在同目录的 Hsin.py。启动轴第一格就是她的
    R(亮才放) -> E -> Q -> 跳A, 每一只 4C 都从她开场。所以她 keep 默认的 is_healer ——
    框架开战前的 switch_healer() 会先把奶妈切上来, 正好省掉宏的一次切人。
    怪死了也是切回她(用户: "死了就切维里奈")。
    """

    @property
    def is_in_fxw(self) -> bool:
        members = 0
        for char in self.task.chars:
            if char and char.name in {'Hsin', 'Phrolova'}:
                members += 1
        return members == 2

    def macro(self):
        """持宏的心月狐。那份自定义没启用时返回 None, 走原版。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'drive') and hasattr(char, 'quick_switch'):
                return char
        return None

    def reset_state(self):
        super().reset_state()
        # 【必须写在 reset_state 里】: 换类时内置实例的字段会整体拷过来, 改过的值被打回内置值
        self.check_f_on_switch = False

    def do_perform(self):
        if not self.is_in_fxw:
            return super().do_perform()
        self.check_f_on_switch = False
        macro = self.macro()
        if macro is None:
            self.logger.warning('fxw: Hsin custom code is off, falling back to the native rotation')
            return super().do_perform()
        macro.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时返回 MUST: 启动轴第一格就是她的 E -> Q -> 跳A。【要写在 super() 之前】"""
        if self.is_in_fxw:
            macro = self.macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
