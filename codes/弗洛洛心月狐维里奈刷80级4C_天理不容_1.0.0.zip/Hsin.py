import ctypes
import threading
import time

import cv2
import numpy as np

from src.Labels import Labels
from src.char.BaseChar import SwitchPriority
from src.char.Hsin import Hsin as NativeHsin

# ==================== 物理 F 键监视 ====================
# 跟 Iuno__JingRan__ShoreKeeper/JingRan.py 里那份逐字相同, 说明见 Chisa__Suisui__YangYangSp/YangYangSp.py。
F_VK = 0x46              # 'F'
F_POLL_INTERVAL = 0.05   # 一次按键按住的时间远大于这个, 不会漏采
F_LOG_DEBOUNCE = 1.0     # 按住不放时别刷日志
F_TASK_NAME = 'FStartCombatTask'


def f_settings(task):
    """读界面上的(开关, F 之后等待秒数)。没装那张卡片就返回默认值(开, 0 秒)。"""
    executor = getattr(task, 'executor', None)
    for group in ('trigger_tasks', 'onetime_tasks'):
        for other in getattr(executor, group, None) or ():
            if type(other).__name__ == F_TASK_NAME:
                try:
                    return bool(other.enabled), float(getattr(other, 'f_start_delay', 0) or 0)
                except Exception:
                    return True, 0.0
    return True, 0.0


# ==================== 自动战斗开关监视 ====================
# 【玩家手动开关自动战斗, 必须从启动轴重跑】。手动停任务不走 combat_end(), opener_armed 会跨局留在
# False, 而角色对象常被粘性复用、reset_state() 不跑。只有独立线程能观察到 enabled 的 True->False->True。
ENABLE_POLL_INTERVAL = 0.2


def start_enable_watch(task, logger=None):
    """盯 task.enabled 的 False->True 跳变, 把时刻记到 task._ww_task_restarted_at。每个 task 只启一次。"""
    if getattr(task, '_ww_enable_watch_started', False):
        return
    task._ww_enable_watch_started = True
    if not hasattr(task, '_ww_task_restarted_at'):
        task._ww_task_restarted_at = -1

    def watch():
        was_on = None
        while True:
            try:
                now_on = bool(getattr(task, 'enabled', False))
                if was_on is False and now_on:
                    task._ww_task_restarted_at = time.time()
                    if logger:
                        logger.info('auto combat re-enabled -> opener re-armed')
                was_on = now_on
                time.sleep(ENABLE_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='ok_ww_enable_watch', daemon=True).start()


def start_f_watch(task, logger=None):
    """把【物理】F 键按下的墙钟时间记到 task._f_last_press。每个 task 只启一次。"""
    if getattr(task, '_f_watch_started', False):
        return
    task._f_watch_started = True
    if not hasattr(task, '_f_last_press'):
        # -1 = 从没按过, 跟 last_opener 的"没跑过"对齐(给 0 的话开局第一次判定恒成立)
        task._f_last_press = -1

    def watch():
        try:
            user32 = ctypes.windll.user32
            user32.GetAsyncKeyState.restype = ctypes.c_short
        except Exception as e:
            task._f_watch_started = False
            if logger:
                logger.error(f'f watch: GetAsyncKeyState unavailable ({e}), '
                             f'the "press F to re-arm the opener" shortcut stays off')
            return
        last_log = 0
        was_down = False
        while True:
            try:
                down = bool(user32.GetAsyncKeyState(F_VK) & 0x8000)
                if down and not was_down and f_settings(task)[0]:
                    now = time.time()
                    # 宏正在跑 = 正在战斗, 这下 F 是玩家手动处决, 不是重开副本
                    if (getattr(task, '_three_fire_macro_busy', False)
                            or getattr(task, '_ww_macro_busy', False)):
                        if logger and now - last_log >= F_LOG_DEBOUNCE:
                            last_log = now
                            logger.info('physical F pressed while the macro is running '
                                        '(manual execution) - opener NOT re-armed')
                        was_down = down
                        time.sleep(F_POLL_INTERVAL)
                        continue
                    task._f_last_press = now
                    task._f_pressed_at = now
                    if logger and now - last_log >= F_LOG_DEBOUNCE:
                        last_log = now
                        logger.info('physical F pressed, opener re-armed')
                was_down = down
                time.sleep(F_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='ok_ww_f_watch', daemon=True).start()

# ==================== SendInput 左键(心的两段长按用) ====================
# 结构体照搬 Iuno__JingRan__ShoreKeeper/JingRan.py。
_INPUT_MOUSE = 0
_MOUSEEVENTF_LEFTDOWN = 0x0002
_MOUSEEVENTF_LEFTUP = 0x0004


class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [('wVk', ctypes.c_ushort), ('wScan', ctypes.c_ushort), ('dwFlags', ctypes.c_ulong),
                ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [('dx', ctypes.c_long), ('dy', ctypes.c_long), ('mouseData', ctypes.c_ulong),
                ('dwFlags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class _HARDWAREINPUT(ctypes.Structure):
    _fields_ = [('uMsg', ctypes.c_ulong), ('wParamH', ctypes.c_ushort), ('wParamL', ctypes.c_ushort)]


class _INPUTUNION(ctypes.Union):
    _fields_ = [('ki', _KEYBDINPUT), ('mi', _MOUSEINPUT), ('hi', _HARDWAREINPUT)]


class _INPUT(ctypes.Structure):
    _fields_ = [('type', ctypes.c_ulong), ('u', _INPUTUNION)]


def send_input_left(up):
    """系统级左键按下/抬起。返回是否发出去了(发不出去调用方退回 PostMessage)。"""
    try:
        inp = _INPUT(type=_INPUT_MOUSE)
        inp.u.mi = _MOUSEINPUT(0, 0, 0, _MOUSEEVENTF_LEFTUP if up else _MOUSEEVENTF_LEFTDOWN, 0, 0)
        return ctypes.windll.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT)) == 1
    except Exception:
        return False


class MacroBroken(Exception):
    """某一步切人没成功 / HUD 长时间不在, 后面的按键会落在错的人身上 —— 整圈放弃, 交回框架。"""


class Hsin(NativeHsin):
    """弗心维(弗洛洛 / 心月狐 / 维里奈)刷 4C 队伍代码, 持宏: 心月狐(Hsin)。

    ================= 轴的出处 =================
    用户 2026-10-28 口述(第 2 版, 覆盖第 1 版): "维里奈开场 REQ 跳A, 如果 R 没有就只 EQ 或者只 E 跳A,
    协奏满了后切弗洛洛; 弗洛洛入场E 强化普攻 再重击, 切心月狐 重击Q; 如果没死就平A, 死了就切维里奈"。
    Q = 声骸技能(默认键 Q), 重击 = 长按左键。心的"重击"= 应世心满之后的强化重击【步红尘】。
    配置: 心月狐 3 链 / 弗洛洛 2 链 / 维里奈 4 链; 心用【共鸣模态·电磁】。
    【没有攻略视频和宏截图】: 时长是按同角色已有轴的实机结论 + 帧表估的, 第一次实机先看时间轴。

    ================= 轴的形状(每一只 4C 各跑一遍) =================
    启动轴:
      维里奈 R(亮才放, 没能量就跳过) -> E -> Q(声骸) -> 跳A(起跳 + 3 下普攻, 循环) 到协奏真满 -> 变奏弗洛洛
      弗洛洛 E -> 强化普攻 -> 按住到强化重击出(重击位图标灭) -> [R 默认关] -> 变奏心月狐
      心月狐 普攻到应世心满(花图标) -> 按住到应世心清空(= 步红尘出手) -> Q(声骸)
      平A 收尾: 没死就一直普攻; 怪死了就切维里奈
    没打死就一直停在收尾格(每 ~6s 一轮, 框架会马上再调进来); 打死脱战后框架 combat_end ->
    每个角色 reset_state -> 启动轴重新武装, 下一只重跑。所以【每一只 4C 都是从维里奈开始】。

    ================= 为什么这么打 =================
    - 维里奈 R 是先手增伤/治疗, 有就放(没能量就跳过, 不为它等); 跳A 是刷 4C 攒协奏最快的形状
      (弗维刷4C 的 scheme3 也是 E -> Q -> 跳 -> A)。
    - 心的应世心上限 100, 变奏入场直接给 60, 剩下的靠普攻; 满了才出步红尘(3 链强化重击是大头)。
      所以弗洛洛那格必须【协奏满再切】—— 不是变奏进来的话心要多打半轮普攻才满。
    - 心不开转相/照世相(用户只要 步红尘): 步红尘 之后 R 会解锁, 这条轴不管它, 下一圈照样能用。
    - 心的 Q(声骸) 放在步红尘 之后按(XN1_Q_AFTER): 步红尘 的演出里按键会被吞掉, 而声骸是瞬发,
      收招走完再按正好补在伤害空档上。想改回"Q 先"把 XN1_Q_AFTER 置 False。
    - 弗洛洛这格【不按 Q(声骸)、不放大招】: 用户第 2 版只写了 "E 强化普攻 再重击", 打完就切心。
      想加回来: PH_ECHO_Q = True / PH_R_AFTER_HEAVY = True。

    ================= 判据 =================
    - 协奏满: task.get_current_con() 连读 CON_FULL_CONFIRM 帧都 >= 1.0(0.99 是"环没闭合"的哨兵值)。
    - 维里奈 R: liberation_available() 连读 2 帧亮才发(fire_r 一直按到 HUD 连续消失); 不亮直接跳过。
    - 弗洛洛强化重击: 重击位 mouse_forte 图标亮 -> 按住 -> 图标连续灭 = 消耗掉。先确认"亮过"才认"灭"。
    - 心应世心满: hsin_h1(花图标) 或 应世心条右半 >= XN_YING_READY; 步红尘出手 = 条被清空(左半 < XN_CONSUMED)。
    - 怪死了: 收尾格读 task.in_combat(), 一旦 False 就切维里奈收场(不抛 NotInCombatException —— 抛出去
      宏就断了, 切人都来不及)。

    ================= 改这个文件之前先读 =================
    - 引擎(macro_* / quick_switch / fire_r / wait_hud_back ...)和心的判据(xn_*)逐字抄自
      skill 自带 assets/reference_team/Hsin__Rover__Suisui/Hsin.py(心雷穗 v1.0.0), 改之前对一下那条轴。
    - 【自定义 __init__ 里跟内置版不同的字段会被打回内置值】, 要保住就在 reset_state() 里重申。
    - 普攻一律走 tap()(按住 A_TAP 秒): task.click() 只按 10ms, 打不出来。
    - 长按期间不调 click()/mouse_down()/send_key() —— 它们先投 WM_ACTIVATE, 会把按住打断。
    """

    # ==================== 全局节奏(引擎用) ====================
    A_INTERVAL = 0.12
    KEY_INTERVAL = 0.10
    A_TAP = 0.06                 # 普攻按住这么久才算一下; task.click() 的 10ms 会被吞

    # ---- 切人 ----
    SWITCH_TIME_OUT = 2.5
    SWITCH_KEY_DOWN_TIME = 0.02
    SWITCH_KEY_INTERVAL = 0.0
    UNTRUSTED_CONFIRM = 3
    TRACE_SWITCH = True

    # ---- 大招 / 演出 ----
    LIB_KEY_INTERVAL = 0.03
    LIB_ANIM_TIME_OUT = 8.0
    HUD_NO_ANIM_GRACE = 0.35
    LIB_GONE_CONFIRM = 3         # HUD 连续这么多帧不在 = 演出真的开始了
    HUD_UP_CAP = 1.0
    HUD_BACK_CONFIRM = 2

    # ---- 杂项 ----
    CON_SAMPLE_MAX = 24
    FIELD_SETTLE_TIME_OUT = 1.5
    E_RESEND_STEP = 0.06
    SKILL_BAR_SETTLE = 0.40
    M_E_KEY_DOWN = 0.05
    CON_ENOUGH = 1.0
    CON_FULL_CONFIRM = 3
    CON_POLL = 0.03

    # ==================== 防重入 ====================
    # 【刷 4C 一局只有十几秒】: 心雷穗那份的 60s 门槛会把下一只的启动轴挡掉, 这里压到 2s(只防战斗判定抖动)
    OPENER_MIN_GAP = 2.0

    # ==================== 保底 ====================
    # 只花时间的默认开; 会改游戏状态的(补技能/多打普攻)只在判据明确说没出去时补
    SWITCH_RETRIES = 2
    SWITCH_RETRY_TIME_OUT = 3.00
    HUD_LOST_ABORT = 9.00
    DRIVE_HUD_CAP = 1.50
    R_TRIES = 3
    R_BLIND_EVERY = 3
    R_BLIND_WINDOW = 0.40
    R_BUILD_SLICE = 0.60

    # ==================== 维里奈 ====================
    VER_R_AT = 0.45              # 到场之后这么久才读 R(切人后技能栏要 ~0.4s 才换成她的, 早了读到上一个人的)
    VER_R_GATE = 1.20            # 读 R 的总窗口: 亮得晚一点也等它一下(真的没能量会很快读完)
    VER_R_READS = 3              # 最多读几次(每次 2 连续帧)
    VER_R_WINDOW = 1.60          # 发 R 的按键窗口(fire_r)
    VER_R_ANIM_MIN = 0.60        # 维里奈 R 演出藏 HUD: 这么久之内读到的"回来"不认
    VER_R_ANIM_CAP = 4.00
    VER_E_AFTER_R = 0.20         # R 演出回来给一拍再按 E(收招里按的技能会被丢)
    VER_E_AT = 0.12              # 到场之后这么久才按 E(变奏入场前几十帧按的键会被吞)
    VER_E_WINDOW = 0.25          # E 连发两下: 入场/收招期间按的键被丢, 不排队
    VER_Q_SETTLE = 0.20          # E 放完给一拍再按 Q(两个技能抢同一个动作位)
    VER_Q_WINDOW = 0.20
    VER_JUMP_A = 0.45            # 一次跳A: 起跳后连点普攻这么久(约 3 下)
    VER_A_EVERY = 0.12
    VER_CON_CAP = 7.00           # 跳A 攒协奏的上限。4 链维里奈估 2~4s, 留一倍余量(到上限照切)
    VER_CON_CONFIRM = 3          # 连读这么多帧 1.0 才算满(0.99 = 环还没闭合)

    # ==================== 弗洛洛 ====================
    PH_E_AT = 0.30               # 到场之后这么久才按 E。变奏入场的 QTE 锁(~0.3s)会把紧跟着的键吞掉
    PH_E_WINDOW = 0.25           # E 连发两下
    PH_E_SETTLE = 0.15           # E 放完给一拍再开始强化普攻
    PH_FORTE_A = 0.90            # 强化普攻窗口: E 之后这几下普攻是强化版(用户: "E 强化普攻 再重击")
    PH_ECHO_Q = False            # 声骸 Q。用户第 2 版没提, 默认不按(想加就 True)
    PH_Q_WINDOW = 0.20           # Q(声骸) 连发两下
    PH_Q_SETTLE = 0.20           # Q 之后给一拍: 声骸召唤出来才解锁强化重击
    PH_FILL_A = 0.35             # 图标没亮先补普攻的窗口(强化普攻打完那一拍)
    PH_HEAVY_CAP = 2.60          # 按住到强化重击消耗掉的上限(弗维刷4C 实测 1.2~1.8s)
    PH_HEAVY_BLIND = 1.00        # 图标一次都没亮过: 按住这么久就松手, 别白按 2.6s
    PH_FORTE_CONFIRM = 2         # 图标连续这么多帧灭才算"消耗掉了"
    PH_R_AFTER_HEAVY = False     # 强化重击之后 R 会解锁(赫卡忒)。用户: "再重击 切心月狐" -> 默认不放
    PH_R_WAIT = 1.20             # 等 R 亮的窗口(强化重击收招里按 R 会被吞)
    PH_R_WINDOW = 1.60
    PH_R_ANIM_MIN = 1.20         # 赫卡忒演出藏 HUD ~2s, 回来连读 2 帧才算
    PH_R_ANIM_CAP = 5.00
    PH_TAIL = 0.30               # 强化重击出手后留给收招
    PH_CON_CAP = 1.60            # 切心之前把协奏补满的上限(补不满照切)

    # ==================== 心月狐(心) ====================
    # ---- 应世心条(4K 坐标, hcenter): 回路条中间徽记左右两半的紫色格子 ----
    XN_GAUGE_L = (1627, 1999, 1837, 2011)
    XN_GAUGE_R = (1965, 1999, 2175, 2011)
    XN_GAUGE_VALID = 0.50        # 左半 >= 这个才算"在应世相、读数可信"
    XN_YING_READY = 0.70         # 右半到这么多就算到线
    XN_CONSUMED = 0.15           # 按住之后左半掉到这个以下 = 整条清空 = 步红尘出手
    XN_FULL_THRESHOLD = 0.70     # hsin_h1(应世心满的花图标)
    XN_HOLD_SENDINPUT = True     # 长按走 SendInput: PostMessage 的按下沿落在普攻收招里会被丢掉
    XN1_Q_AT = 0.30
    XN1_Q_WINDOW = 0.15
    XN1_Q_AFTER = True           # Q(声骸) 按在步红尘 之后(用户第 2 版: "重击Q")。改 False 就回到"Q 先"
    XN1_Q_WINDOW_AFTER = 0.50    # 步红尘 收招回来之后按 Q 的窗口(比入场宽: 这时的按键更容易被吞)
    XN1_Q_DELAY = 0.10           # 收招回来给一拍再按 Q
    XN1_A_FROM = 0.45
    XN1_A_EVERY = 0.17
    XN1_A_HOLD = 0.08
    XN1_GATE_CONFIRM = 2         # 连读这么多帧满/到线才算(特效扫过会闪)
    XN1_HOLD_AT_MIN = 1.90       # 满了也至少打到这一刻再按住(a4 打完)
    XN1_A_CAP = 4.50             # 一直不满就打到这一刻照按
    XN1_LAST_A_GAP = 0.12        # 最后一下普攻和按住之间至少隔这么久(按下沿别跟点击粘在一起)
    XN1_HOLD = 1.80              # 按住时长: 步红尘免疫打断, 按久了不耽误切人
    XN1_RETRIES = 2              # 按满条都没清空(= 出的是普通重击) -> 补两下 A 再按
    XN1_RETRY_A = 2
    XN1_FILL_EVERY = 0.40
    XN1_TAIL = 0.35              # 步红尘出手后留给收招再切人
    # 步红尘 的收招还会挡切人(被拒一次要重试 ~2.5s): 先等 HUD 回来(没有演出就 0.35s 直接过)
    XN1_TAIL_HUD_MIN = 0.25
    XN1_TAIL_HUD_CAP = 1.50

    # ==================== 收尾格(心月狐站场: 没死平A / 死了切维) ====================
    XN_LOOP_CAP = 6.00           # 收尾格一轮的时长(之后框架会马上再调进来)
    XN_LOOP_HUD_LOST_HITS = 4    # HUD 连续这么多轮读不到(约 0.6s) = 结算/过场, 立刻停手
    XN_LOOP_DEAD_POLL = 0.30     # 多久读一次 in_combat(这个判据比普攻贵, 不用每帧读)
    XN_LOOP_DEAD_CONFIRM = 3     # 连读这么多帧"不在战斗"才认怪死了(怪跳走/特效挡一帧会误判, 0.9s 够复活)
    XN_LOOP_SWITCH_TIMEOUT = 1.20  # 死了切维里奈的超时(切不过去就交给框架的 switch_healer)

    def macro_wait(self, sec):
        """精确等待, 【不点击】。切成 0.1 秒一片, 片间检查任务是否被停用。"""
        if sec <= 0:
            self.task.executor.check_enabled(check_pause=False)
            return
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)

    def wait_until_time(self, deadline):
        self.macro_wait(deadline - time.time())

    def macro_start(self):
        self.macro_t0 = time.time()
        self.macro_marks = []

    def macro_mark(self, name):
        self.macro_marks.append(f'{name}@{time.time() - self.macro_t0:.2f}')
        # 【看门狗】每一步都会打标记, 在这里顺手查: HUD 很久没出现 = 关卡结束/过场/窗口没了,
        # 再按下去就是在结算画面上乱按(景月守实机 2026-09-28 19:17 见过)。不读屏, 只比时间戳
        if self.hud_watch and time.time() - self.hud_seen_at > self.HUD_LOST_ABORT:
            self.hud_watch = False
            raise MacroBroken(f'队伍 HUD {time.time() - self.hud_seen_at:.1f}s 没出现(关卡结束/过场/窗口没了?)')

    def hud_ok(self):
        """队伍 HUD 在不在(读当前帧)。见到就记下时刻, 给看门狗用。"""
        ok = bool(self.task.in_team()[0])
        if ok:
            self.hud_seen_at = time.time()
        return ok

    def macro_timeline(self, since=0):
        return ' '.join(self.macro_marks[since:])

    def macro_spam(self, window, interval=None, tag='A'):
        """连点一个窗口。打出几段由 window 决定(动画期间的点击被丢掉, 连点保证总有一下落在动画刚结束时)。"""
        interval = self.A_INTERVAL if interval is None else interval
        start = time.time()
        n = 0
        cap = int(window / max(interval, 0.01)) + 2
        while time.time() - start < window and n < cap:
            self.click()
            n += 1
            remaining = window - (time.time() - start)
            if remaining <= 0:
                break
            # click 自己按住 A_TAP 秒, 不扣的话连点周期从 interval 变成 interval + A_TAP
            self.macro_wait(min(max(0.0, interval - self.A_TAP), remaining))
        self.macro_mark(f'{tag}(x{n})')
        return n

    def spam_key(self, send, window, interval=None, tag='key', poke=None, presses=None,
                 click_interval=None, stop_when=None):
        """在一个窗口里反复发同一个技能键, 用来盖住动画那一段。

        动画期间的按键是被丢掉的、不排队, 所以单发必丢 —— 这个形状在爱琳莫那条轴上
        踩到过六次, 症状统一是"那一步慢了"(要等整个动画演完才有第二次机会)。

        【必须在这个角色自己的回合里跑完, 不要跟切人并行】: 切人期间发出去的键会被
        游戏带过换人边界落在新角色身上。点击可以并行(quick_switch 的 click_during),
        技能键不行。唯一的例外是 switch_into_lib()。

        Args:
            poke: 发键期间要不要照常点普攻(默认不点)。
            click_interval: 点普攻的间隔, 默认 A_INTERVAL。给 A_INTERVAL_FAST
                就是"技能键按自己的节奏、普攻按加密节奏", 两条流互不影响。
            stop_when: 每发一次键之后调一次, 返回 True 就停。用在【多按一下会
                烧掉后面要用的充能】的地方 —— 一旦读到技能已经不可用就立刻收手。
                【会读屏, 别配太密的 interval】。
            presses: 只发这么多次, 均匀铺在窗口里。用在"连续点按两次E"那种
                【次数本身有意义】的地方 —— 连发会把两发挤成一发。
                【给了 presses 就由它说了算, window 只用来推间隔】: 否则
                window=0(要求两发贴着发)会在第一发之后就把循环停掉, 变成单发。
        """
        interval = self.KEY_INTERVAL if interval is None else interval
        poke = bool(poke)
        click_interval = self.A_INTERVAL if click_interval is None else click_interval
        if presses is not None and presses > 0:
            interval = max(interval, window / presses)
        start = time.time()
        n = 0
        clicks = 0
        next_click = 0.0
        while True:
            send()
            n += 1
            if stop_when is not None and stop_when():
                break
            if presses is not None:
                if n >= presses:
                    break
                left = interval
            else:
                left = window - (time.time() - start)
                if left <= 0:
                    break
            step_end = time.time() + min(interval, left)
            # 发键的节奏和点击的节奏各走各的 —— 挂在一起的话点击会被技能键的
            # 间隔卡住(爱琳莫那边 R 被 E2_POLL 卡住就是这个)
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + click_interval
                self.macro_wait(min(0.02, step_end - time.time()))
        # 【点击数也要打进去】: x{n} 只数了技能键, 看不出这段时间有没有在持续普攻。
        # 用户 2026-08-16 问过一次"E的期间也要一直普攻" —— 实际一直在点,
        # 只是日志里看不见。A x0 就是真的没点(poke=False 的那几格)
        self.macro_mark(f'{tag}(x{n},A x{clicks})')
        return n

    def game_foreground(self):
        try:
            return bool(self.task.executor.interaction.hwnd_window.is_foreground())
        except Exception:
            return False

    def attack_down(self, direct):
        """按下左键。direct = 走 SendInput(失败自动退回 PostMessage)。返回实际走没走 SendInput。"""
        if direct and send_input_left(False):
            self.si_holding = True
        else:
            direct = False
            self.task.mouse_down()
        self.holding_attack = True
        return direct

    def release_attack(self):
        # 【SendInput 按下的必须 SendInput 松开】: PostMessage 的 mouse_up 只进游戏窗口的消息队列,
        # 系统里那个左键会一直按着 —— 宏异常退出时整台电脑的左键都是按住的
        if self.si_holding:
            if not send_input_left(True):
                self.logger.warning('SendInput 左键松开没发出去 — 如果左键卡住, 手动点一下')
            self.si_holding = False
            self.holding_attack = False
        elif self.holding_attack:
            self.task.mouse_up()
            self.holding_attack = False

    def tap(self, hold=None):
        """点一下普攻, 【真的按住 hold 秒】。"""
        hold = self.A_TAP if hold is None else hold
        self.task.mouse_down()
        self.holding_attack = True
        try:
            self.macro_wait(hold)
        finally:
            self.task.mouse_up()
            self.holding_attack = False

    def click(self, *args, **kwargs):
        """本队里所有的 self.click() 都改成按住 A_TAP(BaseChar.click 强制 10ms, 等于没点)。不在本队走原版。"""
        if not self.is_in_fxw:
            return super().click(*args, **kwargs)
        self.tap()

    def quick_switch(self, target, click_during=False, time_out=None, read_con=False, assume_con=False):
        """按数字键直切给指定角色(不走 switch_next_char 选人)。

        read_con: 按键之后读一次协奏决定按不按"带变奏"记账; assume_con: 不读屏直接按满协奏记。
        Returns: 是否真的切过去了。
        """
        if target is None:
            return False
        if target is self.cur:
            self.macro_mark(f'>{target.name[:3]}(already)')
            return True
        entry = time.time()
        time_out = self.SWITCH_TIME_OUT if time_out is None else time_out
        source = self.cur if self.cur is not None else self
        slot = target.index + 1
        self.switch_press_at = time.time()
        self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
        if assume_con:
            con_full = True
        elif read_con:
            # 不用 char.is_con_full(): 那层读到过一次满就一直缓存成满
            try:
                con_full = float(self.task.get_current_con()) >= 1.0
            except Exception:
                con_full = False
        else:
            con_full = False
        con_cost = time.time() - entry

        start = time.time()
        last = start
        next_click = 0.0
        trace = [] if self.TRACE_SWITCH else None
        team_size = len([c for c in self.task.chars if c is not None])
        untrusted_hits = 0
        clicks = 0
        while time.time() - start < time_out:
            now = time.time()
            if now - last >= self.SWITCH_KEY_INTERVAL:
                self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
                last = now
            if click_during and now >= next_click:
                self.click()
                clicks += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            hit = in_team and index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if trace is not None:
                trace.append(f'{time.time() - start:.2f}:'
                             f'{(index if trusted else f"?{index}") if in_team else "x"}')
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                self.handoff(source, target, con_full)
                self.macro_mark(f'>{target.name[:3]}{"^" if con_full else ""}'
                                f'({time.time() - entry:.2f}|con{con_cost:.2f}|A x{clicks})')
                if trace and time.time() - entry > 0.4:
                    self.logger.info(f'slow switch trace -> {target.name}: {" ".join(trace)}')
                return True
        # 一直是旧角色的 index = 游戏在拒绝切人; 带 ? 的都是目标 = count 判据挡住了; 全是 x = HUD 不在
        self.logger.warning(f'switch to {target.name} slot {slot} timed out '
                            f'after {time_out:.1f}s (stuck in an animation?)'
                            + (f' trace: {" ".join(trace)}' if trace else ''))
        self.macro_mark(f'>{target.name[:3]}FAIL')
        return False

    def handoff(self, from_char, to_char, con_full):
        """复刻 switch_next_char() 尾部那套交接记账。不补的话 get_current_char() 返回 None, 主循环当场崩。"""
        self.task.in_liberation = False
        from_char.switch_out(con_full=con_full)
        to_char.is_current_char = True
        to_char.has_intro = con_full
        to_char.has_sub_dps_intro = con_full and from_char.is_sub_dps
        to_char.last_switch_in_time = time.time()
        if con_full:
            now = time.time()
            self.task.add_freeze_duration(now, to_char.intro_motion_freeze_duration, -100)
            from_char.last_outro_time = now
        self.cur = to_char

    def switch_retry(self, target, tag, **kw):
        """quick_switch, 超时了先等 HUD 回来再切, 最多再试 SWITCH_RETRIES 次。只花时间。"""
        if self.quick_switch(target, **kw):
            return True
        for i in range(self.SWITCH_RETRIES):
            self.wait_hud_up(cap=2.0, tag=f'{tag}重切前HUD')
            self.macro_mark(f'{tag}切{target.name[:3]}重试#{i + 1}')
            kw2 = dict(kw)
            kw2['time_out'] = self.SWITCH_RETRY_TIME_OUT
            if self.quick_switch(target, **kw2):
                return True
        return False

    def wait_hud_back(self, tag='anim', time_out=None, min_gone=0.0, tail=0.0):
        """等演出结束(队伍 HUD 回来), 【期间一下都不点】。先确认消失过。

        min_gone: 从第一次读到消失起, 这么久之内读到的"回来"不认(演出中途 HUD 会闪一两帧)。
        回来要连读 HUD_BACK_CONFIRM 帧。
        """
        time_out = self.LIB_ANIM_TIME_OUT if time_out is None else time_out
        start = time.time()
        gone_at = None
        back_hits = 0
        back = False
        while time.time() - start < time_out:
            self.task.next_frame()
            if not self.hud_ok():
                if gone_at is None:
                    gone_at = time.time()
                back_hits = 0
            elif gone_at is not None:
                if time.time() - gone_at >= min_gone:
                    back_hits += 1
                    if back_hits >= self.HUD_BACK_CONFIRM:
                        back = True
                        break
            elif time.time() - start >= self.HUD_NO_ANIM_GRACE:
                back = True
                break
            self.macro_wait(0.01)
        if gone_at is not None:
            self.add_freeze_duration(gone_at, time.time() - gone_at)
        self.macro_mark(f'{tag}({"ok" if back else "timeout"},'
                        f'{"anim" if gone_at is not None else "NOANIM"},{time.time() - start:.2f}s)')
        self.macro_wait(tail)
        return back

    def wait_hud_up(self, cap=None, tag='HUD'):
        """等队伍 HUD 【现在】在场。按 R 之前用 —— HUD 本来就不在的时候判"演出开始了"是假成功。"""
        cap = self.HUD_UP_CAP if cap is None else cap
        start = time.time()
        while time.time() - start < cap:
            self.task.next_frame()
            if self.hud_ok():
                if time.time() - start > 0.05:
                    self.macro_mark(f'{tag}在场({time.time() - start:.2f}s)')
                return True
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}一直不在({cap:.1f}s)')
        return False

    def watch_hud_gone(self, window, tag, poke_after=None):
        """在 window 里盯队伍 HUD 有没有连续消失(= 演出开始), 消失了立刻返回 True。

        poke_after: 过了这么久 HUD 还在就开始点普攻(这一下技能没出手, A 在攒资源)。None = 不点。
        """
        start = time.time()
        gone = clicks = 0
        next_click = 0.0
        while time.time() - start < window:
            self.task.next_frame()
            if not self.hud_ok():
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    self.macro_mark(f'{tag}(出手,{time.time() - start:.2f}s,A x{clicks})')
                    return True
            else:
                gone = 0
                now = time.time()
                if poke_after is not None and now - start >= poke_after and now >= next_click:
                    self.tap()
                    clicks += 1
                    next_click = time.time() + self.A_INTERVAL
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}(没出,A x{clicks})')
        return False

    def on_field_char(self, time_out=None):
        """现在场上是谁 —— 只在拿不到入口角色时才用(开局 HUD 渐入时 in_team() 会说谎, 要 count 达标)。"""
        time_out = self.FIELD_SETTLE_TIME_OUT if time_out is None else time_out
        expected = len([c for c in self.task.chars if c is not None])
        end = time.time() + time_out
        while True:
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            if in_team and count >= expected:
                for char in self.task.chars:
                    if char is not None and char.index == index:
                        return char
                return None
            if time.time() >= end:
                self.logger.warning(f'team HUD never settled in {time_out:.1f}s '
                                    f'(in_team={in_team} index={index} count={count} '
                                    f'expected={expected}), cannot tell who is on field')
                return None
            self.macro_wait(0.03)

    def mark_busy(self, busy):
        """F 键监视线程靠它区分"战斗中手动处决"和"重开副本"。"""
        self.task._ww_macro_busy = busy
        self.task._three_fire_macro_busy = busy

    def need(self, ok, what):
        if not ok:
            raise MacroBroken(what)

    def press_key_until_cd(self, send, available, cap, tag, ready_grace=0.15, poke=False):
        """一直按某个技能键到它进 CD。返回放出去了没有(本来就在 CD 上返回 False)。

        【先见过"亮"才认"暗"】: 刚切人那几帧技能栏还是上一个人的, 读到的是上一个人的 CD。
        """
        start = time.time()
        n = live = clicks = 0
        seen_ready = False
        next_click = 0.0
        while time.time() - start < cap:
            self.task.next_frame()
            hud = bool(self.hud_ok())
            if hud:
                if available():
                    seen_ready = True
                elif seen_ready and live > 0:
                    self.macro_mark(f'{tag}_ok(x{n},A x{clicks},{time.time() - start:.2f}s)')
                    return True
                elif not seen_ready and time.time() - start >= ready_grace:
                    self.macro_mark(f'{tag}_没见过亮(x{n},{time.time() - start:.2f}s)')
                    return False
            send()
            n += 1
            if hud:
                live += 1
            step_end = time.time() + self.E_RESEND_STEP
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + self.A_INTERVAL
                self.macro_wait(min(0.02, step_end - now))
        self.macro_mark(f'{tag}_CD?(x{n},seen{int(seen_ready)},{cap:.1f}s)')
        self.logger.info(f'{tag}: never read as on-cooldown after {n} presses (seen ready={seen_ready})')
        return False

    def press_res_until_cd(self, char, cap, tag, ready_grace=None, poke=False):
        ready_grace = self.SKILL_BAR_SETTLE if ready_grace is None else ready_grace
        return self.press_key_until_cd(char.send_resonance_key, char.resonance_available, cap, tag,
                                       ready_grace=ready_grace, poke=poke)

    def fire_r(self, char, tag, window):
        """发大招到队伍 HUD【连续】消失 LIB_GONE_CONFIRM 帧。返回放出去没有。

        发键之前先等 HUD 在场(HUD 本来就不在会假成功)。确认期间继续按 R 没有副作用 —— 演出里的按键被丢掉。
        """
        self.wait_hud_up(tag=f'{tag}前HUD')
        start = time.time()
        self.lib_press_at = start
        n = gone = 0
        fired = False
        while time.time() - start < window:
            char.send_liberation_key()
            n += 1
            self.task.next_frame()
            if not self.hud_ok():
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    fired = True
                    break
            else:
                gone = 0
            self.macro_wait(self.LIB_KEY_INTERVAL)
        self.task.skip_combat_check = True
        if fired:
            char.record_liberation_use()
            self.macro_mark(f'{tag}_fired(x{n},{time.time() - start:.2f}s)')
            return True
        self.macro_mark(f'{tag}_NOFIRE(x{n})')
        try:
            lit = bool(char.liberation_available())
        except Exception:
            lit = 'err'
        # lit=True: 键被上一个动作吞了; lit=False: 能量不够
        self.logger.warning(f'{tag}: {char.name} liberation never started an animation '
                            f'after {n} presses (icon lit={lit})')
        return False

    def lib_ready_reads(self, char, frames):
        """HUD 在场时连续 frames 帧读到 char 的 R 可用。HUD 不在的帧不算, 最多读 frames*3 帧。"""
        hits = 0
        for _ in range(frames * 3):
            self.task.next_frame()
            if self.hud_ok():
                try:
                    ready = bool(char.liberation_available())
                except Exception:
                    ready = False
                if not ready:
                    return False
                hits += 1
                if hits >= frames:
                    return True
            self.macro_wait(0.02)
        return False

    def ensure_r(self, char, tag, window, cap, build):
        """R 一定要放出来。读 R 亮 -> 按; 亮着却没放出去就再按, 最多 R_TRIES 次;
        不亮 -> build(轮次) 攒一小段再读, 每 R_BLIND_EVERY 轮盲按一次防读数不准。上限 cap 只防打不到怪。
        """
        start = time.time()
        tries = rounds = 0
        while time.time() - start < cap:
            if self.lib_ready_reads(char, 2):
                tries += 1
                if self.fire_r(char, f'{tag}R' if tries == 1 else f'{tag}R重按#{tries - 1}', window):
                    if rounds:
                        self.logger.info(f'{tag}: {char.name} R 攒了 {time.time() - start:.1f}s 能量才放出去')
                    return True
                if tries >= self.R_TRIES:
                    break
                continue
            rounds += 1
            if rounds == 1:
                self.macro_mark(f'{tag}R没亮(攒能量)')
            build(rounds)
            if rounds % self.R_BLIND_EVERY == 0 and not self.lib_ready_reads(char, 2) and \
                    self.fire_r(char, f'{tag}R盲按#{rounds}', self.R_BLIND_WINDOW):
                return True
        self.logger.warning(f'{tag}: {char.name} 的 R 保底 {time.time() - start:.1f}s 还是没放出去 '
                            f'(亮了按 {tries} 次, 攒能量 {rounds} 轮), 不放了')
        return False

    def read_cd(self, name='resonance', char=None):
        """读技能框里的 CD 数字(秒)。不在 CD / 读不到都返回 0(框架没 CD 时返回负数, 截成 0)。"""
        try:
            index = None if char is None else char.index
            return max(0.0, float(self.task.get_cd(name, index)))
        except Exception:
            return 0.0

    def read_con(self, want, settle=None, click=False, tag=None):
        """读协奏: 自己刷帧、给结算留时间, 连着几帧达到 want 就立刻返回。返回期间读到的最大值。"""
        settle = 0.50 if settle is None else settle
        start = time.time()
        best = 0.0
        hits = 0
        next_click = 0.0
        while True:
            now = time.time()
            if click and now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            self.hud_ok()
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            best = max(best, con)
            hits = hits + 1 if con >= want else 0
            if hits >= self.CON_FULL_CONFIRM or time.time() - start >= settle:
                break
            self.macro_wait(self.CON_POLL)
        if tag:
            self.macro_mark(f'{tag}(con{best:.2f},{time.time() - start:.2f}s)')
        return best

    def wait_con_full(self, who, cap, tag, poke=True):
        """边打边等协奏真满(连着几帧)。返回满没满。"""
        start = time.time()
        samples = []
        hits = 0
        next_click = 0.0
        while time.time() - start < cap:
            now = time.time()
            if poke and now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            self.hud_ok()
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            if len(samples) < self.CON_SAMPLE_MAX:
                samples.append(f'{time.time() - start:.2f}:{con:.2f}')
            hits = hits + 1 if con >= self.CON_ENOUGH else 0
            if hits >= self.CON_FULL_CONFIRM:
                self.macro_mark(f'{tag}(满,{time.time() - start:.2f}s)')
                return True
            self.macro_wait(self.CON_POLL)
        self.macro_mark(f'{tag}(没满,{time.time() - start:.2f}s)')
        self.logger.info(f'{tag}: {who} 协奏 {" ".join(samples)}')
        return False

    @staticmethod
    def glyph_vec(a):
        v = a.astype(np.float32).flatten()
        v = v - v.mean()
        n = float(np.linalg.norm(v))
        return v / n if n > 0 else v

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.opener_armed = True
        self.last_opener = -1
        self.macro_t0 = 0.0
        self.macro_marks = []
        self.cur = None
        self.holding_attack = False
        self.si_holding = False
        self.switch_press_at = 0.0
        self.lib_press_at = 0.0
        self.loop_count = 0
        self.hud_seen_at = 0.0       # 最后一次读到队伍 HUD 在场的时刻(HUD_LOST_ABORT 用)
        self.hud_watch = False       # 宏跑着的时候才查 HUD 丢没丢
        self.drive_log_at = 0.0
        self.timeline_logged = True
        # reset_state() 只在 load_chars()/combat_end() 时跑, 角色对象会被粘性复用 —— 这里也启一次
        try:
            start_enable_watch(self.task, self.logger)
        except Exception:
            pass

    def reset_state(self):
        super().reset_state()
        # 【刷 4C 的每一只都靠这里重新武装启动轴】: 框架 combat_end() 会对每个角色调一次 reset_state
        self.opener_armed = True
        # 内置非治疗角色默认 True, 换类时会被整体打回, 所以在这里重申(这条轴不在切人时按处决)
        self.check_f_on_switch = False
        start_f_watch(self.task, self.logger)
        start_enable_watch(self.task, self.logger)

    # ==================== 队伍判定 ====================

    @property
    def is_in_fxw(self) -> bool:
        """本队 = 心月狐(Hsin) + 弗洛洛(Phrolova) + 维里奈(Verina)。按类名判。"""
        members = 0
        for char in self.task.chars:
            if char and char.name in {'Phrolova', 'Verina'}:
                members += 1
        return members == 2

    def teammate(self, name):
        for char in self.task.chars:
            if char is not None and char.name == name:
                return char
        return None

    def opener_pending(self):
        return self.opener_blocked_by() is None

    def opener_blocked_by(self):
        """启动轴不跑的原因; 返回 None 表示该跑。不查任何技能可用性(场下读数是旧的)。"""
        if not self.is_in_fxw:
            return 'team is not hsin/phrolova/verina'
        f_press = getattr(self.task, '_f_last_press', -1)
        if not self.opener_armed:
            # 手动开关自动战斗 = 任务停止把战斗循环打断, combat_end()/on_combat_end() 整个跳过,
            # reset_state() 里的重新武装轮不到 —— 只有独立线程看得到 enabled 的跳变
            restarted = getattr(self.task, '_ww_task_restarted_at', -1)
            if restarted > self.last_opener:
                self.logger.info('fxw: auto combat 重开过 — 启动轴重新武装, 从头跑')
                self.opener_armed = True
                return None
            if f_press > self.last_opener:
                self.opener_armed = True
                return None
            return 'already armed-down (ran once this combat)'
        if f_press > self.last_opener:
            waited = time.time() - f_press
            delay = f_settings(self.task)[1]
            if waited < delay:
                return f'F pressed {waited:.2f}s ago, waiting {delay:.2f}s for the mobs'
        if self.last_opener >= 0 and time.time() - self.last_opener < self.OPENER_MIN_GAP:
            return f'ran {time.time() - self.last_opener:.1f}s ago (< {self.OPENER_MIN_GAP:.0f}s)'
        return None

    def xn_gauge(self):
        """应世心条 -> (左半, 右半) 有紫色的列占比。读当前帧, 调用方负责 next_frame。"""
        frame = self.task.frame
        out = []
        for x1, y1, x2, y2 in (self.XN_GAUGE_L, self.XN_GAUGE_R):
            box = self.task.box_of_screen_scaled(3840, 2160, x1, y1, x2, y2, hcenter=True)
            crop = frame[box.y:box.y + box.height, box.x:box.x + box.width, :3]
            if crop.size == 0:
                return 0.0, 0.0
            hsv = cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_BGR2HSV)
            h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
            purple = (h >= 125) & (h <= 160) & (sat >= 70) & (v >= 90)
            out.append(float(purple.any(axis=0).mean()))
        return out[0], out[1]

    def xn_ying(self):
        """应世心 -> (满没满, 左半紫, 右半紫)。满 = 重击位的花图标 hsin_h1; 没满时条是紫色格子。读当前帧。"""
        try:
            full = bool(self.task.find_one('hsin_h1', threshold=self.XN_FULL_THRESHOLD))
        except Exception:
            full = False
        L, R = self.xn_gauge()
        return full, L, R

    def xn_icon(self, name):
        """心技能栏的图标模板(hsin_lib1 = 转相 / hsin_lib2 = 万阙垂天解锁)。读当前帧。"""
        try:
            return bool(self.task.find_one(name, threshold=0.7))
        except Exception:
            return False

    def xn_attack_down(self):
        return self.attack_down(self.XN_HOLD_SENDINPUT and self.game_foreground())

    def xn_hold_burn(self, tag):
        """按住重击 XN1_HOLD 秒, 期间看应世心条有没有被清空(= 步红尘出手)。

        返回 (状态, 清空时刻, 按下时刻)。状态:
          'burned'  清空了(时刻可能是 None: 按住期间没读到那一帧, 松手后读到是空的)
          'full'    松手后条还在 = 出的是普通重击(条差太多/被打断) -> 调用方补 A 再按
          'unknown' 条一次都没读出来, 不知道 -> 不重按(重按落在步红尘演出里会再起一个重击)
        """
        si = self.xn_attack_down()
        start = time.time()
        self.macro_mark(f'{tag}按住({"SI" if si else "PM"})')
        seen_full = False
        burned_at = None
        low_at = None
        trace = []
        try:
            while time.time() - start < self.XN1_HOLD:
                self.task.next_frame()
                if self.hud_ok() and burned_at is None:
                    now = time.time()
                    full, L, R = self.xn_ying()
                    if len(trace) < 30:
                        trace.append(f'{now - start:.2f}:{"满" if full else ""}{L:.2f}/{R:.2f}')
                    if full or L >= self.XN_GAUGE_VALID:
                        seen_full = True
                        low_at = None
                    elif seen_full and L < self.XN_CONSUMED:
                        # 连着两帧空才算(特效闪一下会压暗一帧); 时刻记第一帧 —— 转相解锁从这一刻算
                        if low_at is None:
                            low_at = now
                        else:
                            burned_at = low_at
                            self.macro_mark(f'{tag}步红尘出手({burned_at - start:.2f}s)')
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        if burned_at is not None:
            self.macro_mark(f'{tag}松开')
            return 'burned', burned_at, start
        # 按住期间没读到清空: 松手后再读两帧, 条还在 = 真没出步红尘
        full = empty = 0
        for _ in range(6):
            self.task.next_frame()
            if self.hud_ok():
                is_full, L, R = self.xn_ying()
                if is_full or L >= self.XN_GAUGE_VALID:
                    full += 1
                    seen_full = True
                elif seen_full and L < self.XN_CONSUMED:
                    empty += 1
                if full >= 2 or empty >= 2:
                    break
            self.macro_wait(0.02)
        state = 'full' if full >= 2 else ('burned' if empty >= 2 else 'unknown')
        self.macro_mark(f'{tag}松开({state})')
        self.logger.info(f'{tag}: 按住 {self.XN1_HOLD:.1f}s 没读到应世心清空 -> {state} — {" ".join(trace)}')
        return state, None, start

    def xn1_fill(self, arrived, tag):
        """心第一段: 一直点普攻, 应世心满(花图标 / 右半到线, 连读几帧)并且过了 XN1_HOLD_AT_MIN 就返回。
        返回原因: 'ready' / 'cap'(到上限还没满, 照按) / 'blind'(条一次都没读出来, 照按)。"""
        self.wait_until_time(arrived + self.XN1_A_FROM)
        hits = taps = 0
        next_tap = last_tap = 0.0
        ready_at = None
        valid_seen = False
        trace = []
        why = 'cap'
        while True:
            now = time.time()
            if now >= next_tap:
                self.tap(self.XN1_A_HOLD)
                taps += 1
                last_tap = time.time()
                next_tap = last_tap + max(0.0, self.XN1_A_EVERY - self.XN1_A_HOLD)
            self.task.next_frame()
            now = time.time()
            if self.hud_ok():
                full, L, R = self.xn_ying()
                if len(trace) < 30:
                    trace.append(f'{now - arrived:.2f}:{"满" if full else ""}{L:.2f}/{R:.2f}')
                if full or L >= self.XN_GAUGE_VALID:
                    valid_seen = True
                hits = hits + 1 if (full or (L >= self.XN_GAUGE_VALID and R >= self.XN_YING_READY)) else 0
                if hits >= self.XN1_GATE_CONFIRM and ready_at is None:
                    ready_at = now
                    self.macro_mark(f'{tag}应世心满({"花" if full else f"{R:.2f}"},A x{taps},{now - arrived:.2f}s)')
            if ready_at is not None and now >= arrived + self.XN1_HOLD_AT_MIN:
                why = 'ready'
                break
            if now >= arrived + self.XN1_A_CAP:
                why = 'cap' if valid_seen else 'blind'
                break
            self.macro_wait(0.02)
        if why != 'ready':
            self.macro_mark(f'{tag}应世心{"不够" if why == "cap" else "读不到"}(照按,A x{taps})')
            self.logger.info(f'{tag}: 应世心 {why} — {" ".join(trace)}')
        left = last_tap + self.XN1_LAST_A_GAP - time.time()
        if left > 0:
            self.macro_wait(left)
        return why

    # ==================== 维里奈: R(可选) -> E -> Q -> 跳A 到协奏满 ====================

    def ver_r(self, tag):
        """开场 R: 亮着才放。返回放了没有。

        【不为它等】: 用户说"如果 R 没有就只 EQ 或者只 E 跳A" —— 没能量直接跳过, 不攒能量不重试,
        反正这几秒里跳A 攒协奏才是正事。只是"读不准"的情况给几次机会(切人后技能栏有几帧是上一个人的)。
        """
        ver = self.teammate('Verina')
        if ver is None:
            return False
        if not getattr(self.task, 'use_liberation', True):
            self.macro_mark(f'{tag}R关着(任务没开自动大招)')
            return False
        lit = False
        for _ in range(self.VER_R_READS):
            if self.lib_ready_reads(ver, 2):
                lit = True
                break
            if time.time() - (getattr(ver, 'last_switch_in_time', 0.0) or 0.0) >= self.VER_R_GATE:
                break
            self.macro_wait(0.10)
        if not lit:
            self.macro_mark(f'{tag}R没亮(跳过,打EQ)')
            return False
        fired = self.fire_r(ver, f'{tag}R', self.VER_R_WINDOW)
        if fired:
            self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.VER_R_ANIM_MIN,
                               time_out=self.VER_R_ANIM_CAP)
        return fired

    def ver_fill_con(self, tag):
        """跳A 攒协奏到真满。返回 (满没满, 最大读数, 跳了几次)。

        每次: 起跳 -> 连点普攻一个窗口 -> 连读几帧协奏。到上限照切(判据只决定时机, 不决定做不做)。
        """
        start = time.time()
        hits = 0
        best = 0.0
        jumps = 0
        while time.time() - start < self.VER_CON_CAP:
            self.task.jump(after_sleep=0.02)          # 跳(空中普攻: 这套攒协奏最快的形状)
            jumps += 1
            self.macro_spam(self.VER_JUMP_A, self.VER_A_EVERY, tag='跳A')
            for _ in range(self.VER_CON_CONFIRM):
                self.task.next_frame()
                self.hud_ok()                          # 喂看门狗
                try:
                    con = float(self.task.get_current_con())
                except Exception:
                    con = 0.0
                best = max(best, con)
                if con >= 1.0:
                    hits += 1
                    if hits >= self.VER_CON_CONFIRM:
                        self.macro_mark(f'{tag}协奏满(跳A x{jumps},{time.time() - start:.2f}s)')
                        return True, best, jumps
                else:
                    hits = 0
        self.macro_mark(f'{tag}协奏没满({best:.2f},跳A x{jumps})')
        self.logger.info(f'{tag}: 跳A {self.VER_CON_CAP:.1f}s 协奏只到 {best:.2f}')
        return False, best, jumps

    def seg_ver(self, tag):
        """维里奈: R(亮才放) -> E -> Q(声骸) -> 跳A 到协奏满 -> 变奏弗洛洛。返回协奏满没满。"""
        ver = self.teammate('Verina')
        ph = self.teammate('Phrolova')
        self.need(ver is not None and ph is not None, 'no verina/phrolova in team')
        con = self.read_con(1.0, settle=0.10)
        if con >= 1.0:
            # 上一只留下的协奏可能已经满了: 不用白打一套 R/E/Q/跳A
            self.macro_mark(f'{tag}协奏已满(跳过REQ跳A)')
            full, best = True, con
        else:
            arrived = getattr(ver, 'last_switch_in_time', 0.0) or time.time()
            # R 先(演出会把 HUD 带走, 回来再按键); 没能量就走 EQ
            self.wait_until_time(arrived + self.VER_R_AT)
            if self.ver_r(f'{tag}'):
                self.macro_wait(self.VER_E_AFTER_R)
            self.wait_until_time(arrived + self.VER_E_AT)
            self.spam_key(ver.send_resonance_key, self.VER_E_WINDOW, tag=f'{tag}E', presses=2)
            ver.record_resonance_use()
            self.macro_wait(self.VER_Q_SETTLE)
            # Q = 声骸技能。在 CD 上按了是空操作, 不判可用性
            self.spam_key(ver.send_echo_key, self.VER_Q_WINDOW, tag=f'{tag}Q', presses=2)
            ver.record_echo_use()
            full, best, _n = self.ver_fill_con(tag)
            if not full:
                self.logger.warning(f'{tag}: 维里奈协奏没满({best:.2f})就切弗洛洛 — '
                                    f'弗洛洛不是变奏入场, 心也少 60 应世心')
        self.need(self.switch_retry(ph, f'{tag}切弗', assume_con=full), 'verina -> phrolova')
        return full

    # ==================== 弗洛洛: Q -> 重击(强化重击) -> [R] ====================

    def ph_forte_full(self):
        """重击位(mouse_forte)图标亮 = 强化重击可放。读当前帧。"""
        try:
            return bool(self.task.find_mouse_forte())
        except Exception:
            return False

    def ph_heavy(self, tag):
        """按住左键到强化重击消耗掉(重击位图标灭)。返回确认消耗了没有。

        【先确认"亮过"才认"灭"】: 图标本来就暗的时候一上来就判灭 = 假成功。
        """
        seen = self.ph_forte_full()
        if not seen:
            # 刚放完 Q, 强化重击的解锁有一拍延迟: 图标没亮先补几下普攻再看
            self.macro_spam(self.PH_FILL_A, self.A_INTERVAL, tag=f'{tag}补A')
            seen = self.ph_forte_full()
        lit_seen = seen
        cap = self.PH_HEAVY_CAP if seen else self.PH_HEAVY_BLIND
        si = self.xn_attack_down()
        start = time.time()
        self.macro_mark(f'{tag}按住({"SI" if si else "PM"},{"亮" if seen else "没亮过"})')
        gone = 0
        fired = False
        try:
            while time.time() - start < cap:
                self.task.next_frame()
                if self.hud_ok():
                    if self.ph_forte_full():
                        lit_seen = True
                        gone = 0
                    elif lit_seen:
                        gone += 1
                        if gone >= self.PH_FORTE_CONFIRM:
                            fired = True
                            break
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}强化重击({"出手" if fired else "没确认"},{time.time() - start:.2f}s)')
        if not fired:
            self.logger.info(f'{tag}: 按住 {time.time() - start:.2f}s 重击位图标没从亮变灭'
                             f'(亮过={lit_seen}) — 强化重击没确认, 照切')
        return fired

    def ph_r(self, tag):
        """强化重击之后 R 会解锁: 亮着才放, 放完等演出结束(HUD 回来)再切人。返回放了没有。"""
        ph = self.teammate('Phrolova')
        if ph is None:
            return False
        if not getattr(self.task, 'use_liberation', True):
            self.macro_mark(f'{tag}R关着(任务没开自动大招)')
            return False
        start = time.time()
        lit = False
        while time.time() - start < self.PH_R_WAIT:
            if self.lib_ready_reads(ph, 2):
                lit = True
                break
            self.tap()
            self.macro_wait(self.A_INTERVAL)
        if not lit:
            self.macro_mark(f'{tag}R没亮(跳过)')
            return False
        fired = self.fire_r(ph, f'{tag}R', self.PH_R_WINDOW)
        if not fired:
            self.macro_mark(f'{tag}R重按')
            fired = self.fire_r(ph, f'{tag}R重按', self.PH_R_WINDOW)
        if fired:
            self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.PH_R_ANIM_MIN,
                               time_out=self.PH_R_ANIM_CAP)
        return fired

    def seg_ph_burst(self, tag):
        """弗洛洛第一格: E -> 强化普攻 -> 按住重击到强化重击出 -> [R] -> 变奏心月狐。"""
        ph = self.teammate('Phrolova')
        self.need(ph is not None, 'no phrolova in team')
        arrived = getattr(ph, 'last_switch_in_time', 0.0) or time.time()
        if not ph.has_intro:
            self.macro_mark(f'{tag}弗洛洛不是变奏进来的(没有维里奈延奏)')
        # 【E 不能贴着到场按】: 变奏入场的 QTE 锁(~0.3s)会把这一下吞掉, 强化普攻就出不来
        self.wait_until_time(arrived + self.PH_E_AT)
        self.spam_key(ph.send_resonance_key, self.PH_E_WINDOW, tag=f'{tag}E', presses=2)
        ph.record_resonance_use()
        self.macro_wait(self.PH_E_SETTLE)
        if self.PH_ECHO_Q:
            self.spam_key(ph.send_echo_key, self.PH_Q_WINDOW, tag=f'{tag}Q', presses=2)
            ph.record_echo_use()
            self.macro_wait(self.PH_Q_SETTLE)
        # 强化普攻: E 之后这几下普攻是强化版(用户: "E 强化普攻 再重击")
        self.macro_spam(self.PH_FORTE_A, self.A_INTERVAL, tag=f'{tag}强化普攻')
        self.ph_heavy(f'{tag}重击')
        self.macro_wait(self.PH_TAIL)
        if self.PH_R_AFTER_HEAVY:
            self.ph_r(tag)
        # 切心之前协奏要真满: 心没吃到变奏就少 60 应世心, 要多打半轮普攻
        con = self.read_con(1.0, settle=0.12)
        if con < 1.0:
            self.wait_con_full('弗洛洛', self.PH_CON_CAP, tag=f'{tag}协奏')
            con = self.read_con(1.0, settle=0.08)
        if con < 1.0:
            self.logger.warning(f'{tag}: 弗洛洛协奏 {con:.2f} 就切心 — 心不是变奏入场')
        self.need(self.switch_retry(self, f'{tag}切心', assume_con=con >= 1.0), 'phrolova -> hsin')

    # ==================== 心月狐: 应世心满 -> 步红尘 -> Q ====================

    def seg_xn(self, tag):
        """心月狐: 普攻到应世心满 -> 按住到步红尘出手 -> Q(声骸)。返回步红尘出了没有。

        【不切人】: 这一格之后就是平A 收尾(人还站在心身上), 不再变奏回弗洛洛。
        Q 的位置由 XN1_Q_AFTER 决定: True = 步红尘 之后(用户第 2 版 "重击Q"), False = 进场先按。
        """
        arrived = getattr(self, 'last_switch_in_time', 0.0) or time.time()
        if not self.has_intro:
            self.macro_mark(f'{tag}心不是变奏进来的(应世心少 60)')
        if not self.XN1_Q_AFTER:
            self.wait_until_time(arrived + self.XN1_Q_AT)
            self.spam_key(self.send_echo_key, self.XN1_Q_WINDOW, tag=f'{tag}Q', presses=2)
            self.record_echo_use()
        self.xn1_fill(arrived, tag)
        state = 'unknown'
        for attempt in range(1 + self.XN1_RETRIES):
            if attempt > 0:
                # 上一次松手后条还在 = 出的是普通重击: 补两下 A 再按
                for _ in range(self.XN1_RETRY_A):
                    self.tap(self.XN1_A_HOLD)
                    self.macro_wait(self.XN1_FILL_EVERY)
                self.macro_mark(f'{tag}重击重按#{attempt}')
            state, _burned_at, _hold_at = self.xn_hold_burn(
                f'{tag}重击' if attempt == 0 else f'{tag}重击#{attempt}')
            if state != 'full':
                break
        if state == 'full':
            self.logger.warning(f'{tag}: 重按 {self.XN1_RETRIES} 次应世心都没清空(步红尘没出), 照打')
        self.macro_wait(self.XN1_TAIL)
        # 收招没走完就按键会被游戏吞掉: 先等 HUD 回来/确认没有演出
        self.wait_hud_back(tag=f'{tag}步红尘收招', min_gone=self.XN1_TAIL_HUD_MIN,
                           time_out=self.XN1_TAIL_HUD_CAP)
        if self.XN1_Q_AFTER:
            self.macro_wait(self.XN1_Q_DELAY)
            self.spam_key(self.send_echo_key, self.XN1_Q_WINDOW_AFTER, tag=f'{tag}Q', presses=2)
            self.record_echo_use()
        return state != 'full'

    # ==================== 收尾: 心月狐平A / 死了切维里奈 ====================

    def seg_xn_loop(self, tag):
        """心月狐收尾: 一直普攻; 怪死了就切维里奈(用户: "如果没死就平A, 死了就切维里奈")。

        【不用 check_combat 抛异常】: NotInCombatException 会直接把宏弹出去, 切人这一步就轮不到了。
        这里读 task.in_combat(), 判死就自己切奶再正常返回, 让框架照常走 combat_end。
        """
        ver = self.teammate('Verina')
        prev = self.task.skip_combat_check
        self.task.skip_combat_check = False
        start = time.time()
        a_taps = 0
        next_check = 0.0
        gone_hits = 0
        dead_hits = 0
        dead = False
        try:
            while time.time() - start < self.XN_LOOP_CAP:
                if self.hud_ok():
                    gone_hits = 0
                else:
                    # 结算画面/过场: 再点下去就是在结算界面上乱按
                    gone_hits += 1
                    if gone_hits >= self.XN_LOOP_HUD_LOST_HITS:
                        self.macro_mark(f'{tag}HUD 不在了(收尾停手)')
                        break
                now = time.time()
                if now >= next_check:
                    next_check = now + self.XN_LOOP_DEAD_POLL
                    try:
                        alive = bool(self.task.in_combat())
                    except Exception:
                        alive = True
                    if not alive:
                        # 第二个判据: 演出/过场里 in_combat 会误判成脱战, 目标框还在就是怪没死
                        try:
                            alive = bool(self.task.has_target())
                        except Exception:
                            pass
                    dead_hits = 0 if alive else dead_hits + 1
                    if dead_hits >= self.XN_LOOP_DEAD_CONFIRM:
                        dead = True
                        break
                self.tap()
                a_taps += 1
                self.macro_wait(max(0.0, self.A_INTERVAL - self.A_TAP))
        finally:
            self.task.skip_combat_check = prev
        if dead:
            self.macro_mark(f'{tag}怪死了(切维,A x{a_taps})')
            if ver is not None and self.cur is not ver:
                if not self.quick_switch(ver, time_out=self.XN_LOOP_SWITCH_TIMEOUT):
                    self.macro_mark(f'{tag}切维被拒(交给框架 switch_healer)')
        else:
            self.macro_mark(f'{tag}收尾(到上限,A x{a_taps})')

    def run_cycle(self, tag):
        """启动轴一整条: 维里奈 -> 弗洛洛 -> 心月狐(步红尘+Q) -> 心平A收尾。"""
        marks = len(self.macro_marks)
        self.timeline_logged = False
        ver = self.teammate('Verina')
        self.need(ver is not None, 'no verina in team')
        self.need(self.switch_retry(ver, f'{tag}开场切维'), 'entry -> verina')
        self.seg_ver(f'{tag}维')
        self.seg_ph_burst(f'{tag}弗')
        self.seg_xn(f'{tag}心')
        self.seg_xn_loop(f'{tag}平A')
        self.logger.info(f'fxw {tag} timeline: {self.macro_timeline(marks)}')
        self.timeline_logged = True

    # ==================== 进出 ====================

    def macro_enter(self, entry_char):
        """进宏: 关脱战检查(1 帧判脱战会让整条轴断在半路)、关三个人的切人处决、启 HUD 看门狗。"""
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        self.mark_busy(True)
        self.cur = entry_char or self.on_field_char() or self
        for char in getattr(self.task, 'chars', []):
            if char is not None:
                char.check_f_on_switch = False
        self.macro_start()
        self.timeline_logged = False
        self.hud_seen_at = time.time()
        self.hud_watch = True
        return previous

    def macro_exit(self, previous):
        # 长按跨了好几个方法, 中途抛异常的话鼠标会一直按着。这里是唯一保证松手的地方
        self.release_attack()
        # 中途被停(关自动战斗/切出窗口)也要把时间轴写下来
        if not self.timeline_logged and self.macro_marks:
            self.logger.info(f'fxw timeline (没跑完): {self.macro_timeline()}')
            self.timeline_logged = True
        self.hud_watch = False
        self.task.skip_combat_check = previous
        self.mark_busy(False)

    def perform_opener(self, entry_char=None):
        """启动轴: 切维里奈 -> 一圈(维 -> 弗 -> 心 -> 弗收尾)。"""
        previous = self.macro_enter(entry_char)
        self.logger.info(f'fxw opener entry: {self.cur.name if self.cur else "?"}')
        try:
            self.loop_count = 0
            self.run_cycle('op')
            self.logger.info(
                f'fxw opener total {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        except MacroBroken as e:
            self.logger.warning(f'fxw opener broke ({e}) — timeline: {self.macro_timeline()}')
            self.timeline_logged = True
        finally:
            self.macro_exit(previous)
        return True

    def perform_loop(self, entry_char=None):
        """启动轴跑完之后: 心月狐站场平A 收尾。场上不是她就先切回来(框架的 switch_healer 有时把奶切上来)。"""
        previous = self.macro_enter(entry_char)
        try:
            self.loop_count += 1
            if self.cur is not self:
                self.need(self.switch_retry(self, f'L{self.loop_count}切回收尾'), 'entry -> hsin')
            self.seg_xn_loop(f'L{self.loop_count}')
        except MacroBroken as e:
            self.logger.warning(f'fxw loop broke ({e}) — timeline: {self.macro_timeline()}')
            self.timeline_logged = True
        finally:
            self.macro_exit(previous)
        return True

    # ==================== 框架接口 ====================

    def drive(self, entry):
        """三个人的 do_perform 都走这里。entry = 框架这次调的是谁(= 场上是谁)。"""
        # 【HUD 不在就什么都不做】: 关卡结束/结算/过场时框架还会接着调进来
        if not self.wait_hud_up(cap=self.DRIVE_HUD_CAP, tag='drive'):
            if time.time() - self.drive_log_at > 10:
                self.drive_log_at = time.time()
                self.logger.info('fxw: 队伍 HUD 不在(结算/过场/窗口没了?), 宏不动')
            return None
        blocked = self.opener_blocked_by()
        if blocked is None:
            # 标记要在跑之前落: 中途抛异常(脱战/任务被停)也不能让启动轴重跑
            self.opener_armed = False
            self.last_opener = time.time()
            return self.perform_opener(entry)
        self.logger.info(f'fxw: opener not pending ({blocked}), running the loop')
        return self.perform_loop(entry)

    def do_perform(self):
        if not self.is_in_fxw:
            return super().do_perform()
        self.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时不让框架把心自己切上来(宏自己切)。"""
        if self.is_in_fxw and self.opener_pending():
            return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        self.release_attack()
        return super().on_combat_end(chars)
