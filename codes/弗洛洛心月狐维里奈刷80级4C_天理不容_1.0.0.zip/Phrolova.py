from src.char.BaseChar import SwitchPriority
from src.char.Phrolova import Phrolova as NativePhrolova


class Phrolova(NativePhrolova):
    """弗心维(弗洛洛 / 心月狐 / 维里奈)里的弗洛洛。非本队时整套走原版。

    【她不驱动任何一段轴】: 宏体在同目录的 Hsin.py。她一圈只上场一次:
    E -> 强化普攻 -> 重击(强化重击) -> 变奏心月狐; 之后的平A 收尾是心在打, 不切回来。
    走到 do_perform 说明宏散了(切人失败/脱战重进), 直接转给心的 drive():
    它会按 opener 有没有跑过来决定重跑启动轴还是接着收尾。
    """

    @property
    def is_in_fxw(self) -> bool:
        members = 0
        for char in self.task.chars:
            if char and char.name in {'Hsin', 'Verina'}:
                members += 1
        return members == 2

    def macro(self):
        """持宏的心月狐。那份自定义没启用时返回 None, 走原版。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'drive') and hasattr(char, 'quick_switch'):
                return char
        return None

    def reset_state(self):
        super().reset_state()
        self.check_f_on_switch = False

    def do_perform(self):
        if not self.is_in_fxw:
            return super().do_perform()
        self.check_f_on_switch = False
        macro = self.macro()
        if macro is None:
            self.logger.warning('fxw: Hsin custom code is off, falling back to the native rotation')
            return super().do_perform()
        macro.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时返回 NO: 宏自己按角色切人, 不要框架临时选人打乱顺序。"""
        if self.is_in_fxw:
            macro = self.macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.NO
        # 本队不按"大招后 24s 内不切人"锁人: 收尾格之后要能被切走(拔出来重跑启动轴)
        return SwitchPriority.NORMAL
