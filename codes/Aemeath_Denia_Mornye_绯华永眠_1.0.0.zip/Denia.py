import time
from src.char.BaseChar import BaseChar, SwitchPriority

denia_form1_color = {
    'r': (140, 255),
    'g': (80, 200),
    'b': (0, 160),
}

denia_form2_color = {
    'r': (0, 120),
    'g': (0, 130),
    'b': (130, 255),
}


class Denia(BaseChar):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def do_perform(self):
        if self.has_intro:
            self.continues_normal_attack(1.2)

        current_form = self.detect_form()
        self.logger.debug(f'denia current form: {current_form}')

        if current_form == 1:
            if self.form1_actions():
                self.form2_actions()
        else:
            self.form2_actions()

        self.switch_to_aemeath()

    def detect_form(self):
        box = self.task.box_of_screen_scaled(3840, 2160, 1628, 1972, 2174, 1986, name='denia_forte', hcenter=True)
        form1_percent = self.task.calculate_color_percentage(denia_form1_color, box)
        form2_percent = self.task.calculate_color_percentage(denia_form2_color, box)
        self.logger.debug(f'denia form1={form1_percent:.3f} form2={form2_percent:.3f}')
        if form2_percent > 0.05 and form2_percent > form1_percent:
            return 2
        return 1

    def form1_actions(self):
        """形态1：3.5秒站场时间，目标是开大进入形态2"""
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < 3.5:
            if self.liberation_available():
                self.click_liberation()
                return True

            for _ in range(3):
                self.click()
                self.sleep(0.1)

            self.task.click(key="right")
            self.sleep(0.05)

            if self.liberation_available():
                self.click_liberation()
                return True

            if self.resonance_available():
                self.click_resonance()
            self.sleep(0.05)

            if self.liberation_available():
                self.click_liberation()
                return True

            self.check_combat()
        return False

    def form2_actions(self):
        """形态2：7秒站场时间，目标是释放二段大变回形态1后切人"""
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < 7:
            if self.liberation_available():
                self.click_echo(time_out=0)
                self.sleep(0.05)
                self.click_liberation()
                return

            for _ in range(2):
                if self.resonance_available():
                    self.click_resonance()
                    self.sleep(0.05)
                if self.liberation_available():
                    self.click_echo(time_out=0)
                    self.sleep(0.05)
                    self.click_liberation()
                    return

            for _ in range(4):
                self.click()
                self.sleep(0.1)
                if self.liberation_available():
                    self.click_echo(time_out=0)
                    self.sleep(0.05)
                    self.click_liberation()
                    return

            self.check_combat()

    def switch_to_aemeath(self):
        """切换至爱弥斯，满协奏时打标记通知阿梅斯锁场"""
        target_index = None
        for char in self.task.chars:
            if char and char.char_name == 'char_aemeath':
                target_index = char.index
                break
        if target_index is None:
            self.switch_next_char()
            return
        if self.is_con_full():
            if not hasattr(self.task, 'custom_data'):
                self.task.custom_data = {}
            self.task.custom_data['denia_outro_time'] = time.time()
        self.has_intro = False
        self.has_sub_dps_intro = False
        self._liberation_available = self.liberation_available()
        self.use_tool_box()
        aemeath_key = str(target_index + 1)
        start = time.time()
        while time.time() - start < 3:
            in_team, current_index, count = self.task.in_team()
            if in_team and current_index != self.index:
                for char in self.task.chars:
                    if char:
                        char.is_current_char = (char.index == current_index)
                break
            self.task.send_key(aemeath_key)
            self.sleep(0.2, check_combat=False)

    def on_combat_end(self, chars):
        self.switch_other_char()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_aemeath'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
