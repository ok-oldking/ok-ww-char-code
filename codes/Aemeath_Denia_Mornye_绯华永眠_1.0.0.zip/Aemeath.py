import time
from src.char.BaseChar import BaseChar, SwitchPriority


class Aemeath(BaseChar):
    LIBERATION_COOLDOWN = 25
    LIBERATION_FORCE_DURATION = 30
    LIB2_PREPARE_WINDOW = 8
    INTRO_LIBERATION_DELAY = 14

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.should_wait = False
        self.intro_time = -1
        self.last_liber = -1
        self.last_enhance_e = -1
        self.intro_liberation_time = -1
        self.pending_lib2 = False

    def lib2_cooldown_anchor(self):
        if self.last_liber >= 0:
            return self.last_liber
        combat_start = getattr(self.task, 'combat_start', -1)
        return combat_start if combat_start > 0 else -1

    def lib2_cooldown_left(self):
        anchor = self.lib2_cooldown_anchor()
        if anchor < 0:
            return 0
        elapsed = self.time_elapsed_accounting_for_freeze(anchor)
        return max(0, self.LIBERATION_COOLDOWN - elapsed)

    def liberation_cooldown_left(self):
        if self.last_liber < 0:
            return 0
        elapsed = self.time_elapsed_accounting_for_freeze(self.last_liber)
        return max(0, self.LIBERATION_COOLDOWN - elapsed)

    def lib1_unlock_anchor(self):
        if self.last_liber >= 0:
            return self.last_liber
        return getattr(self.task, 'combat_start', -1)

    def record_intro_liberation(self):
        self.intro_liberation_time = time.time()

    def intro_lib1_ready(self):
        return self.intro_liberation_time >= 0 and (
            self.time_elapsed_accounting_for_freeze(self.intro_liberation_time) <= self.INTRO_LIBERATION_DELAY)

    def lib1_unlocked(self):
        if self.intro_lib1_ready():
            return True
        anchor = self.lib1_unlock_anchor()
        return anchor >= 0 and (
            self.time_elapsed_accounting_for_freeze(anchor) >= self.LIBERATION_FORCE_DURATION)

    def can_cast_lib1(self):
        if self.liberation_available():
            return True
        return self.liberation_cooldown_left() <= 0 and self.lib1_unlocked()

    def can_cast_liberation(self):
        return self.can_cast_lib1()

    def lib2_available(self):
        return bool(self.task.find_one('aemeath_lib2', threshold=0.7))

    def preparing_lib2(self):
        return self.lib2_cooldown_anchor() >= 0 and (
            self.lib2_cooldown_left() < self.LIB2_PREPARE_WINDOW)

    def should_wait_for_lib2(self):
        return self.pending_lib2 or self.preparing_lib2()

    def record_enhance_e(self):
        self.last_enhance_e = time.time()

    def record_liberation(self, is_lib2):
        if is_lib2:
            self.pending_lib2 = False
            self.last_liber = time.time()
            self.last_enhance_e = self.last_liber
        else:
            self.intro_liberation_time = -1

    def do_perform(self):
        self.intro_time = -1

        if self.has_intro:
            self.record_intro_liberation()
            self.continues_normal_attack(1.2)

        if self.check_outro() in {'char_linnai', 'char_lupa'}:
            self.intro_time = 14
        if self.check_outro() in {'chang_changli', 'char_changli2'}:
            self.intro_time = 10
        self.perform_everything()
        self.switch_next_char()

    def lib(self):
        is_lib2 = self.lib2_available()
        if not is_lib2 and not self.can_cast_lib1():
            return False
        if not self.click_liberation(wait_if_cd_ready=0):
            return False
        self.record_liberation(is_lib2)
        self.f_break()
        return True

    def continue_in_intro(self):
        return self.time_elapsed_accounting_for_freeze(self.last_liber) < 30 and \
            self.time_elapsed_accounting_for_freeze(self.last_perform) < self.intro_time

    def perform_everything(self):
        self.should_wait = self.should_wait_for_lib2()
        while True:
            self.check_combat()
            self.cycle_start()

            # 1. 强化重击（最高优先级）
            if self.handle_heavy():
                self.f_break()
                self.should_wait = self.should_wait_for_lib2()
                self.task.next_frame()
                continue

            # 2. 强化E
            if self.enhance_e_available():
                if self.click_resonance(has_animation=True, send_click=True,
                                         animation_min_duration=0.5, time_out=1.5)[0]:
                    self.record_enhance_e()
                    self.click_echo(time_out=0)
                    self.f_break()
                    # 放完强化E后：能放强化重击就放，能放大招就放，都不能就切人
                    if self.handle_heavy():
                        self.f_break()
                        self.should_wait = self.should_wait_for_lib2()
                        self.task.next_frame()
                        continue
                    elif self.lib():
                        self.should_wait = self.should_wait_for_lib2()
                        continue
                    else:
                        return  # 都放不了，切人退场

            # 3. 入场lib1
            if self.intro_lib1_ready() and self.lib():
                self.should_wait = self.should_wait_for_lib2()
                continue

            # 4. 大招
            if self.lib():
                self.should_wait = self.should_wait_for_lib2()
                continue

            # 5. 其余时间一直平A
            self.click()
            self.cycle_sleep()

            # 等待二段大期间，强化重击和大招都不可用 → 切人
            if self.should_wait and not self.preparing_lib2():
                self.switch_next_char()
                return

    def enhance_e_available(self):
        return self.task.find_one('aemeath_e1', threshold=0.7) or self.task.find_one('aemeath_e2', threshold=0.7)

    def heavy_wait_highlight_down(self):
        self.task.mouse_down()
        ret = self.task.wait_until(lambda: not self.has_long_action(), time_out=1.2)
        self.task.mouse_up()
        self.sleep(0.01)
        return ret

    def handle_heavy(self):
        if not self.has_long_action():
            return False
        prepares_lib2 = self.preparing_lib2()
        if self.heavy_wait_highlight_down():
            if prepares_lib2:
                self.pending_lib2 = True
                self.sleep(0.2)
            return True
        return False

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self.should_wait_for_lib2():
            return SwitchPriority.MUST
        if current_char and current_char.char_name == 'char_denai':
            for char in self.task.chars:
                if char and char.char_name in ('char_moning', 'char_moning_new') and char._mornye_needs_entry():
                    return SwitchPriority.NORMAL
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        self.switch_other_char()
