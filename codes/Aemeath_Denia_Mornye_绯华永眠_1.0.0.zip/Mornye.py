import time
from src.char.BaseChar import BaseChar, SwitchPriority


class Mornye(BaseChar):
    ENTRY_INTERVAL = 14

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_heavy = 0
        self.last_liber = -1
        self.last_domain_time = -1
        self._liber_exit = False

    def _domain_active(self, threshold=20):
        if self.last_domain_time < 0:
            return False
        return self.time_elapsed_accounting_for_freeze(self.last_domain_time) < threshold

    def _mornye_needs_entry(self):
        if self.last_switch_time < 0:
            return True
        return self.time_elapsed_accounting_for_freeze(self.last_switch_time) >= self.ENTRY_INTERVAL

    def _is_burst_team(self):
        """聚爆队：有达妮娅"""
        for char in self.task.chars:
            if char and char.char_name == 'char_denia':
                return True
        return False

    def _get_air_duration(self):
        """聚爆队0.6秒（不打空中重击），震谐队1.8秒（打空中强化重击）"""
        return 0.6 if self._is_burst_team() else 1.8

    def do_perform(self):
        self._liber_exit = False
        if self.has_intro and self.on_air():
            self.last_domain_time = time.time()

        if self.on_air():
            self.on_air_actions()
        elif not self._domain_active():
            self._try_takeoff()
            if self.on_air():
                self.last_domain_time = time.time()
                self.on_air_actions()
        else:
            self._ground_quick_actions()

        self.switch_next_char()

    def _try_cast_liberation(self):
        if self.liberation_available():
            if self.click_liberation():
                self.last_liber = time.time()
                self._liber_exit = True
                return True
        return False

    def on_air(self):
        return self.has_long_action2()

    def forward_dash(self):
        self.task.send_key_down('w')
        self.task.next_frame()
        self.task.click(key="right")
        self.task.send_key_up('w')
        self.sleep(0.1)

    def _try_takeoff(self):
        if self.resonance_available():
            self.click_resonance()
        takeoff_start = time.time()
        while self.time_elapsed_accounting_for_freeze(takeoff_start) < 5 and not self.on_air():
            self.check_combat()
            if self._try_cast_liberation():
                self.sleep(0.3)
                if self.on_air():
                    return
            if self.resonance_available():
                self.click_resonance()
                self.sleep(0.01)
                continue
            if self.is_mouse_forte_full():
                self.heavy_click_forte(check_fun=self.is_mouse_forte_full)
                self.sleep(0.3)
            else:
                self.click()
                self.sleep(0.1)

    def on_air_actions(self):
        detect_ready = self.echo_available()
        start = time.time()
        air_duration = self._get_air_duration()
        is_burst = self._is_burst_team()

        if not is_burst:
            # 震谐队：鼠标按住，打空中强化重击
            self.task.mouse_down()

        try:
            while self.time_elapsed_accounting_for_freeze(start) < air_duration and self.on_air():
                self.check_combat()

                if is_burst:
                    # 聚爆队：空中点按普攻（不按鼠标）
                    if self._try_cast_liberation():
                        self.forward_dash()
                        self.click_echo(time_out=0)
                        self.check_f_on_switch = False
                        return
                    if self.resonance_available():
                        self.click_resonance()
                        self.sleep(0.01)
                        continue
                    if self.detect_elbow_strike(detect_ready):
                        self.task.wait_until(lambda: not self.detect_elbow_strike(detect_ready),
                                             post_action=lambda: self.continues_right_click(0.05), time_out=1.5)
                        continue
                    self.click()
                    self.sleep(0.1)
                else:
                    # 震谐队：等强化重击放完再放大招
                    if self.is_mouse_forte_full():
                        self.task.wait_until(lambda: not self.is_mouse_forte_full(), time_out=2)
                    if self._try_cast_liberation():
                        self.task.mouse_up()
                        self.forward_dash()
                        self.click_echo(time_out=0)
                        self.check_f_on_switch = False
                        return
                    if self.resonance_available():
                        self.click_resonance()
                        self.sleep(0.01)
                        continue
                    if self.detect_elbow_strike(detect_ready):
                        self.task.wait_until(lambda: not self.detect_elbow_strike(detect_ready),
                                             post_action=lambda: self.continues_right_click(0.05), time_out=1.5)
                        continue
                    self.sleep(0.01)
        finally:
            if not is_burst:
                try:
                    self.task.mouse_up()
                except Exception:
                    pass
        self.click_echo(time_out=0)

    def _ground_quick_actions(self):
        if self._try_cast_liberation():
            self.sleep(0.3)
            if self.on_air():
                self.last_domain_time = time.time()
                self.on_air_actions()
                return
        if self.resonance_available():
            self.click_resonance()

    def on_combat_end(self, chars):
        self.switch_other_char()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._mornye_needs_entry():
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def detect_elbow_strike(self, ready):
        return ready and not self.available('echo', check_color=True)
