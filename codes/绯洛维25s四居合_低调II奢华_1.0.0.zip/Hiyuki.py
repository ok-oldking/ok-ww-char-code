import time

from src.char.BaseChar import BaseChar, SwitchPriority


class Hiyuki(BaseChar):
    """绯雪 25s 四居合轴 (配队: 绯雪 / 洛瑟拉 / 维里奈).

    绯雪段(严格按图里的顺序):
        变奏入场 a3-闪 → 重击-Q-R1 → 3A-重击 → 2A-重击 → 2A-闪-2居合
        → 2E-居合 → 处决-a3 → 闪-居合 → 重击-R2 → E

    这套输入的要点都是照着能跑的实战代码校准的:
      * 心念靠"按住攻击"打强化重击来攒, 点普攻攒得慢; R1 亮起之前一直按住。
      * 闪避是右键, 不是 Shift。
      * 居合架势看 hiyuki_left; hiyuki_lib_forte = 终结重击(枯霜)已解锁。
      * 处决要到屏幕中央抓 F 提示并排除拾取; 切人时不能让框架替她按 F。
      * R2 是能量门控(图标上没有数字), 用 current_liberation() > 0 判断;
        R 要在终结重击动画里按下并按住, 按早了整段重击会被顶掉。
      * 变身/大招都带时停, 定时段用 macro_wait(纯 time.sleep), 不走 executor.sleep
        (它每 0.4 秒插一次 next_frame 截图且位置不可控)。
    """

    FIELD_TIME_OUT = 16.0
    INTRO_HOLD_TIMEOUT = 8.0
    STANDARD_LIB_CD_MAX = 3.5
    STANDARD_HOLD_SLICE = 1.0
    STANDARD_BUILD_TIMEOUT = 10.0  # 没有变奏时用 3A+E 攒心念的最长时间
    HEAVY_FORTE_TIME_OUT = 1.2

    # 定时段。标定: A3链 1.10 太早(特效没出就闪避), 1.20~1.35 都出
    M_A_CHAIN = 1.20
    M_A2_CHAIN = 0.85
    M_A_INTERVAL = 0.15
    M_A_ONE = 0.55  # 处决后那发A: 接第三段, 不是新连段
    M_AFTER_DODGE = 0.35
    M_HEAVY_HOLD = 0.55  # 预求身重击按住时长
    M_HEAVY_RECOVER = 0.25
    M_HOLD_E_LAND = 0.85  # 常世身/兜底: 长按E落地
    M_LAND_RECOVER = 0.20
    M_E_GAP = 0.50  # 2E: 两段共鸣技能之间
    M_EXIT_E_SETTLE = 0.30  # R2 后面的收尾E
    RES_WAIT = 0.40  # 等共鸣技能可用的时间(第二段E大多在CD, 别干等太久)
    M_EXECUTE_ANIM = 1.60  # 时停期间画面静止, 找图无效只能按秒等

    # 保底段。间隔要略小于居合动画(约0.5s)让点击排队, 但不能小于动画一半否则丢刀
    M_KENDO_INTERVAL = 0.45
    M_KENDO_TO_HOLD = 1.04  # 盲等回退用; 长按不进输入缓冲, 落在居合动画里会被丢
    KENDO_RELEASE_TO_HOLD = 0.35  # 架势图标灭=已释放, 之后只剩0.3~0.4秒动画尾巴
    KENDO_MAX_CLICKS = 4
    HEAVY_TO_R = 0.80  # 标定: <=0.35 必顶掉重击, 0.6/0.7 偶发, 0.95 停顿明显
    KENDO_AFTER_A2 = 2  # 2A-闪-2居合: 二链起双居合(图中【2链2居合】)
    LIB_FORTE_SETTLE = 0.3  # 等图标渲染, 否则会把"刚解锁没画出来"当成没解锁
    M_DODGE_TO_KENDO = 0.30
    STANCE_WAIT = 0.8
    TAIL_TIME_OUT = 6.0
    KENDO_RETRY_STRIDE = 3
    R2_ENERGY_WAIT = 0.8  # 能量不够时补两下, 别在放R前站太久
    M_ENERGY_A_INTERVAL = 0.25
    M_ENERGY_SETTLE = 0.25  # 补完能量到按重击之间的间隔(别停太久)
    # R2 分两段: 先按出终结重击并松手, 隔 R2_START_DELAY 秒再长按 R。
    # 贴着上一个动作按 R, 游戏只认成点按(屏幕上是点一下, 大招放不出来)
    R2_START_DELAY = 0.5
    # 长按节奏放慢, 别让连续的 keydown 被当成连点
    R2_REPEAT_INTERVAL = 0.6
    # 按住蓄满所有锻雪·归刃: 蓄满游戏自动放, 这个值只是兜底上限
    R2_HOLD_TIME = 8.0
    # 蓄力至少这么久才可能放出, 之后角色离场才判定为已放
    R2_MIN_CHARGE = 3.0
    R2_RETRY_DELAY = 0.35
    R2_MAX_ATTEMPTS = 2

    LIB2_KENDO_COUNT = 3
    HOLD_LIB_TIME_OUT = 8.0
    HOLD_LIB_CD_WAIT = 1.5
    POST_LIB2_TEAM_WAIT = 1.0
    WAIT_LOCK_TIME_OUT = 2.0

    OUTRO_HARD_LIMIT = 25.0
    OUTRO_STALL_TIME = 6.0
    CON_TOP_UP_CHAIN = 0.5
    # 按图里的整队循环: 绯雪 → 维里奈(3A/闪-E-Q-R) → 洛瑟拉(完美E-Q-R-长按A) → 绯雪
    # 所以绯雪的延奏交给维里奈; 绯雪自己只从洛瑟拉(或琳奈)手里接变奏
    SWITCH_TARGET_NAME = 'char_verina'
    DIRECT_SWITCH_INDEX = 3
    LIB_ANIM_WAIT = 4.0
    LEAVE_SWITCH_TIMEOUT = 3.5

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.lib_permission = True
        self.lib2_count = 0
        self.just_transformed = False
        self.r2_used = False  # 本场是否放过R2, 决定蓄力档位
        self.macro_t0 = 0.0
        self.macro_marks = []
        # 关掉框架的切人自动按F: 默认 not is_healer 对主C是True, 会在每次交棒时
        # 替她按掉处决, 等她走到轴上那个F位时已经 skip F 了
        self.check_f_on_switch = False

    def switch_out(self, con_full=False):
        super().switch_out(con_full)
        self.lib2_count = 0
        self.just_transformed = False

    def reset_state(self):
        # 不能用 on_combat_end: 绯雪放完R2就切走, 战斗结束时在场的是洛瑟拉,
        # 她的 on_combat_end 永不执行, r2_used 会一直是 True
        super().reset_state()
        self.r2_used = False
        # 【这一句必须在 reset_state 里重申, 只写 __init__ 保不住】:
        # CharFactory.apply_team_char_classes() 换成自定义类的写法是
        # `replacement.__dict__.update(内置实例.__dict__)` —— __init__ 里所有跟内置版
        # 取值不同的字段会被整个打回内置值。BaseChar.__init__ 是 `not self.is_healer`,
        # 所以非治疗角色一律被打回 True, 框架就会在 switch_next_char() 里替她按 F。
        # reset_state() 跑在那次 update 之后, 而且每次重读队伍都会再跑一遍, 放这里才保得住。
        # 绯雪的处决由她自己在轴上那一处按, 不要框架代按。
        self.check_f_on_switch = False

    def do_perform(self):
        self.click_echo(time_out=0)

        # 起手: a3-闪 → 重击-Q-R1
        if self.has_intro or not self.liberation_available():
            self.perform_opening()

        # R1 没开出来(能量不够/被吞键): 继续按住攻击补到 R1 亮起
        if not self.just_transformed and self.has_long_action() \
                and self.task.get_cd('liberation') <= self.STANDARD_LIB_CD_MAX:
            self.perform_standard()

        lib_ok = False
        # 只看"这次站场变身了没有"。挂在 has_long_action2() 下面的话, 变身瞬间
        # 那个判定常常是 False, 整段爆发会被跳过
        if self.just_transformed:
            self.just_transformed = False
            lib_ok = self.transform_macro()

        if not lib_ok and self.has_long_action2():
            lib_ok = self.perform_lib()
        if not lib_ok and self.lib_permission and self.liberation_available():
            lib_ok = self.hold_liberation()

        self.leave(skip_outro=lib_ok)

    # ------------------------------------------------------------------ 常世身
    def perform_opening(self):
        """a3-闪 → 重击-Q-R1。心念靠按住攻击打强化重击攒。"""
        if self.has_intro:
            self.attack_chain()
            self.macro_dodge(self.M_AFTER_DODGE)
            if self.hold_attack_until_lib(min_hold=self.intro_motion_freeze_duration,
                                          timeout=self.INTRO_HOLD_TIMEOUT):
                self.cast_r1()
            return

        # 没有变奏时心念从 0 开始: 一直按住攻击要 8 秒才攒满, 看着像站桩。
        # 普攻第三段 +100, 共鸣技能后接第三段再 +100, 用 3A+E 循环更快。
        self.logger.info('hiyuki no intro, build xinnian with 3A+E')
        if self.build_xinnian():
            self.cast_r1()

    def build_xinnian(self, timeout=None):
        """没有变奏时攒心念: 3A -> E -> 3A, R1 一亮就收。"""
        timeout = self.STANDARD_BUILD_TIMEOUT if timeout is None else timeout
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.liberation_available():
                return True
            self.attack_chain()
            if self.resonance_available():
                self.click_resonance(send_click=False, time_out=0, click_f=False)
            self.hold_attack_until_lib(timeout=self.STANDARD_HOLD_SLICE)
        return self.liberation_available()

    def cast_r1(self):
        """R1 预求我身·见心: 变身进预求身。"""
        if not self.liberation_available():
            return False
        self.click_echo(time_out=0)
        if self.click_liberation(click_f=False):
            self.macro_mark('R1')
            self.just_transformed = True
            return True
        return False

    def hold_attack_until_lib(self, min_hold=0.0, timeout=None):
        """按住攻击键直到大招亮起。心念靠长按打出的强化重击攒, 点普攻攒得慢。"""
        timeout = self.INTRO_HOLD_TIMEOUT if timeout is None else timeout
        start = time.time()
        self.task.mouse_down()
        try:
            while self.time_elapsed_accounting_for_freeze(start) < timeout:
                if self.time_elapsed_accounting_for_freeze(start) >= min_hold \
                        and self.liberation_available():
                    return True
                self.sleep(0.1)
        finally:
            self.task.mouse_up()
        return False

    def perform_standard(self):
        """常世身: 按住攻击键攒心念 -> 放大招变身。这里一下普攻都不点。"""
        while self.has_long_action() and self.field_elapsed() < self.FIELD_TIME_OUT:
            if self.liberation_available() and self.click_liberation(click_f=False):
                self.just_transformed = True
                return
            self.click_echo(time_out=0)
            self.click_resonance(send_click=False, time_out=0, click_f=False)
            self.hold_attack_until_lib(timeout=self.STANDARD_HOLD_SLICE)
            self.sleep(0.05)

    def field_elapsed(self):
        return self.time_elapsed_accounting_for_freeze(self.last_perform)

    # ------------------------------------------------------------------ 预求身
    def transform_macro(self):
        """变身后的爆发, 顺序照图: 3A-重击 → 2A-重击 → 2A-闪-2居合
        → 2E-居合 → 处决-a3 → 闪-居合 → 重击-R2 → E。Returns: R2 是否放出去了。"""
        self.logger.info(f'hiyuki macro: 3A-heavy -> 2A-heavy -> 2A-dodge-{self.KENDO_AFTER_A2}kendo '
                         f'-> 2E-kendo -> [execute-a3] -> dodge-kendo -> heavy-R2 -> E')
        # 整段关掉脱战判定: 爆发期间常有"目标丢失"误报, 一抛异常 R2 就没了
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        try:
            self.macro_start()
            # 3A-重击
            self.attack_chain()
            self.macro_heavy()
            # 2A-重击
            self.attack_chain_short()
            self.macro_heavy()
            # 2A-闪-2居合
            self.attack_chain_short()
            self.kendo_sequence(self.KENDO_AFTER_A2)

            # 2E-居合: 两段共鸣技能, 再闪避进架势打一段居合
            self.cast_resonance_twice()
            self.kendo_sequence(1)

            # 处决-a3: 处决会打断A链, 补一发重接第三段; 没处决就正常打一条A3
            if self.macro_execute():
                self.click()
                self.macro_mark('a_after_f')
                self.macro_wait(self.M_A_ONE)
            else:
                self.attack_chain()

            # 闪-居合 → 重击-R2
            ok = self.finish_with_r2()
            if ok:
                # 图中的收尾 E
                self.exit_resonance()
            return ok
        finally:
            self.task.skip_combat_check = previous

    def attack_chain(self):
        """一条普攻连段, 点到 A3 特效出现。收招时刻从第一下点击算起, 跟点了几下无关。"""
        self.continues_normal_attack(self.M_A_CHAIN, interval=self.M_A_INTERVAL)
        self.macro_mark('a3')

    def attack_chain_short(self):
        """两段普攻(2A)。"""
        self.continues_normal_attack(self.M_A2_CHAIN, interval=self.M_A_INTERVAL)
        self.macro_mark('a2')

    def macro_heavy(self):
        """预求身重击: 按住攻击键打一发蓄力重击, 顺便攒寒意/吃拼刀窗口。"""
        self.task.mouse_down()
        self.macro_mark('heavy')
        try:
            self.macro_wait(self.M_HEAVY_HOLD)
        finally:
            self.task.mouse_up()
        self.macro_wait(self.M_HEAVY_RECOVER)

    def kendo_sequence(self, count):
        """闪避进架势后连打 count 段居合, 不接重击。"""
        self.enter_kendo_stance()
        for _ in range(count):
            self.macro_kendo(self.M_KENDO_INTERVAL)

    def cast_resonance_twice(self):
        """2E: 预求身两段共鸣技能(二链会重置技能CD, 也是寒意来源)。"""
        for index in range(2):
            if not self.task.wait_until(self.resonance_available, post_action=self.click,
                                        time_out=self.RES_WAIT):
                self.logger.info(f'hiyuki macro: resonance {index + 1} not available')
                continue
            self.click_resonance(send_click=False, time_out=0, click_f=False)
            self.macro_mark(f'E{index + 1}')
            self.macro_wait(self.M_E_GAP)

    def exit_resonance(self):
        """R2 后面的收尾 E: 补协奏, 延奏交给下一位。"""
        if not self.resonance_available():
            self.task.wait_until(self.resonance_available, time_out=self.RES_WAIT)
        if self.resonance_available():
            self.macro_tap_e(self.M_EXIT_E_SETTLE)

    def macro_dodge(self, settle):
        self.task.click(key='right')
        self.macro_mark('dodge')
        self.macro_wait(settle)

    def macro_hold_e(self, hold, settle):
        self.task.send_key_down(self.get_resonance_key())
        self.macro_mark('E_down')
        try:
            # macro_wait 会在任务被停用时抛异常, 长按必须放在 finally 里松开
            self.macro_wait(hold)
        finally:
            self.task.send_key_up(self.get_resonance_key())
        self.record_resonance_use()
        self.macro_mark('E_up')
        self.macro_wait(settle)

    def macro_tap_e(self, settle):
        self.task.send_key(self.get_resonance_key())
        self.record_resonance_use()
        self.macro_mark('E_tap')
        self.macro_wait(settle)

    def macro_kendo(self, settle=None):
        self.click()
        self.macro_mark('kendo')
        self.macro_wait(self.M_KENDO_INTERVAL if settle is None else settle)

    def macro_execute(self):
        """处决。没有提示就跳过 —— F 同时是拾取键, 空按会点到场景物件。
        框架的 can_break 只在带战斗判定的 sleep 里刷新, 定时段用不到, 所以自己抓帧现查。
        Returns: 处决是否真按出去了。
        """
        if not self.execute_available():
            return False
        start = time.time()
        self.task.send_key('f')
        self.macro_mark('F')
        self.task.can_break = False  # 自己按掉的, 别让切人时再按一次
        # 提示消失=确实触发; 之后时停画面静止, 找图看不出演到哪只能按秒等
        self.task.wait_until(lambda: not self.execute_prompt(), time_out=0.8)
        self.macro_wait(self.M_EXECUTE_ANIM)
        self.add_freeze_duration(start, time.time() - start)
        return True

    def execute_available(self):
        """只认屏幕中央那个F提示。另外两个信号都不能当判据:
        can_break 是粘滞标记(别的角色场上看到一次击破就一直是True);
        f_break_full 是顿感条满, 条满但处决窗口没开时按下去会被当成拾取吃掉。
        """
        self.task.next_frame()
        prompt = bool(self.execute_prompt())
        if prompt and not self.task.is_pick_f():
            return True
        bar_full = bool(self.task.find_one('f_break_full', threshold=0.92))
        self.logger.info(f'hiyuki macro: skip F (f_break={prompt} bar_full={bar_full})')
        return False

    def execute_prompt(self):
        box = self.task.box_of_screen(0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True)
        return bool(self.task.find_one('f_break', box=box, target_height=720))

    def finish_with_r2(self):
        """闪避进架势 → 居合 → 终结重击 → R2。

        居合刀数不预先决定, 由架势图标说了算: 一直点, 图标一灭说明最后一刀已释放。
        图标是在释放那一刻灭的(慢放确认), 所以按住攻击键的基准从"点击"换成了"释放",
        点击到释放之间那段不确定的排队被自动吸收掉。
        """
        start = time.time()
        self.enter_kendo_stance()

        clicked = 0
        released = None
        while clicked < self.KENDO_MAX_CLICKS:
            self.macro_kendo(self.M_KENDO_INTERVAL)
            clicked += 1
            # 查图标放在下一次点击之前: 图标已经有整整一个间隔去更新
            if not self.in_kendo_stance():
                released = time.time()
                break

        if released is not None:
            hold_at = released + self.KENDO_RELEASE_TO_HOLD
        else:
            hold_at = time.time() + max(0.0, self.M_KENDO_TO_HOLD - self.M_KENDO_INTERVAL)

        if not self.task.wait_until(self.lib_heavy_available, time_out=self.LIB_FORTE_SETTLE):
            self.recover_kendo(start)
            hold_at = time.time() + self.M_KENDO_TO_HOLD  # 补救打乱了节奏, 重新起算
        self.logger.info(f'hiyuki macro: {clicked} kendo, released={released is not None}, '
                         f'lib_forte={bool(self.lib_heavy_available())}')
        return self.hold_heavy_into_r2(hold_at)

    def recover_kendo(self, start):
        """终结重击没亮就接着补。没亮无非被打断吞刀 或 寒意见底居合没出来,
        两者画面上分不清, 所以按连点次数轮换: 连点几下还没亮就补普攻重进架势。"""
        since_reset = 0
        while not self.lib_heavy_available():
            if self.time_elapsed_accounting_for_freeze(start) >= self.TAIL_TIME_OUT:
                self.logger.warning('hiyuki macro: lib forte never lit up, going to R anyway')
                return
            if since_reset >= self.KENDO_RETRY_STRIDE or not self.in_kendo_stance():
                self.attack_chain()
                self.enter_kendo_stance()
                since_reset = 0
            self.macro_kendo()
            since_reset += 1

    def enter_kendo_stance(self):
        """闪避进架势。等不到标记也照样往下走, 真正的判据是终结重击亮没亮。"""
        self.macro_dodge(self.M_DODGE_TO_KENDO)
        return bool(self.task.wait_until(self.in_kendo_stance, time_out=self.STANCE_WAIT))

    def in_kendo_stance(self):
        return bool(self.task.find_one('hiyuki_left', threshold=0.5))

    def lib_heavy_available(self):
        return bool(self.task.find_one('hiyuki_lib_forte', threshold=0.7))

    def r2_press_time(self):
        return self.R2_HOLD_TIME

    def energy_ready(self):
        """大招是能量门控不是CD门控: 图标上没有数字, has_cd('liberation') 永远是假的。"""
        return self.current_liberation() > 0

    def top_up_energy(self):
        """R2 能量不够就补普攻, 补到能开为止。不设次数上限, 只有时间上限。

        位置必须在终结重击之前: R 是在重击动画里按下的, 到那时才发现不够就晚了。
        Returns: 补了几下, 0 = 本来就够。
        """
        if self.energy_ready():
            return 0
        start = time.time()
        n = 0
        while self.time_elapsed_accounting_for_freeze(start) < self.R2_ENERGY_WAIT:
            # 技能回的寒意比普攻多, 能放就插一个
            if self.resonance_available():
                self.click_resonance(send_click=False, time_out=0, click_f=False)
            self.click()
            n += 1
            self.macro_mark(f'energy_a{n}')
            self.macro_wait(self.M_ENERGY_A_INTERVAL)
            if self.energy_ready():
                self.logger.info(f'hiyuki macro: R2 energy full after {n} extra attack(s)')
                return n
        self.logger.warning(f'hiyuki macro: R2 energy still not full after {n}, releasing anyway')
        return n

    def hold_heavy_into_r2(self, hold_at):
        """打出终结重击, 松手 → 间隔 R2_START_DELAY 秒 → 长按 R 蓄满 → 放。

        【重击必须打】: 每次都先补一发终结重击(第一次是主重击, 重试是补救)。
        重击被打断时后面按 R 是没用的, 上一版把第一次的重击漏掉了, 所以出现
        "居合完直接开大、没有重击"。

        Args:
            hold_at: 打算按住攻击键的墙钟时刻, 已经过了就立刻按。
        """
        # 补过能量的话原时刻作废: 那几下普攻自己要收招, 长按会落在普攻动画里被丢
        if self.top_up_energy():
            hold_at = time.time() + self.M_ENERGY_SETTLE

        self.macro_wait(max(0.0, hold_at - time.time()))
        start = time.time()

        fired = False
        r2_start = time.time()
        for attempt in range(1, self.R2_MAX_ATTEMPTS + 1):
            # 1) 终结重击(每次尝试都打)
            self.task.mouse_down()
            self.macro_mark('heavy' if attempt == 1 else f'heavy_retry{attempt}')
            self.macro_wait(self.HEAVY_TO_R)
            self.task.mouse_up()
            self.macro_mark('heavy_up')

            # 2) 距离上一个动作 0.5 秒再开始长按 R —— 贴太近会被当点按
            self.macro_wait(self.R2_START_DELAY if attempt == 1 else self.R2_RETRY_DELAY)
            self.task.send_key_down(self.get_liberation_key())
            self.macro_mark(f'R_down{attempt}')

            # 3) 按住蓄满所有锻雪·归刃(游戏蓄满自动放), 节奏放慢, 不狂点
            r2_start = time.time()
            last = 0.0
            while time.time() - r2_start < self.R2_HOLD_TIME:
                elapsed = time.time() - r2_start
                if elapsed - last >= self.R2_REPEAT_INTERVAL:
                    self.task.send_key_down(self.get_liberation_key())  # 重发防掉键
                    last = elapsed
                # 蓄力至少 3 秒才会放, 之后角色离场就说明放出去了
                if elapsed > self.R2_MIN_CHARGE and not self.task.in_team()[0]:
                    fired = True
                    break
                self.sleep(0.05, check_combat=False)
            self.task.send_key_up(self.get_liberation_key())
            if fired:
                break
            self.logger.info(f'hiyuki macro: R2 attempt {attempt} not fired, retry')
        self.macro_mark('R_up')
        self.logger.info(f'hiyuki macro timeline: {self.macro_timeline()}')

        self.r2_used = True
        self.record_liberation_use()
        self.task.in_liberation = True
        self.task.wait_until(lambda: self.task.in_team()[0], time_out=self.POST_LIB2_TEAM_WAIT)
        self.task.in_liberation = False
        self.add_freeze_duration(start, time.time() - start)
        self.lib2_count = 0
        self.logger.info(f'hiyuki macro: R2 released (held {time.time() - r2_start:.1f}s, '
                         f'{self.R2_START_DELAY:.1f}s after heavy)')
        return True

    def macro_wait(self, sec):
        """精确等待。

        不走 executor.sleep: 它每 sleep_check_interval(0.4s) 会无条件插一次
        next_frame 截图(skip_combat_check 只跳过判定逻辑, 跳不过截图), 插入位置不可控。
        重击接R、居合之间 的容错在 ±0.1 秒级, 排不了这种时序。
        切成 0.1 秒一片并在片间检查任务是否被停用, 精度保持在 10 毫秒。
        """
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)

    def macro_start(self):
        self.macro_t0 = time.time()
        self.macro_marks = []

    def macro_mark(self, name):
        """记一笔输入发出的时刻。对着录像就能看出是哪一下被吞了。"""
        self.macro_marks.append(f'{name}@{time.time() - self.macro_t0:.2f}')

    def macro_timeline(self):
        return ' '.join(self.macro_marks)

    # ------------------------------------------------------------------ 兜底
    def perform_lib(self):
        """宏没走通时的兜底: 反应式循环。"""
        timeout = self.FIELD_TIME_OUT
        while self.has_long_action2() and self.field_elapsed() < timeout:
            self.click_echo(time_out=0)
            lib_heavy_avail = self.lib_heavy_available()
            is_timeout = self.field_elapsed() >= timeout - 0.5

            if self.lib_permission and self.liberation_available() and (
                    self.lib2_count >= self.LIB2_KENDO_COUNT or is_timeout):
                if self.hold_liberation():
                    self.lib2_count = 0
                    return True

            res = self.click_resonance(send_click=False, time_out=0, click_f=False)
            if res and res[0]:
                if is_timeout:
                    break
                self.macro_hold_e(self.M_HOLD_E_LAND, self.M_LAND_RECOVER)
            elif lib_heavy_avail:
                if is_timeout:
                    break
                if self.wait_locked(self.WAIT_LOCK_TIME_OUT):
                    self.heavy_forte_fast(self.lib_heavy_available)
                if self.task.wait_until(self.liberation_available, post_action=self.click,
                                        time_out=0.5):
                    if self.wait_locked(self.WAIT_LOCK_TIME_OUT) and self.hold_liberation():
                        self.lib2_count = 0
                        return True
                self.lib2_count += 1
                self.sleep(0.1)
            elif self.in_kendo_stance():
                self.task.wait_until(lambda: not self.in_kendo_stance(),
                                     post_action=self.click, time_out=3.0)
                if is_timeout:
                    break
                self.sleep(0.1)
            elif bool(self.task.find_one('hiyuki_right', threshold=0.5)):
                self.task.click(key='right', interval=1.0)
                self.sleep(0.1)
            else:
                self.click()
            self.sleep(0.05)

        if self.lib_permission and self.liberation_available() and self.hold_liberation():
            self.lib2_count = 0
            return True
        return False

    def hold_liberation(self):
        """长按大招键放R2。三处修补: 返回值要代表真的按下去了;
        补 record_liberation_use(); 循环退出后继续按住蓄力(循环条件是
        liberation_available(), R2一放出去它立刻变False, 当场松手等于一点没蓄)。
        """
        if not self.task.use_liberation:
            return False

        last_click = 0
        sent = False
        start = time.time()
        while self.task.in_team()[0] and (
                self.liberation_available()
                or self.task.get_cd('liberation') <= self.HOLD_LIB_CD_WAIT) \
                and time.time() - start < self.HOLD_LIB_TIME_OUT:
            if time.time() - start > last_click:
                self.task.send_key_down(self.get_liberation_key())
                sent = True
                last_click += 0.2
            self.sleep(0.05, check_combat=False)

        if not sent:
            self.task.send_key_up(self.get_liberation_key())
            return False

        press_time = self.r2_press_time()
        charge_start = time.time()
        last = 0.0
        while time.time() - charge_start < press_time:
            if time.time() - charge_start - last >= self.R2_REPEAT_INTERVAL:
                self.task.send_key_down(self.get_liberation_key())
                last = time.time() - charge_start
            # 蓄满所有层, 角色离场才算放完
            if time.time() - charge_start > self.R2_MIN_CHARGE and not self.task.in_team()[0]:
                break
            self.sleep(0.05, check_combat=False)
        self.r2_used = True

        self.task.in_liberation = True
        self.task.send_key_up(self.get_liberation_key())
        self.task.wait_until(lambda: self.task.in_team()[0], time_out=self.POST_LIB2_TEAM_WAIT)
        self.task.in_liberation = False
        self.record_liberation_use()
        self.add_freeze_duration(start, time.time() - start)
        self.logger.info(f'hold_liberation end {time.time() - start:.1f}s')
        return True

    # ------------------------------------------------------------------ 交棒
    def leave(self, skip_outro=False):
        """唯一的离场口。整段关掉脱战判定: 打完爆发常有"目标丢失->判定脱战"的误报,
        那时 check_combat() 一抛异常切人就再也执行不到了。"""
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        try:
            if skip_outro and self.direct_switch(assume_intro=True):
                return
            if not skip_outro:
                self.ensure_outro()
            self.switch_next_char()
        except Exception as e:
            # assume_intro 要跟着原来那次一起传: 补救这一下也是紧接在 R2 后面的,
            # 协奏读数照样滞后
            self.logger.warning(f'hiyuki leave failed ({e}), trying direct switch')
            if not self.direct_switch(assume_intro=skip_outro):
                raise
        finally:
            self.task.skip_combat_check = previous

    def ensure_outro(self):
        """协奏不满就不离场。两个安全阀: 协奏卡住不涨, 或站够绝对上限。"""
        # 先等读数稳定: 大招刚放完时协奏往往已经满了, 只是能量环还没渲染回来
        if self.task.wait_until(self.is_con_full, time_out=0.8):
            return True

        start = time.time()
        best_con = self.get_current_con()
        last_gain = time.time()
        while True:
            if self.is_con_full():
                return True
            if self.time_elapsed_accounting_for_freeze(start) >= self.OUTRO_HARD_LIMIT:
                self.logger.warning('hiyuki hit outro hard limit, switching without outro')
                return False
            con = self.get_current_con()
            if con > best_con + 0.01:
                best_con = con
                last_gain = time.time()
            elif time.time() - last_gain > self.OUTRO_STALL_TIME:
                self.logger.warning(f'hiyuki con stuck at {con:.2f}, switching without outro')
                return False

            if self.echo_available():
                self.click_echo(time_out=0)
                continue
            res = self.click_resonance(send_click=False, time_out=0, click_f=False)
            if res and res[0]:
                self.macro_hold_e(self.M_HOLD_E_LAND, self.M_LAND_RECOVER)
                self.macro_kendo()
                continue
            if self.is_mouse_forte_full():
                self.heavy_forte_fast(self.is_mouse_forte_full)
                continue
            self.continues_normal_attack(self.CON_TOP_UP_CHAIN, until_con_full=True)

    def direct_switch(self, assume_intro=False):
        """按数字键直接切给交棒对象。不走 switch_next_char(): 那个内部有三处
        continues_normal_attack/click, 大招之后不想要那几下多余的A。

        R2 刚结束那几秒头像栏是读不到的(in_team() 假、队伍识别退化成 unknown),
        switch_target() 会落空。所以目标解析不出来时改成盲发写死的槽位键,
        切成之后再补记账。
        """
        target = self.switch_target()
        slot = self.DIRECT_SWITCH_INDEX if target is None else target.index + 1
        if slot - 1 == self.index:
            self.logger.warning(f'hiyuki direct switch: slot {slot} is myself, '
                                f'team={self.team_roster()}')
            return False
        # 刚放完大招时直接认定协奏满: 读数滞后会把 has_intro 误判成 False,
        # 那样洛瑟拉会以为自己空手入场跑去走开场流程
        has_intro = True if assume_intro else self.wait_con_full()

        # 大招动画期间就按住普攻并狂发切人键, 不干等动画演完: 按住普攻让动画一结束
        # 攻击立刻接上; 切人键在动画期间发出去看似白发, 但换来"能切的第一帧就切走"
        deadline = self.LIB_ANIM_WAIT + self.LEAVE_SWITCH_TIMEOUT
        start = time.time()
        switched = False
        self.task.mouse_down()
        try:
            while time.time() - start < deadline:
                in_team, current_index, _ = self.task.in_team()
                if in_team and current_index == slot - 1:
                    self.logger.info(f'hiyuki direct switched to slot {slot} '
                                     f'(intro={has_intro}, {time.time() - start:.1f}s)')
                    switched = True
                    break
                self.task.send_key(slot)
                self.sleep(0.12, check_combat=False)
        finally:
            self.task.mouse_up()

        if not switched:
            self.logger.warning(f'hiyuki direct switch to slot {slot} failed')
            return False

        if target is None:
            # 盲发那条路: 人已经过去了, 现在头像栏也读得到了, 重读一次队伍把对象认出来。
            # 必须在打 has_intro 之前读 —— load_chars() 末尾会对每个角色 reset_state()
            self.task.load_chars()
            target = self.char_at_index(slot - 1)
        if target is None or target is self:
            self.logger.warning(f'hiyuki switched to slot {slot} but could not resolve the char, '
                                f'team={self.team_roster()}')
            return True  # 人确实切过去了, 不能再让调用方去 switch_next_char()
        self.handoff_to(target, has_intro)
        return True

    def handoff_to(self, target, has_intro):
        """复刻 switch_next_char() 内部那套交接记账。直接按数字键切人绕开了框架逻辑,
        不补的话没人的 is_current_char 是 True, get_current_char() 返回 None 会崩。
        """
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            # has_intro 是易失的: reset_state() 每次重读队伍都会清掉它
            target.note_intro_handoff()
        target.last_switch_in_time = time.time()
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        return bool(self.task.wait_until(self.is_con_full, time_out=0.5))

    def switch_target(self):
        """交棒对象: 先按角色名找(不假设队伍顺序), 找不到再退回写死的槽位。"""
        for char in self.task.chars:
            if char is not None and char is not self and char.char_name == self.SWITCH_TARGET_NAME:
                return char
        slot_char = self.char_at_index(self.DIRECT_SWITCH_INDEX - 1)
        if slot_char is not None:
            return slot_char
        self.logger.warning(f'hiyuki switch target unresolved '
                            f'(name={self.SWITCH_TARGET_NAME} slot={self.DIRECT_SWITCH_INDEX}), '
                            f'team={self.team_roster()}')
        return None

    def char_at_index(self, index):
        return next((c for c in self.task.chars
                     if c is not None and c is not self and c.index == index), None)

    def team_roster(self):
        return [None if c is None else (c.index, str(c.char_name)) for c in self.task.chars]

    # ------------------------------------------------------------------ 基元
    def heavy_forte_fast(self, check_fun, time_out=None):
        """强化重击。BaseChar.heavy_click_forte 的 wait_until 写死2秒, 回路一直没打掉时白按满。"""
        time_out = self.HEAVY_FORTE_TIME_OUT if time_out is None else time_out
        if not check_fun():
            return False
        self.task.mouse_down()
        try:
            success = self.task.wait_until(lambda: not check_fun(), time_out=time_out)
        finally:
            self.task.mouse_up()
        self.sleep(0.05)
        return bool(success)

    def wait_locked(self, time_out):
        return bool(self.task.wait_until(self.has_long_action2, post_action=self.click,
                                         time_out=time_out))

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """图里的整队循环是 维里奈 → 洛瑟拉 → 绯雪 → 维里奈.

        洛瑟拉打完(完美E-Q-R-长按A满协奏)必须把变奏交给绯雪, 这里给 MUST;
        维里奈后面要先让洛瑟拉上场, 所以不从维里奈手里抢人(让她按自己的优先级切洛瑟拉)。
        """
        if has_intro and current_char and current_char.char_name in {'char_lucilla', 'char_linnai'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
