import time

from src.char.BaseChar import BaseChar, SwitchPriority


class Lucilla(BaseChar):
    LIBERATION_ANIMATION_TIME = 3.0
    LIBERATION_HEAVY_TIME = 5.0
    HEAVY_PULSE_TIME = 0.6
    # 长按E攒一格回路能量的时长。和机器/帧率有关, 时机不稳就往上调, 上游原版是 1.4。
    # 给短了会退化成点按, 静默失败, 日志里看 'Lucilla E swallowed' 的频率
    RES_HOLD_TIME = 0.8
    # E 的后摇。E #1 之后 0.19 秒按 R 会被整个吞掉(日志: perform lib 1 presses 之后
    # forte drained after 0.0s = 根本没进形态), 所以按 R 前必须先等这段后摇走完
    RES_ANIM_WAIT = 0.7
    CHARGE_TIME_OUT = 7.2
    LIBERATION_CD_SKIP = 1.5
    ECHO_WINDOW = (0.6, 4.0)
    EXTRA_BUDGET = 4.0
    HOLD_FIELD_OUTRO = {'char_suisui'}
    # 按 R 的重试窗口: 一次没放出来(被吞)就补按, 不再"按一次就假设成功"
    LIB_PRESS_TIMEOUT = 2.0
    LIB_CONFIRM_TIME = 0.45
    # E 放完等 CD 跳变/图标进CD 的时间(读数有滞后, 不能一下读完就判死)
    CD_CONFIRM_TIME = 0.35

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.e_count = 0
        self.last_res_time = 0.0
        self.check_f_on_switch = False

    def reset_state(self):
        super().reset_state()
        # 【v3.5.32 起这一句必须在 reset_state 里重申, 只写 __init__ 保不住】:
        # CharFactory.apply_team_char_classes() 换成自定义类的写法是
        # `replacement.__dict__.update(内置实例.__dict__)` —— __init__ 里所有跟内置版
        # 取值不同的字段会被整个打回内置值。BaseChar.__init__ 是 `not self.is_healer`,
        # 所以非治疗角色一律被打回 True, 框架就会在 switch_next_char() 里替她按 F。
        # reset_state() 跑在那次 update 之后(load_chars: apply_team_char_classes -> 逐个
        # reset_state), 而且每次重读队伍都会再跑一遍, 放这里才真的保得住。
        # 洛瑟菈全程不打处决, 处决只归绯雪按轴上那一处自己按。
        self.check_f_on_switch = False

    def do_perform(self):
        if not self.perform_combat():
            self.switch_next_char()

    def perform_combat(self):
        start = time.time()
        self.task.wait_until(lambda: self.task.in_team()[0], time_out=0.2)
        if self.has_intro:
            # 入场动画期间的输入会被吞, 不是延迟执行
            self.sleep(self.intro_motion_freeze_duration, check_combat=False)
        self.task.next_frame()

        self.e_count = 0
        self.last_res_time = 0.0
        # 接维里奈延奏时手上已经有两格, 补一格即可; 空手入场要攒满三格
        target = 1 if self.has_intro else 3
        hold_field = self.has_intro and self.check_outro() in self.HOLD_FIELD_OUTRO

        while self.time_elapsed_accounting_for_freeze(start) < self.CHARGE_TIME_OUT:
            if self.e_count >= target:
                if self.perform_liberation():
                    self.switch_next_char(free_intro=self.fill_con())
                    return True
                # 大招没放出去说明有一发 E 被吞了或者 R 被吃了, 退一格重攒
                self.e_count = max(0, self.e_count - 1)
            elif self.time_elapsed_accounting_for_freeze(start) >= 2 and not hold_field \
                    and not self.liberation_available() \
                    and self.task.get_cd('liberation') > self.LIBERATION_CD_SKIP:
                self.logger.info('Lucilla liberation on long cd, switch to save time')
                break
            self.charge_once()
        return False

    def charge_once(self):
        """攒一格: 长按E。

        【CD 读数有滞后】: 刚放完 E 的那一下 get_cd('resonance') 经常还是 0, 旧版据此
        判定"被吞"、不给计数, 结果 E 已经进 CD 没法再放, 整轮卡在 2 格等到超时切人
        (日志: 'E swallowed (cd still -0.0s)' 之后再也没有 E #n)。所以这里等 CD 跳变,
        或者直接看图标进 CD, 任一成立就算放出来了。
        """
        for _ in range(2):
            if not self.resonance_available():
                self.sleep(0.15)
                return
            self.hold_resonance(self.RES_HOLD_TIME)
            fired = self.task.wait_until(
                lambda: self.task.get_cd('resonance') > 0 or not self.resonance_available(),
                time_out=self.CD_CONFIRM_TIME)
            if not fired:
                self.logger.warning(f'Lucilla E swallowed (held {self.RES_HOLD_TIME:.2f}s), retry')
                self.sleep(0.12)
                continue
            self.e_count += 1
            self.last_res_time = time.time()
            self.logger.info(f'Lucilla E #{self.e_count}, resonance cd now '
                             f'{self.task.get_cd("resonance"):.1f}s')
            self.task.next_frame()
            return

    def hold_resonance(self, duration):
        self.task.send_key_down(self.get_resonance_key())
        try:
            self.sleep(duration, check_combat=False)
        finally:
            self.task.send_key_up(self.get_resonance_key())
        self.record_resonance_use()

    def wait_resonance_animation(self):
        """E 的后摇没走完就按 R 会被整段吞掉(实测按在 E 后 0.19 秒时 100% 空放)。"""
        if self.last_res_time <= 0:
            return
        remain = self.RES_ANIM_WAIT - (time.time() - self.last_res_time)
        if remain > 0:
            self.sleep(remain, check_combat=False)

    def liberation_fired(self):
        """变身形态的硬信号: 角色离场(大招动画) 或 太刀回路亮起。

        不能用"大招图标熄灭"当判据 —— E 的后摇/技能动画期间图标也会假性熄灭,
        上一版就是被这个骗了: 按了 1 次 R 就 break, 实际一下都没放出去。
        """
        if not self.task.in_team()[0]:
            return True
        return bool(self.is_mouse_forte_full())

    def perform_liberation(self):
        """放大招变身并输出。返回大招是否真的放出去了。"""
        if not self.task.use_liberation:
            return False

        self.wait_resonance_animation()
        # 不用 click_liberation: 它内部的 while not in_team() 在变身形态下会卡死。
        start = time.time()
        sent = 0
        fired = False
        while time.time() - start < self.LIB_PRESS_TIMEOUT:
            self.send_liberation_key()
            sent += 1
            if self.wait_transform(self.LIB_CONFIRM_TIME):
                fired = True
                break
            self.logger.debug(f'Lucilla liberation press {sent} not fired, retry')
            self.sleep(0.1, check_combat=False)
        if not fired:
            self.logger.warning(f'Lucilla liberation not fired after {sent} presses')
            return False

        self.record_liberation_use()
        self.logger.info(f'Lucilla perform lib ({sent} presses)')
        self.sleep(self.LIBERATION_ANIMATION_TIME, check_combat=False)
        self.pulse_heavy_attack(self.LIBERATION_HEAVY_TIME)
        # 被打断时能量会剩, 变身一结束就作废, 所以按图标打空为准
        self.pulse_until(lambda: not self.is_mouse_forte_full(), 'forte drained')
        self.logger.info(f'Lucilla perform lib end ({time.time() - start:.1f}s)')
        return True

    def wait_transform(self, time_out):
        """等变身形态出现, 超时返回 False(这一下 R 被吞了)。"""
        deadline = time.time() + time_out
        while time.time() < deadline:
            if self.liberation_fired():
                return True
            self.sleep(0.05, check_combat=False)
        return False

    def pulse_heavy_attack(self, total_time):
        """脉冲重击: 每拍重新按下, 某拍被打断下一拍自动恢复。Q 在窗口内反复发。"""
        start = time.time()
        last_echo = 0
        while time.time() - start < total_time:
            elapsed = time.time() - start
            # 变身动画期间按 Q 会被吞, 形态结束后按又没了增益, 只有中间这段有效
            if self.ECHO_WINDOW[0] <= elapsed <= self.ECHO_WINDOW[1] and time.time() - last_echo >= 0.3:
                self.send_echo_key()
                last_echo = time.time()
            self.heavy_pulse()

    def pulse_until(self, cond, name):
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.EXTRA_BUDGET:
            if cond():
                self.logger.info(f'Lucilla {name} after {time.time() - start:.1f}s')
                return True
            self.heavy_pulse()
        self.logger.warning(f'Lucilla {name} timed out')
        return False

    def heavy_pulse(self):
        self.task.mouse_down()
        try:
            self.sleep(self.HEAVY_PULSE_TIME, check_combat=False)
        finally:
            self.task.mouse_up()
        self.sleep(0.02, check_combat=False)

    def fill_con(self):
        """确认协奏满再交棒。变身刚结束时能量环读数滞后, 直接读会读成 0。"""
        if self.task.wait_until(self.is_con_full, time_out=1.5):
            return True
        # 读数已经该稳了还没满, 说明是真的短了(被打断), 站着等没用, 得打
        self.logger.info(f'Lucilla con reads {self.get_current_con():.2f} after settle, attacking')
        if self.pulse_until(self.is_con_full, 'con filled'):
            return True
        self.logger.warning(f'Lucilla con still reads {self.get_current_con():.2f}, '
                            f'next char gets no intro')
        return False

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_verina', 'char_shorekeeper',
                                                                    'char_suisui'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)