import time
from src.char.BaseChar import BaseChar, SwitchPriority


class Phrolova(BaseChar):
    #下面修改后面的数字切换不同连招
    COMBO_SCHEME = 3  #前面这个数字代表用哪个连招
    # ========== 3 套连招切换开关 ==========
    # 1 =（嫖一出场2a强普eaqz)(也就比2多个强化普攻,慢零点几秒）
    # 2 =（直接qz)，无6链放q才能吃专武buff,boss血少用
    # 3 = (裸z）一般来说6链才用，或者boss血极少，比如我们的娅娅，有点练度的2链应该也能裸重秒
    #除了3最快不放q会快1秒，前面两个个时间基本差不了多少，用3秒不了就用2，2秒不了就用1，不同boss可以试试不同的
   
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_liberation = -1
        self.sp = False
        self.res_ready = False

    def skip_combat_check(self):
        return self.time_elapsed_accounting_for_freeze(self.last_liberation) < 2

    def do_perform(self):
        self.last_liberation = -1
        self.sp = False
        self.res_ready = False
        if self.has_intro:
            self.res_ready = False
        if self.check_outro() in {'char_cantarella'}:
            self.sp = True
            self.continues_normal_attack(1.7)
            self.continues_right_click(0.1)
        if self.flying():
            self.wait_down()
        try:
            if self.COMBO_SCHEME == 1:
                # 固定连招
                self.continues_normal_attack(1.2)
                # 普攻 A
                self.continues_right_click(0.1)
                self.continues_normal_attack(0.5)
                # 放eQ
                self.task.send_key(self.get_resonance_key())
                self.continues_normal_attack(0.5)
                
                self.click_echo()
                self.sleep(0.1)
                # 固定起手连招：重击
                self.heavy_and_liber()
                
                # 固定连招结束
            elif self.COMBO_SCHEME == 2:
                # 放 Q
                self.click_echo(time_out=2)
                self.sleep(0.1)
                # 固定起手连招：重击
                self.heavy_and_liber()
                # 放 E
                self.sleep(0.1)
                self.task.send_key(self.get_resonance_key())
                self.sleep(0.5)
                self.normal_attack()
                # 闪避
                self.sleep(0.5)
                self.continues_right_click(0.1)
                pass
            elif self.COMBO_SCHEME == 3:
                #【方案 3 自定义连招】
                # 固定起手连招：重击
                self.heavy_and_liber()
                # 放 EQ
                self.task.send_key(self.get_resonance_key())
                self.sleep(0.28)
                self.click_echo(time_out=2)
                self.sleep(0.1)
                self.continues_normal_attack(1.0)
                # 闪避
                self.sleep(0.1)
                self.continues_right_click(0.1)
                pass

            # 循环输出
            while True:
                self.check_combat()
                if self.flying():
                    self.shorekeeper_auto_dodge()
                    self.task.next_frame()
                    continue
                # 持续 1.8 秒普攻
                self.continues_normal_attack(1.86)
                # 闪避
                self.continues_right_click(0.1)
                self.sleep(0.1)
                # 一次普攻
                self.normal_attack()
                self.sleep(0.23)
                # 闪避
                self.continues_right_click(0.1)
                self.click_echo(time_out=2)
                self.task.next_frame()
                self.heavy_and_liber()
                self.task.send_key(self.get_resonance_key())
                self.click_echo()
                
        finally:
            self.switch_next_char()

    def switch_next_char(self, post_action=None, free_intro=False, target_low_con=False):
        # 切到Phrolova之后强制不切人了，站场到战斗结束
        return self

    def _cantarella_outro_ready(self, current_char, has_intro):
        return self.time_elapsed_accounting_for_freeze(self.last_liberation) > 14 and has_intro and current_char and current_char.char_name in {'char_cantarella'}

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        self.logger.debug(f'Phrolova last_liberation {self.time_elapsed_accounting_for_freeze(self.last_liberation)}')
        if self._cantarella_outro_ready(current_char, has_intro):
            return SwitchPriority.MUST
        if self.time_elapsed_accounting_for_freeze(self.last_liberation) < 24:
            return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def resonance_available(self):
        if self.sp:
            return not (self.flying() or self.has_cd('resonance'))
        return super().resonance_available()

    def heavy_and_liber(self):
        if self.heavy_click_forte(check_fun=self.is_mouse_forte_full):
            self.logger.debug('Phrolova heavy_click_forte')
            self.task.wait_until(lambda: self.click_liberation(wait_if_cd_ready=0), time_out=3)
            return True

    def shorekeeper_auto_dodge(self):
        from src.char.ShoreKeeper import ShoreKeeper
        for i, char in enumerate(self.task.chars):
            if isinstance(char, ShoreKeeper):
                return char.auto_dodge(condition=self.flying)
