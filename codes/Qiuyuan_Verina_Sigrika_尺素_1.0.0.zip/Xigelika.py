# ============================================================================
# Xigelika.py —— 西仇维(维里奈 / 仇远 / 西格莉卡)第三棒：西格莉卡
# ============================================================================
import time

from src.char.Xigelika import Xigelika as NativeXigelika
from src.char.Verina import Verina as NativeVerina


class Xigelika(NativeXigelika):
    """西格莉卡 —— 西仇维主C, 也是整条轴的收尾。

    带变奏入场 -> (Q)R -> E -> 持续检测打重击 -> 回路E -> 处决 -> 切人。
    空手入场 -> 只丢声骸, 交给维里奈重新起圈。
    """

    # ================================================================ 固定顺序切人 (公共段)
    SWITCH_TIMEOUT: float = 2.0
    SWITCH_KEY_INTERVAL: float = 0.12
    SWITCH_SETTLE: float = 0.55
    SETTLE_ATTACK_INTERVAL: float = 0.42
    HANDOFF_CON_WAIT: float = 0.8
    HANDOFF_CON_POLL: float = 0.1
    HOLD_POLL: float = 0.1
    F_BREAK_ON_HANDOFF: bool = False

    intro_pending = False
    switch_confirmed_at = 0.0

    def note_intro_handoff(self):
        self.intro_pending = True

    def take_intro(self):
        intro = self.has_intro or self.intro_pending
        self.intro_pending = False
        return intro

    def reset_fixed_rotation(self):
        self.intro_pending = False

    def direct_switch(self, slot=None, assume_intro=False):
        slot = self.NEXT_SLOT if slot is None else slot
        if slot is None:
            return False
        target = self.char_at_slot(slot)
        if target is None or target is self:
            return False
        has_intro = True if assume_intro else self.wait_con_full()
        if not self.switch_to_index(target.index):
            self.logger.warning(f'direct switch to slot {slot} failed')
            return False
        self.logger.info(f'direct switched to slot {slot} '
                         f'({target.char_name}, intro={has_intro})')
        self.handoff_to(target, has_intro)
        return True

    def switch_to_index(self, index):
        start = time.time()
        while time.time() - start < self.SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if (in_team and current_index == index) or self.switched_away():
                self.switch_confirmed_at = time.time()
                self.settle_with_attack(self.SWITCH_SETTLE)
                return True
            self.task.send_key(index + 1)
            self.click()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)
        return False

    def switched_away(self):
        """自己队伍编号重新出现 = 已经不在场上了。"""
        return self.task.find_one(f'char_{self.index + 1}_text', threshold=0.8) is not None

    def settle_with_attack(self, duration):
        end = time.time() + duration
        while time.time() < end:
            self.click()
            self.sleep(min(self.SETTLE_ATTACK_INTERVAL, max(0.0, end - time.time())),
                       check_combat=False)

    def handoff_to(self, target, has_intro):
        if self.F_BREAK_ON_HANDOFF:
            self.f_break(check_f_on_switch=True)
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = self.switch_confirmed_at or time.time()
        self.switch_confirmed_at = 0.0
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        start = time.time()
        while time.time() - start < self.HANDOFF_CON_WAIT:
            if self.is_con_full():
                return True
            self.sleep(self.HANDOFF_CON_POLL, check_combat=False)
        self.logger.info(f'con not full before switch (con={self.get_current_con()})')
        return False

    def char_at_slot(self, slot):
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    def attack_chain(self, count, interval, last_interval=None):
        for i in range(count):
            self.click()
            if i == count - 1 and last_interval is not None:
                self.sleep(last_interval)
            else:
                self.sleep(interval)

    def hold_until(self, cond, timeout, name):
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < timeout:
            if cond():
                return True
            self.sleep(self.HOLD_POLL)
        self.logger.info(f'timed out waiting for {name} ({timeout:.1f}s)')
        return False

    # ---------------------------------------------- 硬 gate
    GATE_POLL: float = 0.12
    GATE_LOG_EVERY: float = 3.0

    def require(self, name, cond, action=None, timeout=0):
        start = time.time()
        last_log = 0.0
        while True:
            if cond():
                return True
            self.check_combat()
            if action is not None:
                action()
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                self.logger.warning(f'gate [{name}] gave up after {elapsed:.1f}s')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'gate [{name}] not satisfied after {elapsed:.1f}s')
            self.sleep(self.GATE_POLL)

    # ============================================================ 公共段结束

    # ---- 时间常量 ----
    INTRO_ANIM = 0.45
    ECHO_TO_LIB = 0.05
    ECHO_TRIES = 5
    ECHO_RETRY = 0.12
    LIB_TO_E = 0.05
    E_TO_A = 0.60
    A_INTERVAL = 0.18
    FORTE_POLL = 0.05
    HEAVY_START_WAIT = 0.6
    HEAVY_AFTER = 1.20
    DODGE_DELAY = 0.30
    HEAVY_TO_FORTE_E = 0.0
    DODGE_AFTER_HEAVY: bool = False
    ECHO_TO_A = 0.0
    FORTE_E_HOLD = 0.90
    FORTE_E_SETTLE = 0.20
    FORTE_E_TRIES = 2
    FORTE_E_TO_BREAK = 0.20
    BREAK_WINDOW = 0.0
    OPEN_ECHO_TO_SWITCH = 0.05
    CON_GATE_TIMEOUT = 8.0
    MIN_HEAVY_ROUNDS = 2
    FORTE_E_CHECK = 0.25
    FORTE_E_POLL = 0.01
    HEAVY_LOOP_BUDGET = 20.0
    CON_FILL_SLICE = 1.0
    heavy_hold_after = -1.0
    SWITCH_ANCHOR_MAX = 1.5
    SWITCH_TIMEOUT = 3.0
    TEAM_HUD_WAIT = 2.5
    LEAVE_TRIES = 2

    # ---- 指示器阈值 ----
    FORTE_ICON = (2824, 1875, 2962, 1995)
    YELLOW_RB = 35
    YELLOW_GB = 20
    YELLOW_MIN_R = 140
    GREEN_GR = 25
    GREEN_GB = 10
    GREEN_MIN_G = 140
    GREEN_MIN = 0.12
    YELLOW_MIN = 0.10
    FORTE_CONFIRM = 2
    ENHANCED_WAIT = 10.0
    PREINPUT_HOLD: bool = False
    PREINPUT_HOLD_TIME = 0.15
    PREINPUT_GAP = 0.05
    FORTE_E_WAIT = 0.5
    FORTE_LOG_EVERY = 3.0
    CHAIN_E_INTO_HEAVY: bool = False

    @property
    def NEXT_SLOT(self):
        for char in self.task.chars:
            if isinstance(char, NativeVerina):
                return char.index + 1
        return None

    def reset_state(self):
        super().reset_state()
        self.check_f_on_switch = False

    def on_combat_end(self, chars):
        self.reset_fixed_rotation()
        super().on_combat_end(chars)

    # ------------------------------------------------------------------ 路由

    def do_perform(self):
        intro = self.take_intro()
        self.check_f_on_switch = False
        if self.flying():
            self.wait_down()
        if not intro:
            return self.opener_toss()
        return self.main_axis()

    def opener_toss(self):
        """空手入场: 丢声骸, 交给维里奈。不走 direct_switch 以免白等 0.8s 读协奏。"""
        self.logger.info('xigelika: opening toss, handing field to verina')
        self.fire_echo()
        self.sleep(self.OPEN_ECHO_TO_SWITCH)
        target = self.char_at_slot(self.NEXT_SLOT)
        if target is not None and target is not self and self.switch_to_index(target.index):
            self.handoff_to(target, False)
            return
        self.logger.warning('xigelika: opening switch failed, falling back')
        self.switch_next_char()

    # ------------------------------------------------------------------ 主轴

    def main_axis(self):
        anchor = self.switch_in_anchor()
        self.sleep(max(0.0, anchor + self.INTRO_ANIM - time.time()), check_combat=False)
        self.logger.info('xigelika main axis: (Q)R -> E -> heavy_loop -> 回路E -> 处决 -> 切人')

        # Q + R
        self.fire_echo()
        self.sleep(self.ECHO_TO_LIB)
        if not self.click_liberation(wait_if_cd_ready=0.4, click_f=False):
            self.logger.warning('xigelika: liberation not ready, running rest without it')

        # E 打断大招后摇
        self.sleep(self.LIB_TO_E)
        self.cast_resonance()

        # 强化重击循环
        self.sleep(self.E_TO_A)
        e_ready = self.heavy_loop(chain_e=self.CHAIN_E_INTO_HEAVY)

        # 回路E
        if not self.CHAIN_E_INTO_HEAVY:
            self.sleep(self.HEAVY_TO_FORTE_E)
            self.forte_resonance(confirmed=e_ready)

        # 处决 + 切人
        self.sleep(self.FORTE_E_TO_BREAK)
        self.execute_break()
        self.leave()

    # ------------------------------------------------------------------ 动作

    def cast_resonance(self):
        return self.click_resonance(send_click=False, time_out=1)[0]

    def fire_echo(self, click_between=False):
        """Q —— 连发; 进来可用、中途读到冷却才收手。"""
        was_available = self.echo_available()
        for i in range(self.ECHO_TRIES):
            self.send_echo_key()
            self.record_echo_use()
            if click_between:
                self.click()
            self.sleep(self.ECHO_RETRY, check_combat=False)
            if was_available and not self.echo_available():
                return True
        return False

    # ------------------------------------------------------------------ 回路指示器

    def forte_icon_box(self):
        x0, y0, x1, y1 = self.FORTE_ICON
        return self.task.box_of_screen_scaled(3840, 2160, x0, y0, x1, y1,
                                              name='xigelika_forte_icon')

    def forte_color(self):
        """返回 (绿占比, 黄占比)。按通道差算, 不用绝对色值区间。"""
        import numpy as np
        box = self.forte_icon_box()
        try:
            img = box.crop_frame(self.task.frame)
        except Exception:
            return 0.0, 0.0
        if img is None or img.size == 0:
            return 0.0, 0.0
        b = img[:, :, 0].astype(int)
        g = img[:, :, 1].astype(int)
        r = img[:, :, 2].astype(int)
        total = float(r.size)
        yellow = float((((r - b) >= self.YELLOW_RB) & ((g - b) >= self.YELLOW_GB)
                        & (r >= self.YELLOW_MIN_R)).sum()) / total
        green = float((((g - r) >= self.GREEN_GR) & ((g - b) >= self.GREEN_GB)
                       & (g >= self.GREEN_MIN_G)).sum()) / total
        return green, yellow

    def forte_e_ready(self):
        """强化E 是否就绪: e_forte 模板命中 或 E 图标变黄。"""
        if self.is_e_forte_full():
            return True
        try:
            box = self.task.get_box_by_name('box_resonance')
        except Exception:
            return False
        return box is not None and self.box_yellow(box) >= self.YELLOW_MIN

    def box_yellow(self, box):
        try:
            img = box.crop_frame(self.task.frame)
        except Exception:
            return 0.0
        if img is None or img.size == 0:
            return 0.0
        b = img[:, :, 0].astype(int)
        g = img[:, :, 1].astype(int)
        r = img[:, :, 2].astype(int)
        return float((((r - b) >= self.YELLOW_RB) & ((g - b) >= self.YELLOW_GB)
                      & (r >= self.YELLOW_MIN_R)).sum()) / float(r.size)

    def heavy_ready(self):
        """黄 —— 强化重击可用。"""
        _, yellow = self.forte_color()
        return yellow >= self.YELLOW_MIN

    def wait_forte(self, cond, name, timeout, click, click_after=0.0, confirm=None,
                   poll=None):
        """等回路状态成立, 连读 confirm 帧一致才认。"""
        confirm = self.FORTE_CONFIRM if confirm is None else confirm
        poll = self.FORTE_POLL if poll is None else poll
        start = time.time()
        last_click = 0.0
        last_log = 0.0
        hits = 0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if not click or elapsed < click_after:
                self.task.next_frame()
            if cond():
                hits += 1
                if hits >= confirm:
                    self.logger.info(f'xigelika: {name} after {elapsed:.2f}s')
                    return True
            else:
                hits = 0
            if timeout > 0 and elapsed >= timeout:
                return False
            self.check_combat()
            now = time.time()
            if click and elapsed >= click_after and now - last_click >= self.A_INTERVAL:
                self.click()
                last_click = now
            if elapsed - last_log >= self.FORTE_LOG_EVERY:
                last_log = elapsed
                g, y = self.forte_color()
                self.logger.warning(f'xigelika: still waiting for {name} ({elapsed:.1f}s) '
                                    f'g={g:.2f} y={y:.2f}')
            self.sleep(poll)

    def attack_until_heavy(self, timeout):
        """一直打普攻直到黄亮, 返回 (找到, 手是否还按着)。"""
        start = time.time()
        last_log = 0.0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                return False, False
            self.check_combat()
            if self.PREINPUT_HOLD:
                self.task.mouse_down()
                held_at = time.time()
                while time.time() - held_at < self.PREINPUT_HOLD_TIME:
                    self.task.next_frame()
                    if self.heavy_ready():
                        return True, True
                    self.sleep(self.FORTE_POLL, check_combat=False)
                self.task.mouse_up()
                self.sleep(self.PREINPUT_GAP, check_combat=False)
            else:
                self.click()
                self.sleep(self.A_INTERVAL)
            self.task.next_frame()
            if self.heavy_ready():
                return True, False
            if elapsed - last_log >= self.FORTE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'xigelika: waiting 强化重击(黄) ({elapsed:.1f}s)')

    def heavy_loop(self, chain_e=False):
        """持续检测: 黄一亮就长按重击; 直到"重击和强化E都黄"才收尾。"""
        start = time.time()
        heavies = 0
        while True:
            left = self.HEAVY_LOOP_BUDGET - self.time_elapsed_accounting_for_freeze(start)
            if left <= 0:
                self.logger.warning(f'xigelika: heavy_loop budget exhausted '
                                    f'({heavies} heavies)')
                return False
            if heavies >= self.MIN_HEAVY_ROUNDS and self.forte_e_ready():
                return True
            found, held = self.attack_until_heavy(left)
            if not found:
                continue
            started = self.hold_heavy(chain_e=chain_e, already_down=held)
            if started:
                heavies += 1
            if heavies >= self.MIN_HEAVY_ROUNDS and \
                    self.wait_forte(self.forte_e_ready, '强化E 变黄',
                                    timeout=self.FORTE_E_CHECK, click=False,
                                    poll=self.FORTE_E_POLL):
                return True
            self.fire_echo(click_between=True)

    def hold_heavy(self, chain_e=False, already_down=False):
        """长按重击: 锚点是"黄灭"那一刻。返回是否起手。"""
        started = False
        start = time.time()
        if not already_down:
            self.task.mouse_down()
        try:
            started = self.wait_forte(lambda: not self.heavy_ready(), '重击起手(黄灭)',
                                      timeout=self.HEAVY_START_WAIT, click=False)
            start = time.time()
            if chain_e:
                self.task.send_key_down(self.get_resonance_key())
                self.sleep(self.FORTE_E_HOLD, check_combat=False)
                self.task.send_key_up(self.get_resonance_key())
                self.record_resonance_use()
                self.sleep(max(0.0, self.HEAVY_AFTER - self.FORTE_E_HOLD), check_combat=False)
            else:
                self.sleep(self.HEAVY_AFTER, check_combat=False)
        finally:
            self.task.mouse_up()
            self.heavy_hold_after = time.time() - start
        return started

    def forte_resonance(self, confirmed=False):
        """回路E: 长按 E; 用 has_cd 确认放出去了。"""
        if not confirmed:
            if not self.forte_e_ready():
                self.wait_forte(self.forte_e_ready, '强化E 就绪',
                                timeout=self.FORTE_E_WAIT, click=False)
        key = self.get_resonance_key()
        for attempt in range(1, self.FORTE_E_TRIES + 1):
            self.task.send_key_down(key)
            self.sleep(self.FORTE_E_HOLD, check_combat=False)
            self.task.send_key_up(key)
            self.record_resonance_use()
            self.sleep(self.FORTE_E_SETTLE)
            if self.has_cd('resonance'):
                self.logger.info(f'xigelika: 强化E fired (try {attempt})')
                return True
            self.logger.warning(f'xigelika: 强化E not fired (try {attempt})')
        return False

    def dodge(self):
        self.task.click(key='right')

    # ------------------------------------------------------------------ 处决

    def execute_break(self):
        """看一眼处决提示; 有就打, 没有就过。"""
        end = time.time() + self.BREAK_WINDOW
        while True:
            if self.task.can_break or self.break_prompt():
                self.task.can_break = True
                fired = self.f_break()
                self.task.can_break = False
                self.logger.info(f'xigelika: break executed ({fired})')
                return True
            if time.time() >= end:
                break
            if self.heavy_ready():
                self.hold_heavy()
                continue
            self.click()
            self.sleep(0.1)
        self.logger.info('xigelika: no break prompt, switching out')
        return False

    def break_prompt(self):
        box = self.task.box_of_screen(0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True)
        if self.task.find_one('f_break', box=box, target_height=720):
            return not self.task.is_pick_f()
        return False

    # ------------------------------------------------------------------ 离场

    def leave(self):
        """协奏满后切维里奈。切人前先等队伍 HUD 渲染回来。"""
        con_ok = self.fill_con()
        for attempt in range(1, self.LEAVE_TRIES + 1):
            self.wait_team_hud()
            if self.direct_switch(assume_intro=con_ok):
                return
            self.logger.warning(f'xigelika: direct switch failed (try {attempt})')
        self.logger.warning('xigelika: falling back to framework switch')
        self.switch_next_char()

    def fill_con(self):
        """等协奏满 —— 期间盯黄, 亮了就补重击。"""
        start = time.time()
        while True:
            if self.is_con_full():
                return True
            left = self.CON_GATE_TIMEOUT - self.time_elapsed_accounting_for_freeze(start)
            if left <= 0:
                self.logger.warning(f'xigelika: con not full at timeout '
                                    f'(con={self.get_current_con():.2f})')
                return False
            found, held = self.attack_until_heavy(min(self.CON_FILL_SLICE, left))
            if found:
                self.hold_heavy(already_down=held)

    def wait_team_hud(self, timeout=None):
        """等右侧队伍头像编号渲染回来。"""
        timeout = self.TEAM_HUD_WAIT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            if self.task.in_team()[0]:
                return True
            self.task.next_frame()
            self.sleep(0.08, check_combat=False)
        self.logger.warning(f'xigelika: team hud unreadable after {timeout:.1f}s')
        return False

    # ------------------------------------------------------------------ 小工具

    def switch_in_anchor(self):
        now = time.time()
        anchored = self.last_switch_in_time
        gap = now - anchored if anchored > 0 else -1
        if 0 <= gap <= self.SWITCH_ANCHOR_MAX:
            return anchored
        return now