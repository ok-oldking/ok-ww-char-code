# ============================================================================
# Verina.py —— 西仇维(维里奈 / 仇远 / 西格莉卡)第一棒：维里奈
# ============================================================================
import time

from src.char.Verina import Verina as NativeVerina


class Verina(NativeVerina):
    """维里奈 —— 西仇维的开场和循环第一棒。

    轮换环: 维里奈 -> 仇远 -> 西格莉卡 -> 维里奈。她这一棒的活:
    **按 E 拿增益、按 Q 拿声骸增益、(启动时)按 R 攒协奏, 然后带着变奏交给仇远**。

    启动轴: e -> q -> R(反复尝试) -> 等大招动画(0.5s) -> 跳 -> aa
    循环轴: e -> q -> 跳 -> aa
    协奏满后按数字键直接切仇远。

    【R 采用"窗口内反复尝试"模式】: q 之后按 R 经常被 q/e 的动画吃掉,
    单点一次 R 失败率高。用循环反复发 R, 一旦读到进 CD 立即收手。
    【R 之后只等 0.3s】: 用户实机要求 —— 大招动画很快就走完, 缩短等待时间让维里奈
    更快收尾, 把时间让给西格莉卡。
    """
    # ================================================================ 固定顺序切人 (公共段)
    SWITCH_TIMEOUT: float = 2.0
    SWITCH_KEY_INTERVAL: float = 0.12
    SWITCH_SETTLE: float = 0.55
    SETTLE_ATTACK_INTERVAL: float = 0.42
    HANDOFF_CON_WAIT: float = 0.8
    HANDOFF_CON_POLL: float = 0.1
    HOLD_POLL: float = 0.1
    F_BREAK_ON_HANDOFF: bool = False

    intro_pending = False
    switch_confirmed_at = 0.0

    def note_intro_handoff(self):
        self.intro_pending = True

    def take_intro(self):
        intro = self.has_intro or self.intro_pending
        self.intro_pending = False
        return intro

    def reset_fixed_rotation(self):
        self.intro_pending = False

    def direct_switch(self, slot=None, assume_intro=False):
        slot = self.NEXT_SLOT if slot is None else slot
        if slot is None:
            return False
        target = self.char_at_slot(slot)
        if target is None or target is self:
            return False
        has_intro = True if assume_intro else self.wait_con_full()
        if not self.switch_to_index(target.index):
            self.logger.warning(f'verina: direct switch to slot {slot} failed')
            return False
        self.logger.info(f'verina: direct switched to slot {slot} '
                         f'({target.char_name}, intro={has_intro})')
        self.handoff_to(target, has_intro)
        return True

    def switch_to_index(self, index):
        start = time.time()
        while time.time() - start < self.SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == index:
                self.switch_confirmed_at = time.time()
                self.settle_with_attack(self.SWITCH_SETTLE)
                return True
            self.task.send_key(index + 1)
            self.click()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)
        return False

    def settle_with_attack(self, duration):
        end = time.time() + duration
        while time.time() < end:
            self.click()
            self.sleep(min(self.SETTLE_ATTACK_INTERVAL, max(0.0, end - time.time())),
                       check_combat=False)

    def handoff_to(self, target, has_intro):
        if self.F_BREAK_ON_HANDOFF:
            self.f_break(check_f_on_switch=True)
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = self.switch_confirmed_at or time.time()
        self.switch_confirmed_at = 0.0
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        start = time.time()
        while time.time() - start < self.HANDOFF_CON_WAIT:
            if self.is_con_full():
                return True
            self.sleep(self.HANDOFF_CON_POLL, check_combat=False)
        self.logger.info(f'verina: con not full before switch '
                         f'(con={self.get_current_con()}), next char gets no intro')
        return False

    def char_at_slot(self, slot):
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    def attack_chain(self, count, interval, last_interval=None):
        for i in range(count):
            self.click()
            if i == count - 1 and last_interval is not None:
                self.sleep(last_interval)
            else:
                self.sleep(interval)

    def hold_until(self, cond, timeout, name):
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < timeout:
            if cond():
                self.logger.info(f'{name} ready after '
                                 f'{self.time_elapsed_accounting_for_freeze(start):.1f}s')
                return True
            self.sleep(self.HOLD_POLL)
        self.logger.info(f'timed out waiting for {name} ({timeout:.1f}s)')
        return False

    # ---------------------------------------------- 硬 gate
    GATE_POLL: float = 0.12
    GATE_LOG_EVERY: float = 3.0

    def require(self, name, cond, action=None, timeout=0):
        start = time.time()
        last_log = 0.0
        while True:
            if cond():
                waited = self.time_elapsed_accounting_for_freeze(start)
                if waited > 0.3:
                    self.logger.info(f'gate [{name}] ok after {waited:.1f}s')
                return True
            self.check_combat()
            if action is not None:
                action()
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                self.logger.warning(f'gate [{name}] gave up after {elapsed:.1f}s, moving on')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'gate [{name}] not satisfied after {elapsed:.1f}s, '
                                    f'staying on field')
            self.sleep(self.GATE_POLL)

    # ============================================================ 公共段结束

    # ================================================================ 西仇维: 维里奈这一棒

    INTRO_ANIM = 0.5
    E_TO_Q = 0.45
    Q_TO_R = 0.45
    # 【R 之后只等 0.3s】(用户实机要求): 大招动画很快走完, 缩短等待让维里奈更快收尾
    R_ANIM_WAIT = 0.3
    R_TRY_MAX = 6
    R_TRY_INTERVAL = 0.25
    JUMP_ATTACK_TIME = 0.5
    EXTRA_AIR_TIME = 0.4
    NA_INTERVAL = 0.12
    CON_GATE_TIMEOUT = 8.0
    SWITCH_ANCHOR_MAX = 1.5

    @property
    def NEXT_SLOT(self):
        """打完切仇远。按类找人, 不写死队伍位置。"""
        from src.char.Qiuyuan import Qiuyuan as NativeQiuyuan
        for char in self.task.chars:
            if isinstance(char, NativeQiuyuan):
                return char.index + 1
        return None

    def reset_state(self):
        super().reset_state()
        self.check_f_on_switch = False

    def on_combat_end(self, chars):
        self.reset_fixed_rotation()
        super().on_combat_end(chars)

    # ------------------------------------------------------------------ 轴

    def do_perform(self):
        intro = self.take_intro()
        self.check_f_on_switch = False
        if self.flying():
            self.wait_down()
        anchor = self.switch_in_anchor()
        if intro:
            self.sleep(max(0.0, anchor + self.INTRO_ANIM - time.time()),
                       check_combat=False)
        self.logger.info(f'verina axis start (intro={intro})')

        if intro:
            self._loop_combo()
        else:
            self._opener_combo()

        self.leave()

    def _opener_combo(self):
        """启动轴: e -> q -> 反复按 R -> 等大招动画(0.5s) -> 跳 -> aa"""
        self.cast_resonance()
        self.sleep(self.E_TO_Q)
        self.cast_echo()
        self.sleep(self.Q_TO_R)
        self.fire_liberation()
        self.sleep(self.R_ANIM_WAIT)
        if self.flying():
            self.wait_down()
        self.task.jump(after_sleep=0.15)
        self.continues_normal_attack(self.JUMP_ATTACK_TIME)
        if not self.is_con_full():
            self.continues_normal_attack(self.EXTRA_AIR_TIME)

    def _loop_combo(self):
        """循环轴: e -> q -> 跳 -> aa"""
        self.cast_resonance()
        self.sleep(self.E_TO_Q)
        self.cast_echo()
        self.sleep(self.Q_TO_R)
        if self.flying():
            self.wait_down()
        self.task.jump(after_sleep=0.15)
        self.continues_normal_attack(self.JUMP_ATTACK_TIME)
        if not self.is_con_full():
            self.continues_normal_attack(self.EXTRA_AIR_TIME)

    # ------------------------------------------------------------------ 动作

    def cast_resonance(self):
        return self.click_resonance(send_click=False, time_out=1)[0]

    def cast_echo(self):
        was_available = self.echo_available()
        for _ in range(4):
            self.send_echo_key()
            self.record_echo_use()
            self.sleep(0.15, check_combat=False)
            if was_available and not self.echo_available():
                return True
        return False

    def fire_liberation(self):
        self.task.in_liberation = False
        start = time.time()
        deadline = self.R_TRY_MAX * self.R_TRY_INTERVAL
        while time.time() - start < deadline:
            self.task.next_frame()
            if self.liberation_available():
                waited = time.time() - start
                if self.click_liberation(wait_if_cd_ready=0.3, click_f=False):
                    self.logger.info(f'verina: liberation fired after {waited:.2f}s')
                    return True
            self.check_combat()
            self.click()
            self.sleep(self.R_TRY_INTERVAL)
        self.logger.warning(f'verina: liberation never fired within {deadline:.2f}s')
        return self.click_liberation(wait_if_cd_ready=0.5, click_f=False)

    # ------------------------------------------------------------------ 离场

    def leave(self):
        con_ok = self.require('维里奈 协奏满', self.is_con_full,
                              action=self.click, timeout=self.CON_GATE_TIMEOUT)
        if not self.direct_switch(assume_intro=con_ok):
            self.logger.warning('verina: direct switch failed, falling back to framework')
            self.switch_next_char()

    # ------------------------------------------------------------------ 小工具

    def switch_in_anchor(self):
        now = time.time()
        anchored = self.last_switch_in_time
        gap = now - anchored if anchored > 0 else -1
        if 0 <= gap <= self.SWITCH_ANCHOR_MAX:
            return anchored
        return now