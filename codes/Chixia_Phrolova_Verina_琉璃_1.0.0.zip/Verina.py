import time
from src.char.BaseChar import BaseChar, SwitchPriority


class Verina(BaseChar):
    """Verina 自动战斗
    连招方案：1=（刚需2维5奇幻）（打高血量boss可能加上15加深能刚好把boss秒了则此方案更优）伤害高需要的时间长  
             2=（放qe吃奶套和4c增益无需链度和武器）总伤害低一点耗时极短
    """
    # ==================== 连招方案总开关 ====================
    SCHEME_SWITCH: int = 2
    # =======================================================
    HEAVY_ATTACK_DURATION: float = 2
    HEAVY_ATTACK_INTERVAL: float = 8.0
    NORMAL_ATTACK_MIN_TIME: float = 0.1
    CON_FULL_STABLE_DELAY: float = 0.20

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_heavy = -1

    def do_perform(self):
        self.perform_combat()
        self.switch_next_char()

    def perform_combat(self):
        if self.SCHEME_SWITCH == 1:
            self._combat_scheme_1()
        elif self.SCHEME_SWITCH == 2:
            self._combat_scheme_2()

    def _combat_scheme_1(self):
        """方案1：完整连招"""
        self.normal_attack()
        self.sleep(0.28)
        self.normal_attack()

        self.cast_resonance()
        self.cast_echo()
        if self.is_con_full():
            self.sleep(self.CON_FULL_STABLE_DELAY)
            return
        if self.can_heavy_attack():
            self.heavy_attack(self.HEAVY_ATTACK_DURATION)
            self.last_heavy = time.time()
        start_attack = time.time()
        while True:
            self.normal_attack()
            self.sleep(0.1)
            elapsed = time.time() - start_attack
            if elapsed >= self.NORMAL_ATTACK_MIN_TIME and self.is_con_full():
                self.sleep(self.CON_FULL_STABLE_DELAY)
                break

    def _combat_scheme_2(self):
        """方案2：极简QE连招"""
        self.cast_resonance()
        self.sleep(0.01)
        self.cast_echo()

    def cast_resonance(self):
        if self.resonance_available():
            self.click_resonance(send_click=True, time_out=0)

    def cast_echo(self):
        if self.echo_available():
            self.click_echo(time_out=0)

    def can_heavy_attack(self):
        return self.time_elapsed_accounting_for_freeze(self.last_heavy) >= self.HEAVY_ATTACK_INTERVAL

    def switch_next_char(self, post_action=None, free_intro=False, target_low_con=False):
        """
        逻辑规则：
        1. 协奏已满 → 切Phrolova
        2. 协奏未满 → 切Chixia
        """
        self.is_forte_full()
        self.has_intro = False
        self.has_sub_dps_intro = False
        self._liberation_available = self.liberation_available()
        self.use_tool_box()
        target_char = None

        # 满协奏 → Phrolova；未满 → Chixia
        if self.is_con_full():
            target_name = "char_phrolova"
        else:
            target_name = "char_chixia"

        for char in self.task.chars:
            if char is not None and char.char_name == target_name:
                target_char = char
                break

        if target_char is not None:
            switch_key = str(target_char.index + 1)
            target_index = target_char.index
            start = time.time()
            first_send = True
            while time.time() - start < 6:
                in_team, current_index, count = self.task.in_team()
                if in_team and current_index == target_index:
                    for char in self.task.chars:
                        if char:
                            char.is_current_char = (char.index == current_index)
                    break
                down_time = 0.05 if first_send else 0.02
                self.task.send_key(switch_key, down_time=down_time)
                sleep_time = 0.2 if first_send else 0.12
                self.sleep(sleep_time, False)
                first_send = False
            self.switch_out(con_full=self.is_con_full())
            if post_action is not None:
                post_action()
            return

        # 找不到目标时走父类默认逻辑
        super().switch_next_char(
            post_action=post_action,
            free_intro=free_intro,
            target_low_con=target_low_con
        )

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_hiyuki'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
